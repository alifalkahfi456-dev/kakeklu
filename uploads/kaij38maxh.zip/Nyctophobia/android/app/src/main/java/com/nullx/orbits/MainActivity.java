package com.nullx.orbits;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
