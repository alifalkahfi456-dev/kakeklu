import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class TelegramRasukPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;

  const TelegramRasukPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
  });

  @override
  State<TelegramRasukPage> createState() => _TelegramRasukPageState();
}

class _TelegramRasukPageState extends State<TelegramRasukPage> {
  final _botTokenController = TextEditingController();
  final _chatIdController = TextEditingController();
  final _messageController = TextEditingController();
  
  bool _isLoading = false;
  bool _isConnected = false;
  String _botInfo = '';
  
  final Color bgDark = Colors.black;
  final Color cardBg = const Color(0xFF1A1A1A);
  final Color accentGrey = const Color(0xFF444444);
  final Color primaryWhite = Colors.white;
  final Color textGrey = Colors.grey.shade400;

  @override
  void initState() {
    super.initState();
    _loadSavedToken();
  }

  void _loadSavedToken() {
    setState(() {
      _isConnected = false;
      _botInfo = '';
    });
  }

  Future<void> _testConnection() async {
    final token = _botTokenController.text.trim();
    
    if (token.isEmpty) {
      _showAlert("Error", "Masukkan Bot Token terlebih dahulu");
      return;
    }

    setState(() => _isLoading = true);

    try {
      final response = await http.get(
        Uri.parse("https://api.telegram.org/bot$token/getMe"),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['ok'] == true) {
          setState(() {
            _isConnected = true;
            _botInfo = "✅ Bot: @${data['result']['username']}";
          });
          _showAlert("Sukses", "Bot berhasil terhubung!\nUsername: @${data['result']['username']}");
        } else {
          setState(() {
            _isConnected = false;
            _botInfo = "❌ Token tidak valid";
          });
          _showAlert("Error", "Token tidak valid");
        }
      } else {
        setState(() {
          _isConnected = false;
          _botInfo = "❌ Gagal terhubung";
        });
        _showAlert("Error", "Gagal terhubung ke server Telegram");
      }
    } catch (e) {
      setState(() {
        _isConnected = false;
        _botInfo = "❌ Error: $e";
      });
      _showAlert("Error", "Terjadi kesalahan: $e");
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _sendMessage() async {
    final token = _botTokenController.text.trim();
    final chatId = _chatIdController.text.trim();
    final message = _messageController.text.trim();

    if (token.isEmpty || chatId.isEmpty || message.isEmpty) {
      _showAlert("Error", "Token, Chat ID, dan Pesan harus diisi");
      return;
    }

    setState(() => _isLoading = true);

    try {
      final response = await http.post(
        Uri.parse("https://api.telegram.org/bot$token/sendMessage"),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'chat_id': chatId,
          'text': message,
          'parse_mode': 'HTML',
        }),
      );

      final data = jsonDecode(response.body);
      
      if (data['ok'] == true) {
        _showAlert("Berhasil", "Pesan terkirim ke $chatId");
        _messageController.clear();
      } else {
        _showAlert("Gagal", data['description'] ?? "Gagal mengirim pesan");
      }
    } catch (e) {
      _showAlert("Error", "Terjadi kesalahan: $e");
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _sendBroadcast() async {
    final token = _botTokenController.text.trim();
    final chatIds = _chatIdController.text.trim();
    final message = _messageController.text.trim();

    if (token.isEmpty || chatIds.isEmpty || message.isEmpty) {
      _showAlert("Error", "Token, Chat ID, dan Pesan harus diisi");
      return;
    }

    setState(() => _isLoading = true);

    try {
      final chatIdList = chatIds.split(',').map((id) => id.trim()).toList();
      int successCount = 0;
      int failCount = 0;

      for (var chatId in chatIdList) {
        try {
          final response = await http.post(
            Uri.parse("https://api.telegram.org/bot$token/sendMessage"),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'chat_id': chatId,
              'text': message,
              'parse_mode': 'HTML',
            }),
          );
          
          final data = jsonDecode(response.body);
          if (data['ok'] == true) {
            successCount++;
          } else {
            failCount++;
          }
        } catch (e) {
          failCount++;
        }
        await Future.delayed(Duration(milliseconds: 500));
      }

      _showAlert("Broadcast Selesai", "Berhasil: $successCount\nGagal: $failCount");
      _messageController.clear();
      
    } catch (e) {
      _showAlert("Error", "Terjadi kesalahan: $e");
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(title, style: const TextStyle(color: Colors.yellowAccent, fontFamily: 'Orbitron')),
        content: Text(msg, style: const TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK", style: TextStyle(color: Colors.yellowAccent)),
          )
        ],
      ),
    );
  }

  Widget _buildConnectionPanel() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: accentGrey.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(Icons.telegram, color: accentGrey), // Ganti Icons.bot
              SizedBox(width: 10),
              Text(
                "Koneksi Bot Telegram",
                style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 16),
              ),
            ],
          ),
          SizedBox(height: 12),
          TextField(
            controller: _botTokenController,
            style: TextStyle(color: primaryWhite),
            obscureText: true,
            decoration: InputDecoration(
              labelText: "Bot Token",
              labelStyle: TextStyle(color: accentGrey),
              hintText: "1234567890:ABCdefGHIjklMNOpqrsTUVwxyz",
              hintStyle: TextStyle(color: textGrey),
              prefixIcon: Icon(Icons.key, color: accentGrey),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(color: accentGrey),
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
          SizedBox(height: 12),
          if (_botInfo.isNotEmpty)
            Container(
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: _isConnected ? Colors.green.withOpacity(0.1) : Colors.red.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Icon(_isConnected ? Icons.check_circle : Icons.error, 
                       color: _isConnected ? Colors.green : Colors.red, size: 16),
                  SizedBox(width: 8),
                  Expanded(child: Text(_botInfo, style: TextStyle(color: primaryWhite, fontSize: 12))),
                ],
              ),
            ),
          SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _isLoading ? null : _testConnection,
              icon: _isLoading ? SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : Icon(Icons.sync),
              label: Text(_isLoading ? "MENGHUBUNGKAN..." : "TEST KONEKSI"),
              style: ElevatedButton.styleFrom(
                backgroundColor: accentGrey,
                padding: EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessagePanel() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: accentGrey.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(Icons.send, color: accentGrey),
              SizedBox(width: 10),
              Text(
                "Kirim Pesan",
                style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 16),
              ),
            ],
          ),
          SizedBox(height: 12),
          TextField(
            controller: _chatIdController,
            style: TextStyle(color: primaryWhite),
            decoration: InputDecoration(
              labelText: "Chat ID (pisah dengan koma untuk broadcast)",
              labelStyle: TextStyle(color: accentGrey),
              hintText: "-100123456789 atau -1001,-1002",
              hintStyle: TextStyle(color: textGrey),
              prefixIcon: Icon(Icons.group, color: accentGrey),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(color: accentGrey),
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
          SizedBox(height: 12),
          TextField(
            controller: _messageController,
            style: TextStyle(color: primaryWhite),
            maxLines: 5,
            decoration: InputDecoration(
              labelText: "Pesan (support HTML)",
              labelStyle: TextStyle(color: accentGrey),
              hintText: "<b>Teks tebal</b>\n<i>Teks miring</i>\n<a href='https://...'>Link</a>",
              hintStyle: TextStyle(color: textGrey),
              prefixIcon: Icon(Icons.message, color: accentGrey),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(color: accentGrey),
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
          SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _isLoading ? null : _sendMessage,
                  icon: _isLoading ? SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : Icon(Icons.send),
                  label: Text("KIRIM"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    padding: EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _isLoading ? null : _sendBroadcast,
                  icon: _isLoading ? SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : Icon(Icons.broadcast_on_home),
                  label: Text("BROADCAST"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    padding: EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Hanya untuk owner dan vip
    if (!["owner", "vip"].contains(widget.userRole.toLowerCase())) {
      return Scaffold(
        backgroundColor: bgDark,
        appBar: AppBar(
          title: const Text("Rasuk Bot Telegram", style: TextStyle(fontFamily: 'Orbitron')),
          backgroundColor: Colors.transparent,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.lock, color: Colors.red, size: 80),
              SizedBox(height: 20),
              Text(
                "Akses Ditolak",
                style: TextStyle(color: Colors.red, fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Text(
                "Fitur ini hanya untuk Owner dan VIP",
                style: TextStyle(color: Colors.white54),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        title: const Text(
          "Rasuk Bot Telegram",
          style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: accentGrey),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              _buildConnectionPanel(),
              const SizedBox(height: 16),
              _buildMessagePanel(),
              const SizedBox(height: 16),
              Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: cardBg,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: accentGrey.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info_outline, color: accentGrey, size: 16),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        "Cara dapat Chat ID: Kirim pesan ke bot, lalu akses https://api.telegram.org/bot<TOKEN>/getUpdates",
                        style: TextStyle(color: textGrey, fontSize: 11),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}