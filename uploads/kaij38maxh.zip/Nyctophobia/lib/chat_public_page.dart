import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:http/http.dart' as http;
import 'services/api_config_service.dart';

class ChatPublicPage extends StatefulWidget {
  final String username;
  final String role;
  final String apiKey;

  const ChatPublicPage({
    super.key,
    required this.username,
    this.role = 'user',
    required this.apiKey,
  });

  @override
  State<ChatPublicPage> createState() => _ChatPublicPageState();
}

class _ChatPublicPageState extends State<ChatPublicPage> {
  String apiBaseUrl = "";
  final TextEditingController messageController = TextEditingController();
  final ScrollController scrollController = ScrollController();
  final FocusNode messageFocusNode = FocusNode();
  
  IO.Socket? _socket;
  List<Map<String, dynamic>> messages = [];
  List<Map<String, dynamic>> onlineUsersDetailed = [];
  bool isConnected = false;
  bool isSending = false;
  bool isLoading = false;
  Timer? _typingTimer;
  Set<String> typingUsers = {};
  int totalMessages = 0;
  int onlineCount = 0;
  
  int _reconnectAttempts = 0;
  final int _maxReconnectAttempts = 5;
  Timer? _reconnectTimer;

  @override
  void initState() {
    super.initState();
    _initializeAndConnect();
  }

  Future<void> _initializeAndConnect() async {
    apiBaseUrl = await ApiConfigService().getBaseUrl();
    _initSocket();
    _loadInitialData();
  }

  Future<void> _loadInitialData() async {
    setState(() => isLoading = true);
    try {
      await Future.wait([
        _loadMessages(),
        _fetchOnlineUsers(),
      ]);
    } catch (e) {
      print('Error loading initial data: $e');
      _showErrorDialog('Failed to load initial data: $e');
    }
    setState(() => isLoading = false);
  }

  void _initSocket() {
    try {
      _socket = IO.io(apiBaseUrl, <String, dynamic>{
        'transports': ['websocket', 'polling'],
        'autoConnect': true,
        'forceNew': true,
        'reconnection': true,
        'reconnectionAttempts': 10,
        'reconnectionDelay': 1000,
        'reconnectionDelayMax': 5000,
        'timeout': 20000,
        'auth': {
          'username': widget.username,
          'token': widget.apiKey,
        },
        'query': {
          'username': widget.username,
          'role': widget.role,
        },
      });

      _setupSocketListeners();
      _socket?.connect();
      
    } catch (e) {
      print('Socket initialization error: $e');
      _scheduleReconnect();
    }
  }

  void _setupSocketListeners() {
    if (_socket == null) return;

    _socket?.onConnect((_) {
      print('✅ Connected to public chat as ${widget.username}');
      setState(() {
        isConnected = true;
        _reconnectAttempts = 0;
      });
      _joinPublicChat();
      _socket?.emit('get_online_users');
    });

    _socket?.onConnectError((error) {
      print('Connection error: $error');
      setState(() => isConnected = false);
      _scheduleReconnect();
    });

    _socket?.onDisconnect((reason) {
      print('🔌 Disconnected: $reason');
      setState(() => isConnected = false);
      _scheduleReconnect();
    });

    _socket?.onError((error) {
      print('⚠️ Socket error: $error');
    });

    _socket?.on('new_public_message', (data) {
      print('📨 New message received');
      if (mounted && data != null) {
        _handleNewMessage(data);
      }
    });

    _socket?.on('public_message_sent', (data) {
      if (mounted && data != null) {
        if (data['confirmed'] == true) {
          print('✅ Message sent confirmed');
          setState(() => isSending = false);
          messageFocusNode.requestFocus();
          messageController.clear();
        }
      }
    });

    _socket?.on('message_edited', (data) {
      if (mounted && data != null) {
        _updateEditedMessage(data);
      }
    });

    _socket?.on('message_deleted', (data) {
      if (mounted && data != null) {
        _removeDeletedMessage(data);
      }
    });

    _socket?.on('message_reaction', (data) {
      if (mounted && data != null) {
        _updateMessageReactions(data);
      }
    });

    _socket?.on('online_users_list', (data) {
      if (mounted && data != null) {
        _updateOnlineUsersList(data);
      }
    });

    _socket?.on('online_users_update', (data) {
      if (mounted && data != null) {
        _updateOnlineUsersList(data);
      }
    });

    _socket?.on('user_typing', (data) {
      if (mounted && data != null) {
        _handleTypingIndicator(data);
      }
    });

    _socket?.on('user_stopped_typing', (data) {
      if (mounted && data != null) {
        _handleStoppedTyping(data);
      }
    });

    _socket?.on('user_muted', (data) {
      _showNotification('User ${data['username']} has been muted');
    });

    _socket?.on('user_unmuted', (data) {
      _showNotification('User ${data['username']} has been unmuted');
    });

    _socket?.on('user_banned', (data) {
      _showNotification('User ${data['username']} has been banned');
    });

    _socket?.on('user_joined_group', (data) {
      _showNotification('${data['username']} joined the chat');
    });

    _socket?.on('user_left_group', (data) {
      _showNotification('${data['username']} left the chat');
    });

    _socket?.on('joined_public_chat', (data) {
      print('🎯 Joined public chat room');
    });

    _socket?.on('left_public_chat', (data) {
      print('👋 Left public chat room');
    });

    _socket?.on('error', (data) {
      if (mounted && data != null) {
        final errorMsg = data is Map ? data['message'] ?? 'An error occurred' : data.toString();
        _showErrorDialog(errorMsg);
        if (data is Map && data['code'] == 'MUTED') {
          _showMutedDialog(Map<String, dynamic>.from(data));
        }
      }
    });

    _socket?.on('pong', (data) {
      // Connection is healthy
    });
  }

  void _scheduleReconnect() {
    if (_reconnectTimer != null || _reconnectAttempts >= _maxReconnectAttempts) return;
    
    _reconnectAttempts++;
    final delay = Duration(seconds: _reconnectAttempts * 2);
    
    print('🔄 Scheduling reconnect in ${delay.inSeconds}s (attempt $_reconnectAttempts/$_maxReconnectAttempts)');
    
    _reconnectTimer = Timer(delay, () {
      _reconnectTimer = null;
      if (mounted && !isConnected) {
        print('🔄 Attempting to reconnect...');
        _socket?.connect();
      }
    });
  }

  void _handleNewMessage(dynamic data) {
    final Map<String, dynamic> newMessage = {};
    if (data is Map) {
      data.forEach((key, value) {
        newMessage[key.toString()] = value;
      });
    }
    
    final existingIndex = messages.indexWhere((msg) => msg['id'] == newMessage['id']);
    
    setState(() {
      if (existingIndex >= 0) {
        messages[existingIndex] = newMessage;
      } else {
        messages.add(newMessage);
      }
      
      messages.sort((a, b) {
        try {
          final aTime = DateTime.parse(a['timestamp'] ?? a['createdAt'] ?? DateTime.now().toIso8601String());
          final bTime = DateTime.parse(b['timestamp'] ?? b['createdAt'] ?? DateTime.now().toIso8601String());
          return aTime.compareTo(bTime);
        } catch (e) {
          return 0;
        }
      });
    });
    
    _scrollToBottom();
  }

  void _updateEditedMessage(dynamic data) {
    final Map<String, dynamic> editedMessage = {};
    if (data is Map) {
      data.forEach((key, value) {
        editedMessage[key.toString()] = value;
      });
    }
    
    final messageId = editedMessage['id'];
    
    setState(() {
      final index = messages.indexWhere((msg) => msg['id'] == messageId);
      if (index >= 0) {
        messages[index] = editedMessage;
      }
    });
  }

  void _removeDeletedMessage(dynamic data) {
    final messageId = data['id'];
    final deletedBy = data['deletedBy'];
    
    setState(() {
      messages.removeWhere((msg) => msg['id'] == messageId);
    });
    
    if (deletedBy != widget.username && mounted) {
      _showNotification('A message was deleted by $deletedBy');
    }
  }

  void _updateMessageReactions(dynamic data) {
    final messageId = data['id'];
    final Map<String, dynamic> reactions = {};
    if (data['reactions'] is Map) {
      (data['reactions'] as Map).forEach((key, value) {
        reactions[key.toString()] = value;
      });
    }
    
    setState(() {
      final index = messages.indexWhere((msg) => msg['id'] == messageId);
      if (index >= 0) {
        messages[index]['reactions'] = reactions;
      }
    });
  }

  void _updateOnlineUsersList(dynamic data) {
    if (mounted && data != null) {
      final List<String> users = [];
      if (data['users'] is List) {
        for (var user in data['users']) {
          users.add(user.toString());
        }
      }
      
      setState(() {
        onlineCount = data['count'] ?? users.length;
        if (data['detailedUsers'] != null && data['detailedUsers'] is List) {
          onlineUsersDetailed = [];
          for (var user in data['detailedUsers']) {
            if (user is Map) {
              final Map<String, dynamic> convertedUser = {};
              user.forEach((key, value) {
                convertedUser[key.toString()] = value;
              });
              onlineUsersDetailed.add(convertedUser);
            }
          }
        } else {
          onlineUsersDetailed = users.map((username) => {
            'username': username,
            'role': username == 'admin' ? 'admin' : 'user',
            'isOnline': true,
          }).toList();
        }
      });
    }
  }

  void _handleTypingIndicator(dynamic data) {
    if (mounted && data != null) {
      final typingUsername = data['username'] as String?;
      if (typingUsername != null && typingUsername != widget.username) {
        setState(() => typingUsers.add(typingUsername));
        
        Future.delayed(const Duration(seconds: 3), () {
          if (mounted) {
            setState(() => typingUsers.remove(typingUsername));
          }
        });
      }
    }
  }

  void _handleStoppedTyping(dynamic data) {
    if (mounted && data != null) {
      final typingUsername = data['username'] as String?;
      if (typingUsername != null) {
        setState(() => typingUsers.remove(typingUsername));
      }
    }
  }

  void _joinPublicChat() {
    _socket?.emit('join_public_chat', {
      'username': widget.username,
      'role': widget.role,
    });
  }

  Future<void> _loadMessages() async {
    try {
      final response = await http.get(
        Uri.parse("$apiBaseUrl/api/chatpublic/messages?limit=200"),
        headers: {
          'Accept': 'application/json',
          'Authorization': 'Bearer ${widget.apiKey}',
        },
      ).timeout(const Duration(seconds: 15));
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          final List<dynamic> messagesData = data['messages'] ?? [];
          final List<Map<String, dynamic>> loadedMessages = [];
          
          for (var msg in messagesData) {
            if (msg is Map) {
              final Map<String, dynamic> convertedMsg = {};
              msg.forEach((key, value) {
                convertedMsg[key.toString()] = value;
              });
              loadedMessages.add(convertedMsg);
            }
          }
          
          setState(() {
            messages = loadedMessages;
            totalMessages = data['pagination']?['total'] ?? messages.length;
            messages.sort((a, b) {
              try {
                final aTime = DateTime.parse(a['timestamp'] ?? a['createdAt'] ?? '');
                final bTime = DateTime.parse(b['timestamp'] ?? b['createdAt'] ?? '');
                return aTime.compareTo(bTime);
              } catch (e) {
                return 0;
              }
            });
          });
          _scrollToBottom();
        }
      } else {
        print('Failed to load messages: ${response.statusCode}');
      }
    } catch (e) {
      print('Error loading messages: $e');
      _showErrorDialog('Failed to load messages: ${e.toString()}');
    }
  }

  Future<void> _fetchOnlineUsers() async {
    try {
      final response = await http.get(
        Uri.parse("$apiBaseUrl/api/chatpublic/users"),
        headers: {
          'Accept': 'application/json',
          'Authorization': 'Bearer ${widget.apiKey}',
        },
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          final List<dynamic> usersData = data['users'] ?? [];
          final List<Map<String, dynamic>> loadedUsers = [];
          
          for (var user in usersData) {
            if (user is Map) {
              final Map<String, dynamic> convertedUser = {};
              user.forEach((key, value) {
                convertedUser[key.toString()] = value;
              });
              loadedUsers.add(convertedUser);
            }
          }
          
          setState(() {
            onlineUsersDetailed = loadedUsers;
            onlineCount = onlineUsersDetailed.where((u) => u['isOnline'] == true).length;
          });
        }
      }
    } catch (e) {
      print('Error fetching online users: $e');
    }
  }

  Future<void> _sendMessage() async {
    final message = messageController.text.trim();
    if (message.isEmpty || isSending || !isConnected) return;

    setState(() => isSending = true);

    _socket?.emit('public_message', {
      'message': message,
      'avatar': '',
      'role': widget.role,
      'username': widget.username,
    });

    _socket?.emit('public_stop_typing');

    try {
      final response = await http.post(
        Uri.parse("$apiBaseUrl/api/chatpublic/message"),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${widget.apiKey}',
        },
        body: jsonEncode({
          'username': widget.username,
          'message': message,
          'role': widget.role,
          'avatar': '',
        }),
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode != 200 && response.statusCode != 201) {
        print('HTTP send failed: ${response.statusCode}');
        setState(() => isSending = false);
        _showErrorDialog('Failed to send message. Please try again.');
        return;
      }
    } catch (e) {
      print('Error saving message via HTTP: $e');
      setState(() => isSending = false);
      _showErrorDialog('Network error. Please check your connection.');
      return;
    }

    setState(() => isSending = false);
  }

  Future<void> _editMessage(String messageId, String newMessage) async {
    if (newMessage.trim().isEmpty) return;
    
    try {
      final response = await http.put(
        Uri.parse("$apiBaseUrl/api/chatpublic/message/$messageId"),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${widget.apiKey}',
        },
        body: jsonEncode({
          'username': widget.username,
          'message': newMessage.trim(),
        }),
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode != 200) {
        _showErrorDialog('Failed to edit message');
      }
    } catch (e) {
      print('Error editing message: $e');
      _showErrorDialog('Failed to edit message: ${e.toString()}');
    }
  }

  Future<void> _deleteMessage(String messageId) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Message'),
        content: const Text('Are you sure you want to delete this message?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    
    if (confirm != true) return;
    
    try {
      final response = await http.delete(
        Uri.parse("$apiBaseUrl/api/chatpublic/message/$messageId?username=${Uri.encodeComponent(widget.username)}"),
        headers: {
          'Authorization': 'Bearer ${widget.apiKey}',
        },
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode != 200) {
        _showErrorDialog('Failed to delete message');
      }
    } catch (e) {
      print('Error deleting message: $e');
      _showErrorDialog('Failed to delete message: ${e.toString()}');
    }
  }

  Future<void> _muteUser(String username) async {
    try {
      final response = await http.post(
        Uri.parse("$apiBaseUrl/api/chatpublic/mute"),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${widget.apiKey}',
        },
        body: jsonEncode({
          'username': username,
          'mutedBy': widget.username,
          'duration': 3600,
        }),
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode == 200) {
        _showNotification('User $username has been muted');
      } else {
        _showErrorDialog('Failed to mute user');
      }
    } catch (e) {
      print('Error muting user: $e');
      _showErrorDialog('Failed to mute user: ${e.toString()}');
    }
  }

  void _onTyping(String text) {
    if (text.isNotEmpty && isConnected) {
      _socket?.emit('public_typing', {'isTyping': true, 'username': widget.username});
      
      if (_typingTimer != null) {
        _typingTimer!.cancel();
      }
      _typingTimer = Timer(const Duration(seconds: 2), () {
        _socket?.emit('public_stop_typing', {'username': widget.username});
      });
    } else if (isConnected) {
      _socket?.emit('public_stop_typing', {'username': widget.username});
      _typingTimer?.cancel();
    }
  }

  void _addReaction(String messageId, String emoji) {
    if (!isConnected) {
      _showNotification('Not connected to chat server');
      return;
    }
    _socket?.emit('add_reaction', {
      'messageId': messageId,
      'emoji': emoji,
      'username': widget.username,
    });
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scrollController.hasClients && messages.isNotEmpty) {
        scrollController.animateTo(
          scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Color _getRoleColor(String? role) {
    switch ((role ?? '').toLowerCase()) {
      case 'admin': return const Color(0xFFFF4444);
      case 'owner': return const Color(0xFFFFA500);
      case 'moderator': return const Color(0xFF4CAF50);
      case 'vip': return const Color(0xFF9C27B0);
      default: return const Color(0xFF2196F3);
    }
  }

  String _getRoleBadge(String? role) {
    switch ((role ?? '').toLowerCase()) {
      case 'admin': return '🛡️';
      case 'owner': return '👑';
      case 'moderator': return '⚖️';
      case 'vip': return '⭐';
      default: return '👤';
    }
  }

  void _showNotification(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _showErrorDialog(String message) {
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _showMutedDialog(Map<String, dynamic> data) {
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('You are muted'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Reason: ${data['reason'] ?? 'No reason provided'}'),
            if (data['mutedUntil'] != null) ...[
              const SizedBox(height: 8),
              Text('Muted until: ${_formatDateTime(data['mutedUntil'])}'),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _showUserProfile(BuildContext context, Map<String, dynamic> user) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: _getRoleColor(user['role']),
                  child: Text(
                    (user['username']?.toString() ?? 'U')[0].toUpperCase(),
                    style: const TextStyle(color: Colors.white, fontSize: 24),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        user['username'] ?? 'Unknown',
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        user['role']?.toUpperCase() ?? 'USER',
                        style: TextStyle(
                          color: _getRoleColor(user['role']),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      if (user['isOnline'] == true)
                        const Row(
                          children: [
                            Icon(Icons.circle, color: Colors.green, size: 10),
                            SizedBox(width: 4),
                            Text('Online', style: TextStyle(color: Colors.green, fontSize: 12)),
                          ],
                        ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            if (user['lastSeen'] != null) ...[
              Text('Last seen: ${_formatDateTime(user['lastSeen'])}'),
              const SizedBox(height: 8),
            ],
            if (user['messageCount'] != null) ...[
              Text('Messages: ${user['messageCount']}'),
              const SizedBox(height: 8),
            ],
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                if (widget.role == 'admin' || widget.role == 'owner') ...[
                  ElevatedButton.icon(
                    onPressed: () {
                      Navigator.pop(context);
                      _muteUser(user['username']);
                    },
                    icon: const Icon(Icons.block, size: 18),
                    label: const Text('Mute'),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                  ),
                  ElevatedButton.icon(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(Icons.gavel, size: 18),
                    label: const Text('Ban'),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                  ),
                ],
                ElevatedButton.icon(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close, size: 18),
                  label: const Text('Close'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  String _formatDateTime(String? timestamp) {
    if (timestamp == null) return 'Unknown';
    try {
      final date = DateTime.parse(timestamp);
      final now = DateTime.now();
      final diff = now.difference(date);
      
      if (diff.inSeconds < 60) return 'Just now';
      if (diff.inMinutes < 60) return '${diff.inMinutes} minutes ago';
      if (diff.inHours < 24) return '${diff.inHours} hours ago';
      if (diff.inDays < 7) return '${diff.inDays} days ago';
      return '${date.day}/${date.month}/${date.year}';
    } catch (e) {
      return timestamp;
    }
  }

  String _formatTime(String timestamp) {
    try {
      final date = DateTime.parse(timestamp);
      final now = DateTime.now();
      final diff = now.difference(date);
      
      if (diff.inSeconds < 60) return 'Just now';
      if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
      if (diff.inHours < 24) return '${diff.inHours}h ago';
      if (diff.inDays < 7) return '${diff.inDays}d ago';
      return '${date.day}/${date.month} ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
    } catch (e) {
      return '';
    }
  }

  @override
  void dispose() {
    _typingTimer?.cancel();
    _reconnectTimer?.cancel();
    _socket?.emit('public_stop_typing', {'username': widget.username});
    _socket?.disconnect();
    _socket?.dispose();
    messageController.dispose();
    scrollController.dispose();
    messageFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFFB71C1C),
        title: Row(
          children: [
            const Icon(Icons.public),
            const SizedBox(width: 8),
            const Text('Public Chat'),
            const SizedBox(width: 8),
            Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                color: isConnected ? Colors.green : Colors.red,
                shape: BoxShape.circle,
              ),
            ),
            if (!isConnected) ...[
              const SizedBox(width: 8),
              const SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: Colors.white,
                ),
              ),
            ],
          ],
        ),
        actions: [
          GestureDetector(
            onTap: () {
              _showOnlineUsersDialog();
            },
            child: Container(
              margin: const EdgeInsets.only(right: 12),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.3),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                children: [
                  const Icon(Icons.people, size: 18),
                  const SizedBox(width: 4),
                  Text('$onlineCount'),
                ],
              ),
            ),
          ),
          PopupMenuButton<int>(
            icon: const Icon(Icons.more_vert),
            onSelected: (value) {
              if (value == 0) {
                _fetchOnlineUsers();
              } else if (value == 1) {
                _loadMessages();
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 0,
                child: ListTile(
                  leading: Icon(Icons.refresh, size: 20),
                  title: Text('Refresh Users'),
                  dense: true,
                ),
              ),
              const PopupMenuItem(
                value: 1,
                child: ListTile(
                  leading: Icon(Icons.refresh, size: 20),
                  title: Text('Refresh Messages'),
                  dense: true,
                ),
              ),
            ],
          ),
        ],
      ),
      body: isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFFB71C1C)),
            )
          : Column(
              children: [
                if (!isConnected)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    color: Colors.red.withOpacity(0.1),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Disconnected',
                          style: TextStyle(color: Colors.red[300], fontSize: 12),
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() => _reconnectAttempts = 0);
                            _socket?.connect();
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.blue,
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: const Text(
                              'Reconnect',
                              style: TextStyle(color: Colors.white, fontSize: 12),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                if (typingUsers.isNotEmpty)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    color: Colors.grey[900],
                    child: Row(
                      children: [
                        SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.blue[300],
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            typingUsers.length == 1
                                ? '${typingUsers.first} is typing...'
                                : '${typingUsers.length} users are typing...',
                            style: TextStyle(color: Colors.grey[400], fontSize: 12),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ),

                Expanded(
                  child: messages.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.chat_bubble_outline,
                                  size: 60, color: Colors.grey[600]),
                              const SizedBox(height: 16),
                              Text('No messages yet',
                                  style: TextStyle(color: Colors.grey[500], fontSize: 18)),
                              const SizedBox(height: 8),
                              Text('Be the first to chat!',
                                  style: TextStyle(color: Colors.grey[400])),
                            ],
                          ),
                        )
                      : ListView.builder(
                          controller: scrollController,
                          padding: const EdgeInsets.all(12),
                          itemCount: messages.length,
                          itemBuilder: (context, index) {
                            final msg = messages[index];
                            final isMe = msg['username'] == widget.username;
                            final role = msg['role'] as String? ?? 'user';
                            final messageId = msg['id'] as String?;
                            final isEdited = msg['edited'] == true;

                            return _buildMessageCard(msg, isMe, role, messageId, isEdited);
                          },
                        ),
                ),

                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1E1E1E),
                    border: Border(top: BorderSide(color: Colors.grey[800]!)),
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 18,
                        backgroundColor: _getRoleColor(widget.role),
                        child: Text(
                          _getRoleBadge(widget.role),
                          style: const TextStyle(fontSize: 16),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.grey[900],
                            borderRadius: BorderRadius.circular(24),
                          ),
                          child: TextField(
                            controller: messageController,
                            focusNode: messageFocusNode,
                            style: const TextStyle(color: Colors.white),
                            maxLines: null,
                            textCapitalization: TextCapitalization.sentences,
                            decoration: InputDecoration(
                              hintText: isConnected ? "Type a message..." : "Connecting...",
                              hintStyle: TextStyle(color: Colors.grey[500]),
                              border: InputBorder.none,
                              contentPadding:
                                  const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                            ),
                            onChanged: _onTyping,
                            onSubmitted: (_) => _sendMessage(),
                            enabled: isConnected && !isSending,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        child: IconButton(
                          icon: isSending
                              ? const SizedBox(
                                  width: 24,
                                  height: 24,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                )
                              : Icon(Icons.send,
                                  color: isConnected
                                      ? const Color(0xFFE53935)
                                      : Colors.grey),
                          onPressed: isSending || !isConnected ? null : _sendMessage,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }

  Widget _buildMessageCard(Map<String, dynamic> msg, bool isMe, String role, String? messageId, bool isEdited) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      child: Row(
        mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!isMe) ...[
            GestureDetector(
              onTap: () {
                _showUserProfile(context, {
                  'username': msg['username'],
                  'role': role,
                  'isOnline': onlineUsersDetailed.any((u) => u['username'] == msg['username'] && u['isOnline'] == true),
                });
              },
              child: CircleAvatar(
                radius: 16,
                backgroundColor: _getRoleColor(role),
                child: Text(
                  _getRoleBadge(role),
                  style: const TextStyle(fontSize: 12),
                ),
              ),
            ),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Container(
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * 0.75,
              ),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: isMe ? const Color(0xFF2D1B1B) : const Color(0xFF2B2B2B),
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(12),
                  topRight: const Radius.circular(12),
                  bottomLeft: Radius.circular(isMe ? 12 : 4),
                  bottomRight: Radius.circular(isMe ? 4 : 12),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (!isMe)
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            _showUserProfile(context, {
                              'username': msg['username'],
                              'role': role,
                              'isOnline': onlineUsersDetailed.any((u) => u['username'] == msg['username'] && u['isOnline'] == true),
                            });
                          },
                          child: Text(
                            msg['username'] ?? 'Unknown',
                            style: TextStyle(
                              color: _getRoleColor(role),
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                            ),
                          ),
                        ),
                        if (role != 'user') ...[
                          const SizedBox(width: 4),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                            decoration: BoxDecoration(
                              color: _getRoleColor(role),
                              borderRadius: BorderRadius.circular(3),
                            ),
                            child: Text(
                              role.toUpperCase(),
                              style: const TextStyle(color: Colors.white, fontSize: 8),
                            ),
                          ),
                        ],
                        const SizedBox(width: 4),
                        Text(
                          _formatTime(msg['timestamp'] ?? ''),
                          style: TextStyle(color: Colors.grey[500], fontSize: 9),
                        ),
                      ],
                    ),
                  if (isMe)
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          _formatTime(msg['timestamp'] ?? ''),
                          style: TextStyle(color: Colors.grey[500], fontSize: 9),
                        ),
                        const SizedBox(width: 4),
                        if (isEdited)
                          Text('(edited)', style: TextStyle(color: Colors.grey[500], fontSize: 9)),
                      ],
                    ),
                  const SizedBox(height: 4),
                  Text(
                    msg['message'] ?? '',
                    style: const TextStyle(color: Colors.white, fontSize: 14),
                  ),
                  const SizedBox(height: 4),
                  if (msg['reactions'] != null && (msg['reactions'] as Map).isNotEmpty)
                    _buildReactions(msg['reactions'], messageId),
                ],
              ),
            ),
          ),
          if (isMe) ...[
            const SizedBox(width: 8),
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert, size: 18, color: Colors.grey),
              onSelected: (value) async {
                if (value == 'edit') {
                  final TextEditingController editController = TextEditingController(text: msg['message']);
                  final newMessage = await showDialog<String>(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: const Text('Edit Message'),
                      content: TextField(
                        controller: editController,
                        autofocus: true,
                        maxLines: 3,
                        decoration: const InputDecoration(
                          hintText: 'Edit your message...',
                        ),
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('Cancel'),
                        ),
                        TextButton(
                          onPressed: () => Navigator.pop(context, editController.text),
                          child: const Text('Save'),
                        ),
                      ],
                    ),
                  );
                  if (newMessage != null && newMessage.isNotEmpty && messageId != null) {
                    _editMessage(messageId, newMessage);
                  }
                } else if (value == 'delete' && messageId != null) {
                  _deleteMessage(messageId);
                }
              },
              itemBuilder: (context) => [
                const PopupMenuItem(
                  value: 'edit',
                  child: Row(
                    children: [
                      Icon(Icons.edit, size: 18),
                      SizedBox(width: 8),
                      Text('Edit'),
                    ],
                  ),
                ),
                const PopupMenuItem(
                  value: 'delete',
                  child: Row(
                    children: [
                      Icon(Icons.delete, size: 18, color: Colors.red),
                      SizedBox(width: 8),
                      Text('Delete', style: TextStyle(color: Colors.red)),
                    ],
                  ),
                ),
              ],
            ),
          ],
          if (!isMe && (widget.role == 'admin' || widget.role == 'owner'))
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert, size: 18, color: Colors.grey),
              onSelected: (value) {
                if (value == 'delete' && messageId != null) {
                  _deleteMessage(messageId);
                } else if (value == 'mute') {
                  _muteUser(msg['username']);
                }
              },
              itemBuilder: (context) => [
                const PopupMenuItem(
                  value: 'mute',
                  child: Row(
                    children: [
                      Icon(Icons.block, size: 18),
                      SizedBox(width: 8),
                      Text('Mute User'),
                    ],
                  ),
                ),
                const PopupMenuItem(
                  value: 'delete',
                  child: Row(
                    children: [
                      Icon(Icons.delete, size: 18, color: Colors.red),
                      SizedBox(width: 8),
                      Text('Delete Message', style: TextStyle(color: Colors.red)),
                    ],
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }

  Widget _buildReactions(dynamic reactions, String? messageId) {
    if (reactions == null) return const SizedBox.shrink();
    
    Map<String, dynamic> reactionsMap = {};
    if (reactions is Map) {
      reactions.forEach((key, value) {
        reactionsMap[key.toString()] = value;
      });
    }
    
    if (reactionsMap.isEmpty) return const SizedBox.shrink();

    return Wrap(
      spacing: 4,
      runSpacing: 4,
      children: reactionsMap.entries.map((entry) {
        final emoji = entry.key;
        final users = entry.value is List ? List<String>.from(entry.value) : [];
        final hasReacted = users.contains(widget.username);

        return GestureDetector(
          onTap: () {
            if (messageId != null) {
              _addReaction(messageId, emoji);
            }
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: hasReacted
                  ? Colors.blue.withOpacity(0.2)
                  : Colors.grey.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: hasReacted ? Colors.blue : Colors.transparent,
                width: 0.5,
              ),
            ),
            child: Text(
              '$emoji ${users.length}',
              style: TextStyle(
                fontSize: 10,
                color: hasReacted ? Colors.blue : Colors.grey[400],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  void _showOnlineUsersDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            const Icon(Icons.people, color: Colors.blue),
            const SizedBox(width: 8),
            Text('Online Users ($onlineCount)'),
          ],
        ),
        content: Container(
          width: double.maxFinite,
          constraints: const BoxConstraints(maxHeight: 400),
          child: onlineUsersDetailed.isEmpty
              ? const Center(child: Text('No users online'))
              : ListView.builder(
                  shrinkWrap: true,
                  itemCount: onlineUsersDetailed.length,
                  itemBuilder: (context, index) {
                    final user = onlineUsersDetailed[index];
                    final isOnline = user['isOnline'] == true;
                    if (!isOnline) return const SizedBox.shrink();
                    
                    return ListTile(
                      leading: CircleAvatar(
                        radius: 20,
                        backgroundColor: _getRoleColor(user['role']),
                        child: Text(
                          _getRoleBadge(user['role']),
                          style: const TextStyle(fontSize: 14),
                        ),
                      ),
                      title: Text(
                        user['username'] ?? 'Unknown',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(user['role']?.toUpperCase() ?? 'USER'),
                      trailing: Container(
                        width: 8,
                        height: 8,
                        decoration: const BoxDecoration(
                          color: Colors.green,
                          shape: BoxShape.circle,
                        ),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                        _showUserProfile(context, user);
                      },
                    );
                  },
                ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
}