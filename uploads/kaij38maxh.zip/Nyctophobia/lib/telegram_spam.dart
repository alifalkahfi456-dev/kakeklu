import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class TelegramSpamPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;

  const TelegramSpamPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
  });

  @override
  State<TelegramSpamPage> createState() => _TelegramSpamPageState();
}

class _TelegramSpamPageState extends State<TelegramSpamPage> {
  final _targetUsernameController = TextEditingController();
  final _messageController = TextEditingController();
  final _qtyController = TextEditingController(text: "10");
  final _delayController = TextEditingController(text: "500");
  
  bool _isSpamming = false;
  int _sentCount = 0;
  int _failedCount = 0;
  
  // Daftar bot token yang tersedia (bisa ditambah)
  final List<String> _botTokens = [
    "7123456789:AAHdqTcvLxUwV3yLxUwV3y",
    "8989898989:BBHdqTcvLxUwV3yLxUwV3y",
  ];
  
  String _selectedBotToken = "";
  
  final Color bgDark = Colors.black;
  final Color cardBg = const Color(0xFF1A1A1A);
  final Color accentGrey = const Color(0xFF444444);
  final Color primaryWhite = Colors.white;
  final Color textGrey = Colors.grey.shade400;

  @override
  void initState() {
    super.initState();
    if (_botTokens.isNotEmpty) {
      _selectedBotToken = _botTokens[0];
    }
  }

  Future<void> _sendSpam() async {
    final targetUsername = _targetUsernameController.text.trim().replaceAll('@', '');
    final message = _messageController.text.trim();
    final qty = int.tryParse(_qtyController.text) ?? 10;
    final delay = int.tryParse(_delayController.text) ?? 500;

    if (_selectedBotToken.isEmpty) {
      _showAlert("Error", "Pilih bot token terlebih dahulu");
      return;
    }

    if (targetUsername.isEmpty) {
      _showAlert("Error", "Masukkan username target");
      return;
    }

    if (message.isEmpty) {
      _showAlert("Error", "Masukkan pesan spam");
      return;
    }

    if (qty > 100) {
      _showAlert("Error", "Maksimal 100 pesan per spam");
      return;
    }

    setState(() {
      _isSpamming = true;
      _sentCount = 0;
      _failedCount = 0;
    });

    // Dapatkan chat_id dari username
    String? chatId = await _getChatIdByUsername(targetUsername);
    
    if (chatId == null) {
      _showAlert("Error", "Username @$targetUsername belum pernah chat dengan bot ini.\n\nTarget harus chat dulu ke bot minimal 1x.");
      setState(() => _isSpamming = false);
      return;
    }

    // Kirim spam
    for (int i = 0; i < qty; i++) {
      if (!_isSpamming) break;
      
      final success = await _sendMessage(chatId, message);
      if (success) {
        setState(() => _sentCount++);
      } else {
        setState(() => _failedCount++);
      }
      
      if (i < qty - 1) {
        await Future.delayed(Duration(milliseconds: delay));
      }
    }

    setState(() => _isSpamming = false);
    
    _showAlert("Spam Selesai", 
      "✅ Berhasil: $_sentCount pesan\n"
      "❌ Gagal: $_failedCount pesan\n"
      "🎯 Target: @$targetUsername"
    );
  }

  Future<String?> _getChatIdByUsername(String username) async {
    try {
      final response = await http.get(
        Uri.parse("https://api.telegram.org/bot$_selectedBotToken/getUpdates"),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['ok'] == true && data['result'] != null) {
          for (var update in data['result']) {
            if (update['message'] != null) {
              final fromUser = update['message']['from'];
              if (fromUser != null && fromUser['username'] == username) {
                return update['message']['chat']['id'].toString();
              }
            }
          }
        }
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  Future<bool> _sendMessage(String chatId, String message) async {
    try {
      final response = await http.post(
        Uri.parse("https://api.telegram.org/bot$_selectedBotToken/sendMessage"),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'chat_id': chatId,
          'text': message,
        }),
      );
      
      final data = jsonDecode(response.body);
      return data['ok'] == true;
    } catch (e) {
      return false;
    }
  }

  void _stopSpam() {
    setState(() => _isSpamming = false);
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(title, style: const TextStyle(color: Colors.yellowAccent, fontFamily: 'Orbitron')),
        content: Text(msg, style: const TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK", style: TextStyle(color: Colors.yellowAccent)),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!["owner", "vip"].contains(widget.userRole.toLowerCase())) {
      return Scaffold(
        backgroundColor: bgDark,
        appBar: AppBar(
          title: const Text("Spam Telegram", style: TextStyle(fontFamily: 'Orbitron')),
          backgroundColor: Colors.transparent,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.lock, color: Colors.red, size: 80),
              SizedBox(height: 20),
              Text("Akses Ditolak", style: TextStyle(color: Colors.red, fontSize: 24, fontWeight: FontWeight.bold)),
              SizedBox(height: 10),
              Text("Fitur ini hanya untuk Owner dan VIP", style: TextStyle(color: Colors.white54)),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        title: const Text("Spam Telegram", style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: accentGrey),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              // Pilih Bot Token
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: cardBg,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: accentGrey.withOpacity(0.3)),
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Icon(Icons.bot, color: accentGrey),
                        SizedBox(width: 10),
                        Text(
                          "Pilih Bot Token",
                          style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                      ],
                    ),
                    SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: _selectedBotToken,
                      dropdownColor: cardBg,
                      style: TextStyle(color: primaryWhite),
                      decoration: InputDecoration(
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      items: _botTokens.map((token) {
                        return DropdownMenuItem(
                          value: token,
                          child: Text(
                            token.substring(0, 20) + "...",
                            style: TextStyle(color: primaryWhite),
                          ),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() => _selectedBotToken = value!);
                      },
                    ),
                  ],
                ),
              ),

              SizedBox(height: 16),

              // Target
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: cardBg,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: accentGrey.withOpacity(0.3)),
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Icon(Icons.person, color: accentGrey),
                        SizedBox(width: 10),
                        Text(
                          "Target Username",
                          style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                      ],
                    ),
                    SizedBox(height: 12),
                    TextField(
                      controller: _targetUsernameController,
                      style: TextStyle(color: primaryWhite),
                      decoration: InputDecoration(
                        labelText: "Username Telegram",
                        labelStyle: TextStyle(color: accentGrey),
                        hintText: "contoh: username_target",
                        hintStyle: TextStyle(color: textGrey),
                        prefixIcon: Icon(Icons.alternate_email, color: accentGrey),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(height: 16),

              // Pesan Spam
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: cardBg,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: accentGrey.withOpacity(0.3)),
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Icon(Icons.message, color: accentGrey),
                        SizedBox(width: 10),
                        Text(
                          "Pesan Spam",
                          style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                      ],
                    ),
                    SizedBox(height: 12),
                    TextField(
                      controller: _messageController,
                      style: TextStyle(color: primaryWhite),
                      maxLines: 3,
                      decoration: InputDecoration(
                        hintText: "Masukkan pesan yang akan dikirim berulang-ulang",
                        hintStyle: TextStyle(color: textGrey),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(height: 16),

              // Quantity & Delay
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: cardBg,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: accentGrey.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Jumlah Spam", style: TextStyle(color: accentGrey, fontSize: 12)),
                          TextField(
                            controller: _qtyController,
                            keyboardType: TextInputType.number,
                            style: TextStyle(color: primaryWhite),
                            decoration: InputDecoration(
                              hintText: "1-100",
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Delay (ms)", style: TextStyle(color: accentGrey, fontSize: 12)),
                          TextField(
                            controller: _delayController,
                            keyboardType: TextInputType.number,
                            style: TextStyle(color: primaryWhite),
                            decoration: InputDecoration(
                              hintText: "500 = 0.5 detik",
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(height: 24),

              // Progress
              if (_isSpamming)
                Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: cardBg,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    children: [
                      LinearProgressIndicator(
                        value: _sentCount / (int.tryParse(_qtyController.text) ?? 1),
                        backgroundColor: Colors.grey,
                        color: Colors.green,
                      ),
                      SizedBox(height: 12),
                      Text(
                        "Mengirim: $_sentCount / ${_qtyController.text}",
                        style: TextStyle(color: primaryWhite),
                      ),
                      SizedBox(height: 8),
                      Text(
                        "Berhasil: $_sentCount | Gagal: $_failedCount",
                        style: TextStyle(color: textGrey, fontSize: 12),
                      ),
                    ],
                  ),
                ),

              SizedBox(height: 16),

              // Tombol
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _isSpamming ? _stopSpam : _sendSpam,
                      icon: Icon(_isSpamming ? Icons.stop : Icons.send),
                      label: Text(_isSpamming ? "STOP SPAM" : "MULAI SPAM"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _isSpamming ? Colors.red : Colors.green,
                        padding: EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                ],
              ),

              SizedBox(height: 16),

              // Info
              Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: cardBg,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: accentGrey.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info_outline, color: accentGrey, size: 16),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        "⚠️ Catatan:\n"
                        "1. Target harus pernah chat dengan bot minimal 1x\n"
                        "2. Bot akan mengirim pesan berulang-ulang\n"
                        "3. Gunakan dengan bijak, risiko ditanggung sendiri",
                        style: TextStyle(color: textGrey, fontSize: 11),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}