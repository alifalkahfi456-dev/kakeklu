import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

class SpotifyMusicPage extends StatefulWidget {
  const SpotifyMusicPage({super.key});

  @override
  State<SpotifyMusicPage> createState() => _SpotifyMusicPageState();
}

class _SpotifyMusicPageState extends State<SpotifyMusicPage> {
  final TextEditingController _searchController = TextEditingController();
  
  bool _isLoading = false;
  bool _isDownloading = false;
  String _status = '🔍 Search for songs, artists, or albums';
  List<Map<String, dynamic>> _searchResults = [];
  Map<String, dynamic>? _currentTrack;
  AudioPlayer? _audioPlayer;
  bool _isPlaying = false;
  Duration _duration = Duration.zero;
  Duration _position = Duration.zero;
  String _downloadProgress = '';
  List<Map<String, dynamic>> _downloadHistory = [];

  // API Key dan URL
  final String _apiBaseUrl = 'https://api.ikyyxd.my.id/search/spotifyplay';
  final String _apiKey = 'kyzz';

  // --- TEMA WARNA HITAM ---
  final Color bgDark = Colors.black;
  final Color cardDark = const Color(0xFF1A1A1A);
  final Color primaryBlack = const Color(0xFF1A1A1A);
  final Color accentGrey = const Color(0xFF444444);
  final Color primaryWhite = Colors.white;
  final Color textGrey = Colors.grey.shade400;

  @override
  void initState() {
    super.initState();
    _initAudioPlayer();
    _requestPermission();
    _loadDownloadHistory();
  }

  void _initAudioPlayer() {
    _audioPlayer = AudioPlayer();
    _audioPlayer?.onDurationChanged.listen((Duration d) {
      setState(() => _duration = d);
    });
    _audioPlayer?.onPositionChanged.listen((Duration p) {
      setState(() => _position = p);
    });
    _audioPlayer?.onPlayerComplete.listen((_) {
      setState(() {
        _isPlaying = false;
        _position = Duration.zero;
      });
    });
  }

  Future<void> _requestPermission() async {
    if (await Permission.storage.request().isGranted) {
      // Permission granted
    }
  }

  Future<void> _loadDownloadHistory() async {
    final directory = await getApplicationDocumentsDirectory();
    final file = File('${directory.path}/download_history.json');
    if (await file.exists()) {
      try {
        String contents = await file.readAsString();
        List<dynamic> data = json.decode(contents);
        setState(() {
          _downloadHistory = data.cast<Map<String, dynamic>>();
        });
      } catch (e) {}
    }
  }

  Future<void> _saveDownloadHistory() async {
    final directory = await getApplicationDocumentsDirectory();
    final file = File('${directory.path}/download_history.json');
    await file.writeAsString(json.encode(_downloadHistory));
  }

  Future<void> _searchMusic() async {
    String query = _searchController.text.trim();
    
    if (query.isEmpty) {
      _showError('Please enter song name or artist');
      return;
    }
    
    setState(() {
      _isLoading = true;
      _status = 'Searching for "$query"...';
      _searchResults.clear();
    });
    
    try {
      // Menggunakan API baru
      final response = await http.get(
        Uri.parse('$_apiBaseUrl?apikey=$_apiKey&query=${Uri.encodeComponent(query)}'),
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Accept': 'application/json',
        },
      ).timeout(const Duration(seconds: 15));
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        
        if (data['status'] == true && data['result'] != null) {
          final result = data['result'];
          
          // Format single result ke dalam list
          List<Map<String, dynamic>> results = [];
          results.add({
            'id': result['url']?.split('/').last ?? DateTime.now().millisecondsSinceEpoch.toString(),
            'title': result['title'] ?? 'Unknown',
            'artist': result['artist'] ?? 'Unknown',
            'album': result['album'] ?? 'Single',
            'duration': result['duration'] ?? '0:00',
            'preview_url': result['download'] ?? '',
            'image': result['thumbnail'] ?? '',
            'popularity': 0,
            'download_url': result['download'] ?? '',
          });
          
          setState(() {
            _searchResults = results;
            _isLoading = false;
            _status = results.isEmpty 
                ? 'No results found for "$query"' 
                : 'Found ${results.length} song';
          });
        } else {
          setState(() {
            _status = 'No results found';
            _isLoading = false;
          });
        }
      } else {
        setState(() {
          _status = 'Search failed. Please try again.';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _status = 'Error: ${e.toString().replaceAll('Exception: ', '')}';
        _isLoading = false;
      });
      _showError('Connection error. Check your internet.');
    }
  }

  Future<void> _playMusic(Map<String, dynamic> track) async {
    String? previewUrl = track['preview_url'] ?? track['download_url'];
    
    if (previewUrl == null || previewUrl.isEmpty) {
      _showError('No preview available for this song');
      return;
    }
    
    if (_isPlaying) {
      await _audioPlayer?.stop();
      setState(() {
        _isPlaying = false;
        _position = Duration.zero;
      });
    }
    
    setState(() {
      _currentTrack = track;
      _status = 'Playing: ${track['title']} - ${track['artist']}';
    });
    
    try {
      await _audioPlayer?.play(UrlSource(previewUrl));
      setState(() => _isPlaying = true);
    } catch (e) {
      _showError('Failed to play: $e');
    }
  }

  Future<void> _pauseMusic() async {
    await _audioPlayer?.pause();
    setState(() => _isPlaying = false);
  }

  Future<void> _resumeMusic() async {
    await _audioPlayer?.resume();
    setState(() => _isPlaying = true);
  }

  Future<void> _stopMusic() async {
    await _audioPlayer?.stop();
    setState(() {
      _isPlaying = false;
      _position = Duration.zero;
      _currentTrack = null;
      _status = 'Music stopped';
    });
  }

  Future<void> _downloadMusic(Map<String, dynamic> track) async {
    String? downloadUrl = track['download_url'] ?? track['preview_url'];
    
    if (downloadUrl == null || downloadUrl.isEmpty) {
      _showError('No download source available for this song');
      return;
    }
    
    var status = await Permission.storage.request();
    if (!status.isGranted) {
      _showError('Storage permission denied');
      return;
    }
    
    setState(() {
      _isDownloading = true;
      _downloadProgress = 'Downloading ${track['title']}...';
    });
    
    try {
      final response = await http.get(Uri.parse(downloadUrl));
      
      if (response.statusCode == 200) {
        Directory? directory;
        if (Platform.isAndroid) {
          directory = Directory('/storage/emulated/0/Download');
          if (!await directory.exists()) {
            directory = await getExternalStorageDirectory();
          }
        } else {
          directory = await getApplicationDocumentsDirectory();
        }
        
        String fileName = '${track['title']} - ${track['artist']}.mp3';
        fileName = fileName.replaceAll(RegExp(r'[\\/*?:"<>|]'), '');
        final file = File('${directory!.path}/$fileName');
        await file.writeAsBytes(response.bodyBytes);
        
        setState(() {
          _downloadHistory.insert(0, {
            'title': track['title'],
            'artist': track['artist'],
            'file': file.path,
            'date': DateTime.now().toString(),
          });
          _isDownloading = false;
          _downloadProgress = '';
        });
        await _saveDownloadHistory();
        
        _showSuccess('Downloaded: ${track['title']}');
      } else {
        throw Exception('Download failed');
      }
    } catch (e) {
      setState(() {
        _isDownloading = false;
        _downloadProgress = '';
      });
      _showError('Download failed: $e');
    }
  }

  String _formatDuration(String duration) {
    // Duration format dari API "3:17"
    return duration;
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  String _formatTime(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
    String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));
    return '$twoDigitMinutes:$twoDigitSeconds';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        title: Text(
          '🎵 Spotify Music Player',
          style: TextStyle(
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            color: primaryWhite,
            letterSpacing: 1,
          ),
        ),
        backgroundColor: primaryBlack,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: primaryWhite),
          onPressed: () => Navigator.pop(context),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            color: accentGrey.withOpacity(0.3),
          ),
        ),
      ),
      body: Column(
        children: [
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: cardDark,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: primaryBlack.withOpacity(0.3)),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _searchController,
                        style: TextStyle(color: primaryWhite),
                        decoration: InputDecoration(
                          labelText: 'Search Songs',
                          labelStyle: TextStyle(color: accentGrey),
                          hintText: 'Song name, artist, or album...',
                          hintStyle: TextStyle(color: textGrey, fontSize: 12),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(color: primaryBlack.withOpacity(0.5)),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(color: accentGrey, width: 2),
                          ),
                          prefixIcon: Icon(Icons.search, color: accentGrey),
                        ),
                        onSubmitted: (_) => _searchMusic(),
                      ),
                    ),
                    const SizedBox(width: 8),
                    ElevatedButton(
                      onPressed: _isLoading ? null : _searchMusic,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: primaryBlack,
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: _isLoading
                          ? SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                color: primaryWhite,
                                strokeWidth: 2,
                              ),
                            )
                          : Icon(Icons.search, color: primaryWhite),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  _status,
                  style: TextStyle(
                    color: _status.contains('Found') || _status.contains('Playing') 
                        ? Colors.green 
                        : accentGrey,
                    fontSize: 12,
                    fontFamily: 'ShareTechMono',
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
          
          if (_currentTrack != null)
            Container(
              margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [primaryBlack.withOpacity(0.3), cardDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: accentGrey.withOpacity(0.3)),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 60,
                        height: 60,
                        decoration: BoxDecoration(
                          color: bgDark,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: accentGrey.withOpacity(0.3)),
                        ),
                        child: _currentTrack!['image'] != null && _currentTrack!['image'].isNotEmpty
                            ? ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                child: Image.network(
                                  _currentTrack!['image'],
                                  width: 60,
                                  height: 60,
                                  fit: BoxFit.cover,
                                  errorBuilder: (context, error, stackTrace) => Icon(Icons.music_note, color: accentGrey, size: 30),
                                ),
                              )
                            : Icon(Icons.music_note, color: accentGrey, size: 30),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _currentTrack!['title'],
                              style: TextStyle(
                                color: primaryWhite,
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text(
                              _currentTrack!['artist'],
                              style: TextStyle(color: textGrey, fontSize: 12),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        onPressed: _stopMusic,
                        icon: Icon(Icons.stop, color: Colors.red),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  
                  Slider(
                    value: _position.inSeconds.toDouble(),
                    max: _duration.inSeconds.toDouble(),
                    onChanged: (value) {
                      _audioPlayer?.seek(Duration(seconds: value.toInt()));
                    },
                    activeColor: accentGrey,
                    inactiveColor: textGrey.withOpacity(0.3),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(_formatTime(_position), style: TextStyle(color: textGrey, fontSize: 10)),
                      Text(_formatTime(_duration), style: TextStyle(color: textGrey, fontSize: 10)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        onPressed: _isPlaying ? _pauseMusic : _resumeMusic,
                        iconSize: 50,
                        icon: Icon(
                          _isPlaying ? Icons.pause_circle_filled : Icons.play_circle_filled,
                          color: accentGrey,
                          size: 50,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          
          if (_searchResults.isNotEmpty)
            Expanded(
              child: DefaultTabController(
                length: 2,
                child: Column(
                  children: [
                    TabBar(
                      labelColor: accentGrey,
                      unselectedLabelColor: textGrey,
                      indicatorColor: accentGrey,
                      tabs: const [
                        Tab(text: '🎵 SEARCH RESULTS'),
                        Tab(text: '📥 DOWNLOADED'),
                      ],
                    ),
                    Expanded(
                      child: TabBarView(
                        children: [
                          ListView.builder(
                            padding: const EdgeInsets.all(16),
                            itemCount: _searchResults.length,
                            itemBuilder: (context, index) {
                              final track = _searchResults[index];
                              return Card(
                                color: cardDark,
                                margin: const EdgeInsets.only(bottom: 12),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  side: BorderSide(color: primaryBlack.withOpacity(0.3)),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(12),
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 50,
                                        height: 50,
                                        decoration: BoxDecoration(
                                          color: bgDark,
                                          borderRadius: BorderRadius.circular(8),
                                          border: Border.all(color: primaryBlack.withOpacity(0.3)),
                                        ),
                                        child: track['image'] != null && track['image'].isNotEmpty
                                            ? ClipRRect(
                                                borderRadius: BorderRadius.circular(8),
                                                child: Image.network(
                                                  track['image'],
                                                  width: 50,
                                                  height: 50,
                                                  fit: BoxFit.cover,
                                                  errorBuilder: (context, error, stackTrace) => Icon(Icons.album, color: accentGrey, size: 30),
                                                ),
                                              )
                                            : Icon(Icons.album, color: accentGrey, size: 30),
                                      ),
                                      const SizedBox(width: 12),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              track['title'],
                                              style: TextStyle(
                                                color: primaryWhite,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 14,
                                              ),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                            Text(
                                              track['artist'],
                                              style: TextStyle(color: textGrey, fontSize: 12),
                                            ),
                                            Text(
                                              track['duration'],
                                              style: TextStyle(color: textGrey, fontSize: 10),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Row(
                                        children: [
                                          IconButton(
                                            onPressed: () => _playMusic(track),
                                            icon: Icon(Icons.play_arrow, color: Colors.green),
                                          ),
                                          IconButton(
                                            onPressed: () => _downloadMusic(track),
                                            icon: Icon(Icons.download, color: Colors.blue),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                          ListView.builder(
                            padding: const EdgeInsets.all(16),
                            itemCount: _downloadHistory.length,
                            itemBuilder: (context, index) {
                              final track = _downloadHistory[index];
                              return Card(
                                color: cardDark,
                                margin: const EdgeInsets.only(bottom: 12),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  side: BorderSide(color: Colors.green.withOpacity(0.3)),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(12),
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 50,
                                        height: 50,
                                        decoration: BoxDecoration(
                                          color: Colors.green.withOpacity(0.2),
                                          borderRadius: BorderRadius.circular(8),
                                        ),
                                        child: Icon(Icons.download_done, color: Colors.green, size: 30),
                                      ),
                                      const SizedBox(width: 12),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              track['title'],
                                              style: TextStyle(
                                                color: primaryWhite,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 14,
                                              ),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                            Text(
                                              track['artist'],
                                              style: TextStyle(color: textGrey, fontSize: 12),
                                            ),
                                            Text(
                                              'Downloaded: ${track['date'].substring(0, 10)}',
                                              style: TextStyle(color: Colors.green, fontSize: 10),
                                            ),
                                          ],
                                        ),
                                      ),
                                      IconButton(
                                        onPressed: () {
                                          _showError('Tap to play downloaded song');
                                        },
                                        icon: Icon(Icons.play_arrow, color: Colors.green),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          
          if (_searchResults.isEmpty && _downloadHistory.isEmpty)
            Expanded(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.music_note, size: 80, color: accentGrey.withOpacity(0.5)),
                    const SizedBox(height: 20),
                    Text(
                      'Search for Music',
                      style: TextStyle(
                        color: primaryWhite,
                        fontSize: 18,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Find your favorite songs and play them',
                      style: TextStyle(color: textGrey, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
          
          if (_isDownloading)
            Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.blue.withOpacity(0.2),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.blue),
              ),
              child: Row(
                children: [
                  SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      color: Colors.blue,
                      strokeWidth: 2,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      _downloadProgress,
                      style: TextStyle(color: Colors.blue, fontSize: 12),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _audioPlayer?.dispose();
    super.dispose();
  }
}