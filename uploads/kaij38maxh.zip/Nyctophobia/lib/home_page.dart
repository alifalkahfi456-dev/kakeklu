import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'services/api_config_service.dart';
import 'custom_attack_page.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _controller;
  String selectedBugId = "";
  String _selectedBugMode = "number";
  
  // Log activity
  List<Map<String, dynamic>> _activityLogs = [];
  bool _isSending = false;

  final Color bgDark = Colors.black;
  final Color cardBg = const Color(0xFF1A1A1A);
  final Color accentGrey = const Color(0xFF444444);
  final Color primaryBlack = const Color(0xFF1A1A1A);
  final Color textGrey = Colors.grey.shade400;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d]'), '');
    if (cleaned.startsWith('0') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    final urlPattern = RegExp(r'^(https?:\/\/)?(chat\.whatsapp\.com)\/[\w\d]+');
    return urlPattern.hasMatch(input);
  }

  void _addLog(String type, String message, String target) {
    final now = DateTime.now();
    final time = "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}";
    
    setState(() {
      _activityLogs.insert(0, {
        'type': type,
        'message': message,
        'target': target,
        'time': time,
      });
      
      // Batasi log maksimal 50
      if (_activityLogs.length > 50) {
        _activityLogs.removeLast();
      }
    });
  }

  void _clearLogs() {
    setState(() {
      _activityLogs.clear();
    });
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (key.isEmpty) {
      _showAlert("❌ Key Invalid", "Session key tidak valid. Silakan login ulang.");
      _addLog('error', 'Session key tidak valid', rawInput);
      return;
    }

    String targetDisplay = rawInput;
    
    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || rawInput.isEmpty) {
        _showAlert("❌ Invalid Number", "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
        _addLog('error', 'Format nomor tidak valid', rawInput);
        return;
      }
      targetDisplay = target;
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert("❌ Invalid Link", "Masukkan link group WA yang valid (contoh: https://chat.whatsapp.com/...).");
        _addLog('error', 'Link group tidak valid', rawInput);
        return;
      }
    }

    setState(() {
      _isSending = true;
    });
    
    _addLog('info', 'Mengirim bug ke target...', targetDisplay);

    try {
      final baseUrl = await ApiConfigService().getBaseUrl();
      final res = await http.get(
        Uri.parse("$baseUrl/sendBug?key=$key&target=${Uri.encodeComponent(rawInput)}&bug=$selectedBugId")
      );
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("⏳ Cooldown", "Tunggu 5-10 Menit Agar Tidak Terkena Cooldown.");
        _addLog('warning', 'Cooldown - Tunggu 5-10 menit', targetDisplay);
      } else if (data["valid"] == false) {
        _showAlert("❌ Key Invalid", "Session key tidak valid. Silakan login ulang.");
        _addLog('error', 'Session key tidak valid', targetDisplay);
      } else if (data["sended"] == false) {
        _showAlert("⚠️ Gagal", "Gagal mengirim bug. Mungkin server sedang maintenance.");
        _addLog('error', 'Gagal mengirim bug', targetDisplay);
      } else {
        _showAlert("✅ Berhasil", "Bug berhasil dikirim ke ${_selectedBugMode == "number" ? "nomor" : "group"} target.");
        _addLog('success', 'Bug berhasil dikirim', targetDisplay);
        targetController.clear();
      }
    } catch (e) {
      _showAlert("❌ Error", "Terjadi kesalahan: $e");
      _addLog('error', 'Error: $e', targetDisplay);
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  void _navigateToCustomAttack() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CustomAttackPage(
          username: widget.username,
          password: widget.password,
          sessionKey: widget.sessionKey,
          listPayload: widget.listBug,
          role: widget.role,
          expiredDate: widget.expiredDate,
        ),
      ),
    );
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(title, style: const TextStyle(color: Colors.yellowAccent, fontFamily: 'Orbitron')),
        content: Text(msg, style: const TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK", style: TextStyle(color: Colors.yellowAccent)),
          )
        ],
      ),
    );
  }

  Widget _buildModeSelector() {
    return Row(
      children: [
        Expanded(
          child: GestureDetector(
            onTap: () {
              setState(() {
                _selectedBugMode = "number";
                targetController.clear();
              });
            },
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: _selectedBugMode == "number"
                    ? accentGrey.withOpacity(0.2)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _selectedBugMode == "number" ? accentGrey : primaryBlack.withOpacity(0.3),
                  width: _selectedBugMode == "number" ? 2 : 1,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.phone_android,
                    color: _selectedBugMode == "number" ? accentGrey : textGrey,
                    size: 18,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    "NUMBER",
                    style: TextStyle(
                      color: _selectedBugMode == "number" ? accentGrey : textGrey,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: GestureDetector(
            onTap: () {
              setState(() {
                _selectedBugMode = "group";
                targetController.clear();
              });
            },
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: _selectedBugMode == "group"
                    ? accentGrey.withOpacity(0.2)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _selectedBugMode == "group" ? accentGrey : primaryBlack.withOpacity(0.3),
                  width: _selectedBugMode == "group" ? 2 : 1,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.group_add,
                    color: _selectedBugMode == "group" ? accentGrey : textGrey,
                    size: 18,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    "GROUP",
                    style: TextStyle(
                      color: _selectedBugMode == "group" ? accentGrey : textGrey,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: GestureDetector(
            onTap: _navigateToCustomAttack,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: Colors.cyanAccent.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.cyanAccent,
                  width: 2,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.code,
                    color: Colors.cyanAccent,
                    size: 18,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    "CUSTOM",
                    style: TextStyle(
                      color: Colors.cyanAccent,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildInputPanel() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildModeSelector(),
        const SizedBox(height: 24),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: Text(
            _selectedBugMode == "number" ? "NOMOR TARGET" : "LINK GROUP WA",
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w700,
              fontSize: 14,
              fontFamily: 'Orbitron',
              letterSpacing: 1.5,
            ),
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: TextField(
            controller: targetController,
            style: const TextStyle(color: Colors.white, fontSize: 16),
            cursorColor: accentGrey,
            keyboardType: _selectedBugMode == "number" ? TextInputType.phone : TextInputType.url,
            decoration: InputDecoration(
              hintText: _selectedBugMode == "number"
                  ? "Contoh e.g. [+62xxxxxxxxxx]"
                  : "Contoh https://chat.whatsapp.com/...",
              hintStyle: TextStyle(color: textGrey.withOpacity(0.5)),
              filled: true,
              fillColor: Colors.transparent,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide.none,
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide(color: primaryBlack.withOpacity(0.3)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: Color(0xFF444444), width: 2),
              ),
              prefixIcon: Icon(
                _selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.link,
                color: accentGrey,
              ),
              contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
            ),
          ),
        ),
        const SizedBox(height: 30),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: const Text(
            "SELECT BUG",
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w700,
              fontSize: 14,
              fontFamily: 'Orbitron',
              letterSpacing: 1.5,
            ),
          ),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: primaryBlack.withOpacity(0.3), width: 1.5),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              dropdownColor: cardBg,
              value: selectedBugId,
              isExpanded: true,
              iconEnabledColor: accentGrey,
              iconSize: 28,
              style: const TextStyle(color: Colors.white, fontSize: 16, fontFamily: 'ShareTechMono'),
              items: widget.listBug.map((bug) {
                return DropdownMenuItem<String>(
                  value: bug['bug_id'],
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Text(
                      bug['bug_name'],
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  selectedBugId = value ?? "";
                });
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildActivityLog() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: primaryBlack.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: Colors.cyanAccent.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(
                      Icons.history,
                      color: Colors.cyanAccent,
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    "ACTIVITY LOG",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
              if (_activityLogs.isNotEmpty)
                TextButton.icon(
                  onPressed: _clearLogs,
                  icon: const Icon(Icons.delete_outline, size: 16),
                  label: const Text(
                    "Clear",
                    style: TextStyle(fontSize: 12),
                  ),
                  style: TextButton.styleFrom(
                    foregroundColor: Colors.redAccent,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          if (_activityLogs.isEmpty)
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.05),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Center(
                child: Column(
                  children: [
                    Icon(Icons.inbox, color: Colors.white38, size: 32),
                    SizedBox(height: 8),
                    Text(
                      "Belum ada aktivitas",
                      style: TextStyle(color: Colors.white38, fontSize: 12),
                    ),
                  ],
                ),
              ),
            )
          else
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _activityLogs.length,
              itemBuilder: (context, index) {
                final log = _activityLogs[index];
                Color iconColor;
                IconData icon;
                
                switch (log['type']) {
                  case 'success':
                    iconColor = Colors.green;
                    icon = Icons.check_circle;
                    break;
                  case 'error':
                    iconColor = Colors.red;
                    icon = Icons.error;
                    break;
                  case 'warning':
                    iconColor = Colors.orange;
                    icon = Icons.warning;
                    break;
                  default:
                    iconColor = Colors.blue;
                    icon = Icons.info;
                }
                
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: iconColor.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(icon, color: iconColor, size: 16),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              log['message'],
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                            Text(
                              "${log['target']} • ${log['time']}",
                              style: TextStyle(
                                color: Colors.white54,
                                fontSize: 10,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.black, Colors.black],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.white.withOpacity(0.05),
                  border: Border.all(color: Colors.yellowAccent, width: 1.2),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.yellowAccent.withOpacity(0.6),
                      blurRadius: 15,
                      spreadRadius: -3,
                    )
                  ],
                ),
                child: Column(
                  children: [
                    FadeTransition(
                      opacity: Tween(begin: 0.5, end: 1.0).animate(_controller),
                      child: ClipOval(
                        child: Image.asset(
                          'assets/images/logo.jpg',
                          width: 100,
                          height: 100,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return Container(
                              width: 100,
                              height: 100,
                              decoration: BoxDecoration(
                                color: Colors.grey[900],
                                shape: BoxShape.circle,
                                border: Border.all(color: Colors.yellowAccent, width: 2),
                              ),
                              child: const Icon(Icons.person, color: Colors.yellowAccent, size: 50),
                            );
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      widget.username,
                      style: const TextStyle(
                        color: Colors.yellowAccent,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                        letterSpacing: 1.2,
                      ),
                    ),
                    Text(
                      "Role: ${widget.role.toUpperCase()} • Exp: ${widget.expiredDate}",
                      style: const TextStyle(
                        color: Colors.white70,
                        fontFamily: 'ShareTechMono',
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 30),
              _buildInputPanel(),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _isSending ? null : _sendBug,
                  icon: _isSending
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Icon(Icons.bug_report, color: Colors.white),
                  label: Text(
                    _isSending ? "SENDING..." : "SEND BUG ATTACK",
                    style: const TextStyle(
                      fontSize: 18,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.4,
                      color: Colors.white,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    backgroundColor: Colors.transparent,
                    shadowColor: Colors.yellowAccent,
                    elevation: 6,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                  ).copyWith(
                    backgroundColor: WidgetStateProperty.resolveWith<Color>(
                          (states) {
                        if (states.contains(WidgetState.pressed)) {
                          return Colors.yellowAccent;
                        }
                        return Colors.yellow;
                      },
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              _buildActivityLog(),
              const SizedBox(height: 10),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    targetController.dispose();
    super.dispose();
  }
}