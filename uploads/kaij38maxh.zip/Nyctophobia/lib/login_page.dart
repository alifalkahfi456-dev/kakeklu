import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'splash.dart';
import 'services/api_config_service.dart';
import 'debug_connection_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with SingleTickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePassword = true;
  bool _showOrderForm = false;
  bool _isSubmittingOrder = false;
  String? androidId;
  String? _lastOrderId;

  // Order form controllers (HANYA WhatsApp dan Telegram, DANA TIDAK ADA)
  final _whatsappController = TextEditingController();
  final _telegramController = TextEditingController();
  
  // Nomor Dana FIXED (TIDAK BISA DIUBAH)
  final String _adminDana = "085727761257";
  final String _adminUsername = "@rappkanjut";
  final String _adminChatId = "7942829017";
  
  String _selectedPackage = "";
  
  final List<Map<String, String>> _packages = [
    {"name": "Member 30 Hari", "price": "10k"},
    {"name": "Member Permaneti", "price": "15k"},
    {"name": "Resseller 30 Hari", "price": "20k"},
    {"name": "Reseller Permanent", "price": "25k"},
    {"name": "Owner", "price": "35k"},
    {"name": "Staff", "price": "40K"},
    {"name": "VIP/Moderatoe", "price": "50k"},
  ];

  late AnimationController _controller;
  late Animation<double> _fadeAnim;

  // --- TEMA WARNA HITAM ---
  final Color bgDark = Colors.black;
  final Color bgSecondary = const Color (0xFF1A1A1A);
  final Color accentGrey = const Color (0xFF444444);
  final Color primaryBlack = const Color (0xFF1A1A1A);
  final Color whiteText = Colors.white;
  final Color grayText = Colors.white70;

  @override
  void initState() {
    super.initState();
    _initAnim();
    initLogin();
  }

  void _initAnim() {
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..forward();
    _fadeAnim = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
  }

  Future<void> initLogin() async {
    androidId = await getAndroidId();

    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final baseUrl = await ApiConfigService().getBaseUrl();
      final uri = Uri.parse("$baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey");
      
      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);

        if (data['valid'] == true) {
          if (!mounted) return;
          Navigator.pushReplacementNamed(
            context,
            '/loader',
            arguments: {
              'username': savedUser,
              'password': savedPass,
              'role': data['role'],
              'key': data['key'],
              'expiredDate': data['expiredDate'],
              'listBug': data['listBug'] ?? [],
              'listDoos': data['listDDoS'] ?? [],
              'news': data['news'] ?? [],
            },
          );
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id ?? "unknown_device";
  }

  Future<void> login() async {
    final username = userController.text.trim();
    final password = passController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      _showAlert("⚠️ Error", "Username and password are required.");
      return;
    }

    setState(() => isLoading = true);

    try {
      final baseUrl = await ApiConfigService().getBaseUrl();
      
      final validate = await http.post(
        Uri.parse("$baseUrl/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      );

      final validData = jsonDecode(validate.body);
      print("VALIDATE RESPONSE => $validData");

      if (validData['expired'] == true) {
        _showAlert("⛔ Access Expired", "Your access has expired.\nPlease renew it.", showContact: true);
      } else if (validData['valid'] != true) {
        _showAlert("🚫 Login Failed", "Invalid username or password.", showContact: true);
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);

        if (!mounted) return;
        Navigator.pushNamed(
          context,
          '/loader',
          arguments: {
            'username': username,
            'password': password,
            'role': validData['role'],
            'key': validData['key'],
            'expiredDate': validData['expiredDate'],
            'listBug': validData['listBug'] ?? [],
            'listDoos': validData['listDoos'] ?? [],
            'news': validData['news'] ?? [],
          },
        );
      }
    } catch (e) {
      _showAlert("🌐 Connection Error", "Failed to connect to the server.\n\nError: $e");
    }

    setState(() => isLoading = false);
  }

  Future<void> _submitOrder() async {
    final whatsapp = _whatsappController.text.trim();
    final telegram = _telegramController.text.trim();

    if (whatsapp.isEmpty) {
      _showAlert("⚠️ Error", "No WhatsApp harus diisi!");
      return;
    }

    setState(() => _isSubmittingOrder = true);

    try {
      final baseUrl = await ApiConfigService().getBaseUrl();
      
      final response = await http.post(
        Uri.parse("$baseUrl/sendOrder"),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "dana": _adminDana,
          "paket": _selectedPackage,
          "whatsapp": whatsapp,
          "username": userController.text.trim().isEmpty ? "Guest" : userController.text.trim(),
          "telegramUser": telegram.isEmpty ? "-" : telegram,
        }),
      );

      final data = jsonDecode(response.body);
      
      if (data['valid'] == true) {
        _lastOrderId = data['orderId'];
        _showOrderSuccessDialog(data['orderId']);
        _whatsappController.clear();
        _telegramController.clear();
        setState(() => _showOrderForm = false);
      } else {
        _showAlert("❌ Gagal", data['message'] ?? "Gagal membuat order. Coba lagi.");
      }
    } catch (e) {
      _showAlert("❌ Error", "Terjadi kesalahan: $e");
    } finally {
      setState(() => _isSubmittingOrder = false);
    }
  }

  Future<void> _uploadPaymentProof(String orderId) async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);
    
    if (image == null) return;
    
    setState(() => _isSubmittingOrder = true);
    
    try {
      final baseUrl = await ApiConfigService().getBaseUrl();
      var request = http.MultipartRequest('POST', Uri.parse("$baseUrl/uploadPaymentProof"));
      request.fields['orderId'] = orderId;
      request.fields['username'] = userController.text.trim();
      request.files.add(await http.MultipartFile.fromPath('image', image.path));
      
      var response = await request.send();
      var responseData = await response.stream.bytesToString();
      var data = jsonDecode(responseData);
      
      if (data['valid'] == true) {
        _showAlert("✅ Berhasil", "Bukti pembayaran terkirim, admin akan segera memproses.");
      } else {
        _showAlert("❌ Gagal", data['message'] ?? "Gagal upload bukti");
      }
    } catch (e) {
      _showAlert("❌ Error", "Terjadi kesalahan: $e");
    } finally {
      setState(() => _isSubmittingOrder = false);
    }
  }

  void _showOrderSuccessDialog(String orderId) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: bgDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green, size: 28),
            const SizedBox(width: 10),
            const Text("Order Berhasil!", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.telegram, color: Colors.blueAccent, size: 60),
            const SizedBox(height: 16),
            Text(
              "Order ID: #$orderId",
              style: const TextStyle(color: Colors.cyanAccent, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            const Text(
              "Silahkan transfer ke nomor Dana berikut:",
              style: TextStyle(color: Colors.white70),
            ),
            const SizedBox(height: 8),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.green.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.green),
              ),
              child: SelectableText(
                _adminDana,
                style: const TextStyle(
                  color: Colors.green,
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.blueAccent.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.blueAccent.withOpacity(0.3)),
              ),
              child: Column(
                children: [
                  const Text(
                    "Setelah transfer, upload bukti pembayaran:",
                    style: TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                  const SizedBox(height: 8),
                  ElevatedButton.icon(
                    onPressed: () => _uploadPaymentProof(orderId),
                    icon: const Icon(Icons.upload_file, size: 18),
                    label: const Text("UPLOAD BUKTI TRANSFER"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            InkWell(
              onTap: () async {
                final uri = Uri.parse("tg://resolve?domain=rappkanjut");
                if (await canLaunchUrl(uri)) {
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                }
              },
              child: Container(
                padding: const EdgeInsets.all(8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.telegram, color: Colors.blueAccent, size: 16),
                    const SizedBox(width: 8),
                    Text(
                      "Hubungi Admin via Telegram",
                      style: TextStyle(color: Colors.blueAccent),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("TUTUP", style: TextStyle(color: Colors.green)),
          ),
        ],
      ),
    );
  }

  void _buyAccount() async {
    final Uri telegramUri = Uri.parse("tg://resolve?domain=rappkanjut");
    final Uri webUri = Uri.parse("https://t.me/rappkanjut");
    
    try {
      if (await canLaunchUrl(telegramUri)) {
        await launchUrl(telegramUri, mode: LaunchMode.externalApplication);
      } else {
        await launchUrl(webUri, mode: LaunchMode.externalApplication);
      }
    } catch (e) {
      _showAlert("Error", "Tidak dapat membuka Telegram.");
    }
  }

  void _showAlert(String title, String msg, {bool showContact = false}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black87,
        title: Text(
          title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
            fontFamily: 'RobotoMono',
          ),
        ),
        content: Text(
          msg,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 16,
            height: 1.4,
            fontFamily: 'ShareTechMono',
          ),
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        actions: [
          if (showContact)
            TextButton(
              onPressed: () async {
                final uri = Uri.parse("tg://resolve?domain=rappkanjut");
                if (await canLaunchUrl(uri)) {
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                } else {
                  await launchUrl(Uri.parse("https://t.me/rappkanjut"),
                      mode: LaunchMode.externalApplication);
                }
              },
              child: const Text(
                "Contact Admin",
                style: TextStyle(
                  color: Colors.lightBlueAccent,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'RobotoMono',
                ),
              ),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              "CLOSE",
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontFamily: 'RobotoMono',
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showPasswordDialogForDebug() {
    final passwordController = TextEditingController();

    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => AlertDialog(
        backgroundColor: bgSecondary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: accentGrey.withOpacity(0.3)),
        ),
        title: Row(
          children: [
            Icon(Icons.security, color: accentGrey),
            const SizedBox(width: 10),
            const Text(
              "Verifikasi Akses",
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "Masukkan password untuk mengakses Debug Connection",
              style: TextStyle(color: Colors.white70),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: passwordController,
              obscureText: true,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: "Password",
                labelStyle: TextStyle(color: accentGrey),
                prefixIcon: Icon(Icons.lock, color: accentGrey),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: accentGrey.withOpacity(0.5)),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: accentGrey.withOpacity(0.5)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: accentGrey),
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("BATAL", style: TextStyle(color: Colors.white54)),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [bgSecondary, accentGrey]),
              borderRadius: BorderRadius.circular(12),
            ),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () {
                final enteredPassword = passwordController.text.trim();
                
                if (enteredPassword == "RappXDev") {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const DebugConnectionPage(),
                    ),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("Password salah! Akses ditolak."),
                      backgroundColor: Colors.redAccent,
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                }
              },
              child: const Text("VERIFIKASI", style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOrderForm() {
    return Container(
      margin: const EdgeInsets.only(top: 20),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: bgSecondary.withOpacity(0.8),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: accentGrey.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.shopping_cart, color: Colors.green, size: 24),
              const SizedBox(width: 10),
              const Text(
                "ORDER AKUN",
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          
          // Informasi Nomor Dana (TIDAK BISA DIUBAH)
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.green.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Icon(Icons.account_balance_wallet, color: Colors.green, size: 20),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Nomor Dana (Penerima)",
                        style: TextStyle(color: Colors.white70, fontSize: 11),
                      ),
                      Text(
                        _adminDana,
                        style: const TextStyle(
                          color: Colors.green,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          
          // Paket Dropdown
          DropdownButtonFormField<String>(
            value: _selectedPackage,
            dropdownColor: bgSecondary,
            style: TextStyle(color: whiteText),
            decoration: InputDecoration(
              labelText: "Pilih Paket",
              labelStyle: TextStyle(color: accentGrey),
              prefixIcon: Icon(Icons.card_giftcard, color: accentGrey),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: primaryBlack),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(color: accentGrey),
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            items: _packages.map((paket) {
              return DropdownMenuItem<String>(
                value: "${paket['name']} (${paket['price']})",
                child: Text(
                  "${paket['name']} - ${paket['price']}",
                  style: TextStyle(color: whiteText),
                ),
              );
            }).toList(),
            onChanged: (value) {
              setState(() {
                _selectedPackage = value!;
              });
            },
          ),
          const SizedBox(height: 12),
          
          // No WhatsApp (Pembeli)
          TextField(
            controller: _whatsappController,
            keyboardType: TextInputType.phone,
            style: TextStyle(color: whiteText),
            decoration: InputDecoration(
              labelText: "No WhatsApp Aktif (Pembeli)",
              labelStyle: TextStyle(color: accentGrey),
              hintText: "628xxxxxxxxx",
              hintStyle: TextStyle(color: grayText),
              prefixIcon: Icon(Icons.chat, color: accentGrey),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: primaryBlack),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(color: accentGrey),
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
          const SizedBox(height: 12),
          
          // Username Telegram (Opsional)
          TextField(
            controller: _telegramController,
            style: TextStyle(color: whiteText),
            decoration: InputDecoration(
              labelText: "Username Telegram (Opsional)",
              labelStyle: TextStyle(color: accentGrey),
              hintText: "@username",
              hintStyle: TextStyle(color: grayText),
              prefixIcon: Icon(Icons.telegram, color: accentGrey),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: primaryBlack),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(color: accentGrey),
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
          const SizedBox(height: 16),
          
          // Tombol Kirim Order
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _isSubmittingOrder ? null : _submitOrder,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: _isSubmittingOrder
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Text(
                      "KIRIM ORDER",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        fontFamily: 'Orbitron',
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.black, Color(0xFF1A1A1A)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Logo
                      GestureDetector(
                        onLongPress: _showPasswordDialogForDebug,
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: accentGrey.withOpacity(0.3),
                                blurRadius: 20,
                                spreadRadius: 5,
                              ),
                            ],
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(100),
                            child: Image.asset(
                              'assets/images/logo.jpg',
                              height: 120,
                              width: 120,
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) {
                                return Container(
                                  height: 120,
                                  width: 120,
                                  decoration: BoxDecoration(
                                    color: bgSecondary,
                                    shape: BoxShape.circle,
                                    border: Border.all(color: accentGrey, width: 2),
                                  ),
                                  child: Icon(
                                    Icons.person,
                                    size: 60,
                                    color: accentGrey,
                                  ),
                                );
                              },
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),
                      Text(
                        "AUTOBOT PREMIUM",
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 4,
                          fontFamily: 'Orbitron',
                          color: whiteText,
                          shadows: [
                            Shadow(
                              color: accentGrey.withOpacity(0.5),
                              blurRadius: 10,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "Please Login To Your Account",
                        style: TextStyle(
                          color: grayText,
                          fontSize: 14,
                          fontStyle: FontStyle.italic,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                      const SizedBox(height: 48),
                      
                      // Username Field
                      _buildNeonInput(
                        hintText: "USERNAME",
                        controller: userController,
                        icon: Icons.person_outline,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Username required';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 20),
                      
                      // Password Field
                      _buildNeonInput(
                        hintText: "PASSWORD",
                        controller: passController,
                        icon: Icons.lock_outline,
                        isPassword: true,
                        obscureText: _obscurePassword,
                        onToggleObscure: () {
                          setState(() {
                            _obscurePassword = !_obscurePassword;
                          });
                        },
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Password required';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 32),
                      
                      // Login Button
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: isLoading ? null : () {
                            if (_formKey.currentState!.validate()) {
                              login();
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: isLoading ? accentGrey : whiteText,
                            foregroundColor: isLoading ? whiteText : bgDark,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                            elevation: isLoading ? 0 : 8,
                          ),
                          child: isLoading
                              ? Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      width: 20,
                                      height: 20,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        valueColor: AlwaysStoppedAnimation<Color>(whiteText),
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Text(
                                      "PROCESSING...",
                                      style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 2,
                                        fontFamily: 'Orbitron',
                                        color: whiteText,
                                      ),
                                    ),
                                  ],
                                )
                              : Text(
                                  "LOGIN",
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 2,
                                    fontFamily: 'Orbitron',
                                    color: bgDark,
                                  ),
                                ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      
                      // Tombol Order via Form
                      InkWell(
                        onTap: () {
                          setState(() {
                            _showOrderForm = !_showOrderForm;
                          });
                        },
                        borderRadius: BorderRadius.circular(20),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.green, width: 1),
                            borderRadius: BorderRadius.circular(20),
                            color: Colors.transparent,
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.shopping_cart, color: Colors.green, size: 18),
                              const SizedBox(width: 8),
                              Text(
                                _showOrderForm ? "Tutup Form Order" : "Order Akun (Dana/QRIS)",
                                style: TextStyle(
                                  color: Colors.green,
                                  fontSize: 14,
                                  fontFamily: 'Orbitron',
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      
                      // Form Order
                      if (_showOrderForm) _buildOrderForm(),
                      
                      const SizedBox(height: 24),
                      
                      // Footer
                      Text(
                        "© 2024 Autobot Premium",
                        style: TextStyle(
                          color: grayText.withOpacity(0.5),
                          fontSize: 12,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNeonInput({
    required String hintText,
    required TextEditingController controller,
    required IconData icon,
    bool isPassword = false,
    bool obscureText = false,
    VoidCallback? onToggleObscure,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      obscureText: isPassword ? obscureText : false,
      style: TextStyle(color: whiteText, fontSize: 16),
      cursorColor: accentGrey,
      validator: validator,
      decoration: InputDecoration(
        labelText: hintText,
        labelStyle: TextStyle(color: accentGrey, fontSize: 12),
        hintText: hintText,
        hintStyle: TextStyle(color: grayText.withOpacity(0.5), fontSize: 14),
        prefixIcon: Icon(icon, color: accentGrey, size: 22),
        suffixIcon: isPassword
            ? IconButton(
                icon: Icon(
                  obscureText ? Icons.visibility_off : Icons.visibility,
                  color: accentGrey,
                  size: 20,
                ),
                onPressed: onToggleObscure,
              )
            : null,
        filled: true,
        fillColor: bgSecondary.withOpacity(0.5),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: accentGrey.withOpacity(0.3)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: accentGrey.withOpacity(0.3)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: accentGrey, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Colors.redAccent, width: 1),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Colors.redAccent, width: 2),
        ),
        errorStyle: TextStyle(
          color: Colors.redAccent,
          fontSize: 12,
          fontFamily: 'ShareTechMono',
        ),
      ),
    );
  }

  @override
  void dispose() {
    userController.dispose();
    passController.dispose();
    _whatsappController.dispose();
    _telegramController.dispose();
    _controller.dispose();
    super.dispose();
  }
}