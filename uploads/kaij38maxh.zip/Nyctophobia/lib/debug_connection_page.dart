import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../services/api_config_service.dart';

class DebugConnectionPage extends StatefulWidget {
  const DebugConnectionPage({super.key});

  @override
  State<DebugConnectionPage> createState() => _DebugConnectionPageState();
}

class _DebugConnectionPageState extends State<DebugConnectionPage>
    with SingleTickerProviderStateMixin {
  final List<String> _logs = [];
  bool _isTesting = false;
  late AnimationController _pulseController;
  String _connectionStatus = "Ready";
  Color _statusColor = const Color(0xFF444444);

  // --- TEMA KONSISTEN DENGAN HALAMAN LAIN (HITAM) ---
  final Color bgDark = Colors.black;
  final Color primaryBlack = const Color(0xFF1A1A1A);
  final Color accentGrey = const Color(0xFF444444);
  final Color lightGrey = const Color(0xFF555555);
  final Color primaryWhite = Colors.white;
  final Color textGrey = Colors.grey.shade400;
  final Color cardGlass = Colors.white.withOpacity(0.05);
  final Color borderGlass = Colors.white.withOpacity(0.1);
  final Color successGreen = const Color(0xFF00E676);
  final Color errorRed = const Color(0xFFFF5252);
  final Color warningOrange = const Color(0xFFFFA726);

  final LinearGradient blackGradient = const LinearGradient(
    colors: [Color(0xFF1A1A1A), Color(0xFF444444)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  void _addLog(String message) {
    setState(() {
      _logs.add('[${DateTime.now().toString().substring(11, 19)}] $message');
    });
  }

  Future<void> _runDiagnostics() async {
    setState(() {
      _logs.clear();
      _isTesting = true;
      _connectionStatus = "Testing...";
      _statusColor = Colors.orange;
    });

    _addLog('🚀 Starting diagnostics...');
    _addLog('');

    // Test 1: Fetch Gist Config
    _addLog('📡 TEST 1: Fetching Gist Config');
    _addLog('─────────────────────────────────');
    
    try {
      final gistUrl = 'https://gist.githubusercontent.com/rapp695/1db0d6e192ec333c0d23cf4c28af3031/raw/config.json';
      _addLog('URL: $gistUrl');
      
      final gistResponse = await http.get(Uri.parse(gistUrl)).timeout(
        const Duration(seconds: 10),
        onTimeout: () {
          throw Exception('Timeout after 10s');
        },
      );
      
      _addLog('Status: ${gistResponse.statusCode}');
      _addLog('Response: ${gistResponse.body}');
      
      if (gistResponse.statusCode == 200) {
        final data = jsonDecode(gistResponse.body);
        final urlAktif = data['url_aktif'];
        _addLog('✅ Gist OK! url_aktif = $urlAktif');
      } else {
        _addLog('❌ Gist failed with status ${gistResponse.statusCode}');
      }
    } catch (e) {
      _addLog('❌ Gist Error: $e');
    }
    
    _addLog('');
    
    // Test 2: ApiConfig.baseUrl
    _addLog('🔧 TEST 2: ApiConfig.baseUrl');
    _addLog('─────────────────────────────────');
    
    try {
      final baseUrl = await ApiConfig.baseUrl;
      _addLog('✅ ApiConfig.baseUrl = $baseUrl');
      setState(() {
        _connectionStatus = "Connected";
        _statusColor = successGreen;
      });
    } catch (e) {
      _addLog('❌ ApiConfig Error: $e');
      setState(() {
        _connectionStatus = "Failed";
        _statusColor = errorRed;
      });
    }
    
    _addLog('');
    
    // Test 3: Direct Server Ping
    _addLog('🌐 TEST 3: Direct Server Test');
    _addLog('─────────────────────────────────');
    
    try {
      final baseUrl = await ApiConfig.baseUrl;
      _addLog('Testing: $baseUrl');
      
      final serverResponse = await http.get(Uri.parse(baseUrl)).timeout(
        const Duration(seconds: 10),
        onTimeout: () {
          throw Exception('Server timeout after 10s');
        },
      );
      
      _addLog('Status: ${serverResponse.statusCode}');
      _addLog('✅ Server reachable!');
    } catch (e) {
      _addLog('❌ Server Error: $e');
    }
    
    _addLog('');
    
    // Test 4: API Validate Endpoint
    _addLog('🔐 TEST 4: API Validate Endpoint');
    _addLog('─────────────────────────────────');
    
    try {
      final baseUrl = await ApiConfig.baseUrl;
      final validateUrl = '$baseUrl/validate';
      _addLog('URL: $validateUrl');
      
      final validateResponse = await http.post(
        Uri.parse(validateUrl),
        body: {
          'username': 'test',
          'password': 'test',
          'androidId': 'test123',
        },
      ).timeout(
        const Duration(seconds: 10),
        onTimeout: () {
          throw Exception('Validate timeout after 10s');
        },
      );
      
      _addLog('Status: ${validateResponse.statusCode}');
      _addLog('Response: ${validateResponse.body}');
      
      if (validateResponse.statusCode == 200) {
        _addLog('✅ API Endpoint reachable!');
      } else {
        _addLog('⚠️ Endpoint responded but status: ${validateResponse.statusCode}');
      }
    } catch (e) {
      _addLog('❌ API Error: $e');
    }
    
    _addLog('');
    _addLog('═══════════════════════════════════');
    _addLog('🏁 Diagnostics Complete');
    _addLog('═══════════════════════════════════');

    setState(() {
      _isTesting = false;
    });
  }

  Future<void> _testWithRealCredentials() async {
    setState(() {
      _logs.clear();
      _isTesting = true;
      _connectionStatus = "Testing Login...";
      _statusColor = Colors.orange;
    });

    _addLog('🔑 Testing with Real Login');
    _addLog('─────────────────────────────────');
    
    String? username;
    String? password;
    
    await showDialog(
      context: context,
      builder: (context) {
        final userCtrl = TextEditingController();
        final passCtrl = TextEditingController();
        
        return AlertDialog(
          backgroundColor: bgDark,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: accentGrey.withOpacity(0.3)),
          ),
          title: Row(
            children: [
              Icon(Icons.login, color: accentGrey),
              const SizedBox(width: 10),
              const Text(
                'Enter Credentials',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: userCtrl,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Username',
                  labelStyle: TextStyle(color: accentGrey),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: borderGlass),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: accentGrey),
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: passCtrl,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Password',
                  labelStyle: TextStyle(color: accentGrey),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: borderGlass),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: accentGrey),
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                obscureText: true,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel', style: TextStyle(color: textGrey)),
            ),
            Container(
              decoration: BoxDecoration(
                gradient: blackGradient,
                borderRadius: BorderRadius.circular(12),
              ),
              child: TextButton(
                onPressed: () {
                  username = userCtrl.text;
                  password = passCtrl.text;
                  Navigator.pop(context);
                },
                child: const Text(
                  'Test',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        );
      },
    );

    if (username != null && password != null) {
      try {
        final baseUrl = await ApiConfig.baseUrl;
        _addLog('Base URL: $baseUrl');
        _addLog('Username: $username');
        _addLog('Sending request...');
        
        final response = await http.post(
          Uri.parse('$baseUrl/validate'),
          body: {
            'username': username!,
            'password': password!,
            'androidId': 'debug_test',
          },
        ).timeout(const Duration(seconds: 15));
        
        _addLog('Status: ${response.statusCode}');
        _addLog('Response: ${response.body}');
        
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          _addLog('✅ LOGIN SUCCESS!');
          setState(() {
            _connectionStatus = "Login Success";
            _statusColor = successGreen;
          });
        } else if (data['expired'] == true) {
          _addLog('⚠️ Account expired');
          setState(() {
            _connectionStatus = "Account Expired";
            _statusColor = warningOrange;
          });
        } else {
          _addLog('❌ Invalid credentials');
          setState(() {
            _connectionStatus = "Invalid Credentials";
            _statusColor = errorRed;
          });
        }
      } catch (e) {
        _addLog('❌ Error: $e');
        setState(() {
          _connectionStatus = "Error";
          _statusColor = errorRed;
        });
      }
    }

    setState(() {
      _isTesting = false;
    });
  }

  Future<void> _clearCache() async {
    _addLog('🗑️ Clearing cache...');
    try {
      await ApiConfig.clearCache();
      _addLog('✅ Cache cleared');
      setState(() {
        _connectionStatus = "Cache Cleared";
        _statusColor = successGreen;
      });
      Future.delayed(const Duration(seconds: 2), () {
        if (mounted) {
          setState(() {
            _connectionStatus = "Ready";
            _statusColor = accentGrey;
          });
        }
      });
    } catch (e) {
      _addLog('❌ Error: $e');
      setState(() {
        _connectionStatus = "Error";
        _statusColor = errorRed;
      });
    }
  }

  Future<void> _forceRefresh() async {
    _addLog('🔄 Force refreshing from Gist...');
    setState(() {
      _connectionStatus = "Refreshing...";
      _statusColor = warningOrange;
    });
    try {
      final newUrl = await ApiConfig.refresh();
      _addLog('✅ New URL: $newUrl');
      setState(() {
        _connectionStatus = "Refreshed";
        _statusColor = successGreen;
      });
      Future.delayed(const Duration(seconds: 2), () {
        if (mounted) {
          setState(() {
            _connectionStatus = "Ready";
            _statusColor = accentGrey;
          });
        }
      });
    } catch (e) {
      _addLog('❌ Error: $e');
      setState(() {
        _connectionStatus = "Refresh Failed";
        _statusColor = errorRed;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        title: const Text(
          "Connection Diagnostics",
          style: TextStyle(
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: accentGrey),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline, color: Colors.white),
            onPressed: () {
              setState(() {
                _logs.clear();
              });
            },
            tooltip: 'Clear Logs',
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgDark, primaryBlack.withOpacity(0.1), bgDark],
          ),
        ),
        child: Column(
          children: [
            // Status Card
            Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: cardGlass,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: borderGlass),
                boxShadow: [
                  BoxShadow(
                    color: primaryBlack.withOpacity(0.2),
                    blurRadius: 15,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Column(
                children: [
                  AnimatedBuilder(
                    animation: _pulseController,
                    builder: (context, child) {
                      return Container(
                        width: 60,
                        height: 60,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: blackGradient,
                          boxShadow: [
                            BoxShadow(
                              color: _statusColor.withOpacity(0.5),
                              blurRadius: _pulseController.value * 15,
                              spreadRadius: 2,
                            ),
                          ],
                        ),
                        child: Icon(
                          _connectionStatus.contains("Success") || _connectionStatus == "Connected"
                              ? Icons.check_circle
                              : _connectionStatus.contains("Failed") || _connectionStatus.contains("Error")
                              ? Icons.error
                              : Icons.settings_ethernet,
                          color: Colors.white,
                          size: 30,
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 16),
                  Text(
                    "Connection Status",
                    style: TextStyle(
                      color: textGrey,
                      fontSize: 12,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _connectionStatus,
                    style: TextStyle(
                      color: _statusColor,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ],
              ),
            ),

            // Action Buttons
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: _buildActionButton(
                          icon: Icons.play_arrow,
                          label: 'Run Diagnostics',
                          color: successGreen,
                          onPressed: _isTesting ? null : _runDiagnostics,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _buildActionButton(
                          icon: Icons.login,
                          label: 'Test Login',
                          color: accentGrey,
                          onPressed: _isTesting ? null : _testWithRealCredentials,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _buildActionButton(
                          icon: Icons.delete_outline,
                          label: 'Clear Cache',
                          color: warningOrange,
                          onPressed: _isTesting ? null : _clearCache,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _buildActionButton(
                          icon: Icons.refresh,
                          label: 'Force Refresh',
                          color: accentGrey,
                          onPressed: _isTesting ? null : _forceRefresh,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // Log Console
            Expanded(
              child: Container(
                margin: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.6),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: borderGlass),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: primaryBlack.withOpacity(0.2),
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(16),
                          topRight: Radius.circular(16),
                        ),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.terminal, color: accentGrey, size: 20),
                          const SizedBox(width: 8),
                          Text(
                            "Console Output",
                            style: TextStyle(
                              color: primaryWhite,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                              fontSize: 14,
                            ),
                          ),
                          const Spacer(),
                          if (_isTesting)
                            SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: accentGrey,
                              ),
                            ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: _logs.isEmpty
                          ? Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.code_off, color: textGrey, size: 48),
                                  const SizedBox(height: 16),
                                  Text(
                                    'Press "Run Diagnostics" to start testing',
                                    style: TextStyle(color: textGrey, fontSize: 14),
                                  ),
                                ],
                              ),
                            )
                          : ListView.builder(
                              padding: const EdgeInsets.all(12),
                              itemCount: _logs.length,
                              itemBuilder: (context, index) {
                                final log = _logs[index];
                                Color textColor;
                                
                                if (log.contains('❌')) {
                                  textColor = errorRed;
                                } else if (log.contains('⚠️')) {
                                  textColor = warningOrange;
                                } else if (log.contains('✅')) {
                                  textColor = successGreen;
                                } else if (log.contains('─') || log.contains('═')) {
                                  textColor = Colors.cyan;
                                } else if (log.contains('🚀') || log.contains('📡') || 
                                           log.contains('🔧') || log.contains('🌐') || 
                                           log.contains('🔐') || log.contains('🔑')) {
                                  textColor = accentGrey;
                                } else {
                                  textColor = primaryWhite;
                                }
                                
                                return Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 2),
                                  child: SelectableText(
                                    log,
                                    style: TextStyle(
                                      color: textColor,
                                      fontFamily: 'monospace',
                                      fontSize: 11,
                                    ),
                                  ),
                                );
                              },
                            ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required Color color,
    VoidCallback? onPressed,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [primaryBlack, accentGrey],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: primaryBlack.withOpacity(0.4),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: ElevatedButton.icon(
        onPressed: onPressed,
        icon: Icon(icon, color: Colors.white, size: 18),
        label: Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 13,
          ),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }
}