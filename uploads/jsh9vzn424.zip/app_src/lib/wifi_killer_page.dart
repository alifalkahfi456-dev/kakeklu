import 'package:flutter/material.dart';

class WifiKillerPage extends StatelessWidget {
  const WifiKillerPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Wifi Killer')),
      body: const Center(
        child: Text('Fitur belum tersedia'),
      ),
    );
  }
}
