import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listGroupBug;
  final String role;
  final String expiredDate;

  HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.listGroupBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _pulseController;
  
  String selectedBugId = "";
  String selectedGroupBugId = "";
  String _selectedBugMode = "number";
  String _selectedSenderType = "pribadi";
  
  bool _isSending = false;
  String? _responseMessage;
  
  int _personalSenderCount = 0;
  int _globalSenderCount = 0;
  bool _isLoadingCounts = true;

  final Color primaryBg = Color(0xFF0F0F1A);
  final Color cardBg = Color(0xFF1E1E2E);
  final Color primaryPurple = Color(0xFF7B1FA2);
  final Color accentPurple = Color(0xFFE040FB);
  final Color textGrey = Colors.grey.shade400;

  final LinearGradient purpleGradient = LinearGradient(
    colors: [Color(0xFF7B1FA2), Color(0xFFE040FB)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  late VideoPlayerController _videoController;
  ChewieController? _chewieController;
  bool _isVideoInitialized = false;

  bool get isOwner => widget.role.toLowerCase() == 'owner';

  @override
  void initState() {
    super.initState();
    
    _pulseController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'].toString();
    }
    if (widget.listGroupBug.isNotEmpty) {
      selectedGroupBugId = widget.listGroupBug[0]['bug_id'].toString();
    }

    _initializeVideoPlayer();
    _fetchSenderCounts();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    targetController.dispose();
    _videoController.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  Future<void> _fetchSenderCounts() async {
    if (!mounted) return;
    
    setState(() {
      _isLoadingCounts = true;
    });

    try {
      final response = await http.get(
        Uri.parse("http://king.daiyat.store:9907/mySender?key=${widget.sessionKey}"),
        headers: {'Content-Type': 'application/json'},
      ).timeout(Duration(seconds: 10));

      if (mounted && response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          setState(() {
            _personalSenderCount = data["personalCount"] ?? 0;
            _globalSenderCount = data["globalCount"] ?? 0;
          });
        }
      }
    } catch (e) {
      debugPrint("Error fetching sender counts: $e");
    } finally {
      if (mounted) {
        setState(() {
          _isLoadingCounts = false;
        });
      }
    }
  }

  void _initializeVideoPlayer() {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/banner.mp4');

      _videoController.initialize().then((_) {
        if (mounted) {
          setState(() {
            _videoController.setVolume(0.0);
            _chewieController = ChewieController(
              videoPlayerController: _videoController,
              autoPlay: true,
              looping: true,
              showControls: false,
              autoInitialize: true,
              allowFullScreen: false,
              allowMuting: false,
            );
            _isVideoInitialized = true;
          });
        }
      }).catchError((error) {
        debugPrint("Video initialization error: $error");
        if (mounted) {
          setState(() {
            _isVideoInitialized = false;
          });
        }
      });
    } catch (e) {
      debugPrint("Video error: $e");
      if (mounted) {
        setState(() {
          _isVideoInitialized = false;
        });
      }
    }
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com');
  }

  Future<void> _sendBug() async {
    if (_selectedBugMode == "number") {
      await _sendNumberBug();
    } else {
      await _sendGroupBug();
    }
  }

  bool _validateSender() {
    if (_selectedSenderType == "pribadi") {
      if (_personalSenderCount == 0) {
        _showAlert(
          "⚠️ Tidak Ada Sender PRIBADI", 
          "Anda tidak memiliki Sender PRIBADI!\n\nSilahkan pairing nomor WhatsApp Anda terlebih dahulu."
        );
        return false;
      }
      return true;
    } 
    else if (_selectedSenderType == "global") {
      if (!isOwner) {
        _showAlert(
          "⛔ Akses Ditolak", 
          "Anda tidak memiliki akses ke Sender GLOBAL!\n\nFitur ini hanya untuk OWNER."
        );
        return false;
      }
      
      if (_globalSenderCount == 0) {
        _showAlert(
          "⚠️ Tidak Ada Sender GLOBAL", 
          "Tidak ada Sender GLOBAL yang aktif!\n\nHubungi admin untuk menambahkan sender global."
        );
        return false;
      }
      return true;
    }
    return false;
  }

  Future<void> _sendNumberBug() async {
    final rawInput = targetController.text.trim();
    final target = formatPhoneNumber(rawInput);
    final key = widget.sessionKey;

    if (target == null || key.isEmpty) {
      _showAlert("❌ Invalid Number", "Gunakan nomor internasional (misal: +62xxx)");
      return;
    }

    if (!_validateSender()) return;

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });

    try {
      final res = await http.get(Uri.parse(
          "http://king.daiyat.store:9907/sendBug?key=$key&target=$target&bug=$selectedBugId&senderType=$_selectedSenderType"));
      final data = jsonDecode(res.body);

      if (mounted) {
        if (data["cooldown"] == true) {
          setState(() => _responseMessage = "⏳ Cooldown: Tunggu beberapa saat.");
        } else if (data["valid"] == false) {
          setState(() => _responseMessage = "❌ ${data["message"] ?? "Gagal mengirim bug."}");
        } else if (data["sended"] == false) {
          setState(() => _responseMessage = "⚠️ Gagal: ${data["message"] ?? "Server maintenance."}");
        } else {
          setState(() => _responseMessage = "✅ Berhasil mengirim bug ke $target!");
          targetController.clear();
        }
      }
    } catch (_) {
      if (mounted) {
        setState(() => _responseMessage = "❌ Error: Terjadi kesalahan.");
      }
    } finally {
      if (mounted) {
        setState(() {
          _isSending = false;
        });
      }
    }
  }

  Future<void> _sendGroupBug() async {
    final link = targetController.text.trim();
    final key = widget.sessionKey;

    if (!isValidGroupLink(link)) {
      _showAlert("❌ Invalid Link", "Gunakan link WhatsApp Group yang valid");
      return;
    }

    if (key.isEmpty) {
      _showAlert("❌ Error", "Session key tidak valid");
      return;
    }

    if (!_validateSender()) return;

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });

    try {
      final res = await http.get(Uri.parse(
          "http://king.daiyat.store:9907/sendGroupBug?key=$key&bug=$selectedGroupBugId&link=${Uri.encodeComponent(link)}&senderType=$_selectedSenderType"));
      final data = jsonDecode(res.body);

      if (mounted) {
        if (data["cooldown"] == true) {
          setState(() => _responseMessage = "⏳ Cooldown: Tunggu beberapa saat.");
        } else if (data["valid"] == false) {
          setState(() => _responseMessage = "❌ ${data["message"] ?? "Gagal mengirim bug."}");
        } else if (data["sended"] == false) {
          setState(() => _responseMessage = "⚠️ Gagal: ${data["message"] ?? "Server maintenance."}");
        } else {
          setState(() => _responseMessage = "✅ Berhasil mengirim bug ke group!");
          targetController.clear();
        }
      }
    } catch (_) {
      if (mounted) {
        setState(() => _responseMessage = "❌ Error: Terjadi kesalahan.");
      }
    } finally {
      if (mounted) {
        setState(() {
          _isSending = false;
        });
      }
    }
  }

  void _showAlert(String title, String msg) {
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => AlertDialog(
        backgroundColor: cardBg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: primaryPurple.withOpacity(0.5)),
        ),
        title: Text(title, style: TextStyle(color: Color(0xFFE040FB), fontWeight: FontWeight.bold)),
        content: Text(msg, style: TextStyle(color: Colors.grey)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: Color(0xFF7B1FA2), fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Widget _buildSenderSelector() {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: primaryPurple.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("PILIH SENDER", style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
          SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _buildSenderOption(
                  value: "pribadi",
                  label: "PRIBADI",
                  icon: Icons.person,
                  color: Colors.green,
                  count: _personalSenderCount,
                ),
              ),
              SizedBox(width: 12),
              if (isOwner) 
                Expanded(
                  child: _buildSenderOption(
                    value: "global",
                    label: "GLOBAL",
                    icon: Icons.public,
                    color: Colors.blue,
                    count: _globalSenderCount,
                  ),
                ),
            ],
          ),
          if (!isOwner) ...[
            SizedBox(height: 8),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.orange.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.orange.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  Icon(Icons.info_outline, size: 12, color: Colors.orange),
                  SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      "Sender GLOBAL hanya untuk OWNER",
                      style: TextStyle(color: Colors.orange, fontSize: 10),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildSenderOption({
    required String value,
    required String label,
    required IconData icon,
    required Color color,
    required int count,
  }) {
    final isSelected = _selectedSenderType == value;
    final isAvailable = count > 0;
    
    return GestureDetector(
      onTap: isAvailable ? () {
        setState(() {
          _selectedSenderType = value;
        });
      } : null,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          gradient: isSelected ? LinearGradient(
            colors: [color.withOpacity(0.3), color.withOpacity(0.1)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ) : null,
          color: isSelected ? null : Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? color : Colors.white.withOpacity(0.1),
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Column(
          children: [
            Icon(icon, color: isSelected ? color : Colors.white54, size: 24),
            SizedBox(height: 4),
            Text(label, style: TextStyle(color: isSelected ? color : Colors.white54, fontSize: 12, fontWeight: FontWeight.bold)),
            SizedBox(height: 2),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: isAvailable ? Colors.green.withOpacity(0.2) : Colors.red.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                isAvailable ? "$count Tersedia" : "0 Tersedia",
                style: TextStyle(color: isAvailable ? Colors.green : Colors.red, fontSize: 8, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderPanel() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: primaryPurple.withOpacity(0.3), width: 1),
        boxShadow: [BoxShadow(color: primaryPurple.withOpacity(0.15), blurRadius: 20, offset: Offset(0, 10))],
      ),
      child: Row(
        children: [
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: purpleGradient,
              boxShadow: [BoxShadow(color: accentPurple.withOpacity(0.6), blurRadius: 15, spreadRadius: 2)],
            ),
            child: CircleAvatar(radius: 32, backgroundColor: Colors.transparent, child: Icon(Icons.person, size: 40, color: Colors.white)),
          ),
          SizedBox(width: 20),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.username, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 20)),
                SizedBox(height: 6),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: isOwner ? Colors.orange.withOpacity(0.2) : primaryPurple.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: isOwner ? Colors.orange : primaryPurple.withOpacity(0.3)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(isOwner ? Icons.admin_panel_settings : Icons.person, size: 12, color: isOwner ? Colors.orange : accentPurple),
                      SizedBox(width: 4),
                      Text(
                        "Role: ${widget.role.toUpperCase()} • Exp: ${widget.expiredDate}",
                        style: TextStyle(color: isOwner ? Colors.orange : accentPurple, fontSize: 12, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoPlayer() {
    if (!_isVideoInitialized || _chewieController == null) {
      return Container(
        width: double.infinity,
        height: 200,
        margin: EdgeInsets.symmetric(vertical: 20),
        decoration: BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(20)),
        child: Center(child: CircularProgressIndicator(color: accentPurple)),
      );
    }

    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(vertical: 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: primaryPurple.withOpacity(0.4), blurRadius: 20, spreadRadius: 2)],
        border: Border.all(color: accentPurple.withOpacity(0.3), width: 1.5),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: AspectRatio(
          aspectRatio: _videoController.value.aspectRatio,
          child: Chewie(controller: _chewieController!),
        ),
      ),
    );
  }

  Widget _buildModeSelector() {
    return Row(
      children: [
        Expanded(
          child: GestureDetector(
            onTap: () => setState(() { _selectedBugMode = "number"; targetController.clear(); }),
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                color: _selectedBugMode == "number" ? accentPurple.withOpacity(0.2) : Colors.transparent,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _selectedBugMode == "number" ? accentPurple : primaryPurple.withOpacity(0.3), width: _selectedBugMode == "number" ? 2 : 1),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.phone_android_rounded, color: _selectedBugMode == "number" ? accentPurple : textGrey, size: 20),
                  SizedBox(width: 8),
                  Text("BUG NOMOR", style: TextStyle(color: _selectedBugMode == "number" ? accentPurple : textGrey, fontWeight: FontWeight.bold, fontSize: 14)),
                ],
              ),
            ),
          ),
        ),
        SizedBox(width: 16),
        Expanded(
          child: GestureDetector(
            onTap: () => setState(() { _selectedBugMode = "group"; targetController.clear(); }),
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                color: _selectedBugMode == "group" ? accentPurple.withOpacity(0.2) : Colors.transparent,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _selectedBugMode == "group" ? accentPurple : primaryPurple.withOpacity(0.3), width: _selectedBugMode == "group" ? 2 : 1),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.group_add, color: _selectedBugMode == "group" ? accentPurple : textGrey, size: 20),
                  SizedBox(width: 8),
                  Text("BUG GROUP", style: TextStyle(color: _selectedBugMode == "group" ? accentPurple : textGrey, fontWeight: FontWeight.bold, fontSize: 14)),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildBugSelector() {
    if (_selectedBugMode == "number") {
      if (widget.listBug.isEmpty) {
        return Container(
          padding: EdgeInsets.all(20),
          decoration: BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(16)),
          child: Center(child: Text("❌ Tidak ada bug tersedia", style: TextStyle(color: Colors.white54))),
        );
      }

      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("PILIH BUG", style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
          SizedBox(height: 12),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(12), border: Border.all(color: primaryPurple.withOpacity(0.3))),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: selectedBugId,
                dropdownColor: cardBg,
                style: TextStyle(color: Colors.white),
                isExpanded: true,
                icon: Icon(Icons.arrow_drop_down, color: accentPurple),
                items: widget.listBug.map<DropdownMenuItem<String>>((bug) {
                  return DropdownMenuItem<String>(
                    value: bug['bug_id'].toString(),
                    child: Text(bug['name'] ?? 'Bug ${bug['bug_id']}', style: TextStyle(color: Colors.white)),
                  );
                }).toList(),
                onChanged: (value) {
                  if (value != null) setState(() => selectedBugId = value);
                },
              ),
            ),
          ),
        ],
      );
    } else {
      if (widget.listGroupBug.isEmpty) {
        return Container(
          padding: EdgeInsets.all(20),
          decoration: BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(16)),
          child: Center(child: Text("❌ Tidak ada group bug tersedia", style: TextStyle(color: Colors.white54))),
        );
      }

      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("PILIH GROUP BUG", style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
          SizedBox(height: 12),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(12), border: Border.all(color: primaryPurple.withOpacity(0.3))),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: selectedGroupBugId,
                dropdownColor: cardBg,
                style: TextStyle(color: Colors.white),
                isExpanded: true,
                icon: Icon(Icons.arrow_drop_down, color: accentPurple),
                items: widget.listGroupBug.map<DropdownMenuItem<String>>((bug) {
                  return DropdownMenuItem<String>(
                    value: bug['bug_id'].toString(),
                    child: Text(bug['name'] ?? 'Group Bug ${bug['bug_id']}', style: TextStyle(color: Colors.white)),
                  );
                }).toList(),
                onChanged: (value) {
                  if (value != null) setState(() => selectedGroupBugId = value);
                },
              ),
            ),
          ),
        ],
      );
    }
  }

  Widget _buildInputPanel() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildModeSelector(),
        SizedBox(height: 20),
        _buildSenderSelector(),
        SizedBox(height: 20),
        _buildBugSelector(),
        SizedBox(height: 30),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: Text(
            _selectedBugMode == "number" ? "NOMOR TARGET" : "LINK GROUP WA",
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14, letterSpacing: 1.5),
          ),
        ),
        SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 8, offset: Offset(0, 4))],
          ),
          child: TextField(
            controller: targetController,
            style: TextStyle(color: Colors.white, fontSize: 16),
            cursorColor: accentPurple,
            keyboardType: _selectedBugMode == "number" ? TextInputType.phone : TextInputType.url,
            decoration: InputDecoration(
              hintText: _selectedBugMode == "number" ? "Contoh: +62xxxxxxxxxx" : "Contoh: https://chat.whatsapp.com/...",
              hintStyle: TextStyle(color: textGrey.withOpacity(0.5)),
              filled: true,
              fillColor: Colors.transparent,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: primaryPurple.withOpacity(0.3))),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: Color(0xFFE040FB), width: 2)),
              prefixIcon: Icon(_selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.link, color: accentPurple),
              contentPadding: EdgeInsets.symmetric(vertical: 16, horizontal: 16),
            ),
          ),
        ),
        SizedBox(height: 30),
        AnimatedBuilder(
          animation: _pulseController,
          builder: (context, child) {
            return Container(
              decoration: BoxDecoration(
                gradient: purpleGradient,
                borderRadius: BorderRadius.circular(30),
                boxShadow: [BoxShadow(color: accentPurple.withOpacity(0.3 + (_pulseController.value * 0.3)), blurRadius: 15 + (_pulseController.value * 10), spreadRadius: 1)],
              ),
              child: ElevatedButton(
                onPressed: _isSending ? null : _sendBug,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  padding: EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                ),
                child: _isSending
                    ? SizedBox(height: 24, width: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : Text("KIRIM BUG", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 2, color: Colors.white)),
              ),
            );
          },
        ),
        if (_responseMessage != null) ...[
          SizedBox(height: 20),
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _responseMessage!.contains("✅") ? Colors.green.withOpacity(0.1) : _responseMessage!.contains("❌") ? Colors.red.withOpacity(0.1) : Colors.orange.withOpacity(0.1),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _responseMessage!.contains("✅") ? Colors.green : _responseMessage!.contains("❌") ? Colors.red : Colors.orange, width: 1),
            ),
            child: Row(
              children: [
                Icon(
                  _responseMessage!.contains("✅") ? Icons.check_circle : _responseMessage!.contains("❌") ? Icons.error : Icons.warning,
                  color: _responseMessage!.contains("✅") ? Colors.green : _responseMessage!.contains("❌") ? Colors.red : Colors.orange,
                  size: 20,
                ),
                SizedBox(width: 12),
                Expanded(child: Text(_responseMessage!, style: TextStyle(color: Colors.white, fontSize: 12))),
              ],
            ),
          ),
        ],
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryBg,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          padding: EdgeInsets.all(16),
          child: Column(
            children: [
              _buildHeaderPanel(),
              _buildVideoPlayer(),
              _buildInputPanel(),
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}