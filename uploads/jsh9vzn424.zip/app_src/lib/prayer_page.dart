
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';

class PrayerPage extends StatefulWidget {
  const PrayerPage({super.key});
  @override State<PrayerPage> createState()=>_PrayerPageState();
}

class _PrayerPageState extends State<PrayerPage>{
  Map<String,dynamic>? times;
  String city="Mencari lokasi...";
  bool loading=true;

  @override void initState(){super.initState();load();}

  Future<void> load() async{
    try{
      LocationPermission perm=await Geolocator.checkPermission();
      if(perm==LocationPermission.denied){
        perm=await Geolocator.requestPermission();
      }
      if(perm==LocationPermission.deniedForever){
        setState(()=>loading=false);
        return;
      }
      final pos=await Geolocator.getCurrentPosition();
      final url="https://api.aladhan.com/v1/timings?latitude=${pos.latitude}&longitude=${pos.longitude}&method=2";
      final res=await http.get(Uri.parse(url));
      final data=jsonDecode(res.body);
      setState((){
        times=data["data"]["timings"];
        city="Lokasi GPS aktif";
        loading=false;
      });
    }catch(e){
      setState(()=>loading=false);
    }
  }

  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title:const Text("Jadwal Solat")),
      body: loading ? const Center(child:CircularProgressIndicator()) :
      ListView(
        padding:const EdgeInsets.all(16),
        children:[
          Text(city,style:const TextStyle(fontSize:18)),
          const SizedBox(height:15),
          ...?times?.entries.map((e)=>Card(
            child:ListTile(
              title:Text(e.key),
              trailing:Text(e.value.toString(),style:const TextStyle(fontWeight:FontWeight.bold)),
            ),
          ))
        ],
      ),
    );
  }
}
