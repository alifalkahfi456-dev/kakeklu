import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

// ==================== SIMPLE STORAGE ====================
class SimpleStorage {
  static String? _sessionKey;
  
  static Future<void> saveSessionKey(String key) async {
    _sessionKey = key;
  }
  
  static Future<String?> getSessionKey() async {
    return _sessionKey;
  }
  
  static Future<void> clearSession() async {
    _sessionKey = null;
  }
}

// ==================== SIMPLE HTTP CLIENT (LENGKAP) ====================
class SimpleHttpClient {
  static final http.Client _client = http.Client();
  static String BASE_URL = "http://king.daiyat.store:9907";
  
  static Future<http.Response?> get(String path, {Map<String, String>? headers}) async {
    try {
      final response = await _client.get(
        Uri.parse('$BASE_URL$path'),
        headers: headers ?? {'Content-Type': 'application/json'},
      ).timeout(Duration(seconds: 30));
      return response;
    } catch (e) {
      return null;
    }
  }
  
  // ✅ TAMBAHKAN METHOD DELETE
  static Future<http.Response?> delete(String path, {Map<String, String>? headers}) async {
    try {
      final response = await _client.delete(
        Uri.parse('$BASE_URL$path'),
        headers: headers ?? {'Content-Type': 'application/json'},
      ).timeout(Duration(seconds: 30));
      return response;
    } catch (e) {
      return null;
    }
  }
  
  static void close() {
    _client.close();
  }
}

// ==================== BUG SENDER PAGE ====================
class BugSenderPage extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;

  BugSenderPage({
    super.key,
    required this.username,
    required this.role,
    required this.sessionKey,
  });

  @override
  State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage> {
  List<dynamic> senderList = [];
  List<dynamic> globalSenderList = [];
  bool isLoading = false;
  bool isRefreshing = false;
  String? errorMessage;
  String? _sessionKey;
  bool _isAuthenticated = false;
  
  final Color bgDark = Color(0xFF0D0221);
  final Color primaryPurple = Color(0xFF7B1FA2);
  final Color accentPurple = Color(0xFFEA80FC);
  final Color cardGlass = Colors.white.withOpacity(0.05);
  final Color borderGlass = Colors.white.withOpacity(0.1);

  bool get isOwner => widget.role.toLowerCase() == 'owner';

  @override
  void initState() {
    super.initState();

    _sessionKey = widget.sessionKey;

    Future.microtask(() async {
      if (_sessionKey == null || _sessionKey!.isEmpty) {
        if (mounted) {
          Navigator.of(context).pushReplacementNamed('/login');
        }
        return;
      }

      if (mounted) setState(() => _isAuthenticated = true);
      await _fetchData();
    });
  }

  @override
  void dispose() {
    SimpleHttpClient.close();
    super.dispose();
  }


  
  Future<void> _fetchData() async {
    await _fetchSenders();
    if (isOwner) {
      await _fetchGlobalSenders();
    }
  }
  
  Future<void> _refreshData() async {
    if (isRefreshing) return;
    setState(() => isRefreshing = true);
    await _fetchData();
    setState(() => isRefreshing = false);
  }
  
  Future<void> _fetchSenders() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });
    
    try {
      final response = await SimpleHttpClient.get('/mySender?key=$_sessionKey');
      if (response == null) throw Exception('No response');
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            final allSenders = data['connections'] ?? [];
            senderList = allSenders.where((sender) {
              final folder = sender['folder']?.toString().toLowerCase() ?? '';
              return folder != 'global';
            }).toList();
          });
        } else {
          setState(() => errorMessage = data['message'] ?? 'Failed to fetch senders');
        }
      } else if (response.statusCode == 401) {
        await SimpleStorage.clearSession();
        if (mounted) Navigator.of(context).pushReplacementNamed('/login');
      } else {
        setState(() => errorMessage = 'Server error: ${response.statusCode}');
      }
    } catch (e) {
      setState(() => errorMessage = 'Connection failed. Please check your internet.');
    } finally {
      setState(() => isLoading = false);
    }
  }
  
  Future<void> _fetchGlobalSenders() async {
    try {
      final response = await SimpleHttpClient.get('/mySender?key=$_sessionKey');
      if (response != null && response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            final allSenders = data['connections'] ?? [];
            globalSenderList = allSenders.where((sender) {
              final folder = sender['folder']?.toString().toLowerCase() ?? '';
              return folder == 'global';
            }).toList();
          });
        }
      }
    } catch (e) {
      // Silent error
    }
  }
  
  void _showAddSenderDialog() {
    final phoneController = TextEditingController();
    bool isGlobal = false;
    
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setStateDialog) {
          return AlertDialog(
            backgroundColor: bgDark,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            title: Row(
              children: [
                Icon(Icons.add_circle, color: accentPurple),
                SizedBox(width: 12),
                Text('Add New Sender', style: TextStyle(color: Colors.white)),
              ],
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: phoneController,
                  keyboardType: TextInputType.phone,
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: 'Phone Number',
                    labelStyle: TextStyle(color: accentPurple),
                    hintText: '628123456789',
                    hintStyle: TextStyle(color: Colors.white54),
                    prefixIcon: Icon(Icons.phone, color: accentPurple),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                SizedBox(height: 8),
                Text('Format: 628xxxxxxxxx (Indonesia)', style: TextStyle(color: Colors.white38, fontSize: 10)),
                if (isOwner) ...[
                  SizedBox(height: 16),
                  Container(
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(color: primaryPurple.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                    child: Row(
                      children: [
                        Icon(Icons.public, color: accentPurple),
                        SizedBox(width: 12),
                        Expanded(child: Text('Global Sender (Accessible by all users)', style: TextStyle(color: Colors.white, fontSize: 12))),
                        Switch(
                          value: isGlobal,
                          onChanged: (value) => setStateDialog(() => isGlobal = value),
                          activeColor: accentPurple,
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
            actions: [
              TextButton(
                onPressed: () { phoneController.dispose(); Navigator.pop(context); },
                child: Text('CANCEL', style: TextStyle(color: Colors.white54)),
              ),
              ElevatedButton(
                onPressed: () async {
                  final number = phoneController.text.trim();
                  if (number.isEmpty || !RegExp(r'^628[0-9]{8,12}$').hasMatch(number)) {
                    _showSnackBar('Please enter a valid Indonesian phone number', isError: true);
                    return;
                  }
                  phoneController.dispose();
                  Navigator.pop(context);
                  await _addSender(number, isGlobal);
                },
                child: Text('ADD SENDER'),
              ),
            ],
          );
        },
      ),
    );
  }
  
  Future<void> _addSender(String number, bool isGlobal) async {
    setState(() => isLoading = true);
    
    try {
      String url = '/getPairing?key=$_sessionKey&number=$number';
      if (isGlobal && isOwner) url += '&folder=global';
      
      final response = await SimpleHttpClient.get(url);
      if (response == null) throw Exception('No response');
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          _showPairingDialog(number, data['pairingCode'], isGlobal);
          _showSnackBar('Pairing code generated successfully!');
        } else {
          _showSnackBar(data['message'] ?? 'Failed to generate pairing code', isError: true);
        }
      } else {
        _showSnackBar('Server error: ${response.statusCode}', isError: true);
      }
    } catch (e) {
      _showSnackBar('Connection failed. Please try again.', isError: true);
    } finally {
      setState(() => isLoading = false);
      await _refreshData();
    }
  }
  
  void _showPairingDialog(String number, String code, bool isGlobal) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: bgDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Column(
          children: [
            Container(
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(color: primaryPurple.withOpacity(0.2), shape: BoxShape.circle),
              child: Icon(Icons.qr_code_2, color: accentPurple, size: 40),
            ),
            SizedBox(height: 15),
            Text('Pairing Required', style: TextStyle(color: Colors.white, fontSize: 18)),
          ],
        ),
        content: Container(
          padding: EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: accentPurple.withOpacity(0.3)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Number: $number', style: TextStyle(color: Colors.white)),
              if (isGlobal) ...[
                SizedBox(height: 8),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(color: Colors.blue.withOpacity(0.2), borderRadius: BorderRadius.circular(8)),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.public, color: Colors.blueAccent, size: 14),
                      SizedBox(width: 4),
                      Text('Global Sender', style: TextStyle(color: Colors.blueAccent, fontSize: 10)),
                    ],
                  ),
                ),
              ],
              SizedBox(height: 20),
              Container(
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: accentPurple, width: 2),
                  boxShadow: [BoxShadow(color: accentPurple.withOpacity(0.4), blurRadius: 15)],
                ),
                child: SelectableText(
                  code,
                  style: TextStyle(color: accentPurple, fontSize: 28, fontWeight: FontWeight.bold, letterSpacing: 4, fontFamily: 'monospace'),
                ),
              ),
              SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  icon: Icon(Icons.copy, color: accentPurple),
                  label: Text('COPY CODE', style: TextStyle(color: accentPurple)),
                  onPressed: () async {
                    await Clipboard.setData(ClipboardData(text: code));
                    if (mounted) _showSnackBar('Code copied to clipboard!');
                  },
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('CLOSE', style: TextStyle(color: Colors.white)),
          ),
          ElevatedButton(
            onPressed: () { Navigator.pop(context); _refreshData(); },
            child: Text('REFRESH LIST'),
          ),
        ],
      ),
    );
  }
  
  Future<void> _deleteSender(String senderId, bool isGlobal) async {
    if (isGlobal && !isOwner) {
      _showSnackBar('Only Owner can delete global senders!', isError: true);
      return;
    }
    
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: Colors.orangeAccent),
            SizedBox(width: 12),
            Text('Confirm Delete', style: TextStyle(color: Colors.white)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              isGlobal ? '⚠️ This is a GLOBAL sender!' : 'Are you sure you want to delete this sender?',
              style: TextStyle(color: isGlobal ? Colors.orangeAccent : Colors.white70),
            ),
            SizedBox(height: 8),
            Text('This action cannot be undone.', style: TextStyle(color: Colors.white54, fontSize: 12)),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text('CANCEL', style: TextStyle(color: Colors.white))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
            onPressed: () => Navigator.pop(context, true),
            child: Text('DELETE', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    
    if (confirmed == true) {
      setState(() => isLoading = true);
      
      try {
        final response = await SimpleHttpClient.delete('/deleteSender?key=$_sessionKey&id=$senderId');
        if (response == null) throw Exception('No response');
        
        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data['valid'] == true) {
            _showSnackBar('Sender deleted successfully!');
            await _refreshData();
          } else {
            _showSnackBar(data['message'] ?? 'Failed to delete sender', isError: true);
          }
        } else {
          _showSnackBar('Server error: ${response.statusCode}', isError: true);
        }
      } catch (e) {
        _showSnackBar('Connection failed. Please try again.', isError: true);
      } finally {
        setState(() => isLoading = false);
      }
    }
  }
  
  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: TextStyle(color: Colors.white)),
        backgroundColor: isError ? Colors.redAccent : primaryPurple,
        behavior: SnackBarBehavior.floating,
        duration: Duration(seconds: isError ? 4 : 2),
      ),
    );
  }
  
  Widget _buildSenderCard(Map<String, dynamic> sender, {bool isGlobal = false}) {
    final name = sender['sessionName'] ?? 'WhatsApp Sender';
    final phone = sender['phone'] ?? '📱 Personal Sender';
    
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        gradient: isGlobal ? LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.blue.withOpacity(0.1), primaryPurple.withOpacity(0.1)],
        ) : null,
        color: isGlobal ? null : cardGlass,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: isGlobal ? Colors.blueAccent.withOpacity(0.3) : borderGlass, width: 1),
      ),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: isGlobal ? Colors.blue.withOpacity(0.2) : primaryPurple.withOpacity(0.2),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(isGlobal ? Icons.public : Icons.phone_android, color: isGlobal ? Colors.blueAccent : accentPurple),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(child: Text(name, style: TextStyle(color: Colors.white, fontSize: 16), overflow: TextOverflow.ellipsis)),
                          if (isGlobal) ...[
                            SizedBox(width: 8),
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(color: Colors.blue.withOpacity(0.2), borderRadius: BorderRadius.circular(4)),
                              child: Text('GLOBAL', style: TextStyle(color: Colors.blueAccent, fontSize: 8, fontWeight: FontWeight.bold)),
                            ),
                          ],
                        ],
                      ),
                      SizedBox(height: 4),
                      Text(phone, style: TextStyle(color: Colors.white54, fontSize: 12, fontFamily: 'monospace')),
                    ],
                  ),
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.green.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.green.withOpacity(0.3)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(width: 8, height: 8, decoration: BoxDecoration(color: Colors.green, shape: BoxShape.circle)),
                      SizedBox(width: 4),
                      Text('CONNECTED', style: TextStyle(color: Colors.green, fontSize: 10, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: _refreshData,
                    style: OutlinedButton.styleFrom(side: BorderSide(color: Colors.white.withOpacity(0.2))),
                    child: Text('REFRESH'),
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent.withOpacity(0.2), foregroundColor: Colors.redAccent),
                    onPressed: () => _deleteSender(sender['id'] ?? sender['sessionName'], isGlobal),
                    child: Text('DELETE'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildEmptyState(String type) {
    final isGlobal = type == 'global';
    final canAdd = type == 'personal' || isOwner;
    
    return Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: EdgeInsets.all(30),
              decoration: BoxDecoration(
                color: primaryPurple.withOpacity(0.1),
                shape: BoxShape.circle,
                border: Border.all(color: primaryPurple.withOpacity(0.3)),
              ),
              child: Icon(isGlobal ? Icons.public : Icons.phone_iphone, color: accentPurple, size: 80),
            ),
            SizedBox(height: 24),
            Text(
              isGlobal ? 'No Global Senders Found' : 'No Personal Senders Found',
              style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 12),
            Text(
              isGlobal ? 'Add global senders to share with all users' : 'Add your first WhatsApp sender to get started',
              style: TextStyle(color: Colors.white54, fontSize: 14),
              textAlign: TextAlign.center,
            ),
            if (canAdd) ...[
              SizedBox(height: 40),
              ElevatedButton.icon(
                icon: Icon(Icons.add),
                label: Text('ADD SENDER'),
                onPressed: _showAddSenderDialog,
                style: ElevatedButton.styleFrom(padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12)),
              ),
            ],
          ],
        ),
      ),
    );
  }
  
  @override
  Widget build(BuildContext context) {
    if (!_isAuthenticated) {
      return Scaffold(
        backgroundColor: Color(0xFF0D0221),
        body: Center(child: CircularProgressIndicator()),
      );
    }
    
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        backgroundColor: bgDark,
        elevation: 0,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Sender Management', style: TextStyle(color: Colors.white)),
            if (isOwner) Text('Owner Access • Full Control', style: TextStyle(color: accentPurple, fontSize: 12)),
          ],
        ),
        actions: [
          if (isOwner)
            Container(
              margin: EdgeInsets.only(right: 16),
              child: Row(
                children: [
                  Icon(Icons.admin_panel_settings, color: accentPurple, size: 20),
                  SizedBox(width: 4),
                  Text('OWNER', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white)),
                ],
              ),
            ),
          IconButton(
            icon: Icon(Icons.logout, color: Colors.white),
            onPressed: () async {
              await SimpleStorage.clearSession();
              if (mounted) Navigator.of(context).pushReplacementNamed('/login');
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _refreshData,
        color: accentPurple,
        child: isLoading && senderList.isEmpty
            ? Center(child: CircularProgressIndicator())
            : SingleChildScrollView(
                physics: AlwaysScrollableScrollPhysics(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                      child: Row(
                        children: [
                          Icon(Icons.person, color: accentPurple, size: 20),
                          SizedBox(width: 8),
                          Text('Personal Senders', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
                          Spacer(),
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(color: primaryPurple.withOpacity(0.2), borderRadius: BorderRadius.circular(12)),
                            child: Text('${senderList.length}', style: TextStyle(color: accentPurple, fontWeight: FontWeight.bold)),
                          ),
                        ],
                      ),
                    ),
                    senderList.isEmpty
                        ? _buildEmptyState('personal')
                        : ListView.builder(
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemCount: senderList.length,
                            itemBuilder: (ctx, i) => _buildSenderCard(senderList[i]),
                          ),
                    if (isOwner) ...[
                      SizedBox(height: 24),
                      Padding(
                        padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
                        child: Row(
                          children: [
                            Icon(Icons.public, color: Colors.blueAccent, size: 20),
                            SizedBox(width: 8),
                            Text('Global Senders', style: TextStyle(color: Colors.blueAccent, fontSize: 16, fontWeight: FontWeight.bold)),
                            Spacer(),
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(color: Colors.blue.withOpacity(0.2), borderRadius: BorderRadius.circular(12)),
                              child: Text('${globalSenderList.length}', style: TextStyle(color: Colors.blueAccent, fontWeight: FontWeight.bold)),
                            ),
                          ],
                        ),
                      ),
                      globalSenderList.isEmpty
                          ? _buildEmptyState('global')
                          : ListView.builder(
                              shrinkWrap: true,
                              physics: NeverScrollableScrollPhysics(),
                              itemCount: globalSenderList.length,
                              itemBuilder: (ctx, i) => _buildSenderCard(globalSenderList[i], isGlobal: true),
                            ),
                    ],
                    SizedBox(height: 80),
                  ],
                ),
              ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddSenderDialog,
        icon: Icon(Icons.add),
        label: Text('ADD SENDER'),
      ),
    );
  }
}