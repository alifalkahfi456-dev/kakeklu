import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'dart:ui';
import 'lawliet/.dart';
final baseUrl = Api.api;

class AttackPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const AttackPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<AttackPage> createState() => _AttackPageState();
}

class _AttackPageState extends State<AttackPage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  final ScrollController _bugScrollController = ScrollController();
  

  // Animation controllers
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late AnimationController _glowController;
  late AnimationController _pulseController;
  late AnimationController _rotateController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _glowAnimation;
  late Animation<double> _pulseAnimation;
  late Animation<double> _rotateAnimation;

  // Video controllers
  late VideoPlayerController _videoController;
  bool _videoInitialized = false;
  bool _videoError = false;

  // State variables
  String selectedBugId = "";
  bool _isSending = false;
  bool _isSuccess = false;

  // Sender variables
  String _senderType = "private";
  int _globalSenderCount = 3;
  bool _isLoadingSenders = false;

  // DARK YELLOW / GOLDEN BLACK THEME
  // BLUE GLASS / CYBER THEME
final Color _primaryColor = const Color(0xFF2196F3);
final Color _secondaryColor = const Color(0xFF1565C0);
final Color _accentColor = const Color(0xFF64B5F6);
final Color _successColor = const Color(0xFF4FC3F7);
final Color _warningColor = const Color(0xFF29B6F6);
final Color _darkBg = const Color(0xFF050B18);
final Color _darkerBg = const Color(0xFF02050D);
final Color _surfaceColor = const Color(0xFF0D1525);
final Color _cardColor = const Color(0xFF2196F3).withOpacity(0.08);
final Color _glowColor1 = const Color(0xFF7FDBFF);
final Color _glowColor2 = const Color(0xFF3AA0FF);
final Color _glowColor3 = const Color(0xFF5EC2FF);
final Color _goldColor = const Color(0xFF4A90E2);
final Color _roseColor = const Color(0xFF6BB6FF);

  bool get canUseGlobalSender {
    final allowedRoles = ["founder", "partner", "tk", "moderator", "tk", "high tk", "dev"];
    return allowedRoles.contains(widget.role.toLowerCase());
  }

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeVideoController();
    _setDefaultBug();
    _startAnimations();

    if (!canUseGlobalSender) {
      _senderType = "private";
    }

    _fetchGlobalSenderCount();
  }

  Future<void> _fetchGlobalSenderCount() async {
    if (!mounted) return;
    setState(() => _isLoadingSenders = true);
    try {
      final res = await http.get(Uri.parse("$baseUrl/api/whatsapp/mySender?key=${widget.sessionKey}"));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);

        if (data['valid'] == true && data['connections'] != null) {
          final globalList = data['connections']['global'] as List?;
          setState(() {
            _globalSenderCount = globalList?.length ?? 0;
          });
        }
      }
    } catch (e) {
      debugPrint("Error fetching global sender count: $e");
    } finally {
      if (mounted) {
        setState(() => _isLoadingSenders = false);
      }
    }
  }

  void _initializeAnimations() {
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1300),
    );

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2500),
    );
    _glowController.repeat(reverse: true);

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    );
    _pulseController.repeat(reverse: true);

    _rotateController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    );
    _rotateController.repeat();

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeOutCubic),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.4),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic));

    _glowAnimation = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOutSine),
    );

    _pulseAnimation = Tween<double>(begin: 0.92, end: 1.08).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOutSine),
    );

    _rotateAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _rotateController, curve: Curves.linear),
    );
  }

  void _startAnimations() {
    _fadeController.forward();
    Future.delayed(const Duration(milliseconds: 200), () {
      _slideController.forward();
    });
  }

  void _setDefaultBug() {
    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }
  }

  void _initializeVideoController() {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/banner.mp4')
        ..initialize().then((_) {
          if (mounted) {
            setState(() {
              _videoInitialized = true;
            });
            _videoController.setLooping(true);
            _videoController.play();
            _videoController.setVolume(0);
          }
        }).catchError((error) {
          debugPrint('Video initialization error: $error');
          if (mounted) {
            setState(() {
              _videoError = true;
            });
          }
        });
    } catch (e) {
      debugPrint('Video controller creation error: $e');
      if (mounted) {
        setState(() {
          _videoError = true;
        });
      }
    }
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d]'), '');
    if (cleaned.startsWith('0') || cleaned.length < 8) return null;
    return cleaned;
  }

  Future<void> _sendBug() async {
    if (_isSending) return;

    setState(() {
      _isSending = true;
    });

    final rawInput = targetController.text.trim();
    final target = formatPhoneNumber(rawInput);
    final key = widget.sessionKey;

    if (target == null || key.isEmpty) {
      _showAlert("Invalid Number", "Use international format (e.g., 628123456789, not 08xxx).");
      setState(() {
        _isSending = false;
      });
      return;
    }

    try {
      final res = await http.get(Uri.parse("$baseUrl/api/whatsapp/sendBug?key=$key&target=$target&bug=$selectedBugId&senderType=$_senderType"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("Cooldown", "Please wait a moment before sending again.");
      } else if (data["senderOn"] == false) {
        _showAlert("Failed", "Failed to send bug. Sender empty, contact seller.");
      } else if (data["valid"] == false) {
        _showAlert("Failed", data["message"] ?? "Invalid session key or access denied.");
      } else if (data["sended"] == false) {
        _showAlert("Failed", "Failed to send bug. Server may be under maintenance.");
      } else {
        setState(() {
          _isSuccess = true;
        });
        _showSuccessPopup(target);
      }
    } catch (_) {
      _showAlert("Connection Error", "Failed to connect to the server. Please try again.");
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  void _showSuccessPopup(String target) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => _SuccessDialog(
        target: target,
        senderType: _senderType,
        onDismiss: () {
          Navigator.of(context).pop();
          setState(() {
            _isSuccess = false;
          });
        },
      ),
    );
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _surfaceColor.withOpacity(0.98),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(28),
          side: BorderSide(color: _glowColor1.withOpacity(0.4), width: 1),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: _glowColor1.withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _glowColor1.withOpacity(0.3), width: 1),
              ),
              child: Icon(title.contains("Error") ? Icons.error_outline_rounded : Icons.warning_amber_rounded,
                  color: _glowColor1, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'Rajdhani',
                  letterSpacing: 1.5,
                ),
              ),
            ),
          ],
        ),
        content: Text(
          msg,
          style: TextStyle(
            color: Colors.white.withOpacity(0.65),
            fontSize: 13,
            height: 1.6,
            fontFamily: 'Rajdhani',
            fontWeight: FontWeight.w500,
          ),
        ),
        actionsPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              backgroundColor: Colors.white.withOpacity(0.04),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
                side: BorderSide(color: Colors.white.withOpacity(0.08), width: 1),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
            ),
            child: const Text(
              "CLOSE",
              style: TextStyle(
                color: Colors.white60,
                fontFamily: 'Rajdhani',
                fontWeight: FontWeight.w700,
                fontSize: 12,
                letterSpacing: 2,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== UI BUILDERS ====================

  Widget _buildAnimatedBackground() {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: _darkerBg),
        if (_videoInitialized && !_videoError)
          FittedBox(
            fit: BoxFit.cover,
            child: SizedBox(
              width: _videoController.value.size.width,
              height: _videoController.value.size.height,
              child: Opacity(opacity: 0.50, child: VideoPlayer(_videoController)),
            ),
          )
        else
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  const Color(0xFF071421),
                  _darkerBg,
                  const Color(0xFF020611),
                ],
              ),
            ),
          ),
        BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 1.0, sigmaY: 1.0),
          child: Container(color: Colors.transparent),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black.withOpacity(0.10),
                const Color(0xFF07101B).withOpacity(0.42),
                _darkerBg.withOpacity(0.92),
              ],
              stops: const [0.0, 0.50, 1.0],
            ),
          ),
        ),
        IgnorePointer(
          child: CustomPaint(
            painter: _DottedPatternPainter(
              dotColor: _glowColor1.withOpacity(0.115),
              lineColor: _glowColor1.withOpacity(0.035),
            ),
            size: Size.infinite,
          ),
        ),
        AnimatedBuilder(
          animation: _glowAnimation,
          builder: (context, _) => IgnorePointer(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(0.85, -0.10),
                  radius: 1.10,
                  colors: [
                    _glowColor1.withOpacity(0.16 * _glowAnimation.value),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: Alignment.center,
              radius: 1.16,
              colors: [Colors.transparent, Colors.black.withOpacity(0.55)],
            ),
          ),
        ),
      ],
    );
  }


  Widget _buildGlassCard({required Widget child, EdgeInsetsGeometry? padding}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
        child: Container(
          width: double.infinity,
          padding: padding ?? const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFF07111E).withOpacity(0.76),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _glowColor1.withOpacity(0.10), width: 1),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.38), blurRadius: 20, offset: const Offset(0, 10)),
              BoxShadow(color: _glowColor1.withOpacity(0.035), blurRadius: 18),
            ],
          ),
          child: child,
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Row(
      children: [
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: _glowColor1.withOpacity(0.12),
            borderRadius: BorderRadius.circular(13),
            border: Border.all(color: _glowColor1.withOpacity(0.32)),
            boxShadow: [BoxShadow(color: _glowColor1.withOpacity(0.18), blurRadius: 12)],
          ),
          child: Icon(Icons.bolt_rounded, color: _glowColor1, size: 22),
        ),
        const SizedBox(width: 10),
        const Text(
          'LAWLIET BUG',
          style: TextStyle(
            color: Colors.white,
            fontSize: 23,
            fontFamily: 'Rajdhani',
            fontWeight: FontWeight.w900,
            letterSpacing: 2.8,
          ),
        ),
        const Spacer(),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
          decoration: BoxDecoration(
            color: _glowColor1.withOpacity(0.09),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _glowColor1.withOpacity(0.15)),
          ),
          child: Text(
            'v4.0',
            style: TextStyle(
              color: _glowColor1.withOpacity(0.82),
              fontSize: 13,
              fontFamily: 'Rajdhani',
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSectionHeader(IconData icon, String title, {Widget? trailing, Color? dotColor}) {
    return Row(
      children: [
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: _glowColor1.withOpacity(0.09),
            borderRadius: BorderRadius.circular(13),
            border: Border.all(color: _glowColor1.withOpacity(0.18)),
          ),
          child: Icon(icon, color: _glowColor1.withOpacity(0.76), size: 22),
        ),
        const SizedBox(width: 8),
        if (dotColor != null) ...[
          Container(
            width: 7,
            height: 7,
            decoration: BoxDecoration(
              color: dotColor,
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: dotColor.withOpacity(0.6), blurRadius: 8)],
            ),
          ),
          const SizedBox(width: 7),
        ],
        Text(
          title,
          style: TextStyle(
            color: Colors.white.withOpacity(0.74),
            fontSize: 16,
            fontFamily: 'Rajdhani',
            fontWeight: FontWeight.w800,
            letterSpacing: 2.4,
          ),
        ),
        const Spacer(),
        if (trailing != null) trailing,
      ],
    );
  }

  Widget _buildUserProfileCard() {
    return _buildGlassCard(
      padding: const EdgeInsets.fromLTRB(24, 22, 24, 24),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 74,
                height: 74,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFF0A1B2B),
                  border: Border.all(color: _glowColor1.withOpacity(0.25)),
                  boxShadow: [BoxShadow(color: _glowColor1.withOpacity(0.13), blurRadius: 12)],
                ),
                child: ClipOval(
                  child: Image.asset(
                    'assets/images/abc.jpg',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Icon(Icons.person_rounded, color: _glowColor1, size: 23),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.username,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontFamily: 'Rajdhani',
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      widget.role.toUpperCase(),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: _glowColor1.withOpacity(0.72),
                        fontSize: 13,
                        fontFamily: 'Rajdhani',
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.22),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _glowColor1.withOpacity(0.10)),
                ),
                child: Text(
                  'ACTIVE ${widget.expiredDate}',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.62),
                    fontSize: 11,
                    fontFamily: 'Rajdhani',
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.7,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 11),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.20),
              borderRadius: BorderRadius.circular(13),
              border: Border.all(color: Colors.white.withOpacity(0.035)),
            ),
            child: Row(
              children: [
                _buildStatItem(Icons.bug_report_rounded, widget.listBug.length.toString(), 'Total Bug', _glowColor1),
                _buildDivider(),
                _buildStatItem(Icons.local_fire_department_rounded, 'GACOR', 'System Mode', const Color(0xFF20D6A0)),
                _buildDivider(),
                _buildStatItem(Icons.verified_rounded, 'ACTIVE', 'Status', const Color(0xFF20D6A0)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDivider() {
    return Container(width: 1, height: 34, color: Colors.white.withOpacity(0.045));
  }

  Widget _buildStatItem(IconData icon, String value, String label, Color color) {
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 25,
            height: 25,
            decoration: BoxDecoration(
              color: color.withOpacity(0.11),
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: color.withOpacity(0.12), blurRadius: 10)],
            ),
            child: Icon(icon, color: color.withOpacity(0.82), size: 13),
          ),
          const SizedBox(height: 5),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: Colors.white.withOpacity(0.88),
              fontSize: 10,
              fontFamily: 'Rajdhani',
              fontWeight: FontWeight.w900,
              letterSpacing: 0.7,
            ),
          ),
          const SizedBox(height: 1),
          Text(
            label,
            style: TextStyle(
              color: Colors.white.withOpacity(0.32),
              fontSize: 11,
              fontFamily: 'Rajdhani',
              fontWeight: FontWeight.w700,
              letterSpacing: 0.8,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTargetInputCard() {
    return _buildGlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(Icons.phone_android_rounded, 'NOMOR TARGET'),
          const SizedBox(height: 10),
          Container(
            height: 68,
            decoration: BoxDecoration(
              color: const Color(0xFF050A12).withOpacity(0.78),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _glowColor1.withOpacity(0.07)),
            ),
            child: TextField(
              controller: targetController,
              keyboardType: TextInputType.phone,
              cursorColor: _glowColor1,
              style: TextStyle(
                color: Colors.white.withOpacity(0.86),
                fontFamily: 'Rajdhani',
                fontSize: 18,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.5,
              ),
              decoration: InputDecoration(
                border: InputBorder.none,
                prefixIcon: Icon(Icons.search_rounded, color: Colors.white.withOpacity(0.25), size: 17),
                hintText: '628xxxxxxx',
                hintStyle: TextStyle(
                  color: Colors.white.withOpacity(0.28),
                  fontFamily: 'Rajdhani',
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                ),
                contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
              ),
            ),
          ),
        ],
      ),
    );
  }

  int get _selectedBugIndex {
    final index = widget.listBug.indexWhere((bug) => bug['bug_id'] == selectedBugId);
    return index < 0 ? 0 : index;
  }

  void _selectBugAt(int index) {
    if (index < 0 || index >= widget.listBug.length) return;
    final bug = widget.listBug[index];
    setState(() => selectedBugId = bug['bug_id']);

    if (_bugScrollController.hasClients) {
      final targetOffset = (index * 180.0).clamp(
        0.0,
        _bugScrollController.position.maxScrollExtent,
      );
      _bugScrollController.animateTo(
        targetOffset,
        duration: const Duration(milliseconds: 320),
        curve: Curves.easeOutCubic,
      );
    }
  }

  Widget _buildBugDots() {
    final total = widget.listBug.length;
    if (total <= 1) return const SizedBox.shrink();

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(total, (i) {
        final active = i == _selectedBugIndex;
        return GestureDetector(
          onTap: () => _selectBugAt(i),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 240),
            curve: Curves.easeOutCubic,
            width: active ? 36 : 10,
            height: 10,
            margin: const EdgeInsets.symmetric(horizontal: 4),
            decoration: BoxDecoration(
              color: active ? _glowColor1 : Colors.white.withOpacity(0.24),
              borderRadius: BorderRadius.circular(999),
              boxShadow: active
                  ? [BoxShadow(color: _glowColor1.withOpacity(0.55), blurRadius: 14)]
                  : null,
            ),
          ),
        );
      }),
    );
  }

  Widget _buildBugSelectionCard() {
    return _buildGlassCard(
      padding: const EdgeInsets.fromLTRB(24, 22, 0, 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(right: 24),
            child: _buildSectionHeader(Icons.adjust_rounded, 'PILIH BUG', dotColor: const Color(0xFFE64261)),
          ),
          const SizedBox(height: 22),
          SizedBox(
            height: 154,
            child: widget.listBug.isEmpty
                ? Center(
                    child: Text(
                      'No bugs available',
                      style: TextStyle(color: Colors.white.withOpacity(0.35), fontFamily: 'Rajdhani'),
                    ),
                  )
                : ListView.builder(
                    controller: _bugScrollController,
                    scrollDirection: Axis.horizontal,
                    physics: const BouncingScrollPhysics(),
                    itemCount: widget.listBug.length,
                    itemBuilder: (ctx, i) {
                      final bug = widget.listBug[i];
                      final isSelected = selectedBugId == bug['bug_id'];
                      return GestureDetector(
                        onTap: () => _selectBugAt(i),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 220),
                          curve: Curves.easeOutCubic,
                          width: 166,
                          margin: const EdgeInsets.only(right: 14),
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: isSelected
                                  ? [
                                      _glowColor1.withOpacity(0.30),
                                      const Color(0xFF0B3542).withOpacity(0.82),
                                    ]
                                  : [
                                      const Color(0xFF060D18).withOpacity(0.88),
                                      const Color(0xFF0B1020).withOpacity(0.78),
                                    ],
                            ),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: isSelected ? _glowColor1.withOpacity(0.92) : _glowColor1.withOpacity(0.10),
                              width: isSelected ? 1.7 : 1,
                            ),
                            boxShadow: isSelected
                                ? [
                                    BoxShadow(color: _glowColor1.withOpacity(0.28), blurRadius: 24, offset: const Offset(0, 8)),
                                    BoxShadow(color: _glowColor1.withOpacity(0.14), blurRadius: 32),
                                  ]
                                : null,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    width: 52,
                                    height: 52,
                                    decoration: BoxDecoration(
                                      color: _glowColor1.withOpacity(isSelected ? 0.18 : 0.10),
                                      shape: BoxShape.circle,
                                      border: Border.all(color: _glowColor1.withOpacity(isSelected ? 0.45 : 0.12)),
                                    ),
                                    child: Icon(Icons.security_rounded, color: _glowColor1.withOpacity(0.92), size: 28),
                                  ),
                                  const Spacer(),
                                  AnimatedContainer(
                                    duration: const Duration(milliseconds: 220),
                                    width: isSelected ? 34 : 12,
                                    height: isSelected ? 34 : 12,
                                    decoration: BoxDecoration(
                                      color: isSelected ? const Color(0xFF20F39B) : Colors.white.withOpacity(0.16),
                                      shape: BoxShape.circle,
                                      boxShadow: isSelected
                                          ? [BoxShadow(color: const Color(0xFF20F39B).withOpacity(0.72), blurRadius: 18)]
                                          : null,
                                    ),
                                    child: isSelected ? Icon(Icons.check_rounded, color: _darkerBg, size: 22) : null,
                                  ),
                                ],
                              ),
                              const Spacer(),
                              Text(
                                bug['bug_name'].toString().toUpperCase(),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.90),
                                  fontSize: 16,
                                  fontFamily: 'Rajdhani',
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1.0,
                                ),
                              ),
                              const SizedBox(height: 10),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.22),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: _glowColor1.withOpacity(isSelected ? 0.38 : 0.10)),
                                ),
                                child: Text(
                                  bug['bug_id'].toString(),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: (isSelected ? _glowColor1 : Colors.white).withOpacity(isSelected ? 0.86 : 0.40),
                                    fontSize: 12,
                                    fontFamily: 'Rajdhani',
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: 1.0,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
          const SizedBox(height: 22),
          Padding(
            padding: const EdgeInsets.only(right: 24),
            child: _buildBugDots(),
          ),
        ],
      ),
    );
  }


  Widget _buildSenderSelectionCard() {
    return _buildGlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(
            Icons.wifi_tethering_rounded,
            'PILIH SENDER',
            trailing: GestureDetector(
              onTap: _isLoadingSenders ? null : _fetchGlobalSenderCount,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFFE64261).withOpacity(0.12),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFFE64261).withOpacity(0.22)),
                ),
                child: _isLoadingSenders
                    ? const SizedBox(width: 10, height: 10, child: CircularProgressIndicator(strokeWidth: 1.6))
                    : const Text(
                        'Close dulu',
                        style: TextStyle(
                          color: Color(0xFFE64261),
                          fontSize: 7,
                          fontFamily: 'Rajdhani',
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                        ),
                      ),
              ),
            ),
          ),
          const SizedBox(height: 11),
          Row(
            children: [
              Expanded(
                child: _buildSenderOption(
                  title: 'Private',
                  icon: Icons.person_rounded,
                  subtitle: 'Bawaan akun',
                  type: 'private',
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: _buildSenderOption(
                  title: 'Global',
                  icon: Icons.public_rounded,
                  subtitle: '$_globalSenderCount sender',
                  type: 'global',
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            'Pilih sender yang ingin di gunakan.',
            style: TextStyle(
              color: Colors.white.withOpacity(0.22),
              fontSize: 11,
              fontFamily: 'Rajdhani',
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSenderOption({
    required String title,
    required IconData icon,
    required String subtitle,
    required String type,
  }) {
    final isActive = _senderType == type;
    final isDisabled = type == 'global' && !canUseGlobalSender;

    return GestureDetector(
      onTap: () {
        if (isDisabled) {
          _showAlert('Sender Required', 'Tidak ada sender aktif. Sending hanya gunakan global atau private.');
          return;
        }
        setState(() => _senderType = type);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        height: 96,
        decoration: BoxDecoration(
          color: isActive ? _glowColor1.withOpacity(0.95) : const Color(0xFF050A12).withOpacity(0.62),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: isActive ? _glowColor1.withOpacity(0.95) : Colors.white.withOpacity(0.065),
          ),
          boxShadow: isActive ? [BoxShadow(color: _glowColor1.withOpacity(0.22), blurRadius: 14)] : null,
        ),
        child: Stack(
          children: [
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, color: isActive ? _darkerBg : Colors.white.withOpacity(0.34), size: 28),
                  const SizedBox(height: 7),
                  Text(
                    title,
                    style: TextStyle(
                      color: isActive ? _darkerBg : Colors.white.withOpacity(isDisabled ? 0.24 : 0.60),
                      fontSize: 16,
                      fontFamily: 'Rajdhani',
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.5,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: isActive ? _darkerBg.withOpacity(0.65) : Colors.white.withOpacity(0.20),
                      fontSize: 12,
                      fontFamily: 'Rajdhani',
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            if (isDisabled)
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.18),
                    borderRadius: BorderRadius.circular(18),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildAttackButton() {
    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (context, _) {
        return GestureDetector(
          onTap: _isSending ? null : _sendBug,
          child: Container(
            width: double.infinity,
            height: 72,
            decoration: BoxDecoration(
              color: _glowColor1,
              borderRadius: BorderRadius.circular(18),
              boxShadow: [
                BoxShadow(
                  color: _glowColor1.withOpacity(0.30 * _glowAnimation.value),
                  blurRadius: 22,
                  offset: const Offset(0, 7),
                ),
              ],
            ),
            child: Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (_isSending)
                    SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(color: _darkerBg, strokeWidth: 2),
                    )
                  else
                    Icon(Icons.send_rounded, color: _darkerBg, size: 30),
                  const SizedBox(width: 9),
                  Text(
                    _isSending ? 'MENGIRIM...' : 'KIRIM BUG',
                    style: TextStyle(
                      color: _darkerBg,
                      fontSize: 21,
                      fontFamily: 'Rajdhani',
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.8,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildFooter() {
    return Column(
      children: [
        const SizedBox(height: 4),
        Text(
          'LAWLIET',
          style: TextStyle(
            color: Colors.white.withOpacity(0.15),
            fontSize: 8,
            fontFamily: 'Rajdhani',
            fontWeight: FontWeight.w900,
            letterSpacing: 2.2,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          '© Private advanced bug system',
          style: TextStyle(
            color: Colors.white.withOpacity(0.08),
            fontSize: 12,
            fontFamily: 'Rajdhani',
            fontWeight: FontWeight.w600,
            letterSpacing: 0.8,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _darkerBg,
      resizeToAvoidBottomInset: true,
      body: Stack(
        children: [
          _buildAnimatedBackground(),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(30, 26, 30, 34),
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: SlideTransition(
                  position: _slideAnimation,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      _buildTopBar(),
                      const SizedBox(height: 26),
                      _buildUserProfileCard(),
                      const SizedBox(height: 26),
                      _buildTargetInputCard(),
                      const SizedBox(height: 26),
                      _buildBugSelectionCard(),
                      const SizedBox(height: 26),
                      _buildSenderSelectionCard(),
                      const SizedBox(height: 28),
                      _buildAttackButton(),
                      const SizedBox(height: 18),
                      _buildFooter(),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    _glowController.dispose();
    _pulseController.dispose();
    _rotateController.dispose();
    _videoController.dispose();
    _bugScrollController.dispose();
    targetController.dispose();
    super.dispose();
  }
}


class _DottedPatternPainter extends CustomPainter {
  final Color dotColor;
  final Color lineColor;

  const _DottedPatternPainter({required this.dotColor, required this.lineColor});

  @override
  void paint(Canvas canvas, Size size) {
    final dotPaint = Paint()..color = dotColor;
    final linePaint = Paint()
      ..color = lineColor
      ..strokeWidth = 0.7;

    const spacing = 28.0;
    for (double x = 0; x <= size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), linePaint);
    }
    for (double y = 0; y <= size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), linePaint);
    }
    for (double y = 14; y <= size.height; y += spacing) {
      for (double x = 14; x <= size.width; x += spacing) {
        canvas.drawCircle(Offset(x, y), 1.15, dotPaint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _DottedPatternPainter oldDelegate) {
    return oldDelegate.dotColor != dotColor || oldDelegate.lineColor != lineColor;
  }
}

// Success Dialog
class _SuccessDialog extends StatefulWidget {
  final String target;
  final String senderType;
  final VoidCallback onDismiss;

  const _SuccessDialog({
    required this.target,
    required this.senderType,
    required this.onDismiss,
  });

  @override
  State<_SuccessDialog> createState() => _SuccessDialogState();
}

class _SuccessDialogState extends State<_SuccessDialog> with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late AnimationController _scaleController;
  late AnimationController _glowController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;
  late Animation<double> _glowAnimation;

  final Color _glowColor1 = const Color(0xFF7FDBFF);
final Color _primaryColor = const Color(0xFF2196F3);
final Color _secondaryColor = const Color(0xFF1565C0);
final Color _successColor = const Color(0xFF4FC3F7);
final Color _darkerBg = const Color(0xFF02050D);
final Color _surfaceColor = const Color(0xFF0D1525);
final Color _cardColor = const Color(0xFF2196F3).withOpacity(0.08);


  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    _scaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    );
    _glowController.repeat(reverse: true);

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeOutCubic),
    );

    _scaleAnimation = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
    );

    _glowAnimation = Tween<double>(begin: 0.4, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOutSine),
    );

    _fadeController.forward();
    _scaleController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _scaleController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final dialogWidth = screenSize.width * 0.85;

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: EdgeInsets.zero,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: dialogWidth),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              width: dialogWidth,
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    _surfaceColor.withOpacity(0.96),
                    _cardColor.withOpacity(0.96),
                  ],
                ),
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: _glowColor1.withOpacity(0.35), width: 1.5),
                boxShadow: [
                  BoxShadow(color: _glowColor1.withOpacity(0.2), blurRadius: 40, spreadRadius: 4),
                ],
              ),
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: ScaleTransition(
                  scale: _scaleAnimation,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      AnimatedBuilder(
                        animation: _glowController,
                        builder: (context, _) {
                          return Container(
                            padding: const EdgeInsets.all(24),
                            decoration: BoxDecoration(
                              color: _cardColor,
                              shape: BoxShape.circle,
                              border: Border.all(color: _glowColor1.withOpacity(0.4), width: 1.5),
                              boxShadow: [
                                BoxShadow(
                                  color: _glowColor1.withOpacity(0.45 * _glowAnimation.value),
                                  blurRadius: 40,
                                  spreadRadius: 4,
                                ),
                              ],
                            ),
                            child: Icon(
                              widget.senderType == "global"
                                  ? FontAwesomeIcons.rocket
                                  : FontAwesomeIcons.skullCrossbones,
                              color: _glowColor1,
                              size: 48,
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 28),
                      Text(
                        widget.senderType == "global" ? "GLOBAL STRIKE!" : "ATTACK SUCCESS",
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Rajdhani',
                          letterSpacing: 3,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          color: _cardColor,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: _glowColor1.withOpacity(0.12), width: 1),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.phone_android, color: _glowColor1.withOpacity(0.6), size: 22),
                            const SizedBox(width: 10),
                            Text(
                              widget.target,
                              style: TextStyle(
                                color: _glowColor1.withOpacity(0.85),
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                                fontFamily: 'Rajdhani',
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                        decoration: BoxDecoration(
                          color: _glowColor1.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: _glowColor1.withOpacity(0.25), width: 1),
                        ),
                        child: Text(
                          widget.senderType.toUpperCase(),
                          style: TextStyle(
                            color: _glowColor1.withOpacity(0.85),
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Rajdhani',
                            letterSpacing: 2,
                          ),
                        ),
                      ),
                      const SizedBox(height: 28),
                      GestureDetector(
                        onTap: widget.onDismiss,
                        child: Container(
                          width: double.infinity,
                          height: 72,
                          decoration: BoxDecoration(
                            color: _glowColor1.withOpacity(0.92),
                            borderRadius: BorderRadius.circular(14),
                            boxShadow: [
                              BoxShadow(color: _glowColor1.withOpacity(0.3), blurRadius: 20),
                            ],
                          ),
                          child: const Center(
                            child: Text(
                              "CLOSE",
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Rajdhani',
                                letterSpacing: 3,
                                color: Color(0xFF050505),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}