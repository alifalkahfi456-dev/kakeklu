package com.darkness.darkverse;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
