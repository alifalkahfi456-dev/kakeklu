import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';

class FloatingTools extends StatefulWidget {
  const FloatingTools({super.key});

  @override
  State<FloatingTools> createState() => _FloatingToolsState();
}

class _FloatingToolsState extends State<FloatingTools> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 60,
      height: 60,
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.9),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: Colors.red, width: 2),
      ),
      child: const Center(
        child: Icon(Icons.build, color: Colors.white, size: 30),
      ),
    );
  }
}