import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'theme_provider.dart';
import 'dashboard_page.dart';
import 'login_page.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => ThemeProvider(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeProvider>(
      builder: (context, theme, child) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'DarkVerse',
          theme: ThemeData(
            brightness: Brightness.dark,
            scaffoldBackgroundColor: const Color(0xFF000000),
            primaryColor: theme.primaryColor,
            colorScheme: ColorScheme.dark(
              primary: theme.primaryColor,
              secondary: theme.accentColor,
            ),
            appBarTheme: const AppBarTheme(
              backgroundColor: Colors.transparent,
              elevation: 0,
            ),
          ),
          home: const LoginPage(),
          // home: const DashboardPage(
          //   username: 'test',
          //   password: 'test',
          //   role: 'owner',
          //   expiredDate: '2025-12-31',
          //   sessionKey: 'test123',
          //   listBug: [],
          //   listDoos: [],
          //   news: [],
          // ),
        );
      },
    );
  }
}