import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ColorPreset {
  final String name;
  final Color primary;
  final Color accent;
  const ColorPreset({required this.name, required this.primary, required this.accent});
}

class ThemeProvider extends ChangeNotifier {
  static const Color _defaultPrimary = Color(0xFFFF1744);
  static const Color _defaultAccent = Color(0xFF2979FF);

  Color _primaryColor = _defaultPrimary;
  Color _accentColor = _defaultAccent;
  bool _isDarkMode = true;
  int _currentPresetIndex = 0;

  Color get primaryColor => _primaryColor;
  Color get accentColor => _accentColor;
  bool get isDarkMode => _isDarkMode;

  Color get backgroundColor => const Color(0xFF08080C);
  Color get surfaceColor => const Color(0xFF0C0C12);
  Color get cardColor => const Color(0xFF101018);
  Color get textPrimaryColor => const Color(0xFFFF4060);
  Color get textSecondaryColor => const Color(0xFF2979FF).withOpacity(0.6);
  Color get glassPrimary => Colors.white.withOpacity(0.02);
  Color get glassSecondary => Colors.white.withOpacity(0.04);
  Color get borderColor => _primaryColor.withOpacity(0.15);
  Color get glowColor => _primaryColor.withOpacity(0.3);

  static const List<ColorPreset> colorPresets = [
    ColorPreset(name: 'Blood Blue', primary: Color(0xFFFF1744), accent: Color(0xFF2979FF)),
    ColorPreset(name: 'Crimson Cyan', primary: Color(0xFFFF0040), accent: Color(0xFF00E5FF)),
    ColorPreset(name: 'Inferno', primary: Color(0xFFFF3D00), accent: Color(0xFFFFAB00)),
    ColorPreset(name: 'Phantom', primary: Color(0xFFAA00FF), accent: Color(0xFF00E676)),
    ColorPreset(name: 'Toxic', primary: Color(0xFF76FF03), accent: Color(0xFFFF1744)),
    ColorPreset(name: 'Ice', primary: Color(0xFF00B0FF), accent: Color(0xFFFF4081)),
    ColorPreset(name: 'Ghost', primary: Color(0xFFB0BEC5), accent: Color(0xFFFF5252)),
    ColorPreset(name: 'Solar', primary: Color(0xFFFFAB00), accent: Color(0xFFFF1744)),
  ];

  ThemeProvider() { _loadSavedTheme(); }

  Future<void> _loadSavedTheme() async {
    final prefs = await SharedPreferences.getInstance();
    _currentPresetIndex = prefs.getInt('theme_preset_index') ?? 0;
    _isDarkMode = prefs.getBool('theme_dark_mode') ?? true;
    _applyPresetByIndex(_currentPresetIndex);
    notifyListeners();
  }

  Future<void> _saveTheme() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('theme_preset_index', _currentPresetIndex);
    await prefs.setBool('theme_dark_mode', _isDarkMode);
  }

  void applyPreset(ColorPreset preset) {
    final index = colorPresets.indexWhere((p) => p.name == preset.name);
    if (index != -1) { _applyPresetByIndex(index); _saveTheme(); notifyListeners(); }
  }

  void _applyPresetByIndex(int index) {
    if (index >= 0 && index < colorPresets.length) {
      _currentPresetIndex = index;
      _primaryColor = colorPresets[index].primary;
      _accentColor = colorPresets[index].accent;
    }
  }

  bool isActivePreset(ColorPreset preset) =>
      _primaryColor == preset.primary && _accentColor == preset.accent;

  void resetToDefault() {
    _currentPresetIndex = 0;
    _primaryColor = _defaultPrimary;
    _accentColor = _defaultAccent;
    _saveTheme();
    notifyListeners();
  }

  void toggleDarkMode() { _isDarkMode = !_isDarkMode; _saveTheme(); notifyListeners(); }
  void setDarkMode(bool value) { _isDarkMode = value; _saveTheme(); notifyListeners(); }
}

// ── Scanline Overlay ──
class ScanlinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white.withOpacity(0.012)..strokeWidth = 0.5;
    for (double y = 0; y < size.height; y += 3) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }
  @override
  bool shouldRepaint(covariant ScanlinePainter oldDelegate) => false;
}

// ── Grid Painter ──
class GridPainter extends CustomPainter {
  final Color color;
  GridPainter({required this.color});
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color.withOpacity(0.03)..strokeWidth = 0.5;
    for (double x = 0; x < size.width; x += 30) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += 30) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }
  @override
  bool shouldRepaint(covariant GridPainter oldDelegate) => oldDelegate.color != color;
}

// ── Hacker Card Widget ──
class HackerCard extends StatelessWidget {
  final Widget child;
  final Color? borderColor;
  final EdgeInsetsGeometry? padding;
  const HackerCard({super.key, required this.child, this.borderColor, this.padding});
  @override
  Widget build(BuildContext context) {
    final theme = Provider.of<ThemeProvider>(context);
    final c = borderColor ?? theme.primaryColor;
    return Container(
      padding: padding ?? const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0C0C14),
        border: Border(
          left: BorderSide(color: c.withOpacity(0.4), width: 2),
          top: BorderSide(color: c.withOpacity(0.08)),
          right: BorderSide(color: c.withOpacity(0.05)),
          bottom: BorderSide(color: c.withOpacity(0.15)),
        ),
      ),
      child: child,
    );
  }
}

// ── Terminal Text Widget ──
class TerminalText extends StatelessWidget {
  final String text;
  final Color? color;
  final double fontSize;
  final bool bold;
  const TerminalText({super.key, required this.text, this.color, this.fontSize = 12, this.bold = false});
  @override
  Widget build(BuildContext context) {
    final c = color ?? const Color(0xFFFF4060);
    return Text(
      text,
      style: TextStyle(
        color: c,
        fontSize: fontSize,
        fontFamily: 'ShareTechMono',
        fontWeight: bold ? FontWeight.bold : FontWeight.normal,
        letterSpacing: 0.8,
      ),
    );
  }
}
