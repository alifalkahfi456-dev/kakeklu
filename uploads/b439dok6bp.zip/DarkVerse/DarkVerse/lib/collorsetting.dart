import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'theme_provider.dart';

void showColorSettingsSheet(BuildContext context) {
  showModalBottomSheet(
    context: context,
    backgroundColor: Colors.transparent,
    isScrollControlled: true,
    builder: (_) => const _ColorSettingsSheet(),
  ).then((_) {
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    theme.notifyListeners();
  });
}

class _ColorSettingsSheet extends StatelessWidget {
  const _ColorSettingsSheet();

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0A0A10),
        border: Border(
          top: BorderSide(color: Color(0xFFFF1744), width: 1.5),
        ),
      ),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle
          Container(width: 40, height: 3, color: theme.primaryColor.withOpacity(0.4)),
          const SizedBox(height: 16),
          // Title
          Row(children: [
            Icon(Icons.palette_outlined, color: theme.primaryColor, size: 16),
            const SizedBox(width: 8),
            Text('// COLOR CONFIG', style: TextStyle(color: theme.primaryColor, fontFamily: 'ShareTechMono', fontSize: 12, letterSpacing: 2)),
            const Spacer(),
            GestureDetector(
              onTap: () => theme.toggleDarkMode(),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: theme.primaryColor.withOpacity(0.1),
                  border: Border.all(color: theme.primaryColor.withOpacity(0.3)),
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(theme.isDarkMode ? Icons.dark_mode : Icons.light_mode, color: theme.primaryColor, size: 12),
                  const SizedBox(width: 4),
                  Text(theme.isDarkMode ? 'DARK' : 'LIGHT', style: TextStyle(color: theme.primaryColor, fontSize: 9, fontFamily: 'ShareTechMono')),
                ]),
              ),
            ),
          ]),
          const SizedBox(height: 16),
          // Preview
          Container(
            height: 32,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [theme.primaryColor, theme.accentColor]),
            ),
            child: const Center(child: Text('ACTIVE PREVIEW', style: TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 10, letterSpacing: 2))),
          ),
          const SizedBox(height: 16),
          // Label
          Align(alignment: Alignment.centerLeft, child: Text('// SELECT PRESET', style: TextStyle(color: theme.accentColor.withOpacity(0.4), fontFamily: 'ShareTechMono', fontSize: 9, letterSpacing: 1.5))),
          const SizedBox(height: 10),
          // Color grid
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, mainAxisSpacing: 8, crossAxisSpacing: 8),
            itemCount: ThemeProvider.colorPresets.length,
            itemBuilder: (context, i) {
              final preset = ThemeProvider.colorPresets[i];
              final isActive = theme.isActivePreset(preset);
              return GestureDetector(
                onTap: () => theme.applyPreset(preset),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [preset.primary, preset.accent]),
                    border: Border.all(color: isActive ? Colors.white : Colors.transparent, width: isActive ? 2 : 0),
                    boxShadow: isActive ? [BoxShadow(color: preset.primary.withOpacity(0.5), blurRadius: 8)] : [],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.color_lens, color: Colors.white.withOpacity(0.8), size: 18),
                      const SizedBox(height: 4),
                      Text(preset.name, style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 7, fontFamily: 'ShareTechMono'), textAlign: TextAlign.center),
                    ],
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 12),
          // Reset
          GestureDetector(
            onTap: () { theme.resetToDefault(); Navigator.pop(context); },
            child: Text('[ RESET DEFAULT ]', style: TextStyle(color: theme.accentColor.withOpacity(0.3), fontFamily: 'ShareTechMono', fontSize: 10, letterSpacing: 1)),
          ),
        ],
      ),
    );
  }
}
