// ©dimax

module.exports = {
  domain: "http://", // Ganti sma domain panel lu dan pastiin harus *http*
  port: "3002" // Ganti Portnoy di panel network.
};