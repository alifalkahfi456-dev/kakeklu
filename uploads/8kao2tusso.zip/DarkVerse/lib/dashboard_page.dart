import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';

import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'partner_page.dart';
import 'moderator_page.dart';
import 'gaple_game.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? _profileImage;
  VideoPlayerController? _menuVideoController;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const Placeholder();

  int onlineUsers = 0;
  int activeConnections = 0;

  // ── Tema Merah Gelap ──
  final Color bgDark    = const Color(0xFF0A0A0A);
  final Color primaryRed = const Color(0xFFB71C1C);
  final Color accentRed  = const Color(0xFFE53935);
  final Color lightRed   = const Color(0xFFEF9A9A);
  final Color primaryWhite = Colors.white;
  final Color accentGrey  = const Color(0xFF9E9E9E);
  final Color cardGlass   = const Color(0xFF1A1A1A);
  final Color cardBorder  = const Color(0xFF2A2A2A);

  @override
  void initState() {
    super.initState();
    sessionKey  = widget.sessionKey;
    username    = widget.username;
    password    = widget.password;
    role        = widget.role;
    expiredDate = widget.expiredDate;
    listBug     = widget.listBug;
    listDoos    = widget.listDoos;
    newsList    = widget.news;

    _controller = AnimationController(duration: const Duration(milliseconds: 450), vsync: this);
    _animation  = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _selectedPage = _buildNewsPage();
    _initAndroidIdAndConnect();
    _loadProfileImage();
    _initMenuVideo();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path  = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty) setState(() => _profileImage = File(path));
  }

  void _initMenuVideo() {
    _menuVideoController = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        setState(() {});
        _menuVideoController?.setLooping(true);
        _menuVideoController?.play();
      });
  }

  Future<void> _initAndroidIdAndConnect() async {
    final info = await DeviceInfoPlugin().androidInfo;
    androidId  = info.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('wss://ws-dark.darkverse.my.id'));
    channel.sink.add(jsonEncode({"type": "validate", "key": sessionKey, "androidId": androidId}));
    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo' && data['valid'] == false) {
        if (data['reason'] == 'androidIdMismatch')
          _handleInvalidSession("Your account has logged on another device.");
        else if (data['reason'] == 'keyInvalid')
          _handleInvalidSession("Key is not valid. Please login again.");
      }
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers       = data['onlineUsers']       ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    });
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication))
      throw Exception("Could not launch $uri");
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: bgDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text("⚠️ Session Expired",
            style: TextStyle(color: accentRed, fontWeight: FontWeight.bold)),
        content: Text(message, style: TextStyle(color: accentGrey)),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false),
            child: Text("OK", style: TextStyle(color: accentRed, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  // ── Bottom Nav ──
  void _onBottomNavTapped(int index) {
    if (index == 1) {
      _showWhatsAppTools(); // Tab WA buka sheet, index tidak berubah
      return;
    }
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) _selectedPage = _buildNewsPage();
      else if (index == 2) _selectedPage = InfoPage(sessionKey: sessionKey);
      else if (index == 3) _selectedPage = ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos);
    });
  }

  // ── WhatsApp Tools Sheet ──
  void _showWhatsAppTools() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      barrierColor: Colors.black.withOpacity(0.65),
      builder: (_) => _WhatsAppToolsSheet(
        sessionKey: sessionKey,
        username:   username,
        password:   password,
        listBug:    listBug,
        role:       role,
        expiredDate: expiredDate,
      ),
    );
  }

  void _onSidebarTabSelected(int index) {
    setState(() {
      if (index == 1) _selectedPage = SellerPage(keyToken: sessionKey);
      else if (index == 2) _selectedPage = AdminPage(sessionKey: sessionKey);
      else if (index == 3) _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
      else if (index == 4) _selectedPage = PartnerPage(sessionKey: sessionKey, username: username);
      else if (index == 5) _selectedPage = ModeratorPage(sessionKey: sessionKey, username: username);
    });
    Navigator.pop(context);
  }

  // ── Profile Card ──
  Widget _buildProfileCard() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: primaryRed.withOpacity(0.4)),
        boxShadow: [BoxShadow(color: primaryRed.withOpacity(0.12), blurRadius: 20, offset: const Offset(0, 4))],
      ),
      child: Row(
        children: [
          Container(
            width: 56, height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: accentRed, width: 2),
              boxShadow: [BoxShadow(color: accentRed.withOpacity(0.3), blurRadius: 10)],
            ),
            child: ClipOval(
              child: _profileImage != null
                  ? Image.file(_profileImage!, fit: BoxFit.cover)
                  : Container(
                      color: primaryRed.withOpacity(0.15),
                      child: Icon(FontAwesomeIcons.userAstronaut, size: 28, color: accentRed)),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(username.toUpperCase(),
                    style: const TextStyle(color: Colors.white, fontSize: 18,
                        fontWeight: FontWeight.bold, fontFamily: 'Orbitron', letterSpacing: 1)),
                const SizedBox(height: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: primaryRed.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: accentRed.withOpacity(0.5)),
                  ),
                  child: Text("${role.toUpperCase()} · $expiredDate",
                      style: TextStyle(color: lightRed, fontSize: 11, fontFamily: 'ShareTechMono')),
                ),
              ],
            ),
          ),
          Column(
            children: [
              _statusBadge(color: Colors.greenAccent, dotColor: Colors.green),
              const SizedBox(height: 8),
              _statusBadge(color: accentGrey, dotColor: accentGrey),
            ],
          ),
        ],
      ),
    );
  }

  Widget _statusBadge({required Color color, required Color dotColor}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(width: 6, height: 6,
              decoration: BoxDecoration(color: dotColor, shape: BoxShape.circle,
                  boxShadow: [BoxShadow(color: dotColor.withOpacity(0.6), blurRadius: 4)])),
          const SizedBox(width: 5),
          Icon(Icons.crop_square_rounded, color: color, size: 12),
        ],
      ),
    );
  }

  // ── News Page ──
  Widget _buildNewsPage() {
    return SingleChildScrollView(
      child: Column(
        children: [
          const SizedBox(height: 8),
          _buildProfileCard(),
          const SizedBox(height: 16),
          SizedBox(
            height: 190,
            child: PageView.builder(
              controller: PageController(viewportFraction: 0.92),
              itemCount: newsList.length,
              itemBuilder: (context, index) {
                final item = newsList[index];
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: cardGlass,
                    border: Border.all(color: primaryRed.withOpacity(0.25)),
                    boxShadow: [BoxShadow(color: primaryRed.withOpacity(0.15), blurRadius: 16, offset: const Offset(0, 5))],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        if (item['image'] != null && item['image'].toString().isNotEmpty)
                          NewsMedia(url: item['image']),
                        Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Colors.black.withOpacity(0.75), Colors.transparent,
                                primaryRed.withOpacity(0.08)],
                              begin: Alignment.bottomCenter, end: Alignment.topCenter,
                            ),
                          ),
                        ),
                        Positioned(
                          top: 12, left: 12,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(color: accentRed, borderRadius: BorderRadius.circular(6)),
                            child: const Text("NEWS", style: TextStyle(color: Colors.white, fontSize: 10,
                                fontWeight: FontWeight.bold, letterSpacing: 1)),
                          ),
                        ),
                        Positioned(
                          bottom: 16, left: 16, right: 16,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(item['title'] ?? 'No Title',
                                  style: const TextStyle(color: Colors.white, fontSize: 16,
                                      fontFamily: "Orbitron", fontWeight: FontWeight.bold)),
                              const SizedBox(height: 4),
                              Text(item['desc'] ?? '',
                                  style: TextStyle(color: accentGrey, fontFamily: "ShareTechMono", fontSize: 11),
                                  maxLines: 2, overflow: TextOverflow.ellipsis),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              width: double.infinity, height: 55,
              decoration: BoxDecoration(
                color: cardGlass,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: primaryRed.withOpacity(0.4)),
                boxShadow: [BoxShadow(color: primaryRed.withOpacity(0.15), blurRadius: 20, offset: const Offset(0, 6))],
              ),
              child: ElevatedButton.icon(
                icon: Icon(FontAwesomeIcons.telegram, color: accentRed, size: 22),
                label: const Text("Join Channel",
                    style: TextStyle(color: Colors.white, fontSize: 15,
                        fontWeight: FontWeight.bold, fontFamily: 'Orbitron', letterSpacing: 1)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                onPressed: () => _openUrl("https://t.me/DarkVerse7"),
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  // ── Drawer ──
  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: bgDark,
      width: MediaQuery.of(context).size.width * 0.8,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            height: 250,
            color: primaryRed.withOpacity(0.1),
            child: Stack(
              children: [
                if (_menuVideoController != null && _menuVideoController!.value.isInitialized)
                  SizedBox.expand(
                    child: FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _menuVideoController!.value.size.width,
                        height: _menuVideoController!.value.size.height,
                        child: VideoPlayer(_menuVideoController!),
                      ),
                    ),
                  ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter, end: Alignment.bottomCenter,
                      colors: [Colors.black.withOpacity(0.2), Colors.black.withOpacity(0.85)],
                    ),
                  ),
                ),
                SafeArea(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 100, height: 100,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: accentRed, width: 3),
                            boxShadow: [BoxShadow(color: accentRed.withOpacity(0.5), blurRadius: 15, spreadRadius: 2)],
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(_profileImage!, fit: BoxFit.cover)
                                : Container(
                                    color: primaryRed.withOpacity(0.15),
                                    child: Icon(FontAwesomeIcons.userAstronaut, size: 50, color: accentRed)),
                          ),
                        ),
                        const SizedBox(height: 16),
                        Text(username, style: const TextStyle(color: Colors.white, fontSize: 22,
                            fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                        Text(role.toUpperCase(), style: TextStyle(color: accentRed, fontSize: 14,
                            letterSpacing: 2, fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              color: bgDark,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 20),
                children: [
                  if (role == "reseller")   _drawerItem(icon: Icons.storefront, label: "Seller Page",    onTap: () => _onSidebarTabSelected(1)),
                  if (role == "admin")      _drawerItem(icon: Icons.admin_panel_settings, label: "Admin Page", onTap: () => _onSidebarTabSelected(2)),
                  if (role == "partner")    _drawerItem(icon: FontAwesomeIcons.handshake, label: "Partner Page", onTap: () => _onSidebarTabSelected(4)),
                  if (role == "moderator")  _drawerItem(icon: FontAwesomeIcons.userShield, label: "Moderator Page", onTap: () => _onSidebarTabSelected(5)),
                  if (role == "owner")      _drawerItem(icon: Icons.workspace_premium, label: "Owner Page", onTap: () => _onSidebarTabSelected(3)),
                  _drawerItem(
                    icon: Icons.casino_rounded, label: "Gaple Game",
                    onTap: () {
                      Navigator.pop(context);
                      showDialog(
                        context: context,
                        builder: (context) => _GapleMenuDialog(username: username),
                      );
                    },
                  ),
                  _drawerItem(
                    icon: Icons.history_rounded, label: "Riwayat Aktivitas",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(
                          builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role)));
                    },
                  ),
                  const SizedBox(height: 20),
                  _drawerItem(
                    icon: Icons.logout, label: "Log Out", isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false);
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _drawerItem({required IconData icon, required String label,
      required VoidCallback onTap, bool isLogout = false}) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: isLogout ? primaryRed.withOpacity(0.15) : cardGlass,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: isLogout ? primaryRed.withOpacity(0.5) : cardBorder),
      ),
      child: ListTile(
        leading: Icon(icon, color: accentRed, size: 22),
        title: Text(label, style: TextStyle(
            color: isLogout ? accentRed : primaryWhite, fontWeight: FontWeight.w600, fontSize: 16)),
        trailing: const Icon(Icons.arrow_forward_ios, color: Color(0xFF9E9E9E), size: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        onTap: onTap,
      ),
    );
  }

  // ── Build ──
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text("dark verse copyright",
            style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 22,
                fontFamily: 'Orbitron',
                shadows: [Shadow(color: accentRed.withOpacity(0.8), blurRadius: 12)])),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: accentRed),
        actions: [
          IconButton(
            icon: Icon(Icons.headset_mic_outlined, color: primaryWhite), tooltip: 'Customer Service',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ContactPage())),
          ),
          IconButton(
            icon: Icon(FontAwesomeIcons.userCircle, color: primaryWhite), tooltip: 'My Profile',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(
                username: username, password: password, role: role,
                expiredDate: expiredDate, sessionKey: sessionKey))),
          ),
        ],
      ),
      drawer: _buildCustomDrawer(),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [bgDark, primaryRed.withOpacity(0.05), bgDark],
          ),
        ),
        child: SafeArea(child: FadeTransition(opacity: _animation, child: _selectedPage)),
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF111111),
          border: Border(top: BorderSide(color: primaryRed.withOpacity(0.3), width: 1)),
          boxShadow: [BoxShadow(color: primaryRed.withOpacity(0.08), blurRadius: 10, offset: const Offset(0, -2))],
        ),
        child: BottomNavigationBar(
          backgroundColor: Colors.transparent,
          selectedItemColor: accentRed,
          unselectedItemColor: accentGrey,
          currentIndex: _bottomNavIndex,
          onTap: _onBottomNavTapped,
          selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold),
          type: BottomNavigationBarType.fixed,
          items: [
            BottomNavigationBarItem(
              icon: _bottomNavIndex == 0
                  ? _pillIcon(Icons.home, accentRed)
                  : const Icon(Icons.home),
              label: "Home",
            ),
            // Tab WA: tidak pernah dalam state "selected"
            const BottomNavigationBarItem(
              icon: Icon(FontAwesomeIcons.whatsapp),
              label: "WhatsApp",
            ),
            BottomNavigationBarItem(
              icon: _bottomNavIndex == 2
                  ? _pillIcon(Icons.notifications_none, accentRed)
                  : const Icon(Icons.notifications_none),
              label: "Info",
            ),
            BottomNavigationBarItem(
              icon: _bottomNavIndex == 3
                  ? _pillIcon(Icons.build_circle_outlined, accentRed)
                  : const Icon(Icons.build_circle_outlined),
              label: "Tools",
            ),
          ],
        ),
      ),
    );
  }

  Widget _pillIcon(IconData icon, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
    decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
    child: Icon(icon, color: color),
  );

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _menuVideoController?.dispose();
    super.dispose();
  }
}

// ════════════════════════════════════════════════════════════════
//  _WhatsAppToolsSheet — bottom sheet animasi slide-up + stagger
// ════════════════════════════════════════════════════════════════
class _WhatsAppToolsSheet extends StatefulWidget {
  final String sessionKey, username, password, role, expiredDate;
  final List<Map<String, dynamic>> listBug;

  const _WhatsAppToolsSheet({
    required this.sessionKey,
    required this.username,
    required this.password,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<_WhatsAppToolsSheet> createState() => _WhatsAppToolsSheetState();
}

class _WhatsAppToolsSheetState extends State<_WhatsAppToolsSheet>
    with SingleTickerProviderStateMixin {
  late AnimationController _animCtrl;
  late Animation<double>  _fadeAnim;
  late Animation<Offset>  _slideAnim;

  static const Color _bg    = Color(0xFF0D0D0D);
  static const Color _card  = Color(0xFF161616);
  static const Color _red   = Color(0xFFE53935);

  // ── Menu items ──
  static const List<Map<String, dynamic>> _items = [
    {
      'icon':      FontAwesomeIcons.whatsapp,
      'iconColor': Color(0xFFE53935),
      'bgColor':   Color(0xFF2A0A0A),
      'title':     'WhatsApp Crash',
      'subtitle':  'Send payloads & crash codes',
      'type':      'crash',
    },
    {
      'icon':      Icons.devices_rounded,
      'iconColor': Color(0xFF4CAF50),
      'bgColor':   Color(0xFF0A2A0A),
      'title':     'Manage Sender',
      'subtitle':  'Pair devices & manage sessions',
      'type':      'sender',
    },
  ];

  @override
  void initState() {
    super.initState();
    _animCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 420));
    _fadeAnim  = CurvedAnimation(parent: _animCtrl, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(CurvedAnimation(parent: _animCtrl, curve: Curves.easeOutCubic));
    _animCtrl.forward();
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fadeAnim,
      child: SlideTransition(
        position: _slideAnim,
        child: Container(
          decoration: const BoxDecoration(
            color: _bg,
            borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Drag handle
              Container(
                margin: const EdgeInsets.only(top: 12, bottom: 6),
                width: 40, height: 4,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),

              // Header
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
                child: Row(
                  children: [
                    Container(
                      width: 42, height: 42,
                      decoration: BoxDecoration(
                        color: _red.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _red.withOpacity(0.4)),
                      ),
                      child: const Icon(FontAwesomeIcons.whatsapp, color: _red, size: 20),
                    ),
                    const SizedBox(width: 14),
                    const Text("WHATSAPP TOOLS",
                        style: TextStyle(color: _red, fontSize: 18, fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron', letterSpacing: 1.5)),
                  ],
                ),
              ),

              // Divider merah gradient
              Container(
                margin: const EdgeInsets.fromLTRB(20, 16, 20, 4),
                height: 1,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [_red.withOpacity(0.6), Colors.transparent]),
                ),
              ),

              // Menu items dengan staggered animation
              ..._items.asMap().entries.map((e) => _StaggeredItem(
                    delay: Duration(milliseconds: 80 + e.key * 90),
                    child: _buildItem(e.value),
                  )),

              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildItem(Map<String, dynamic> item) {
    final Color  iconColor = item['iconColor'] as Color;
    final Color  bgColor   = item['bgColor']   as Color;
    final IconData icon    = item['icon']       as IconData;
    final String title     = item['title']      as String;
    final String subtitle  = item['subtitle']   as String;
    final String type      = item['type']       as String;

    return GestureDetector(
      onTap: () {
        Navigator.pop(context);
        final route = PageRouteBuilder(
          transitionDuration: const Duration(milliseconds: 350),
          pageBuilder: (_, __, ___) => type == 'crash'
              ? HomePage(
                  username: widget.username, password: widget.password,
                  sessionKey: widget.sessionKey, listBug: widget.listBug,
                  role: widget.role, expiredDate: widget.expiredDate)
              : BugSenderPage(
                  sessionKey: widget.sessionKey,
                  username:   widget.username,
                  role:       widget.role),
          transitionsBuilder: (_, anim, __, child) => SlideTransition(
            position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
                .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
            child: child,
          ),
        );
        Navigator.push(context, route);
      },
      child: Container(
        margin: const EdgeInsets.fromLTRB(16, 6, 16, 6),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        decoration: BoxDecoration(
          color: _card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(0.06)),
        ),
        child: Row(
          children: [
            Container(
              width: 46, height: 46,
              decoration: BoxDecoration(
                color: bgColor,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: iconColor.withOpacity(0.3)),
                boxShadow: [BoxShadow(color: iconColor.withOpacity(0.15), blurRadius: 8)],
              ),
              child: Icon(icon, color: iconColor, size: 22),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(color: Colors.white, fontSize: 15,
                      fontWeight: FontWeight.bold, fontFamily: 'ShareTechMono')),
                  const SizedBox(height: 3),
                  Text(subtitle, style: TextStyle(color: Colors.white.withOpacity(0.45),
                      fontSize: 12, fontFamily: 'ShareTechMono')),
                ],
              ),
            ),
            Container(
              width: 28, height: 28,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.05),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(Icons.chevron_right_rounded,
                  color: Colors.white.withOpacity(0.4), size: 18),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Staggered per-item animation ──
class _StaggeredItem extends StatefulWidget {
  final Widget child;
  final Duration delay;
  const _StaggeredItem({required this.child, required this.delay});

  @override
  State<_StaggeredItem> createState() => _StaggeredItemState();
}

class _StaggeredItemState extends State<_StaggeredItem>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double>  _fade;
  late Animation<Offset>  _slide;

  @override
  void initState() {
    super.initState();
    _ctrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 350));
    _fade  = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    Future.delayed(widget.delay, () { if (mounted) _ctrl.forward(); });
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => FadeTransition(
      opacity: _fade, child: SlideTransition(position: _slide, child: widget.child));
}

// ════════════════════════════════════════════════════════════════
//  NewsMedia (tidak diubah)
// ════════════════════════════════════════════════════════════════
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) =>
      url.endsWith(".mp4") || url.endsWith(".webm") || url.endsWith(".mov") || url.endsWith(".mkv");

  @override
  void dispose() { _controller?.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized)
        return AspectRatio(aspectRatio: _controller!.value.aspectRatio, child: VideoPlayer(_controller!));
      return const Center(child: CircularProgressIndicator(color: Colors.white));
    }
    return Image.network(widget.url, fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
            color: const Color(0xFF1A1A1A), child: const Icon(Icons.error, color: Colors.white)));
  }
}

// ════════════════════════════════════════════════════════════════
//  _GapleMenuDialog — Dialog pilihan mode Gaple
// ════════════════════════════════════════════════════════════════
class _GapleMenuDialog extends StatefulWidget {
  final String username;
  const _GapleMenuDialog({required this.username});

  @override
  State<_GapleMenuDialog> createState() => _GapleMenuDialogState();
}

class _GapleMenuDialogState extends State<_GapleMenuDialog> {
  final _roomCodeController = TextEditingController();

  @override
  void dispose() {
    _roomCodeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const Color primaryRed = Color(0xFFB71C1C);
    const Color accentRed  = Color(0xFFE53935);
    const Color bgDark     = Color(0xFF0A0A0A);

    return AlertDialog(
      backgroundColor: bgDark,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: accentRed.withOpacity(0.5)),
      ),
      title: const Row(
        children: [
          Icon(Icons.casino_rounded, color: Color(0xFFE53935)),
          SizedBox(width: 10),
          Text(
            'GAPLE GAME',
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
        ],
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Offline button
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton.icon(
              onPressed: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => GapleGame(
                      playerName: widget.username,
                      isHost: true,
                      isOnlineMode: false,
                    ),
                  ),
                );
              },
              icon: const Icon(Icons.devices, color: Colors.white),
              label: const Text(
                'Main Offline (vs Bot)',
                style: TextStyle(color: Colors.white, fontFamily: 'ShareTechMono'),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryRed,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
          const SizedBox(height: 12),
          // Online - Buat Room
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton.icon(
              onPressed: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => GapleGame(
                      playerName: widget.username,
                      isHost: true,
                      isOnlineMode: true,
                    ),
                  ),
                );
              },
              icon: const Icon(Icons.add_circle_outline, color: Colors.white),
              label: const Text(
                'Buat Room Online',
                style: TextStyle(color: Colors.white, fontFamily: 'ShareTechMono'),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF1565C0),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Divider(color: Colors.white24),
          const SizedBox(height: 8),
          // Gabung Room
          TextField(
            controller: _roomCodeController,
            style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono'),
            textCapitalization: TextCapitalization.characters,
            decoration: InputDecoration(
              labelText: 'Kode Room',
              labelStyle: const TextStyle(color: Colors.white54),
              hintText: 'Contoh: ABC123',
              hintStyle: const TextStyle(color: Colors.white30),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: accentRed.withOpacity(0.4)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: Color(0xFFE53935)),
              ),
              filled: true,
              fillColor: Colors.black45,
              prefixIcon: const Icon(Icons.vpn_key_rounded, color: Color(0xFFE53935)),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton.icon(
              onPressed: () {
                if (_roomCodeController.text.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Masukkan kode room!')),
                  );
                  return;
                }
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => GapleGame(
                      playerName: widget.username,
                      roomCode: _roomCodeController.text.toUpperCase(),
                      isHost: false,
                      isOnlineMode: true,
                    ),
                  ),
                );
              },
              icon: const Icon(Icons.login_rounded, color: Colors.white),
              label: const Text(
                'Gabung Room Online',
                style: TextStyle(color: Colors.white, fontFamily: 'ShareTechMono'),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF00695C),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Tutup', style: TextStyle(color: Color(0xFFE53935))),
        ),
      ],
    );
  }
}
