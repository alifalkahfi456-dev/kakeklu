import 'package:flutter/material.dart';
import 'dart:math';
import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';

// NOTE: Firebase sudah diinisialisasi di main.dart proyek utama.
// File ini hanya berisi komponen game Gaple yang dapat diakses
// melalui menu Dashboard.

// ==================== MODEL KARTU DOMINO ====================
class DominoCard {
  final int left;
  final int right;
  
  DominoCard(this.left, this.right);
  
  int get value => left + right;
  bool get isDouble => left == right;
  
  Map<String, dynamic> toJson() => {'left': left, 'right': right};
  
  factory DominoCard.fromJson(Map<String, dynamic> json) {
    return DominoCard(json['left'], json['right']);
  }
  
  @override
  String toString() => '[$left|$right]';
}

// ==================== MODEL PEMAIN ====================
class Player {
  final String id;
  String name;
  List<DominoCard> hand = [];
  int score = 0;
  bool isReady = false;
  
  Player(this.id, this.name);
  
  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'score': score,
    'hand': hand.map((c) => c.toJson()).toList(),
    'isReady': isReady,
  };
}

enum GameStatus { waiting, playing, finished }

// ==================== GAME UTAMA ====================
class GapleGame extends StatefulWidget {
  final String playerName;
  final String? roomCode;
  final bool isHost;
  final bool isOnlineMode; // DIPERBAIKI - TAMBAH PARAMETER
  
  const GapleGame({
    super.key, 
    required this.playerName,
    this.roomCode,
    this.isHost = false,
    this.isOnlineMode = false, // DIPERBAIKI - DEFAULT FALSE
  });

  @override
  State<GapleGame> createState() => _GapleGameState();
}

class _GapleGameState extends State<GapleGame> {
  // Game variables
  List<DominoCard> stock = [];
  List<DominoCard> board = [];
  List<Player> players = [];
  int currentPlayerIndex = 0;
  GameStatus gameStatus = GameStatus.waiting;
  String message = '';
  
  // Firebase
  late FirebaseFirestore firestore;
  String? roomId;
  StreamSubscription? roomSubscription;
  
  // UI State
  bool isOnline = false;
  String inviteCode = '';
  bool isGameStarted = false;
  
  @override
  void initState() {
    super.initState();
    firestore = FirebaseFirestore.instance;
    
    if (widget.roomCode != null) {
      // Mode online - join room
      isOnline = true;
      roomId = widget.roomCode;
      joinOnlineRoom();
    } else if (widget.isOnlineMode && widget.isHost) {
      // Mode online - buat room baru (DIPERBAIKI)
      isOnline = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        createOnlineRoom(4);
      });
    } else {
      // Mode offline dengan bot
      initializeOfflineGame();
    }
  }
  
  @override
  void dispose() {
    roomSubscription?.cancel();
    if (isOnline && roomId != null) {
      leaveRoom();
    }
    super.dispose();
  }
  
  void initializeOfflineGame() {
    setState(() {
      players = [
        Player('player1', widget.playerName),
        Player('bot1', 'Bot 1'),
        Player('bot2', 'Bot 2'),
        Player('bot3', 'Bot 3'),
      ];
      gameStatus = GameStatus.waiting;
      message = 'Tekan Mulai untuk bermain';
    });
  }
  
  void startOfflineGame() {
    setState(() {
      initializeDeck();
      dealCards();
      determineFirstPlayer();
      gameStatus = GameStatus.playing;
      message = 'Permainan dimulai! Giliran ${players[currentPlayerIndex].name}';
    });
    
    if (currentPlayerIndex != 0) {
      Future.delayed(const Duration(milliseconds: 500), () => botPlay());
    }
  }
  
  Future<void> joinOnlineRoom() async {
    setState(() {
      isOnline = true;
      gameStatus = GameStatus.waiting;
      message = 'Bergabung ke room...';
    });
    
    roomSubscription = firestore.collection('rooms').doc(roomId).snapshots().listen((snapshot) {
      if (snapshot.exists) {
        var data = snapshot.data()!;
        List<dynamic> playersData = data['players'];
        List<Player> updatedPlayers = [];
        
        for (var p in playersData) {
          updatedPlayers.add(Player(p['id'], p['name']));
        }
        
        setState(() {
          players = updatedPlayers;
          inviteCode = data['inviteCode'] ?? '';
          
          if (data['gameStatus'] == 'playing' && !isGameStarted) {
            startOnlineGame(data);
          }
        });
      }
    });
    
    var roomDoc = await firestore.collection('rooms').doc(roomId).get();
    if (roomDoc.exists) {
      var data = roomDoc.data()!;
      setState(() {
        inviteCode = data['inviteCode'];
        List<dynamic> playersData = data['players'];
        players = playersData.map((p) => Player(p['id'], p['name'])).toList();
        message = 'Menunggu host memulai game... (${players.length}/${data['maxPlayers']} pemain)';
      });
    }
  }
  
  void startOnlineGame(Map<String, dynamic> gameData) {
    setState(() {
      isGameStarted = true;
      gameStatus = GameStatus.playing;
      
      stock = (gameData['stock'] as List)
          .map((c) => DominoCard.fromJson(c))
          .toList();
      board = (gameData['board'] as List)
          .map((c) => DominoCard.fromJson(c))
          .toList();
      
      for (var i = 0; i < players.length; i++) {
        var playerData = gameData['players'][i];
        players[i].hand = (playerData['hand'] as List)
            .map((c) => DominoCard.fromJson(c))
            .toList();
        players[i].score = playerData['score'];
      }
      
      currentPlayerIndex = gameData['currentPlayer'];
      message = 'Giliran: ${players[currentPlayerIndex].name}';
    });
  }
  
  Future<void> createOnlineRoom(int maxPlayers) async {
    roomId = DateTime.now().millisecondsSinceEpoch.toString();
    inviteCode = _generateInviteCode();
    
    List<Player> initialPlayers = [
      Player(widget.playerName, widget.playerName)
    ];
    
    Map<String, dynamic> roomData = {
      'roomId': roomId,
      'inviteCode': inviteCode,
      'maxPlayers': maxPlayers,
      'players': initialPlayers.map((p) => p.toJson()).toList(),
      'gameStatus': 'waiting',
      'createdAt': FieldValue.serverTimestamp(),
      'host': widget.playerName,
    };
    
    await firestore.collection('rooms').doc(roomId).set(roomData);
    
    setState(() {
      players = initialPlayers;
      isOnline = true;
      gameStatus = GameStatus.waiting;
      message = 'Room dibuat! Kode: $inviteCode. Tunggu pemain lain...';
    });
    
    roomSubscription = firestore.collection('rooms').doc(roomId).snapshots().listen((snapshot) {
      if (snapshot.exists) {
        var data = snapshot.data()!;
        List<dynamic> playersData = data['players'];
        
        setState(() {
          players = playersData.map((p) => Player(p['id'], p['name'])).toList();
          message = '${players.length}/$maxPlayers pemain siap. Tekan Mulai untuk bermain!';
        });
      }
    });
    
    _showInviteDialog();
  }
  
  String _generateInviteCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ0123456789';
    Random rnd = Random();
    return String.fromCharCodes(Iterable.generate(6, (_) => chars.codeUnitAt(rnd.nextInt(chars.length))));
  }
  
  void _showInviteDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('🎮 Undang Teman'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Bagikan kode ini ke teman Anda:'),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.amber.shade100,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.amber, width: 2),
              ),
              child: SelectableText(
                inviteCode,
                style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 10),
            const Text('Maksimal pemain: 4 orang', style: TextStyle(fontSize: 12)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }
  
  Future<void> startOnlineGame() async {
    if (players.length < 2) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Minimal 2 pemain untuk memulai!')),
      );
      return;
    }
    
    initializeDeck();
    dealCards();
    determineFirstPlayer();
    
    Map<String, dynamic> gameData = {
      'stock': stock.map((c) => c.toJson()).toList(),
      'board': board.map((c) => c.toJson()).toList(),
      'players': players.map((p) => p.toJson()).toList(),
      'currentPlayer': currentPlayerIndex,
      'gameStatus': 'playing',
    };
    
    await firestore.collection('rooms').doc(roomId).update(gameData);
    
    setState(() {
      gameStatus = GameStatus.playing;
      message = 'Permainan dimulai! Giliran ${players[currentPlayerIndex].name}';
    });
  }
  
  void initializeDeck() {
    stock.clear();
    board.clear();
    
    for (int i = 0; i <= 6; i++) {
      for (int j = i; j <= 6; j++) {
        stock.add(DominoCard(i, j));
      }
    }
    stock.shuffle(Random());
  }
  
  void dealCards() {
    for (var player in players) {
      player.hand.clear();
    }
    
    for (int i = 0; i < players.length * 7; i++) {
      if (stock.isNotEmpty) {
        players[i % players.length].hand.add(stock.removeAt(0));
      }
    }
  }
  
  void determineFirstPlayer() {
    int highestDouble = -1;
    int playerWithHighestDouble = 0;
    
    for (int i = 0; i < players.length; i++) {
      for (var card in players[i].hand) {
        if (card.isDouble && card.left > highestDouble) {
          highestDouble = card.left;
          playerWithHighestDouble = i;
        }
      }
    }
    
    currentPlayerIndex = playerWithHighestDouble;
    if (highestDouble == -1) {
      currentPlayerIndex = Random().nextInt(players.length);
    }
  }
  
  bool isValidMove(DominoCard card) {
    if (board.isEmpty) return true;
    
    int leftBoard = board.first.left;
    int rightBoard = board.last.right;
    
    return card.left == leftBoard || card.right == leftBoard ||
           card.left == rightBoard || card.right == rightBoard;
  }
  
  Future<void> playCard(DominoCard card, bool fromLeft) async {
    if (currentPlayerIndex != 0 && isOnline) return;
    
    if (board.isEmpty) {
      setState(() {
        board.add(card);
        players[0].hand.remove(card);
        checkNextTurn();
      });
    } else {
      int leftBoard = board.first.left;
      int rightBoard = board.last.right;
      
      if (fromLeft && (card.right == leftBoard || card.left == leftBoard)) {
        setState(() {
          if (card.right == leftBoard) {
            board.insert(0, card);
          } else {
            board.insert(0, DominoCard(card.right, card.left));
          }
          players[0].hand.remove(card);
          checkNextTurn();
        });
      } else if (!fromLeft && (card.left == rightBoard || card.right == rightBoard)) {
        setState(() {
          if (card.left == rightBoard) {
            board.add(card);
          } else {
            board.add(DominoCard(card.right, card.left));
          }
          players[0].hand.remove(card);
          checkNextTurn();
        });
      }
    }
    
    if (isOnline && roomId != null) {
      await firestore.collection('rooms').doc(roomId).update({
        'board': board.map((c) => c.toJson()).toList(),
        'players': players.map((p) => p.toJson()).toList(),
        'currentPlayer': currentPlayerIndex,
      });
    }
  }
  
  void playCardForBot(int playerIndex, DominoCard card) {
    if (board.isEmpty) {
      setState(() {
        board.add(card);
        players[playerIndex].hand.remove(card);
        message = '${players[playerIndex].name} memainkan $card';
      });
      
      Future.delayed(const Duration(milliseconds: 500), () {
        checkNextTurn();
        if (!isOnline && currentPlayerIndex != 0 && gameStatus == GameStatus.playing) {
          Future.delayed(const Duration(milliseconds: 500), () => botPlay());
        }
      });
    } else {
      int leftBoard = board.first.left;
      int rightBoard = board.last.right;
      
      if (card.right == leftBoard || card.left == leftBoard) {
        setState(() {
          if (card.right == leftBoard) {
            board.insert(0, card);
          } else {
            board.insert(0, DominoCard(card.right, card.left));
          }
          players[playerIndex].hand.remove(card);
          message = '${players[playerIndex].name} memainkan $card di kiri';
        });
        
        Future.delayed(const Duration(milliseconds: 500), () {
          checkNextTurn();
          if (!isOnline && currentPlayerIndex != 0 && gameStatus == GameStatus.playing) {
            Future.delayed(const Duration(milliseconds: 500), () => botPlay());
          }
        });
      } 
      else if (card.left == rightBoard || card.right == rightBoard) {
        setState(() {
          if (card.left == rightBoard) {
            board.add(card);
          } else {
            board.add(DominoCard(card.right, card.left));
          }
          players[playerIndex].hand.remove(card);
          message = '${players[playerIndex].name} memainkan $card di kanan';
        });
        
        Future.delayed(const Duration(milliseconds: 500), () {
          checkNextTurn();
          if (!isOnline && currentPlayerIndex != 0 && gameStatus == GameStatus.playing) {
            Future.delayed(const Duration(milliseconds: 500), () => botPlay());
          }
        });
      }
    }
  }
  
  void botPlay() {
    if (gameStatus != GameStatus.playing) return;
    if (currentPlayerIndex == 0) return;
    if (isOnline) return;
    
    Player currentBot = players[currentPlayerIndex];
    
    for (int i = 0; i < currentBot.hand.length; i++) {
      var card = currentBot.hand[i];
      if (isValidMove(card)) {
        playCardForBot(currentPlayerIndex, card);
        return;
      }
    }
    
    setState(() {
      message = '${players[currentPlayerIndex].name} tidak punya kartu, skip giliran';
    });
    
    Future.delayed(const Duration(milliseconds: 800), () {
      checkNextTurn();
      if (!isOnline && currentPlayerIndex != 0 && gameStatus == GameStatus.playing) {
        Future.delayed(const Duration(milliseconds: 500), () => botPlay());
      }
    });
  }
  
  void checkNextTurn() {
    for (int i = 0; i < players.length; i++) {
      if (players[i].hand.isEmpty) {
        endGame(i);
        return;
      }
    }
    
    currentPlayerIndex = (currentPlayerIndex + 1) % players.length;
    message = 'Giliran: ${players[currentPlayerIndex].name}';
    
    if (!isOnline && gameStatus == GameStatus.playing && currentPlayerIndex != 0) {
      Future.delayed(const Duration(milliseconds: 500), () => botPlay());
    }
  }
  
  void endGame(int winnerIndex) {
    setState(() {
      gameStatus = GameStatus.finished;
      message = '🎉 ${players[winnerIndex].name} MENANG! 🎉';
      
      for (int i = 0; i < players.length; i++) {
        int totalValue = players[i].hand.fold(0, (sum, card) => sum + card.value);
        if (i == winnerIndex) {
          players[i].score += totalValue;
        } else {
          players[i].score -= totalValue;
        }
      }
    });
    
    if (isOnline && roomId != null) {
      firestore.collection('rooms').doc(roomId).update({
        'gameStatus': 'finished',
        'winner': winnerIndex,
      });
    }
  }
  
  Future<void> leaveRoom() async {
    if (roomId != null) {
      await firestore.collection('rooms').doc(roomId).delete();
    }
  }
  
  void resetGame() {
    if (isOnline) {
      startOnlineGame();
    } else {
      setState(() {
        initializeDeck();
        dealCards();
        determineFirstPlayer();
        gameStatus = GameStatus.playing;
        message = 'Game dimulai ulang! Giliran ${players[currentPlayerIndex].name}';
      });
      
      Future.delayed(const Duration(milliseconds: 500), () {
        if (!isOnline && currentPlayerIndex != 0 && gameStatus == GameStatus.playing) {
          botPlay();
        }
      });
    }
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Text(isOnline ? 'Gaple Online' : 'Gaple Offline'),
            if (isOnline && inviteCode.isNotEmpty)
              Container(
                margin: const EdgeInsets.only(left: 10),
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text('Kode: $inviteCode', style: const TextStyle(fontSize: 12)),
              ),
          ],
        ),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
        actions: [
          if (!isOnline && gameStatus == GameStatus.waiting)
            ElevatedButton(
              onPressed: startOfflineGame,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
              child: const Text('Mulai Game'),
            ),
          if (isOnline && gameStatus == GameStatus.waiting && widget.isHost)
            ElevatedButton(
              onPressed: players.length >= 2 ? startOnlineGame : null,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
              child: const Text('Mulai Game'),
            ),
          // DIPERBAIKI - Tombol refresh dihapus karena tidak diperlukan
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.green.shade900, Colors.green.shade300],
          ),
        ),
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.all(8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.black54,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: players.asMap().entries.map((entry) {
                  int idx = entry.key;
                  Player player = entry.value;
                  return Column(
                    children: [
                      Text(
                        player.name,
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        '${player.score}',
                        style: const TextStyle(color: Colors.yellow, fontSize: 18),
                      ),
                      if (gameStatus == GameStatus.playing && idx == currentPlayerIndex)
                        const Icon(Icons.arrow_upward, color: Colors.yellow, size: 16),
                      if (isOnline && idx > 0 && gameStatus == GameStatus.waiting)
                        const Icon(Icons.person, color: Colors.white70, size: 12),
                    ],
                  );
                }).toList(),
              ),
            ),
            
            Container(
              margin: const EdgeInsets.all(8),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.amber,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(message, style: const TextStyle(fontWeight: FontWeight.bold)),
            ),
            
            Container(
              height: 120,
              margin: const EdgeInsets.all(8),
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.brown.shade800,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.brown.shade600, width: 3),
              ),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: board.map((card) {
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.black, width: 1),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(card.left.toString(), style: const TextStyle(fontSize: 20)),
                          const Text('|', style: TextStyle(fontSize: 20)),
                          Text(card.right.toString(), style: const TextStyle(fontSize: 20)),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
            
            Expanded(
              child: Container(
                margin: const EdgeInsets.all(8),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.9),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Kartu ${players[0].name} (${players[0].hand.length})',
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(height: 8),
                    Expanded(
                      child: GridView.builder(
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 4,
                          childAspectRatio: 1.5,
                          crossAxisSpacing: 8,
                          mainAxisSpacing: 8,
                        ),
                        itemCount: players[0].hand.length,
                        itemBuilder: (context, index) {
                          final card = players[0].hand[index];
                          return CardWidget(
                            card: card,
                            isPlayable: gameStatus == GameStatus.playing && 
                                       currentPlayerIndex == 0 &&
                                       isValidMove(card),
                            onTap: () {
                              if (gameStatus == GameStatus.playing && currentPlayerIndex == 0) {
                                if (board.isEmpty) {
                                  playCard(card, true);
                                } else {
                                  int leftBoard = board.first.left;
                                  int rightBoard = board.last.right;
                                  
                                  if (card.left == leftBoard || card.right == leftBoard) {
                                    playCard(card, true);
                                  } else if (card.left == rightBoard || card.right == rightBoard) {
                                    playCard(card, false);
                                  }
                                }
                              }
                            },
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        if (gameStatus == GameStatus.finished)
                          Expanded(
                            child: ElevatedButton(
                              onPressed: resetGame,
                              style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
                              child: const Text('Main Lagi', style: TextStyle(color: Colors.white)),
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            
            if (players.length > 1)
              Container(
                margin: const EdgeInsets.all(8),
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: players.skip(1).map((player) {
                    return Column(
                      children: [
                        Text(player.name, style: const TextStyle(color: Colors.white)),
                        Text('${player.hand.length} kartu', style: const TextStyle(color: Colors.white70)),
                      ],
                    );
                  }).toList(),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class CardWidget extends StatelessWidget {
  final DominoCard card;
  final bool isPlayable;
  final VoidCallback onTap;
  
  const CardWidget({
    super.key,
    required this.card,
    required this.isPlayable,
    required this.onTap,
  });
  
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: isPlayable ? onTap : null,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isPlayable ? Colors.green : Colors.grey,
            width: isPlayable ? 3 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black26,
              blurRadius: 4,
              offset: const Offset(2, 2),
            ),
          ],
        ),
        child: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(card.left.toString(), 
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 4),
                width: 2,
                height: 30,
                color: Colors.black,
              ),
              Text(card.right.toString(), 
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }
}