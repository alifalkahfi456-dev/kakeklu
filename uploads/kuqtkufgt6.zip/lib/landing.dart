import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with TickerProviderStateMixin {
  late VideoPlayerController _controller;
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  final Color bgBlack = const Color(0xFF000000);
  final Color bgDark = const Color(0xFF0F0518);
  final Color primaryPurple = const Color(0xFFD500F9);
  final Color primaryPink = const Color(0xFFFF4081);
  final Color textWhite = const Color(0xFFFFFFFF);
  final Color textGrey = const Color(0xFFB0BEC5);

  // REGISTER FORM
  bool _isRegistering = false;
  bool _showRegisterForm = false;
  final TextEditingController _regUsername = TextEditingController();
  final TextEditingController _regPassword = TextEditingController();
  final TextEditingController _regConfirmPassword = TextEditingController();

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.asset("assets/videos/landing.mp4")
      ..initialize().then((_) {
        setState(() {});
        _controller.setLooping(true);
        _controller.play();
      });

    _fadeController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );

    _slideController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _slideController, curve: Curves.elasticOut),
    );

    _fadeController.forward();
    _slideController.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    _fadeController.dispose();
    _slideController.dispose();
    _regUsername.dispose();
    _regPassword.dispose();
    _regConfirmPassword.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  Future<void> _register() async {
    String user = _regUsername.text.trim();
    String pass = _regPassword.text.trim();
    String confirm = _regConfirmPassword.text.trim();

    if (user.isEmpty || pass.isEmpty) {
      _showMsg("ERROR", "Username & password required", Colors.red);
      return;
    }
    if (pass != confirm) {
      _showMsg("ERROR", "Passwords do not match", Colors.red);
      return;
    }

    setState(() => _isRegistering = true);

    try {
      // UBAH: dari createAccount menjadi publicRegister
      final res = await http.get(Uri.parse(
        "http://nodepapi.queen-official.com:2565/publicRegister?newUser=$user&pass=$pass&day=30"
      ));
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _showMsg("SUCCESS", "Account created! Please login.", Colors.green);
        _regUsername.clear();
        _regPassword.clear();
        _regConfirmPassword.clear();
        setState(() => _showRegisterForm = false);
        Navigator.pushNamed(context, "/login");
      } else {
        _showMsg("ERROR", data['message'] ?? "Failed", Colors.red);
      }
    } catch (e) {
      _showMsg("ERROR", "Connection failed", Colors.red);
    } finally {
      setState(() => _isRegistering = false);
    }
  }

  void _showMsg(String title, String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        content: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFF141414),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: color.withOpacity(0.5)),
          ),
          child: Row(
            children: [
              Icon(color == Colors.green ? Icons.check_circle : Icons.error, color: color),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                    Text(msg, style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 12)),
                  ],
                ),
              ),
            ],
          ),
        ),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.topCenter,
                  radius: 1.5,
                  colors: [bgDark, bgBlack, Colors.black],
                ),
              ),
              child: CustomPaint(painter: BackgroundPattern()),
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 20),
                  
                  FadeTransition(
                    opacity: _fadeAnimation,
                    child: Column(
                      children: [
                        Text("WELCOME TO", style: TextStyle(color: primaryPurple, fontSize: 14, letterSpacing: 3.0, fontWeight: FontWeight.bold, shadows: [Shadow(color: primaryPurple.withOpacity(0.5), blurRadius: 10)])),
                        const SizedBox(height: 8),
                        Text("XNX-VENGE", textAlign: TextAlign.center, style: TextStyle(color: textWhite, fontSize: 42, fontFamily: 'Courier', fontWeight: FontWeight.w900, shadows: [Shadow(color: primaryPurple.withOpacity(0.8), blurRadius: 20), Shadow(color: textWhite.withOpacity(0.5), blurRadius: 5)])),
                        const SizedBox(height: 8),
                        Text("Ultimate Tools & Resources", style: TextStyle(color: textGrey, fontSize: 14, letterSpacing: 1.5)),
                      ],
                    ),
                  ),

                  const SizedBox(height: 40),

                  SlideTransition(
                    position: _slideAnimation,
                    child: Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.03),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: Colors.white.withOpacity(0.1)),
                      ),
                      child: Column(
                        children: [
                          // LOGIN
                          Container(
                            width: double.infinity,
                            height: 55,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              gradient: LinearGradient(colors: [primaryPurple, primaryPink]),
                              boxShadow: [BoxShadow(color: primaryPurple.withOpacity(0.4), blurRadius: 20, offset: const Offset(0, 4))],
                            ),
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, shadowColor: Colors.transparent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                              onPressed: () => Navigator.pushNamed(context, "/login"),
                              child: Text("LOGIN ACCOUNT", style: TextStyle(color: textWhite, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1.0)),
                            ),
                          ),
                          
                          const SizedBox(height: 16),

                          // REGISTER BUTTON (TOGGLE)
                          Container(
                            width: double.infinity,
                            height: 55,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: Colors.cyanAccent, width: 1.5),
                            ),
                            child: TextButton.icon(
                              onPressed: () => setState(() => _showRegisterForm = !_showRegisterForm),
                              icon: Icon(_showRegisterForm ? Icons.arrow_drop_up : Icons.app_registration, color: Colors.cyanAccent),
                              label: Text(
                                _showRegisterForm ? "CLOSE REGISTER" : "REGISTER (30 DAYS)",
                                style: TextStyle(color: Colors.cyanAccent, fontSize: 14, fontWeight: FontWeight.bold),
                              ),
                            ),
                          ),

                          // REGISTER FORM
                          if (_showRegisterForm)
                            Container(
                              margin: const EdgeInsets.only(top: 16),
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.5),
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: Colors.cyanAccent.withOpacity(0.3)),
                              ),
                              child: Column(
                                children: [
                                  TextField(
                                    controller: _regUsername,
                                    style: const TextStyle(color: Colors.white),
                                    decoration: InputDecoration(
                                      labelText: "USERNAME",
                                      labelStyle: TextStyle(color: primaryPurple),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: BorderSide(color: primaryPurple.withOpacity(0.3)),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: const BorderSide(color: Colors.cyanAccent),
                                      ),
                                      prefixIcon: Icon(Icons.person, color: primaryPurple),
                                    ),
                                  ),
                                  const SizedBox(height: 12),
                                  TextField(
                                    controller: _regPassword,
                                    obscureText: true,
                                    style: const TextStyle(color: Colors.white),
                                    decoration: InputDecoration(
                                      labelText: "PASSWORD",
                                      labelStyle: TextStyle(color: primaryPurple),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: BorderSide(color: primaryPurple.withOpacity(0.3)),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: const BorderSide(color: Colors.cyanAccent),
                                      ),
                                      prefixIcon: Icon(Icons.lock, color: primaryPurple),
                                    ),
                                  ),
                                  const SizedBox(height: 12),
                                  TextField(
                                    controller: _regConfirmPassword,
                                    obscureText: true,
                                    style: const TextStyle(color: Colors.white),
                                    decoration: InputDecoration(
                                      labelText: "CONFIRM PASSWORD",
                                      labelStyle: TextStyle(color: primaryPurple),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: BorderSide(color: primaryPurple.withOpacity(0.3)),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: const BorderSide(color: Colors.cyanAccent),
                                      ),
                                      prefixIcon: Icon(Icons.lock_outline, color: primaryPurple),
                                    ),
                                  ),
                                  const SizedBox(height: 20),
                                  Container(
                                    width: double.infinity,
                                    height: 45,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      gradient: const LinearGradient(colors: [Colors.cyanAccent, Colors.blueAccent]),
                                    ),
                                    child: ElevatedButton(
                                      onPressed: _isRegistering ? null : _register,
                                      style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, shadowColor: Colors.transparent),
                                      child: _isRegistering
                                          ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                                          : const Text("REGISTER NOW", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          
                          const SizedBox(height: 16),

                          // BUY ACCESS
                          Container(
                            width: double.infinity,
                            height: 55,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: primaryPurple, width: 1.5),
                              boxShadow: [BoxShadow(color: primaryPurple.withOpacity(0.1), blurRadius: 10)],
                            ),
                            child: TextButton.icon(
                              onPressed: () => _openUrl("http://nodepapi.queen-official.com:2565"),
                              icon: Icon(Icons.shopping_cart_outlined, color: textWhite, size: 20),
                              label: Text("BUY ACCESS", style: TextStyle(color: textWhite, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1.0)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 30),

                  FadeTransition(
                    opacity: _fadeAnimation,
                    child: Container(
                      height: 220,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: primaryPink.withOpacity(0.3)),
                        boxShadow: [BoxShadow(color: primaryPink.withOpacity(0.15), blurRadius: 30)],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(24),
                        child: Stack(
                          children: [
                            _controller.value.isInitialized
                                ? SizedBox.expand(
                                    child: FittedBox(
                                      fit: BoxFit.cover,
                                      child: SizedBox(
                                        width: _controller.value.size.width,
                                        height: _controller.value.size.height,
                                        child: VideoPlayer(_controller),
                                      ),
                                    ),
                                  )
                                : Container(color: Colors.grey.shade900, child: const Center(child: CircularProgressIndicator())),
                            Positioned.fill(
                              child: Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [Colors.transparent, Colors.black.withOpacity(0.7)],
                                  ),
                                ),
                              ),
                            ),
                            Center(
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(30),
                                child: BackdropFilter(
                                  filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                                    decoration: BoxDecoration(
                                      color: Colors.black.withOpacity(0.5),
                                      borderRadius: BorderRadius.circular(30),
                                      border: Border.all(color: primaryPurple.withOpacity(0.8)),
                                      boxShadow: [BoxShadow(color: primaryPurple.withOpacity(0.4), blurRadius: 15)],
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(Icons.verified, color: Colors.cyanAccent, size: 18),
                                        const SizedBox(width: 8),
                                        Text("@BARZz_REAL01", style: TextStyle(color: textWhite, fontWeight: FontWeight.bold, fontSize: 16)),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 30),

                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 20),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0F1520).withOpacity(0.8),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: Colors.white.withOpacity(0.1)),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 20)],
                    ),
                    child: Column(
                      children: [
                        Text("CONNECT WITH US", style: TextStyle(color: primaryPurple, fontSize: 12, letterSpacing: 2.0, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            _buildSocialCircle(icon: FontAwesomeIcons.telegram, url: "https://t.me/BARZz_REAL01", color: const Color(0xFF0088CC)),
                            const SizedBox(width: 20),
                            _buildSocialCircle(icon: FontAwesomeIcons.tiktok, url: "https://tiktok.com/", color: textWhite),
                          ],
                        ),
                        const SizedBox(height: 20),
                        Divider(color: Colors.white.withOpacity(0.1)),
                        const SizedBox(height: 16),
                        Text("© 2026 XNX-VENGE Projects", style: TextStyle(color: textGrey.withOpacity(0.5), fontSize: 10)),
                      ],
                    ),
                  ),
                  
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSocialCircle({required IconData icon, required String url, required Color color}) {
    return GestureDetector(
      onTap: () => _openUrl(url),
      child: Container(
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white.withOpacity(0.1),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Center(child: FaIcon(icon, color: color, size: 24)),
      ),
    );
  }
}

class BackgroundPattern extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white.withOpacity(0.05)..style = PaintingStyle.fill;
    const dotSize = 2.0;
    const spacing = 30.0;
    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), dotSize, paint);
      }
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}