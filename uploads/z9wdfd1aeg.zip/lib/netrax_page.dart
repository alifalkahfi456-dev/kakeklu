// ignore_for_file: use_build_context_synchronously, deprecated_member_use
import 'dart:ui';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import 'home_page.dart';

// ══════════════════════════════════════════════════════════════════════════════
// CONSTANTS — DARK GREY PREMIUM THEME
// ══════════════════════════════════════════════════════════════════════════════
const Color _nBg = Color(0xFF121212);        // deep dark grey background
const Color _nCard = Color(0xFF1E1E1E);      // card dark grey
const Color _nGreyAccent = Color(0xFFB0BEC5); // soft grey accent
const Color _nGreyDark = Color(0xFF424242);
const Color _nGreyMid = Color(0xFF757575);
const Color _nGreen = Color(0xFF4CAF50);     // kept for WA, but can be greyed if desired
const String _nFont = "Rajdhani";

// ══════════════════════════════════════════════════════════════════════════════
// MAIN PAGE — NO GROUP BUG
// ══════════════════════════════════════════════════════════════════════════════
class NetraxPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final String role;
  final String expiredDate;
  final List<Map<String, dynamic>> listBug;

  NetraxPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.role,
    required this.expiredDate,
    required this.listBug,
  });

  @override
  State<NetraxPage> createState() => _NetraxPageState();
}

class _NetraxPageState extends State<NetraxPage> with TickerProviderStateMixin {
  bool _showContactPopup = false;
  bool _showWarningToast = false;
  int _featureIndex = 0;
  final PageController _featureCtrl = PageController(viewportFraction: 0.88);

  late AnimationController _popupCtrl;
  late Animation<double> _popupScale;
  late Animation<double> _popupFade;

  @override
  void initState() {
    super.initState();
    _popupCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 280));
    _popupScale = CurvedAnimation(parent: _popupCtrl, curve: Curves.easeOutBack);
    _popupFade = CurvedAnimation(parent: _popupCtrl, curve: Curves.easeOut);

    _featureCtrl.addListener(() {
      final p = _featureCtrl.page?.round() ?? 0;
      if (p != _featureIndex) setState(() => _featureIndex = p);
    });
  }

  @override
  void dispose() {
    _popupCtrl.dispose();
    _featureCtrl.dispose();
    super.dispose();
  }

  void _openContact() {
    setState(() => _showContactPopup = true);
    _popupCtrl.forward(from: 0);
  }

  void _closeContact() async {
    await _popupCtrl.reverse();
    if (mounted) setState(() => _showContactPopup = false);
  }

  void _triggerWarning() async {
    setState(() => _showWarningToast = true);
    await Future.delayed(const Duration(seconds: 2));
    if (mounted) setState(() => _showWarningToast = false);
  }

  Future<void> _launch(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  // ─── HEADER (dark grey) ─────────────────────────────────────────────────────
  Widget _buildHeader() {
    return ClipRRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 22, sigmaY: 22),
        child: Container(
          padding: EdgeInsets.only(
            top: MediaQuery.of(context).padding.top + 16,
            bottom: 18,
            left: 18,
            right: 18,
          ),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A1A).withOpacity(0.92),
            border: Border(
              bottom: BorderSide(color: _nGreyAccent.withOpacity(0.12), width: 0.8),
            ),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 12, offset: const Offset(0, 4)),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // ── Kiri: box WA + logo ──
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(9),
                    decoration: BoxDecoration(
                      color: _nGreen.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(11),
                      border: Border.all(color: _nGreen.withOpacity(0.45), width: 1),
                    ),
                    child: const FaIcon(FontAwesomeIcons.whatsapp, color: _nGreen, size: 20),
                  ),
                  const SizedBox(width: 11),
                  RichText(
                    text: const TextSpan(
                      style: TextStyle(
                          fontSize: 21, fontWeight: FontWeight.w900, fontFamily: _nFont, letterSpacing: 2.5),
                      children: [
                        TextSpan(text: 'BL', style: TextStyle(color: Colors.white)),
                        TextSpan(text: 'UE', style: TextStyle(color: _nGreyAccent)),
                        TextSpan(text: '  ', style: TextStyle(color: Colors.white)),
                        TextSpan(text: 'B', style: TextStyle(color: _nGreyAccent)),
                        TextSpan(text: 'UG', style: TextStyle(color: Colors.white)),
                      ],
                    ),
                  ),
                ],
              ),
              // ── Kanan: 2 icon ──
              Row(
                children: [
                  GestureDetector(
                    onTap: _triggerWarning,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.amberAccent.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.amberAccent.withOpacity(0.2), width: 0.8),
                      ),
                      child: const Icon(Icons.warning_amber_rounded, color: Colors.amberAccent, size: 20),
                    ),
                  ),
                  const SizedBox(width: 10),
                  GestureDetector(
                    onTap: _openContact,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: _nGreyAccent.withOpacity(0.10),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: _nGreyAccent.withOpacity(0.25), width: 0.8),
                      ),
                      child: const Icon(Icons.headset_mic_rounded, color: _nGreyAccent, size: 20),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── CONTACT POPUP (dark grey) ─────────────────────────────────────────────
  Widget _buildContactPopup() {
    return Positioned.fill(
      child: FadeTransition(
        opacity: _popupFade,
        child: GestureDetector(
          onTap: _closeContact,
          child: Container(
            color: Colors.black.withOpacity(0.70),
            alignment: Alignment.center,
            child: GestureDetector(
              onTap: () {},
              child: ScaleTransition(
                scale: _popupScale,
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 26),
                  padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
                  decoration: BoxDecoration(
                    color: const Color(0xFF2A2A2A),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: _nGreyAccent.withOpacity(0.15), width: 0.8),
                    boxShadow: [
                      BoxShadow(color: Colors.black.withOpacity(0.55), blurRadius: 40),
                      BoxShadow(color: _nGreyAccent.withOpacity(0.05), blurRadius: 30, spreadRadius: 4),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.groups_rounded, color: _nGreyAccent.withOpacity(0.8), size: 18),
                          const SizedBox(width: 8),
                          const Text(
                            'HUBUNGI TEAM',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 13,
                                fontWeight: FontWeight.w800,
                                fontFamily: _nFont,
                                letterSpacing: 2.0),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Divider(color: Colors.white.withOpacity(0.07), thickness: 0.8),
                      const SizedBox(height: 12),
                      _contactBox('VinzNotDev ( Owner )', 'https://t.me/hidenxvinzz'),
                      const SizedBox(height: 10),
                      _contactBox('Testie Vinz ( Channel )', 'https://t.me/vinzoffcc'),
                      const SizedBox(height: 10),
                      _contactBox('Info hiden ( Chanel )', 'https://t.me/infohidencrasher'),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _contactBox(String name, String url) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF353535),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.06), width: 0.8),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 6, offset: const Offset(0, 2))],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              color: _nGreyAccent.withOpacity(0.16),
              borderRadius: BorderRadius.circular(9),
            ),
            child: const FaIcon(FontAwesomeIcons.telegram, color: _nGreyAccent, size: 15),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(name,
                style: const TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.w500)),
          ),
          GestureDetector(
            onTap: () => _launch(url),
            child: Container(
              padding: const EdgeInsets.all(7),
              decoration: BoxDecoration(
                color: _nGreyAccent.withOpacity(0.14),
                borderRadius: BorderRadius.circular(9),
              ),
              child: const Icon(Icons.arrow_forward_ios_rounded, color: _nGreyAccent, size: 13),
            ),
          ),
        ],
      ),
    );
  }

  // ─── WARNING TOAST (unchanged) ─────────────────────────────────────────────
  Widget _buildWarningToast() {
    return AnimatedOpacity(
      opacity: _showWarningToast ? 1.0 : 0.0,
      duration: const Duration(milliseconds: 280),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
        decoration: BoxDecoration(
          color: const Color(0xFF1C1A10),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.amberAccent.withOpacity(0.5), width: 1),
          boxShadow: [BoxShadow(color: Colors.amberAccent.withOpacity(0.1), blurRadius: 20)],
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.warning_amber_rounded, color: Colors.amberAccent, size: 16),
            SizedBox(width: 8),
            Flexible(
              child: Text(
                'Ngapain Ditekan Bodoh Wkwkwkwk',
                style: TextStyle(color: Colors.amberAccent, fontSize: 13, fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── NEWS SECTION (grey accents) ───────────────────────────────────────────
  Widget _buildNewsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            children: [
              _fireIcon(),
              const SizedBox(width: 9),
              const Text(
                'BLUE BUG ( LATEST NEWS )',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    fontFamily: _nFont,
                    letterSpacing: 1.2),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 220,
          child: ListView(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 20),
            children: [
              _newsCard(
                icon: Icons.code_rounded,
                title: 'New Update Func !!',
                items: const ['New Func Delay', 'New Crash ios', 'New Crash X Delay', 'New Delay Hard', 'New Crash Home'],
                topColor: const Color(0xFF3A3A3A),
                bottomColor: const Color(0xFF1F1F1F),
              ),
              const SizedBox(width: 14),
              _newsCard(
                icon: FontAwesomeIcons.bug,
                title: 'New Bug',
                items: const ['Bug Command Ready', 'Pengoptimalan Bug Group', 'Pengoptimalan Bug Basic'],
                topColor: const Color(0xFF2C2C2C),
                bottomColor: const Color(0xFF1A1A1A),
              ),
              const SizedBox(width: 14),
              _newsCard(
                icon: Icons.bolt_rounded,
                title: 'Hot Patch',
                items: const ['Fix Crash Report', 'Stability Update', 'Speed Boost x2'],
                topColor: const Color(0xFF2E2E2E),
                bottomColor: const Color(0xFF181818),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _fireIcon() {
    return SizedBox(
      width: 26,
      height: 26,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Icon(Icons.local_fire_department, color: Colors.red.shade900, size: 26),
          Icon(Icons.local_fire_department, color: Colors.deepOrange.shade700, size: 20),
          const Icon(Icons.local_fire_department, color: Colors.orange, size: 13),
        ],
      ),
    );
  }

  Widget _newsCard({
    required IconData icon,
    required String title,
    required List<String> items,
    required Color topColor,
    required Color bottomColor,
  }) {
    return Container(
      width: 252,
      decoration: BoxDecoration(
        gradient: LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [topColor, bottomColor]),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.07), width: 0.8),
        boxShadow: [
          BoxShadow(color: topColor.withOpacity(0.45), blurRadius: 18, offset: const Offset(0, 8)),
          BoxShadow(color: Colors.black.withOpacity(0.35), blurRadius: 6),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          children: [
            Positioned(
              top: -24,
              left: -24,
              child: Container(
                  width: 76,
                  height: 76,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle, color: Colors.white.withOpacity(0.06))),
            ),
            Positioned(
              bottom: -30,
              right: -30,
              child: Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle, color: Colors.white.withOpacity(0.05))),
            ),
            Padding(
              padding: const EdgeInsets.all(17),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(icon, color: Colors.white, size: 18),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(title,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                fontFamily: _nFont)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  ...items.map((item) => Padding(
                        padding: const EdgeInsets.only(bottom: 7),
                        child: Row(
                          children: [
                            const Icon(Icons.check_circle_rounded, color: Colors.white54, size: 13),
                            const SizedBox(width: 8),
                            Expanded(
                                child: Text(item,
                                    style: const TextStyle(color: Colors.white60, fontSize: 11))),
                          ],
                        ),
                      )),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── FEATURE SECTION — ONLY TWO CARDS (BUG BASIC + BUG COMMAND) ────────────
  Widget _buildFeatureSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            children: [
              const Icon(Icons.widgets_rounded, color: Colors.white54, size: 20),
              const SizedBox(width: 8),
              const Text(
                'BUG FEATURE',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    fontFamily: _nFont,
                    letterSpacing: 1.2),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                decoration: BoxDecoration(color: _nGreyMid, borderRadius: BorderRadius.circular(6)),
                child: const Text('NEW',
                    style: TextStyle(
                        color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1)),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 232,
          child: PageView(
            controller: _featureCtrl,
            physics: const BouncingScrollPhysics(),
            children: [
              // BUG BASIC
              _featureCard(
                icon: FontAwesomeIcons.whatsapp,
                title: 'BUG WHATSAPP',
                items: const ['Func Terbaru', 'Crash Ios New', 'Mudah Dan Praktis', 'Sudah Diuji Oleh Tim Hiden'],
                cardColor: const Color(0xFF1E1E2F),
                accentColor: _nGreyAccent,
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => HomePage(
                      username: widget.username,
                      password: widget.password,
                      sessionKey: widget.sessionKey,
                      listBug: widget.listBug,
                      role: widget.role,
                      expiredDate: widget.expiredDate,
                    ),
                  ),
                ),
              ),
              // BUG COMMAND
            ],
          ),
        ),
        const SizedBox(height: 14),
        // Dot indicators — now only 2 dots
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(2, (i) {
            final active = i == _featureIndex;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              width: active ? 22 : 7,
              height: 7,
              decoration: BoxDecoration(
                color: active ? _nGreyAccent : Colors.white.withOpacity(0.18),
                borderRadius: BorderRadius.circular(4),
              ),
            );
          }),
        ),
      ],
    );
  }

  Widget _featureCard({
    required IconData icon,
    required String title,
    required List<String> items,
    required Color cardColor,
    required Color accentColor,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: accentColor.withOpacity(0.28), width: 1),
          boxShadow: [
            BoxShadow(color: cardColor.withOpacity(0.7), blurRadius: 24, offset: const Offset(0, 10), spreadRadius: 1),
            BoxShadow(color: accentColor.withOpacity(0.10), blurRadius: 14),
            BoxShadow(color: Colors.black.withOpacity(0.35), blurRadius: 8, offset: const Offset(4, 4)),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: Stack(
            children: [
              Positioned(
                top: -22,
                left: -22,
                child: Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle, color: Colors.white.withOpacity(0.05))),
              ),
              Positioned(
                bottom: -32,
                right: -32,
                child: Container(
                    width: 105,
                    height: 105,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle, color: Colors.white.withOpacity(0.04))),
              ),
              Padding(
                padding: const EdgeInsets.all(19),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(9),
                          decoration: BoxDecoration(
                            color: accentColor.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: accentColor.withOpacity(0.3), width: 1),
                          ),
                          child: Icon(icon, color: accentColor, size: 21),
                        ),
                        const SizedBox(width: 13),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(title,
                                style: TextStyle(
                                    color: accentColor,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w800,
                                    fontFamily: _nFont,
                                    letterSpacing: 1.0)),
                            Text('Tap to launch',
                                style: TextStyle(
                                    color: Colors.white.withOpacity(0.3),
                                    fontSize: 10,
                                    fontFamily: _nFont)),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    ...items.map((item) => Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Row(
                            children: [
                              Icon(Icons.check_circle_rounded,
                                  color: accentColor.withOpacity(0.7), size: 13),
                              const SizedBox(width: 9),
                              Text(item,
                                  style: const TextStyle(color: Colors.white60, fontSize: 11.5)),
                            ],
                          ),
                        )),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── FOOTER (dark grey) ────────────────────────────────────────────────────
  Widget _buildFooter() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 20),
      decoration: BoxDecoration(
        color: _nCard.withOpacity(0.55),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.06), width: 0.8),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.25), blurRadius: 12)],
      ),
      child: Column(
        children: [
          const Text(
            'BY : @hidenxvinzz',
            style: TextStyle(
                color: Colors.white,
                fontSize: 15,
                fontWeight: FontWeight.w900,
                fontFamily: _nFont,
                letterSpacing: 2.5),
          ),
          const SizedBox(height: 5),
          Text(
            'Powered by the best team in the universe.',
            style: TextStyle(color: Colors.white.withOpacity(0.28), fontSize: 11, fontFamily: _nFont),
          ),
        ],
      ),
    );
  }

  // ─── BUILD ──────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final topPad = MediaQuery.of(context).padding.top;

    return Scaffold(
      backgroundColor: _nBg,
      body: Stack(
        children: [
          // Hexagon background (grey version)
          Positioned(
            top: -20,
            right: -20,
            child: CustomPaint(
              size: const Size(220, 220),
              painter: _HexPainter(color: _nGreyAccent.withOpacity(0.07)),
            ),
          ),
          Positioned(
            bottom: -20,
            left: -20,
            child: CustomPaint(
              size: const Size(220, 220),
              painter: _HexPainter(color: _nGreyAccent.withOpacity(0.07)),
            ),
          ),

          SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: EdgeInsets.only(top: topPad + 80, bottom: 50),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 14),
                _buildNewsSection(),
                const SizedBox(height: 28),
                _buildFeatureSection(),
                const SizedBox(height: 28),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: _buildFooter(),
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),

          Positioned(top: 0, left: 0, right: 0, child: _buildHeader()),
          Positioned(
            top: topPad + 82,
            left: 22,
            right: 22,
            child: _buildWarningToast(),
          ),
          if (_showContactPopup) _buildContactPopup(),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// HEXAGON PAINTER (unchanged)
// ══════════════════════════════════════════════════════════════════════════════
class _HexPainter extends CustomPainter {
  final Color color;
  const _HexPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    const r = 56.0;
    final centers = <Offset>[
      const Offset(65, 65),
      const Offset(170, 65),
      const Offset(117, 155),
    ];

    for (final c in centers) {
      final path = Path();
      for (int i = 0; i < 6; i++) {
        final angle = math.pi / 180 * (60 * i - 30);
        final x = c.dx + r * math.cos(angle);
        final y = c.dy + r * math.sin(angle);
        if (i == 0) {
          path.moveTo(x, y);
        } else {
          path.lineTo(x, y);
        }
      }
      path.close();
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(_HexPainter old) => false;
}

// ══════════════════════════════════════════════════════════════════════════════
// BLUR EXTENSION (unchanged)
// ══════════════════════════════════════════════════════════════════════════════
extension BlurExtension on Widget {
  Widget blurred({double sigma = 10}) {
    return BackdropFilter(
      filter: ImageFilter.blur(sigmaX: sigma, sigmaY: sigma),
      child: this,
    );
  }
}