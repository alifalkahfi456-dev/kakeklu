const String apiBaseUrl = "http://vintolxbuyerbetot.omdhankiw.my.id:2000";

const String urlRat = "http://vintolxbuyerbetot.omdhankiw.my.id:2001";
