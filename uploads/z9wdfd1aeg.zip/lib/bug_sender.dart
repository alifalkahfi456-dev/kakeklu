import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import '.dart';

class BugSenderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const BugSenderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage> with SingleTickerProviderStateMixin {
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;
  late TabController _tabController;
  
  // Neon Red Theme
  final Color neonRed = const Color(0xFFFF2E63);
  final Color neonRedLight = const Color(0xFFFF6B8A);
  final Color neonRedDark = const Color(0xFFC41E3A);
  final Color bgDark = const Color(0xFF05050A);
  final Color bgCard = const Color(0xFF0A0A14);
  final Color bgSurface = const Color(0xFF11111F);
  final Color textPrimary = const Color(0xFFF3F8FF);
  final Color textMuted = const Color(0xFF8A93B5);

  List<dynamic> privateSenders = [];
  List<dynamic> globalSenders = [];
  bool isLoading = false;
  String? currentSenderId;
  String? currentSenderName;
  bool isUsingGlobal = false;
  String? errorMessage;

  bool get canAddGlobal => ["member", "reseller", "owner", "developer", "admin"].contains(widget.role.toLowerCase());

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.3, end: 0.9).animate(_glowController);
    _fetchSenders();
    _getCurrentSender();
  }

  @override
  void dispose() {
    _glowController.dispose();
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _getCurrentSender() async {
    try {
      final res = await http.get(
        Uri.parse("$apiBaseUrl/currentSender?key=${widget.sessionKey}"),
      );
      final data = jsonDecode(res.body);
      if (res.statusCode == 200 && data["valid"] == true) {
        setState(() {
          currentSenderId = data["senderId"];
          currentSenderName = data["senderName"];
          isUsingGlobal = data["isGlobal"] == true;
        });
      }
    } catch (e) {}
  }

  Future<void> _fetchSenders() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });
    try {
      final res = await http.get(
        Uri.parse("$apiBaseUrl/mySender?key=${widget.sessionKey}"),
      );
      final data = jsonDecode(res.body);
      if (res.statusCode == 200 && data["valid"] == true) {
        final connections = data["connections"] as List<dynamic>? ?? [];
        final globalSendersList = data["globalConnections"] as List<dynamic>? ?? [];
        
        // Sort private senders
        final sortedPrivate = connections.toList();
        sortedPrivate.sort((a, b) => (a["sessionName"] ?? "").toString().compareTo(
          (b["sessionName"] ?? "").toString(),
        ));
        
        // Sort global senders
        final sortedGlobal = globalSendersList.toList();
        sortedGlobal.sort((a, b) => (a["sessionName"] ?? "").toString().compareTo(
          (b["sessionName"] ?? "").toString(),
        ));
        
        setState(() {
          privateSenders = sortedPrivate;
          globalSenders = sortedGlobal;
        });
      } else {
        setState(() {
          errorMessage = data["message"] ?? "Failed to fetch senders";
        });
      }
    } catch (e) {
      setState(() => errorMessage = "Connection failed: $e");
    } finally {
      setState(() => isLoading = false);
    }
  }

  Future<void> _addSender(String number, bool isGlobal) async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse(
          "$apiBaseUrl/getPairing?key=${widget.sessionKey}&number=$number&global=${isGlobal ? 1 : 0}",
        ),
      );
      final data = jsonDecode(res.body);
      if (res.statusCode == 200 && data["valid"] == true) {
        _pairingDialog(number, data["pairingCode"].toString());
        _showSnackbar("Pairing code generated successfully");
        await _fetchSenders();
      } else {
        _showSnackbar(data["message"] ?? "Failed to generate pairing code", isError: true);
      }
    } catch (e) {
      _showSnackbar("Connection failed: $e", isError: true);
    } finally {
      setState(() => isLoading = false);
    }
  }

  Future<void> _useSender(String id, String name, bool isGlobal) async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse(
          "$apiBaseUrl/useSender?key=${widget.sessionKey}&senderId=$id&scope=${isGlobal ? 'global' : 'private'}",
        ),
      );
      final data = jsonDecode(res.body);
      if (res.statusCode == 200 && data["valid"] == true) {
        setState(() {
          currentSenderId = id;
          currentSenderName = name;
          isUsingGlobal = isGlobal;
        });
        _showSnackbar("Now using: $name");
        await _fetchSenders();
        await _getCurrentSender();
      } else {
        _showSnackbar(data["message"] ?? "Failed to use sender", isError: true);
      }
    } catch (e) {
      _showSnackbar("Connection failed: $e", isError: true);
    } finally {
      setState(() => isLoading = false);
    }
  }

  Future<void> _deleteSender(String id, bool isGlobal) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgCard,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: neonRed.withOpacity(0.5)),
        ),
        title: Text(
          "CONFIRM DELETE",
          style: TextStyle(color: neonRed, fontFamily: 'Orbitron', fontSize: 16),
        ),
        content: Text(
          isGlobal
              ? "This global sender will be deleted for ALL users."
              : "Delete this sender permanently?",
          style: TextStyle(color: textMuted, fontFamily: 'ShareTechMono'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text("CANCEL", style: TextStyle(color: Colors.white54)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text("DELETE", style: TextStyle(color: neonRed, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
    if (ok != true) return;

    setState(() => isLoading = true);
    try {
      final res = await http.delete(
        Uri.parse(
          "$apiBaseUrl/deleteSender?key=${widget.sessionKey}&id=$id&scope=${isGlobal ? 'global' : 'private'}",
        ),
      );
      final data = jsonDecode(res.body);
      if (res.statusCode == 200 && data["valid"] == true) {
        _showSnackbar("Sender deleted successfully");
        if (currentSenderId == id) {
          setState(() {
            currentSenderId = null;
            currentSenderName = null;
            isUsingGlobal = false;
          });
        }
        await _fetchSenders();
        await _getCurrentSender();
      } else {
        _showSnackbar(data["message"] ?? "Failed to delete sender", isError: true);
      }
    } catch (e) {
      _showSnackbar("Connection failed: $e", isError: true);
    } finally {
      setState(() => isLoading = false);
    }
  }

  void _addDialog() {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (_) {
        var isGlobal = false;
        return StatefulBuilder(
          builder: (context, setLocal) => Dialog(
            backgroundColor: Colors.transparent,
            child: Container(
              width: 400,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: bgCard,
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: neonRed.withOpacity(0.3)),
                boxShadow: [
                  BoxShadow(color: neonRed.withOpacity(0.15), blurRadius: 30, spreadRadius: 5, offset: const Offset(0, 10)),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [neonRed, neonRedLight]),
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [BoxShadow(color: neonRed.withOpacity(0.4), blurRadius: 12)],
                        ),
                        child: const Icon(Icons.add_link_rounded, color: Colors.white, size: 24),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "ADD NEW SENDER",
                              style: TextStyle(
                                fontFamily: 'Orbitron',
                                fontSize: 16,
                                color: neonRed,
                                letterSpacing: 1,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              "Connect WhatsApp session with pairing code",
                              style: TextStyle(color: textMuted, fontSize: 11, fontFamily: 'ShareTechMono'),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: controller,
                    keyboardType: TextInputType.phone,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: "628xxxxxxxxxx",
                      hintStyle: TextStyle(color: textMuted.withOpacity(0.5)),
                      prefixIcon: Icon(Icons.phone_android_rounded, color: neonRed),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: BorderSide(color: neonRed.withOpacity(0.3)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: BorderSide(color: neonRed, width: 1.5),
                      ),
                      filled: true,
                      fillColor: bgSurface,
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (canAddGlobal)
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      value: isGlobal,
                      onChanged: (v) => setLocal(() => isGlobal = v),
                      title: Text(
                        "GLOBAL SENDER",
                        style: TextStyle(color: textPrimary, fontSize: 13, fontFamily: 'Orbitron', letterSpacing: 1),
                      ),
                      subtitle: Text(
                        "Available for ALL users",
                        style: TextStyle(color: textMuted, fontSize: 10, fontFamily: 'ShareTechMono'),
                      ),
                      activeColor: neonRed,
                    ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: TextButton(
                          onPressed: () => Navigator.pop(context),
                          style: TextButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          ),
                          child: Text("CANCEL", style: TextStyle(color: textMuted, fontWeight: FontWeight.bold)),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () async {
                            final number = controller.text.trim();
                            if (number.isEmpty) {
                              _showSnackbar("Please enter phone number", isError: true);
                              return;
                            }
                            if (isGlobal && !canAddGlobal) {
                              _showSnackbar("Only owner can add global sender", isError: true);
                              return;
                            }
                            Navigator.pop(context);
                            await _addSender(number, isGlobal);
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: neonRed,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          ),
                          child: const Text("GENERATE CODE", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _pairingDialog(String number, String code) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: bgCard,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: neonRed.withOpacity(0.4)),
            boxShadow: [BoxShadow(color: neonRed.withOpacity(0.2), blurRadius: 20)],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [neonRed, neonRedDark]),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Icon(Icons.qr_code_scanner_rounded, color: Colors.white, size: 30),
              ),
              const SizedBox(height: 16),
              Text(
                "PAIRING CODE",
                style: TextStyle(
                  fontFamily: 'Orbitron',
                  fontSize: 18,
                  color: neonRed,
                  letterSpacing: 2,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text("Number: $number", style: TextStyle(color: textMuted, fontFamily: 'ShareTechMono')),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: bgSurface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: neonRed.withOpacity(0.3)),
                ),
                child: SelectableText(
                  code,
                  style: TextStyle(
                    color: neonRed,
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 6,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () async {
                        await Clipboard.setData(ClipboardData(text: code));
                        _showSnackbar("Code copied to clipboard");
                      },
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      child: Text("COPY", style: TextStyle(color: neonRed, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        _fetchSenders();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: neonRed,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      child: const Text("CLOSE", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSnackbar(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontFamily: 'ShareTechMono')),
        backgroundColor: isError ? neonRed : neonRedDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  Widget _buildCurrentSender() {
    if (currentSenderId == null) {
      return Container(
        margin: const EdgeInsets.fromLTRB(16, 12, 16, 8),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [neonRed.withOpacity(0.15), bgCard],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: neonRed.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: neonRed, size: 20),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                "No sender selected. Please select a sender to start.",
                style: TextStyle(color: textMuted, fontSize: 12, fontFamily: 'ShareTechMono'),
              ),
            ),
          ],
        ),
      );
    }

    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (context, child) {
        return Container(
          margin: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [neonRed.withOpacity(0.2), bgCard],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: neonRed.withOpacity(0.4 + (0.1 * _glowAnimation.value)),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: neonRed.withOpacity(0.1 * _glowAnimation.value),
                blurRadius: 12,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [neonRed, neonRedDark]),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  isUsingGlobal ? Icons.public_rounded : Icons.phone_android_rounded,
                  color: Colors.white,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "ACTIVE SENDER",
                      style: TextStyle(
                        color: neonRed.withOpacity(0.7),
                        fontSize: 10,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                      ),
                    ),
                    Text(
                      currentSenderName ?? "Unknown",
                      style: TextStyle(
                        color: textPrimary,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: neonRed.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: neonRed.withOpacity(0.3)),
                ),
                child: Text(
                  isUsingGlobal ? "GLOBAL" : "PRIVATE",
                  style: TextStyle(
                    color: neonRed,
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSenderCard(Map<String, dynamic> s, bool isGlobal) {
    final name = (s["sessionName"] ?? (isGlobal ? "Global Sender" : "Private Sender")).toString();
    final id = (s["id"] ?? name).toString();
    final isActive = currentSenderId == id;
    final canDelete = s["canDelete"] != false && (isGlobal ? canAddGlobal : true);
    
    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (context, child) {
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: isActive ? neonRed.withOpacity(0.05) : bgCard,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: isActive 
                ? neonRed 
                : neonRed.withOpacity(0.25 + (0.05 * _glowAnimation.value)),
              width: isActive ? 2 : 1.2,
            ),
            boxShadow: [
              BoxShadow(
                color: neonRed.withOpacity(isActive ? 0.15 : 0.05 * _glowAnimation.value),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: isActive 
                          ? [neonRed.withOpacity(0.3), neonRedDark.withOpacity(0.15)]
                          : [neonRed.withOpacity(0.15), neonRedDark.withOpacity(0.05)],
                      ),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: isActive ? neonRed : neonRed.withOpacity(0.3)),
                    ),
                    child: Icon(
                      isGlobal ? Icons.public_rounded : Icons.phone_android_rounded,
                      color: isActive ? neonRed : neonRed.withOpacity(0.7),
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                name,
                                style: TextStyle(
                                  color: isActive ? neonRed : textPrimary,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 1,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            if (isActive)
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: neonRed,
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: const Text(
                                  "ACTIVE",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 8,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 1,
                                  ),
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: isGlobal ? neonRed.withOpacity(0.12) : bgSurface,
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: neonRed.withOpacity(0.2)),
                          ),
                          child: Text(
                            isGlobal ? "GLOBAL SENDER" : "PRIVATE SENDER",
                            style: TextStyle(
                              color: isGlobal ? neonRed : textMuted,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: isActive ? null : () => _useSender(id, name, isGlobal),
                      icon: Icon(isActive ? Icons.check_circle_rounded : Icons.play_arrow_rounded, size: 18),
                      label: Text(isActive ? "ACTIVE" : "USE", style: const TextStyle(fontWeight: FontWeight.bold)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: isActive ? Colors.transparent : neonRed,
                        foregroundColor: isActive ? neonRed : Colors.white,
                        disabledBackgroundColor: neonRed.withOpacity(0.1),
                        disabledForegroundColor: neonRed.withOpacity(0.5),
                        side: isActive ? BorderSide(color: neonRed.withOpacity(0.5)) : null,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: canDelete && !isActive ? () => _deleteSender(id, isGlobal) : null,
                      icon: Icon(
                        canDelete && !isActive ? Icons.delete_outline_rounded : (isActive ? Icons.lock_outline_rounded : Icons.block_rounded),
                        size: 18,
                      ),
                      label: Text(
                        canDelete && !isActive ? "DELETE" : (isActive ? "ACTIVE" : "LOCKED"),
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: canDelete && !isActive ? neonRed : textMuted,
                        side: BorderSide(color: canDelete && !isActive ? neonRed.withOpacity(0.5) : textMuted.withOpacity(0.3)),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildPrivateTab() {
    if (isLoading && privateSenders.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircularProgressIndicator(color: Color(0xFFFF2E63)),
            const SizedBox(height: 16),
            Text(
              "LOADING PRIVATE SENDERS",
              style: TextStyle(color: neonRed.withOpacity(0.7), fontSize: 11, fontFamily: 'ShareTechMono', letterSpacing: 2),
            ),
          ],
        ),
      );
    }

    if (errorMessage != null && privateSenders.isEmpty && globalSenders.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline_rounded, color: neonRed, size: 48),
            const SizedBox(height: 12),
            Text(
              errorMessage!,
              style: TextStyle(color: textMuted, fontFamily: 'ShareTechMono'),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    if (privateSenders.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.sensor_door_rounded, color: textMuted, size: 48),
            const SizedBox(height: 12),
            Text(
              "NO PRIVATE SENDERS",
              style: TextStyle(color: textMuted, fontFamily: 'Orbitron', fontSize: 14, letterSpacing: 1),
            ),
            const SizedBox(height: 8),
            Text(
              "Tap + button to add a private sender",
              style: TextStyle(color: textMuted.withOpacity(0.7), fontSize: 11, fontFamily: 'ShareTechMono'),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _fetchSenders,
      color: neonRed,
      child: ListView.builder(
        padding: const EdgeInsets.only(bottom: 80),
        itemCount: privateSenders.length,
        itemBuilder: (_, i) => _buildSenderCard(Map<String, dynamic>.from(privateSenders[i]), false),
      ),
    );
  }

  Widget _buildGlobalTab() {
    if (isLoading && globalSenders.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircularProgressIndicator(color: Color(0xFFFF2E63)),
            const SizedBox(height: 16),
            Text(
              "LOADING GLOBAL SENDERS",
              style: TextStyle(color: neonRed.withOpacity(0.7), fontSize: 11, fontFamily: 'ShareTechMono', letterSpacing: 2),
            ),
          ],
        ),
      );
    }

    if (errorMessage != null && privateSenders.isEmpty && globalSenders.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline_rounded, color: neonRed, size: 48),
            const SizedBox(height: 12),
            Text(
              errorMessage!,
              style: TextStyle(color: textMuted, fontFamily: 'ShareTechMono'),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    if (globalSenders.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.public_off_rounded, color: textMuted, size: 48),
            const SizedBox(height: 12),
            Text(
              "NO GLOBAL SENDERS",
              style: TextStyle(color: textMuted, fontFamily: 'Orbitron', fontSize: 14, letterSpacing: 1),
            ),
            const SizedBox(height: 8),
            Text(
              canAddGlobal
                ? "Tap + button to add a global sender"
                : "Only owner can add global senders",
              style: TextStyle(color: textMuted.withOpacity(0.7), fontSize: 11, fontFamily: 'ShareTechMono'),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _fetchSenders,
      color: neonRed,
      child: ListView.builder(
        padding: const EdgeInsets.only(bottom: 80),
        itemCount: globalSenders.length,
        itemBuilder: (_, i) => _buildSenderCard(Map<String, dynamic>.from(globalSenders[i]), true),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [neonRed, neonRedDark]),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.bug_report_rounded, color: Colors.white, size: 18),
            ),
            const SizedBox(width: 10),
            Text(
              "SENDER MANAGER",
              style: TextStyle(
                fontFamily: 'Orbitron',
                fontSize: 14,
                color: neonRed,
                letterSpacing: 2,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        backgroundColor: bgSurface,
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(48),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: bgCard,
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: neonRed.withOpacity(0.2)),
                    ),
                    child: TabBar(
                      controller: _tabController,
                      labelColor: neonRed,
                      unselectedLabelColor: textMuted,
                      indicator: BoxDecoration(
                        color: neonRed.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(30),
                      ),
                      labelStyle: const TextStyle(
                        fontFamily: 'Orbitron',
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                      tabs: const [
                        Tab(text: "PRIVATE", icon: Icon(Icons.phone_android_rounded, size: 18)),
                        Tab(text: "GLOBAL", icon: Icon(Icons.public_rounded, size: 18)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          IconButton(
            onPressed: isLoading ? null : _fetchSenders,
            icon: AnimatedBuilder(
              animation: _glowAnimation,
              builder: (context, child) => Icon(
                Icons.refresh_rounded,
                color: neonRed.withOpacity(0.7 + (0.3 * _glowAnimation.value)),
              ),
            ),
            tooltip: "REFRESH",
          ),
        ],
      ),
      body: Column(
        children: [
          _buildCurrentSender(),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildPrivateTab(),
                _buildGlobalTab(),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: AnimatedBuilder(
        animation: _glowAnimation,
        builder: (context, child) {
          return FloatingActionButton(
            onPressed: _addDialog,
            backgroundColor: neonRed,
            foregroundColor: Colors.white,
            elevation: 8,
            child: const Icon(Icons.add_rounded, size: 28),
          );
        },
      ),
    );
  }
}