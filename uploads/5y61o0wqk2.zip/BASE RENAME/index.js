const { Telegraf, Markup } = require("telegraf");
const fs = require('fs');
const pino = require('pino');
const crypto = require('crypto');
const chalk = require('chalk');
const path = require("path");
const axios = require("axios");
const express = require('express');
const fetch = require("node-fetch");
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const { spawn } = require('child_process');
const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestWaWebVersion,
    delay
} = require("@whiskeysockets/baileys");

// --- CONFIGURATION (MASTER RANZ DATA) ---
const config = {
    tokens: "8661538960:AAFxsbrYiUkv1Yhuz_kbE4OvzRpCaKT89vE",
    owners: ["1682354183"], // ID MASTER RANZ
    port: 3000
};

const bot = new Telegraf(config.tokens);
const app = express();
const sessions = new Map();
const userEvents = new Map(); 

// --- DIRECTORY SETUP ---
const sessions_dir = "./auth";
const file_akses = "./database/akses.json";
const userSessionsPath = path.join(__dirname, "user_sessions.json");

if (!fs.existsSync("./database")) fs.mkdirSync("./database");

// --- AUTH SYSTEM ---
function loadAkses() {
    if (!fs.existsSync(file_akses)) {
        const initData = { owners: config.owners, akses: [], resellers: [], pts: [], moderators: [] };
        fs.writeFileSync(file_akses, JSON.stringify(initData, null, 2));
        return initData;
    }
    return JSON.parse(fs.readFileSync(file_akses));
}

function isOwner(id) {
    const data = loadAkses();
    return data.owners.includes(id.toString());
}

// --- WHATSAPP CONNECTION CORE ---
const connectToWhatsAppUser = async (username, BotNumber, sessionDir) => {
    try {
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
        const { version } = await fetchLatestWaWebVersion();

        const userSock = makeWASocket({
            auth: state,
            printQRInTerminal: false,
            logger: pino({ level: "silent" }),
            version: version,
            browser: ["INTIVICTUS V2", "Chrome", "1.0.0"]
        });

        userSock.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect, qr } = update;
            
            if (connection === "open") {
                console.log(chalk.green(`[INTIVICTUS] ${BotNumber} CONNECTED!`));
                sessions.set(BotNumber, userSock);
            }

            if (qr) {
                console.log(chalk.yellow(`[INTIVICTUS] Pairing Required for ${BotNumber}`));
            }

            if (connection === "close") {
                const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
                if (shouldReconnect) connectToWhatsAppUser(username, BotNumber, sessionDir);
            }
        });

        userSock.ev.on("creds.update", saveCreds);
        return userSock;
    } catch (error) {
        console.error("Connection Error:", error);
    }
};

// --- TELEGRAM COMMANDS (RENAME VERSION) ---
bot.command("start", async (ctx) => {
    const username = ctx.from.username || ctx.from.first_name;
    const teks = `
<blockquote>🛡️ INTIVICTUS V2 - MASTER EDITION</blockquote>
<i>Sistem pengiriman pesan dan manajemen akses telah diperbarui.</i>

<b>Developer : @Ranz (Owner)</b>
<b>Version   : 4.0 ⧸ <code>V2</code></b>
<b>User      : ${username}</b>

<i>Gunakan menu di bawah untuk mengelola sistem:</i>`;

    const keyboard = Markup.keyboard([
        ["🔑 Create Menu", "🔐 Access Menu"],
        ["ℹ️ System Info", "💬 Chat"],
        ["📢 Channel"]
    ]).resize();

    await ctx.reply(teks, { parse_mode: "HTML", reply_markup: keyboard.reply_markup });
});

bot.hears("🔑 Create Menu", async (ctx) => {
    const menu = `
<blockquote>🛡️ INTIVICTUS V2 - KEYS</blockquote>
• /addkey
• /listkey
• /delkey`;
    await ctx.reply(menu, { parse_mode: "HTML" });
});

bot.hears("🔐 Access Menu", async (ctx) => {
    const menu = `
<blockquote>🛡️ INTIVICTUS V2 - ACCESS</blockquote>
• /addacces | /delacces
• /addowner | /delowner
• /addreseller | /delreseller
• /addpt | /delpt
• /addmod | /delmod`;
    await ctx.reply(menu, { parse_mode: "HTML" });
});

// --- API & SERVER ---
app.get('/', (req, res) => res.send('INTIVICTUS V2 SERVER ACTIVE'));

bot.launch().then(() => {
    console.log(chalk.cyan("╔═════════════════════════════╗"));
    console.log(chalk.cyan("║    INTIVICTUS V2 ONLINE     ║"));
    console.log(chalk.cyan("║    OWNER: MASTER RANZ       ║"));
    console.log(chalk.cyan("╚═════════════════════════════╝"));
});

// Emergency Stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
