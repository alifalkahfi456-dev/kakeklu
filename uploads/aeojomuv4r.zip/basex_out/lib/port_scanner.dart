import 'dart:io';
import 'package:flutter/material.dart';

class PortScannerPage extends StatefulWidget {
  const PortScannerPage({super.key});

  @override
  State<PortScannerPage> createState() => _PortScannerPageState();
}

class _PortScannerPageState extends State<PortScannerPage> {
  final TextEditingController _hostController = TextEditingController();
  final TextEditingController _portController = TextEditingController();
  bool _isScanning = false;
  String _result = "";
  List<int> _openPorts = [];

  final Color bgBlack = Colors.black;
  final Color greyDark = Colors.grey[800]!;
  final Color greyLight = Colors.grey[500]!;
  final Color redDark = const Color(0xFFB71C1C);

  Future<void> _scanPorts() async {
    final host = _hostController.text.trim();
    final portsInput = _portController.text.trim();
    if (host.isEmpty || portsInput.isEmpty) {
      setState(() {
        _result = "Masukkan host dan port (pisahkan dengan koma)";
        _openPorts = [];
      });
      return;
    }

    List<int> ports = [];
    for (var p in portsInput.split(',')) {
      final port = int.tryParse(p.trim());
      if (port != null && port > 0 && port < 65536) ports.add(port);
    }
    if (ports.isEmpty) {
      setState(() {
        _result = "Port tidak valid. Contoh: 80,443,8080";
        _openPorts = [];
      });
      return;
    }

    setState(() {
      _isScanning = true;
      _result = "Memindai $host pada port ${ports.join(', ')}...";
      _openPorts = [];
    });

    List<int> open = [];
    for (int port in ports) {
      try {
        final socket = await Socket.connect(host, port, timeout: const Duration(seconds: 2));
        await socket.close();
        open.add(port);
        setState(() {
          _result += "\n✅ Port $port terbuka";
        });
      } catch (_) {
        setState(() {
          _result += "\n❌ Port $port tertutup";
        });
      }
    }

    setState(() {
      _isScanning = false;
      _openPorts = open;
      _result += "\n\nSelesai. Port terbuka: ${open.join(', ')}";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      appBar: AppBar(
        title: const Text("Port Scanner", style: TextStyle(color: Colors.white, fontFamily: 'Orbitron')),
        backgroundColor: bgBlack,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: greyLight),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: _hostController,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: "Host / IP",
                hintText: "contoh: google.com atau 8.8.8.8",
                labelStyle: TextStyle(color: greyLight),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: greyLight.withOpacity(0.5)),
                  borderRadius: BorderRadius.circular(12),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: greyLight),
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: greyDark,
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _portController,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: "Port (pisahkan dengan koma)",
                hintText: "contoh: 80,443,8080",
                labelStyle: TextStyle(color: greyLight),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: greyLight.withOpacity(0.5)),
                  borderRadius: BorderRadius.circular(12),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: greyLight),
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: greyDark,
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _isScanning ? null : _scanPorts,
              style: ElevatedButton.styleFrom(
                backgroundColor: redDark,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: _isScanning
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text("SCAN PORTS", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: SingleChildScrollView(
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: greyDark,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: greyLight.withOpacity(0.3)),
                  ),
                  child: SelectableText(
                    _result.isEmpty ? "Masukkan host dan port, lalu klik scan" : _result,
                    style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono'),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}