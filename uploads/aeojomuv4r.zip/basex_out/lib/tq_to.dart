import 'package:flutter/material.dart';
import '../services/api_config_service.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:math' as math;
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class TqPage extends StatefulWidget {
  const TqPage({super.key});

  @override
  State<TqPage> createState() => TqPageState();
}

class TqPageState extends State<TqPage> with TickerProviderStateMixin {
  // ── Palette ──────────────────────────────────────────────────────────────
  static const Color bgBlack    = Color(0xFF0A0A0C);
  static const Color surface    = Color(0xFF111114);
  static const Color cardColor  = Color(0xFF16161A);
  static const Color redCore    = Color(0xFFE53935);
  static const Color redGlow    = Color(0xFFFF6B6B);
  static const Color redDark    = Color(0xFF8B0000);
  static const Color borderDim  = Color(0xFF2A2A2E);
  static const Color textPrimary   = Color(0xFFF0F0F0);
  static const Color textSecondary = Color(0xFF888890);
  static const Color textMuted     = Color(0xFF44444C);

  List<dynamic> _tqList = [];
  bool _isLoading = true;
  String? _errorMessage;

  late AnimationController _bgController;
  late AnimationController _headerController;
  late Animation<double> _headerFade;
  late Animation<Offset> _headerSlide;

  @override
  void initState() {
    super.initState();

    _bgController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();

    _headerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    _headerFade = CurvedAnimation(
      parent: _headerController,
      curve: Curves.easeOut,
    );
    _headerSlide = Tween<Offset>(
      begin: const Offset(0, -0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _headerController,
      curve: Curves.easeOutCubic,
    ));

    _headerController.forward();
    _fetchTqData();
  }

  @override
  void dispose() {
    _bgController.dispose();
    _headerController.dispose();
    super.dispose();
  }

  Future<void> _fetchTqData() async {
    setState(() { _isLoading = true; _errorMessage = null; });
    try {
      final response = await http.get(
        Uri.parse('${await ApiConfig.baseUrl}/tq'),
        headers: {'Content-Type': 'application/json'},
      );
      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        if (data['status'] == true && data['result'] != null) {
          setState(() { _tqList = data['result']; _isLoading = false; });
        } else {
          setState(() { _errorMessage = 'Failed to load data'; _isLoading = false; });
        }
      } else {
        setState(() { _errorMessage = 'Error: ${response.statusCode}'; _isLoading = false; });
      }
    } catch (e) {
      setState(() { _errorMessage = 'Connection error'; _isLoading = false; });
    }
  }

  Future<void> _launchTelegram(String contact) async {
    String telegramUrl = contact.startsWith('http') ? contact : 'https://$contact';
    final Uri url = Uri.parse(telegramUrl);
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    } else {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Could not launch $contact'),
          backgroundColor: cardColor,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    }
  }

  // ── Background deco dots ─────────────────────────────────────────────────
  Widget _buildAnimatedBackground() {
    return AnimatedBuilder(
      animation: _bgController,
      builder: (context, _) {
        return CustomPaint(
          painter: _BgDotsPainter(_bgController.value),
          child: const SizedBox.expand(),
        );
      },
    );
  }

  // ── Header ───────────────────────────────────────────────────────────────
  Widget _buildHeader() {
    return FadeTransition(
      opacity: _headerFade,
      child: SlideTransition(
        position: _headerSlide,
        child: Container(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
          decoration: const BoxDecoration(
            border: Border(
              bottom: BorderSide(color: borderDim, width: 1),
            ),
          ),
          child: Row(
            children: [
              // back button
              _CircleButton(
                onTap: () => Navigator.pop(context),
                child: const Icon(Icons.arrow_back_ios_new_rounded,
                    color: textSecondary, size: 18),
              ),
              const SizedBox(width: 14),
              // title block
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ShaderMask(
                      shaderCallback: (bounds) => const LinearGradient(
                        colors: [textPrimary, redGlow],
                        stops: [0.55, 1.0],
                      ).createShader(bounds),
                      child: const Text(
                        'SPECIAL THANKS TO',
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                          letterSpacing: 1.8,
                        ),
                      ),
                    ),
                    const SizedBox(height: 3),
                    _isLoading
                        ? const SizedBox.shrink()
                        : Text(
                            '${_tqList.length} contributors',
                            style: const TextStyle(
                              color: textSecondary,
                              fontSize: 12,
                              letterSpacing: 0.4,
                            ),
                          ),
                  ],
                ),
              ),
              // refresh button
              _CircleButton(
                onTap: _fetchTqData,
                child: const Icon(Icons.refresh_rounded,
                    color: textSecondary, size: 20),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Card ─────────────────────────────────────────────────────────────────
  Widget _buildTqCard(Map<String, dynamic> item, int index) {
    return _AnimatedListItem(
      index: index,
      child: Container(
        margin: EdgeInsets.only(
          left: 16, right: 16,
          bottom: index == _tqList.length - 1 ? 20 : 10,
        ),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: borderDim, width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.5),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Stack(
            children: [
              // subtle red accent bar on left
              Positioned(
                left: 0, top: 0, bottom: 0,
                child: Container(
                  width: 3,
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [redCore, Colors.transparent],
                    ),
                  ),
                ),
              ),
              // card content
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 14, 14, 14),
                child: Row(
                  children: [
                    // avatar
                    _GradientAvatar(
                      imageUrl: item['ppUrl'] ?? '',
                      size: 64,
                    ),
                    const SizedBox(width: 14),
                    // name + status
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            item['name']?.toString().replaceAll(RegExp(r'<[^>]*>'), '') ?? 'Unknown',
                            style: const TextStyle(
                              color: textPrimary,
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.2,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 6),
                          _StatusBadge(label: item['status'] ?? 'Member'),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    // telegram button
                    _TelegramButton(
                      onTap: () => _launchTelegram(item['contac'] ?? ''),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── States ───────────────────────────────────────────────────────────────
  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 52, height: 52,
            child: CircularProgressIndicator(
              strokeWidth: 2.5,
              valueColor: const AlwaysStoppedAnimation<Color>(redCore),
              backgroundColor: borderDim,
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            'Loading contributors...',
            style: TextStyle(color: textSecondary, fontSize: 13, letterSpacing: 0.5),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72, height: 72,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: redCore.withOpacity(0.1),
                border: Border.all(color: redCore.withOpacity(0.3), width: 1.5),
              ),
              child: const Icon(Icons.wifi_off_rounded, color: redCore, size: 32),
            ),
            const SizedBox(height: 20),
            const Text('Connection Failed',
                style: TextStyle(color: textPrimary, fontSize: 17, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(
              _errorMessage ?? 'Something went wrong',
              style: const TextStyle(color: textSecondary, fontSize: 13),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 28),
            GestureDetector(
              onTap: _fetchTqData,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 13),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [redDark, redCore]),
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [
                    BoxShadow(
                      color: redCore.withOpacity(0.35),
                      blurRadius: 14, spreadRadius: 0, offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.refresh_rounded, color: Colors.white, size: 17),
                    SizedBox(width: 8),
                    Text('Try Again',
                        style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 72, height: 72,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: borderDim,
              border: Border.all(color: textMuted, width: 1),
            ),
            child: const Icon(Icons.people_outline_rounded, color: textSecondary, size: 32),
          ),
          const SizedBox(height: 16),
          const Text('No Contributors Found',
              style: TextStyle(color: textPrimary, fontSize: 16, fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          const Text('The list is empty',
              style: TextStyle(color: textSecondary, fontSize: 13)),
        ],
      ),
    );
  }

  // ── Build ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          _buildAnimatedBackground(),
          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                Expanded(
                  child: _isLoading
                      ? _buildLoadingState()
                      : _errorMessage != null
                          ? _buildErrorState()
                          : _tqList.isEmpty
                              ? _buildEmptyState()
                              : ListView.builder(
                                  padding: const EdgeInsets.only(top: 14),
                                  itemCount: _tqList.length,
                                  itemBuilder: (context, index) =>
                                      _buildTqCard(_tqList[index], index),
                                ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// Helper Widgets
// ════════════════════════════════════════════════════════════════════════════

/// Circle icon button
class _CircleButton extends StatelessWidget {
  final VoidCallback onTap;
  final Widget child;
  const _CircleButton({required this.onTap, required this.child});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 40, height: 40,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: TqPageState.cardColor,
          border: Border.all(color: TqPageState.borderDim, width: 1),
        ),
        child: Center(child: child),
      ),
    );
  }
}

/// Avatar with gradient ring
class _GradientAvatar extends StatelessWidget {
  final String imageUrl;
  final double size;
  const _GradientAvatar({required this.imageUrl, required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size + 4,
      height: size + 4,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [TqPageState.redGlow, TqPageState.redDark, TqPageState.borderDim],
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(2),
        child: ClipOval(
          child: Image.network(
            imageUrl,
            width: size, height: size,
            fit: BoxFit.cover,
            loadingBuilder: (_, child, progress) {
              if (progress == null) return child;
              return Container(
                color: TqPageState.surface,
                child: const Center(
                  child: SizedBox(
                    width: 20, height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: TqPageState.redCore,
                    ),
                  ),
                ),
              );
            },
            errorBuilder: (_, __, ___) => Container(
              color: TqPageState.surface,
              child: const Icon(Icons.person_rounded, color: TqPageState.textSecondary, size: 28),
            ),
          ),
        ),
      ),
    );
  }
}

/// Status badge
class _StatusBadge extends StatelessWidget {
  final String label;
  const _StatusBadge({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            TqPageState.redCore.withOpacity(0.18),
            TqPageState.redDark.withOpacity(0.08),
          ],
        ),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: TqPageState.redCore.withOpacity(0.35),
          width: 1,
        ),
      ),
      child: Text(
        label,
        style: const TextStyle(
          color: TqPageState.redGlow,
          fontSize: 11,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.6,
        ),
      ),
    );
  }
}

/// Telegram launch button with gradient + glow
class _TelegramButton extends StatefulWidget {
  final VoidCallback onTap;
  const _TelegramButton({required this.onTap});

  @override
  State<_TelegramButton> createState() => _TelegramButtonState();
}

class _TelegramButtonState extends State<_TelegramButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 120));
    _scale = Tween<double>(begin: 1.0, end: 0.88).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) { _ctrl.reverse(); widget.onTap(); },
      onTapCancel: () => _ctrl.reverse(),
      child: ScaleTransition(
        scale: _scale,
        child: Container(
          width: 46, height: 46,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [TqPageState.redCore, TqPageState.redDark],
            ),
            boxShadow: [
              BoxShadow(
                color: TqPageState.redCore.withOpacity(0.45),
                blurRadius: 14,
                spreadRadius: 0,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: const Center(
            child: FaIcon(FontAwesomeIcons.telegram, color: Colors.white, size: 20),
          ),
        ),
      ),
    );
  }
}

/// Staggered fade+slide animation for list items
class _AnimatedListItem extends StatefulWidget {
  final int index;
  final Widget child;
  const _AnimatedListItem({required this.index, required this.child});

  @override
  State<_AnimatedListItem> createState() => _AnimatedListItemState();
}

class _AnimatedListItemState extends State<_AnimatedListItem>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 450),
    );
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(
      begin: const Offset(0, 0.12),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));

    // stagger based on index, capped so it doesn't feel slow
    final delay = (widget.index * 60).clamp(0, 400);
    Future.delayed(Duration(milliseconds: delay), () {
      if (mounted) _ctrl.forward();
    });
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(position: _slide, child: widget.child),
    );
  }
}

/// Custom painter for subtle animated dot pattern background
class _BgDotsPainter extends CustomPainter {
  final double t;
  _BgDotsPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xFF2A2A2E).withOpacity(0.45);
    const spacing = 28.0;
    final offsetY = (t * spacing) % spacing;

    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = -spacing + offsetY; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 1.2, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_BgDotsPainter old) => old.t != t;
}
