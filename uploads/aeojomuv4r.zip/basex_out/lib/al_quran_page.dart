import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Ayat {
  final int nomor;
  final String arab;
  final String arti;

  Ayat({
    required this.nomor,
    required this.arab,
    required this.arti,
  });
}

class Surat {
  final int nomor;
  final String nama;
  final String latin;
  final List<Ayat> ayat;

  Surat({
    required this.nomor,
    required this.nama,
    required this.latin,
    required this.ayat,
  });
}

class AlQuranPage extends StatefulWidget {
  const AlQuranPage({super.key});

  @override
  State<AlQuranPage> createState() => _AlQuranPageState();
}

class _AlQuranPageState extends State<AlQuranPage> {
  bool loading = true;
  List<Surat> suratList = [];

  // ========== WARNA CYBER DARK NAVY (SAMA SEPERTI HOMEPAGE) ==========
  final Color primaryBg = const Color(0xFF080C12);
  final Color cardBg = const Color(0xFF0D1520);
  final Color panelBg = const Color(0xFF0A1018);
  final Color cyanAccent = const Color(0xFF00E5FF);
  final Color cyanDim = const Color(0xFF0097A7);
  final Color redAccent = const Color(0xFFE53935);
  final Color textWhite = const Color(0xFFFFFFFF);
  final Color textGrey = const Color(0xFF607D8B);
  final Color borderGlass = const Color(0xFF1A3A4A);
  final Color green = const Color(0xFF4CAF50);

  @override
  void initState() {
    super.initState();
    _loadQuran();
  }

  Future<void> _loadQuran() async {
    try {
      final arabRes = await http.get(
        Uri.parse('https://api.alquran.cloud/v1/quran/quran-uthmani'),
      );
      final indoRes = await http.get(
        Uri.parse('https://api.alquran.cloud/v1/quran/id.indonesian'),
      );

      final arabData = jsonDecode(arabRes.body);
      final indoData = jsonDecode(indoRes.body);

      final List arabSurah = arabData['data']['surahs'];
      final List indoSurah = indoData['data']['surahs'];

      List<Surat> result = [];

      for (int i = 0; i < arabSurah.length; i++) {
        final List arabAyat = arabSurah[i]['ayahs'];
        final List indoAyat = indoSurah[i]['ayahs'];

        List<Ayat> ayatList = [];

        for (int j = 0; j < arabAyat.length; j++) {
          ayatList.add(
            Ayat(
              nomor: arabAyat[j]['numberInSurah'],
              arab: arabAyat[j]['text'],
              arti: indoAyat[j]['text'],
            ),
          );
        }

        result.add(
          Surat(
            nomor: arabSurah[i]['number'],
            nama: arabSurah[i]['name'],
            latin: arabSurah[i]['englishName'],
            ayat: ayatList,
          ),
        );
      }

      setState(() {
        suratList = result;
        loading = false;
      });
    } catch (e) {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryBg,
      appBar: AppBar(
        backgroundColor: cardBg,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: cyanAccent, size: 22),
          onPressed: () => Navigator.pop(context),
        ),
        title: ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [Color(0xFF00E5FF), Color(0xFF00BCD4)],
          ).createShader(bounds),
          child: Text(
            'AL-QUR\'AN',
            style: TextStyle(
              color: textWhite,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
              letterSpacing: 2,
            ),
          ),
        ),
      ),
      body: loading
          ? Center(
              child: CircularProgressIndicator(
                color: cyanAccent,
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: suratList.length,
              itemBuilder: (context, index) {
                return _suratCard(suratList[index]);
              },
            ),
    );
  }

  Widget _suratCard(Surat surat) {
    return Container(
      margin: const EdgeInsets.only(bottom: 18),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: borderGlass, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: cyanAccent.withOpacity(0.1),
            blurRadius: 16,
            spreadRadius: 2,
          ),
        ],
      ),
      child: ExpansionTile(
        iconColor: cyanAccent,
        collapsedIconColor: cyanDim,
        collapsedTextColor: textGrey,
        textColor: cyanAccent,
        backgroundColor: cardBg,
        collapsedBackgroundColor: cardBg,
        title: Text(
          '${surat.nomor}. ${surat.latin}',
          style: TextStyle(
            fontFamily: 'Orbitron',
            color: cyanAccent,
            letterSpacing: 1.5,
            fontWeight: FontWeight.w500,
            fontSize: 14,
          ),
        ),
        subtitle: Text(
          surat.nama,
          textAlign: TextAlign.right,
          style: TextStyle(
            fontSize: 18,
            color: textWhite.withOpacity(0.8),
            fontFamily: 'ShareTechMono',
          ),
        ),
        children: surat.ayat.map(_ayatTile).toList(),
      ),
    );
  }

  Widget _ayatTile(Ayat ayat) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: cyanAccent.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: cyanAccent.withOpacity(0.3)),
            ),
            child: Text(
              'Ayat ${ayat.nomor}',
              style: TextStyle(
                fontFamily: 'Orbitron',
                color: cyanAccent,
                fontSize: 11,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            ayat.arab,
            textAlign: TextAlign.right,
            style: TextStyle(
              fontSize: 24,
              height: 1.9,
              color: textWhite,
              fontFamily: 'ShareTechMono',
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: panelBg,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: borderGlass,
                width: 1,
              ),
            ),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                ayat.arti,
                style: TextStyle(
                  fontSize: 13,
                  color: textGrey,
                  height: 1.5,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Divider(
            color: borderGlass,
            thickness: 1,
          ),
        ],
      ),
    );
  }
}