import 'dart:async';
import '../services/api_config_service.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

// ══════════════════════════════════════════════════════════════════
//  OVALIUM GHOST — PRIVATE SENDER MANAGER  (Red × Black Edition)
// ══════════════════════════════════════════════════════════════════

class _C {
  static const bg      = Color(0xFF0A0A0A);
  static const card    = Color(0xFF141414);
  static const card2   = Color(0xFF1C1C1C);
  static const border  = Color(0xFF2A2A2A);
  static const red     = Color(0xFFE53935);
  static const redDark = Color(0xFFB71C1C);
  static const redGlow = Color(0x33E53935);
  static const white   = Colors.white;
  static const grey    = Color(0xFF9E9E9E);
  static const greyDim = Color(0xFF424242);
  static const green   = Color(0xFF00E676);
}

class BugSenderPage extends StatefulWidget {
  final String sessionKey, username, role;
  const BugSenderPage({super.key, required this.sessionKey, required this.username, required this.role});
  @override State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage> with TickerProviderStateMixin {
  List<dynamic> _private = [];
  bool _loading = true;
  String? _error;

  // State untuk add sender
  final _phoneCtrl = TextEditingController();
  final _nameCtrl = TextEditingController();
  bool _isAdding = false;
  String? _pairingCode;
  String? _lastAddedPhone;

  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    _fetchPrivate();
    _refreshTimer = Timer.periodic(const Duration(seconds: 15), (_) => _fetchPrivate());
  }

  @override
  void dispose() {
    _phoneCtrl.dispose();
    _nameCtrl.dispose();
    _refreshTimer?.cancel();
    super.dispose();
  }

  Future<void> _fetchPrivate() async {
    setState(() { _loading = true; _error = null; });
    try {
      final res = await http.get(Uri.parse('${await ApiConfig.baseUrl}/mySender?key=${widget.sessionKey}')).timeout(const Duration(seconds: 10));
      final d = jsonDecode(res.body);
      if (d['valid'] == true) {
        final conn = d['connections'];
        setState(() {
          if (conn is Map)        _private = List.from(conn['private'] ?? []);
          else if (conn is List)  _private = List.from(conn);
          else                    _private = [];
          _loading = false;
        });
      } else {
        setState(() { _error = d['error'] ?? 'Gagal mengambil data'; _loading = false; });
      }
    } catch (e) {
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  Future<void> _addPrivateSender() async {
    final phone = _phoneCtrl.text.trim().replaceAll(RegExp(r'\D'), '');
    final customName = _nameCtrl.text.trim();

    if (phone.isEmpty) {
      _showToast('Masukkan nomor WhatsApp!', true);
      return;
    }

    setState(() { _isAdding = true; _pairingCode = null; });

    try {
      final res = await http.get(
        Uri.parse('${await ApiConfig.baseUrl}/getPairing?key=${widget.sessionKey}&number=$phone')
      ).timeout(const Duration(seconds: 20));

      final d = jsonDecode(res.body);

      if (d['valid'] == true) {
        _pairingCode = d['pairingCode']?.toString() ?? '-';
        _lastAddedPhone = phone;
        
        Navigator.pop(context);
        
        if (mounted) {
          _showPairingDialog();
        }
        
        await Future.delayed(const Duration(seconds: 30));
        _fetchPrivate();
        
        _phoneCtrl.clear();
        _nameCtrl.clear();
      } else {
        _showToast(d['message'] ?? 'Gagal generate pairing code', true);
        Navigator.pop(context);
      }
    } catch (e) {
      _showToast('Error: $e', true);
      if (mounted) Navigator.pop(context);
    }

    if (mounted) setState(() { _isAdding = false; });
  }

  Future<void> _deleteSender(String sessionName) async {
    setState(() {});
    try {
      final res = await http.get(
        Uri.parse('${await ApiConfig.baseUrl}/deleteSender?key=${widget.sessionKey}&session=$sessionName')
      ).timeout(const Duration(seconds: 10));
      final d = jsonDecode(res.body);
      _showToast(d['valid'] == true ? 'Sender dihapus' : (d['message'] ?? 'Gagal hapus'), d['valid'] != true);
      if (d['valid'] == true) _fetchPrivate();
    } catch (e) {
      _showToast('Error: $e', true);
    }
  }

  void _showToast(String msg, bool isError) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(
        children: [
          Icon(isError ? Icons.error_outline : Icons.check_circle, color: _C.white, size: 18),
          const SizedBox(width: 12),
          Expanded(child: Text(msg, style: const TextStyle(color: _C.white))),
        ],
      ),
      backgroundColor: isError ? _C.red : _C.green,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      duration: const Duration(seconds: 3),
    ));
  }

  void _copyToClipboard(String text, String message) {
    Clipboard.setData(ClipboardData(text: text));
    _showToast(message, false);
  }

  void _showAddDialog() {
    _phoneCtrl.clear();
    _nameCtrl.clear();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _AnimatedDialog(
        title: 'TAMBAH SENDER',
        subtitle: 'Masukkan nomor WhatsApp & nama custom',
        icon: Icons.add_rounded,
        color: _C.red,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            decoration: BoxDecoration(
              color: _C.card2,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _C.border),
            ),
            child: TextField(
              controller: _phoneCtrl,
              keyboardType: TextInputType.phone,
              style: const TextStyle(color: _C.white, fontSize: 14),
              decoration: InputDecoration(
                hintText: '628123456789',
                hintStyle: TextStyle(color: _C.grey.withOpacity(0.5), fontSize: 12),
                prefixIcon: Icon(Icons.phone_android_rounded, color: _C.red, size: 20),
                filled: true,
                fillColor: Colors.transparent,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Container(
            decoration: BoxDecoration(
              color: _C.card2,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _C.border),
            ),
            child: TextField(
              controller: _nameCtrl,
              style: const TextStyle(color: _C.white, fontSize: 14),
              decoration: InputDecoration(
                hintText: 'Nama Sender (opsional)',
                hintStyle: TextStyle(color: _C.grey.withOpacity(0.5), fontSize: 12),
                prefixIcon: Icon(Icons.edit_note_rounded, color: _C.red, size: 20),
                filled: true,
                fillColor: Colors.transparent,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _C.red.withOpacity(0.08),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _C.red.withOpacity(0.2)),
            ),
            child: Row(
              children: [
                Icon(Icons.info_outline_rounded, color: _C.red, size: 16),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Kode pairing akan muncul setelah generate. Kamu punya waktu 30 detik untuk memasangnya di WhatsApp.',
                    style: TextStyle(color: _C.grey, fontSize: 11, height: 1.4),
                  ),
                ),
              ],
            ),
          ),
        ]),
        onConfirm: () async {
          Navigator.pop(context);
          showDialog(
            context: context,
            barrierDismissible: false,
            builder: (_) => _LoadingDialog(),
          );
          await _addPrivateSender();
        },
        confirmLabel: 'GENERATE PAIRING',
      ),
    );
  }

  void _showPairingDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _PairingDialog(
        pairingCode: _pairingCode!,
        phoneNumber: _lastAddedPhone ?? '',
        onDismiss: () {
          Navigator.pop(context);
          _fetchPrivate();
        },
      ),
    );
  }

  void _confirmDelete(String name) {
    showDialog(
      context: context,
      builder: (_) => _AnimatedDialog(
        title: 'HAPUS SENDER',
        subtitle: 'Tindakan ini tidak dapat dibatalkan',
        icon: Icons.delete_outline_rounded,
        color: _C.red,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _C.card2,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _C.red.withOpacity(0.2)),
            ),
            child: Row(
              children: [
                Icon(Icons.warning_rounded, color: _C.red, size: 22),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Hapus sender "$name"?',
                    style: const TextStyle(color: _C.white, fontWeight: FontWeight.w500),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'Sender akan dihapus secara permanen dari akun Anda.',
            style: TextStyle(color: _C.grey, fontSize: 12),
            textAlign: TextAlign.center,
          ),
        ]),
        onConfirm: () {
          Navigator.pop(context);
          _deleteSender(name);
        },
        confirmLabel: 'HAPUS',
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: Container(
          margin: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(12),
          ),
          child: IconButton(
            icon: const Icon(Icons.arrow_back_rounded, color: _C.red),
            onPressed: () => Navigator.pop(context),
          ),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: _C.red.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.router_rounded, color: _C.red, size: 14),
                ),
                const SizedBox(width: 10),
                const Text(
                  'PRIVATE SENDER',
                  style: TextStyle(
                    color: _C.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 2),
            Text(
              '${_private.length} sender terhubung',
              style: TextStyle(color: _C.grey, fontSize: 11),
            ),
          ],
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16),
            child: GestureDetector(
              onTap: _fetchPrivate,
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _C.card,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.refresh_rounded, color: _C.red, size: 18),
              ),
            ),
          ),
        ],
      ),
      body: _loading
          ? _buildShimmerLoading()
          : _error != null
              ? _buildErrorWidget()
              : _private.isEmpty
                  ? _buildEmptyState()
                  : _buildSenderList(),
      floatingActionButton: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_C.red, _C.redDark],
          ),
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: _C.red.withOpacity(0.4),
              blurRadius: 20,
              spreadRadius: 2,
            ),
          ],
        ),
        child: FloatingActionButton(
          onPressed: _isAdding ? null : _showAddDialog,
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: _isAdding
              ? const SizedBox(
                  width: 24,
                  height: 24,
                  child: CircularProgressIndicator(color: _C.white, strokeWidth: 2),
                )
              : const Icon(Icons.add_rounded, color: _C.white, size: 28),
        ),
      ),
    );
  }

  Widget _buildSenderList() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
      children: [
        // ── USER INFO BANNER ──────────────────────────────────────
        Container(
          margin: const EdgeInsets.only(bottom: 16),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.red.withOpacity(0.25)),
            gradient: LinearGradient(
              colors: [_C.red.withOpacity(0.08), _C.card],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_C.red, _C.redDark],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Center(
                  child: Text(
                    widget.username.isNotEmpty
                        ? widget.username[0].toUpperCase()
                        : '?',
                    style: const TextStyle(
                      color: _C.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.username,
                      style: const TextStyle(
                        color: _C.white,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: _C.red.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: _C.red.withOpacity(0.3)),
                          ),
                          child: Text(
                            widget.role.toUpperCase(),
                            style: const TextStyle(
                              color: _C.red,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          '${_private.length} sender aktif',
                          style: TextStyle(color: _C.grey, fontSize: 11),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: _C.green.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _C.green.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: _C.green,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    const Text(
                      'ONLINE',
                      style: TextStyle(
                        color: _C.green,
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        // ── SENDER LIST ──────────────────────────────────────────
        ...List.generate(_private.length, (i) => Padding(
          padding: EdgeInsets.only(bottom: i < _private.length - 1 ? 10 : 0),
          child: _SenderCard(
            data: _private[i],
            onDelete: () => _confirmDelete(_private[i]['sessionName'] ?? _private[i]['number'] ?? 'Unknown'),
          ),
        )),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: _C.card,
              shape: BoxShape.circle,
              border: Border.all(color: _C.border),
            ),
            child: Icon(Icons.router_rounded, color: _C.greyDim, size: 48),
          ),
          const SizedBox(height: 24),
          Text(
            'BELUM ADA SENDER',
            style: TextStyle(
              color: _C.grey.withOpacity(0.6),
              fontSize: 12,
              letterSpacing: 2,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Tambahkan sender WhatsApp untuk mulai mengirim pesan',
            style: TextStyle(color: _C.grey, fontSize: 13),
          ),
          const SizedBox(height: 32),
          GestureDetector(
            onTap: _showAddDialog,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [_C.red, _C.redDark]),
                borderRadius: BorderRadius.circular(30),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Icon(Icons.add_rounded, color: _C.white, size: 18),
                  SizedBox(width: 8),
                  Text('TAMBAH SENDER', style: TextStyle(color: _C.white, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorWidget() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: _C.red.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.error_outline_rounded, color: _C.red, size: 48),
          ),
          const SizedBox(height: 20),
          Text(
            'GAGAL MEMUAT DATA',
            style: TextStyle(color: _C.grey, fontSize: 12, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              _error!,
              style: TextStyle(color: _C.grey, fontSize: 12),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 24),
          GestureDetector(
            onTap: _fetchPrivate,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              decoration: BoxDecoration(
                color: _C.card,
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: _C.red.withOpacity(0.5)),
              ),
              child: const Text('COBA LAGI', style: TextStyle(color: _C.red, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildShimmerLoading() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: 5,
      itemBuilder: (_, __) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: _C.card2,
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: double.infinity,
                    height: 14,
                    decoration: BoxDecoration(
                      color: _C.card2,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    width: 100,
                    height: 10,
                    decoration: BoxDecoration(
                      color: _C.card2,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: _C.card2,
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════
//  COMPONENTS
// ══════════════════════════════════════════════════════════════════

class _SenderCard extends StatelessWidget {
  final Map<String, dynamic> data;
  final VoidCallback onDelete;

  const _SenderCard({required this.data, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    final name = data['sessionName'] ?? data['number'] ?? 'Unknown';
    final status = data['status'] ?? 'connected';
    final isConnected = status == 'connected';
    final number = data['number']?.toString() ?? '-';

    return Container(
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isConnected ? _C.green.withOpacity(0.25) : _C.border,
          width: 1,
        ),
        boxShadow: isConnected
            ? [BoxShadow(color: _C.green.withOpacity(0.05), blurRadius: 12, spreadRadius: 0)]
            : [],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onLongPress: onDelete,
          borderRadius: BorderRadius.circular(20),
          splashColor: _C.red.withOpacity(0.05),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            child: Row(
              children: [
                // Avatar icon with gradient border
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    gradient: isConnected
                        ? LinearGradient(
                            colors: [_C.green.withOpacity(0.2), _C.green.withOpacity(0.05)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          )
                        : LinearGradient(
                            colors: [_C.greyDim.withOpacity(0.15), _C.greyDim.withOpacity(0.05)],
                          ),
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(
                      color: isConnected ? _C.green.withOpacity(0.3) : _C.greyDim.withOpacity(0.2),
                    ),
                  ),
                  child: Center(
                    child: Icon(
                      Icons.phone_android_rounded,
                      color: isConnected ? _C.green : _C.greyDim,
                      size: 24,
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                // Info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: const TextStyle(
                          color: _C.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          letterSpacing: 0.3,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          // Status badge
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: isConnected
                                  ? _C.green.withOpacity(0.12)
                                  : _C.greyDim.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: isConnected
                                    ? _C.green.withOpacity(0.3)
                                    : _C.greyDim.withOpacity(0.2),
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  width: 5,
                                  height: 5,
                                  decoration: BoxDecoration(
                                    color: isConnected ? _C.green : _C.grey,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                                const SizedBox(width: 5),
                                Text(
                                  isConnected ? 'CONNECTED' : 'OFFLINE',
                                  style: TextStyle(
                                    color: isConnected ? _C.green : _C.grey,
                                    fontSize: 9,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 0.8,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          Icon(Icons.tag_rounded, color: _C.greyDim, size: 11),
                          const SizedBox(width: 2),
                          Flexible(
                            child: Text(
                              number,
                              style: TextStyle(color: _C.greyDim, fontSize: 10),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                // Delete button
                GestureDetector(
                  onTap: onDelete,
                  child: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: _C.red.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _C.red.withOpacity(0.2)),
                    ),
                    child: const Icon(Icons.delete_outline_rounded, color: _C.red, size: 18),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _AnimatedDialog extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final Widget child;
  final VoidCallback onConfirm;
  final String confirmLabel;

  const _AnimatedDialog({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.child,
    required this.onConfirm,
    required this.confirmLabel,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      child: TweenAnimationBuilder(
        duration: const Duration(milliseconds: 300),
        tween: Tween<double>(begin: 0.8, end: 1.0),
        curve: Curves.easeOutBack,
        builder: (context, double scale, child) {
          return Transform.scale(
            scale: scale,
            child: child,
          );
        },
        child: Container(
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: color.withOpacity(0.3)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.fromLTRB(24, 24, 24, 16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [color.withOpacity(0.15), Colors.transparent],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(28),
                    topRight: Radius.circular(28),
                  ),
                ),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: color.withOpacity(0.15),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(icon, color: color, size: 28),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      title,
                      style: TextStyle(
                        color: color,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: TextStyle(color: _C.grey, fontSize: 11),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: child,
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
                child: Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            color: _C.card2,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: _C.border),
                          ),
                          child: const Center(
                            child: Text('BATAL', style: TextStyle(color: _C.grey, fontWeight: FontWeight.bold)),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: GestureDetector(
                        onTap: onConfirm,
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [color, color.withOpacity(0.8)],
                            ),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Center(
                            child: Text(
                              confirmLabel,
                              style: const TextStyle(color: _C.white, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PairingDialog extends StatelessWidget {
  final String pairingCode;
  final String phoneNumber;
  final VoidCallback onDismiss;

  const _PairingDialog({
    required this.pairingCode,
    required this.phoneNumber,
    required this.onDismiss,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: TweenAnimationBuilder(
        duration: const Duration(milliseconds: 400),
        tween: Tween<double>(begin: 0.7, end: 1.0),
        curve: Curves.elasticOut,
        builder: (context, double scale, child) {
          return Transform.scale(scale: scale, child: child);
        },
        child: Container(
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(32),
            border: Border.all(color: _C.red.withOpacity(0.4)),
            boxShadow: [
              BoxShadow(
                color: _C.red.withOpacity(0.2),
                blurRadius: 30,
                spreadRadius: 5,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.fromLTRB(24, 30, 24, 20),
                child: Column(
                  children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 500),
                      curve: Curves.elasticOut,
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [_C.red, _C.redDark]),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.link_rounded, color: _C.white, size: 36),
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'PAIRING CODE GENERATED',
                      style: TextStyle(
                        color: _C.red,
                        fontSize: 12,
                        letterSpacing: 2,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Nomor: $phoneNumber',
                      style: TextStyle(color: _C.grey, fontSize: 12),
                    ),
                  ],
                ),
              ),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 24),
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: _C.card2,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _C.red.withOpacity(0.2)),
                ),
                child: Column(
                  children: [
                    const Text(
                      'KODE PAIRING',
                      style: TextStyle(color: _C.grey, fontSize: 10, letterSpacing: 2),
                    ),
                    const SizedBox(height: 10),
                    SelectableText(
                      pairingCode,
                      style: const TextStyle(
                        color: _C.red,
                        fontSize: 34,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 6,
                        fontFamily: 'monospace',
                      ),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: _C.red.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Row(
                        children: [
                          Icon(Icons.info_outline, color: _C.red, size: 14),
                          SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Buka WhatsApp → Perangkat Tertaut → Tautkan dengan nomor telepon',
                              style: TextStyle(color: _C.grey, fontSize: 11),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 0, 24, 30),
                child: Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          Clipboard.setData(ClipboardData(text: pairingCode));
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Kode pairing disalin!'),
                              backgroundColor: _C.green,
                              behavior: SnackBarBehavior.floating,
                              duration: Duration(seconds: 2),
                            ),
                          );
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          decoration: BoxDecoration(
                            color: _C.card2,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: _C.red.withOpacity(0.3)),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: const [
                              Icon(Icons.copy_rounded, color: _C.red, size: 18),
                              SizedBox(width: 8),
                              Text('SALIN', style: TextStyle(color: _C.red, fontWeight: FontWeight.bold)),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: GestureDetector(
                        onTap: onDismiss,
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(colors: [_C.red, _C.redDark]),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: const Center(
                            child: Text('SELESAI', style: TextStyle(color: _C.white, fontWeight: FontWeight.bold)),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LoadingDialog extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(32),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: _C.red.withOpacity(0.3)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: const [
            SizedBox(
              width: 48,
              height: 48,
              child: CircularProgressIndicator(color: _C.red, strokeWidth: 3),
            ),
            SizedBox(height: 20),
            Text(
              'MENGIRIM PERMINTAAN...',
              style: TextStyle(color: _C.grey, fontSize: 11, letterSpacing: 2),
            ),
          ],
        ),
      ),
    );
  }
}