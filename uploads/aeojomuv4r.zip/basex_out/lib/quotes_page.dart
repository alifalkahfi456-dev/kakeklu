import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class QuotesPage extends StatefulWidget {
  const QuotesPage({super.key});

  @override
  State<QuotesPage> createState() => _QuotesPageState();
}

class _QuotesPageState extends State<QuotesPage> {
  final TextEditingController _textController = TextEditingController();
  final TextEditingController _deleteController = TextEditingController();
  List<String> _quotes = [];

  final Color primaryBg = const Color(0xFF080C12);
  final Color cardBg = const Color(0xFF0D1520);
  final Color panelBg = const Color(0xFF0A1018);
  final Color cyanAccent = const Color(0xFF00E5FF);
  final Color textWhite = Colors.white;
  final Color textGrey = const Color(0xFF607D8B);
  final Color borderGlass = const Color(0xFF1A3A4A);
  final Color pinkAccent = const Color(0xFFFF6B9D);
  final Color redAccent = const Color(0xFFFF4444);
  final Color orangeAccent = const Color(0xFFFF9800);

  // ==================== 500 VARIASI FONT ====================
  List<String> _generateVariations(String input) {
    List<String> results = [];
    
    // 1-10: Basic cases
    results.add(input);
    results.add(input.toUpperCase());
    results.add(input.toLowerCase());
    results.add(input[0].toUpperCase() + input.substring(1).toLowerCase());
    results.add(input.split('').reversed.join());
    results.add(_toAlternatingCase(input));
    results.add(_toRandomCase(input));
    results.add(_toCamelCase(input));
    results.add(_toSnakeCase(input));
    results.add(_toKebabCase(input));
    
    // 11-40: Bold family (30 gaya)
    results.add(_toBold(input));
    results.add(_toBoldItalic(input));
    results.add(_toDoubleStruck(input));
    results.add(_toMonospace(input));
    results.add(_toSansSerif(input));
    for (int i = 0; i < 25; i++) {
      results.add(_toBoldVariant(input, i));
    }
    
    // 41-70: Italic/Script family (30 gaya)
    results.add(_toItalic(input));
    results.add(_toScript(input));
    results.add(_toCursive(input));
    results.add(_toSerif(input));
    for (int i = 0; i < 26; i++) {
      results.add(_toItalicVariant(input, i));
    }
    
    // 71-110: Fraktur/Blackletter (40 gaya)
    results.add(_toFraktur(input));
    for (int i = 0; i < 39; i++) {
      results.add(_toFrakturVariant(input, i));
    }
    
    // 111-150: Decorations (40 gaya)
    results.add(_toStrikethrough(input));
    results.add(_toUnderline(input));
    results.add(_toTildeStrike(input));
    results.add(_toSlashed(input));
    results.add(_toZalgo(input));
    results.add(_toGlitch(input));
    for (int i = 0; i < 34; i++) {
      results.add(_toDecorationVariant(input, i));
    }
    
    // 151-200: Brackets & Parenthesis (50 gaya)
    results.add(_toParenthesis(input));
    results.add(_toAngleBrackets(input));
    results.add(_toSquareBrackets(input));
    results.add(_toCurlyBrackets(input));
    results.add(_toDoubleBrackets(input));
    results.add(_toFloorCeiling(input));
    for (int i = 0; i < 44; i++) {
      results.add(_toBracketVariant(input, i));
    }
    
    // 201-250: Symbols & Emoji (50 gaya)
    results.add(_toStarred(input));
    results.add(_toDotted(input));
    results.add(_toHeart(input));
    results.add(_toWave(input));
    results.add(_toStars(input));
    results.add(_toEquals(input));
    results.add(_toBoxed(input));
    for (int i = 0; i < 43; i++) {
      results.add(_toSymbolVariant(input, i));
    }
    
    // 251-300: Spacing & Creative (50 gaya)
    results.add(_toWide(input));
    results.add(_toSpaced(input));
    results.add(_toDots(input));
    results.add(_toTiny(input));
    for (int i = 0; i < 46; i++) {
      results.add(_toCreativeVariant(input, i));
    }
    
    // 301-350: Case & Transform (50 gaya)
    results.add(_toTitleCase(input));
    results.add(_toUpsideDown(input));
    results.add(_toMirror(input));
    results.add(_toSmallCaps(input));
    for (int i = 0; i < 46; i++) {
      results.add(_toCaseVariant(input, i));
    }
    
    // 351-400: Circled & Squared (50 gaya)
    results.add(_toCircled(input));
    results.add(_toSquared(input));
    for (int i = 0; i < 48; i++) {
      results.add(_toCircledVariant(input, i));
    }
    
    // 401-450: Mixed styles (50 gaya)
    for (int i = 0; i < 50; i++) {
      results.add(_toMixedStyle(input, i));
    }
    
    // 451-500: Extra creative (50 gaya)
    for (int i = 0; i < 50; i++) {
      results.add(_toExtraStyle(input, i));
    }
    
    return results.take(500).toList();
  }

  // Core style functions
  String _toBold(String text) {
    const boldMap = {
      'a': '𝗮', 'b': '𝗯', 'c': '𝗰', 'd': '𝗱', 'e': '𝗲', 'f': '𝗳', 'g': '𝗴',
      'h': '𝗵', 'i': '𝗶', 'j': '𝗷', 'k': '𝗸', 'l': '𝗹', 'm': '𝗺', 'n': '𝗻',
      'o': '𝗼', 'p': '𝗽', 'q': '𝗾', 'r': '𝗿', 's': '𝘀', 't': '𝘁', 'u': '𝘂',
      'v': '𝘃', 'w': '𝘄', 'x': '𝘅', 'y': '𝘆', 'z': '𝘇',
      'A': '𝗔', 'B': '𝗕', 'C': '𝗖', 'D': '𝗗', 'E': '𝗘', 'F': '𝗙', 'G': '𝗚',
      'H': '𝗛', 'I': '𝗜', 'J': '𝗝', 'K': '𝗞', 'L': '𝗟', 'M': '𝗠', 'N': '𝗡',
      'O': '𝗢', 'P': '𝗣', 'Q': '𝗤', 'R': '𝗥', 'S': '𝗦', 'T': '𝗧', 'U': '𝗨',
      'V': '𝗩', 'W': '𝗪', 'X': '𝗫', 'Y': '𝗬', 'Z': '𝗭'
    };
    return text.split('').map((c) => boldMap[c] ?? c).join();
  }

  String _toItalic(String text) {
    const italicMap = {
      'a': '𝑎', 'b': '𝑏', 'c': '𝑐', 'd': '𝑑', 'e': '𝑒', 'f': '𝑓', 'g': '𝑔',
      'h': 'ℎ', 'i': '𝑖', 'j': '𝑗', 'k': '𝑘', 'l': '𝑙', 'm': '𝑚', 'n': '𝑛',
      'o': '𝑜', 'p': '𝑝', 'q': '𝑞', 'r': '𝑟', 's': '𝑠', 't': '𝑡', 'u': '𝑢',
      'v': '𝑣', 'w': '𝑤', 'x': '𝑥', 'y': '𝑦', 'z': '𝑧',
      'A': '𝐴', 'B': '𝐵', 'C': '𝐶', 'D': '𝐷', 'E': '𝐸', 'F': '𝐹', 'G': '𝐺',
      'H': '𝐻', 'I': '𝐼', 'J': '𝐽', 'K': '𝐾', 'L': '𝐿', 'M': '𝑀', 'N': '𝑁',
      'O': '𝑂', 'P': '𝑃', 'Q': '𝑄', 'R': '𝑅', 'S': '𝑆', 'T': '𝑇', 'U': '𝑈',
      'V': '𝑉', 'W': '𝑊', 'X': '𝑋', 'Y': '𝑌', 'Z': '𝑍'
    };
    return text.split('').map((c) => italicMap[c] ?? c).join();
  }

  String _toBoldItalic(String text) {
    const boldItalicMap = {
      'a': '𝒂', 'b': '𝒃', 'c': '𝒄', 'd': '𝒅', 'e': '𝒆', 'f': '𝒇', 'g': '𝒈',
      'h': '𝒉', 'i': '𝒊', 'j': '𝒋', 'k': '𝒌', 'l': '𝒍', 'm': '𝒎', 'n': '𝒏',
      'o': '𝒐', 'p': '𝒑', 'q': '𝒒', 'r': '𝒓', 's': '𝒔', 't': '𝒕', 'u': '𝒖',
      'v': '𝒗', 'w': '𝒘', 'x': '𝒙', 'y': '𝒚', 'z': '𝒛',
      'A': '𝑨', 'B': '𝑩', 'C': '𝑪', 'D': '𝑫', 'E': '𝑬', 'F': '𝑭', 'G': '𝑮',
      'H': '𝑯', 'I': '𝑰', 'J': '𝑱', 'K': '𝑲', 'L': '𝑳', 'M': '𝑴', 'N': '𝑵',
      'O': '𝑶', 'P': '𝑷', 'Q': '𝑸', 'R': '𝑹', 'S': '𝑺', 'T': '𝑻', 'U': '𝑼',
      'V': '𝑽', 'W': '𝑾', 'X': '𝑿', 'Y': '𝒀', 'Z': '𝒁'
    };
    return text.split('').map((c) => boldItalicMap[c] ?? c).join();
  }

  String _toScript(String text) {
    const scriptMap = {
      'a': '𝒶', 'b': '𝒷', 'c': '𝒸', 'd': '𝒹', 'e': '𝑒', 'f': '𝒻', 'g': '𝑔',
      'h': '𝒽', 'i': '𝒾', 'j': '𝒿', 'k': '𝓀', 'l': '𝓁', 'm': '𝓂', 'n': '𝓃',
      'o': '𝑜', 'p': '𝓅', 'q': '𝓆', 'r': '𝓇', 's': '𝓈', 't': '𝓉', 'u': '𝓊',
      'v': '𝓋', 'w': '𝓌', 'x': '𝓍', 'y': '𝓎', 'z': '𝓏',
      'A': '𝒜', 'B': '𝐵', 'C': '𝒞', 'D': '𝒟', 'E': '𝐸', 'F': '𝐹', 'G': '𝒢',
      'H': '𝐻', 'I': '𝐼', 'J': '𝒥', 'K': '𝒦', 'L': '𝐿', 'M': '𝑀', 'N': '𝒩',
      'O': '𝒪', 'P': '𝒫', 'Q': '𝒬', 'R': '𝑅', 'S': '𝒮', 'T': '𝒯', 'U': '𝒰',
      'V': '𝒱', 'W': '𝒲', 'X': '𝒳', 'Y': '𝒴', 'Z': '𝒵'
    };
    return text.split('').map((c) => scriptMap[c] ?? c).join();
  }

  String _toFraktur(String text) {
    const frakturMap = {
      'a': '𝔞', 'b': '𝔟', 'c': '𝔠', 'd': '𝔡', 'e': '𝔢', 'f': '𝔣', 'g': '𝔤',
      'h': '𝔥', 'i': '𝔦', 'j': '𝔧', 'k': '𝔨', 'l': '𝔩', 'm': '𝔪', 'n': '𝔫',
      'o': '𝔬', 'p': '𝔭', 'q': '𝔮', 'r': '𝔯', 's': '𝔰', 't': '𝔱', 'u': '𝔲',
      'v': '𝔳', 'w': '𝔴', 'x': '𝔵', 'y': '𝔶', 'z': '𝔷',
      'A': '𝔄', 'B': '𝔅', 'C': 'ℭ', 'D': '𝔇', 'E': '𝔈', 'F': '𝔉', 'G': '𝔊',
      'H': 'ℌ', 'I': 'ℑ', 'J': '𝔍', 'K': '𝔎', 'L': '𝔏', 'M': '𝔐', 'N': '𝔑',
      'O': '𝔒', 'P': '𝔓', 'Q': '𝔔', 'R': 'ℜ', 'S': '𝔖', 'T': '𝔗', 'U': '𝔘',
      'V': '𝔙', 'W': '𝔚', 'X': '𝔛', 'Y': '𝔜', 'Z': 'ℨ'
    };
    return text.split('').map((c) => frakturMap[c] ?? c).join();
  }

  String _toDoubleStruck(String text) {
    const doubleStruckMap = {
      'a': '𝕒', 'b': '𝕓', 'c': '𝕔', 'd': '𝕕', 'e': '𝕖', 'f': '𝕗', 'g': '𝕘',
      'h': '𝕙', 'i': '𝕚', 'j': '𝕛', 'k': '𝕜', 'l': '𝕝', 'm': '𝕞', 'n': '𝕟',
      'o': '𝕠', 'p': '𝕡', 'q': '𝕢', 'r': '𝕣', 's': '𝕤', 't': '𝕥', 'u': '𝕦',
      'v': '𝕧', 'w': '𝕨', 'x': '𝕩', 'y': '𝕪', 'z': '𝕫',
      'A': '𝔸', 'B': '𝔹', 'C': 'ℂ', 'D': '𝔻', 'E': '𝔼', 'F': '𝔽', 'G': '𝔾',
      'H': 'ℍ', 'I': '𝕀', 'J': '𝕁', 'K': '𝕂', 'L': '𝕃', 'M': '𝕄', 'N': 'ℕ',
      'O': '𝕆', 'P': 'ℙ', 'Q': 'ℚ', 'R': 'ℝ', 'S': '𝕊', 'T': '𝕋', 'U': '𝕌',
      'V': '𝕍', 'W': '𝕎', 'X': '𝕏', 'Y': '𝕐', 'Z': 'ℤ'
    };
    return text.split('').map((c) => doubleStruckMap[c] ?? c).join();
  }

  String _toMonospace(String text) {
    const monoMap = {
      'a': '𝚊', 'b': '𝚋', 'c': '𝚌', 'd': '𝚍', 'e': '𝚎', 'f': '𝚏', 'g': '𝚐',
      'h': '𝚑', 'i': '𝚒', 'j': '𝚓', 'k': '𝚔', 'l': '𝚕', 'm': '𝚖', 'n': '𝚗',
      'o': '𝚘', 'p': '𝚙', 'q': '𝚚', 'r': '𝚛', 's': '𝚜', 't': '𝚝', 'u': '𝚞',
      'v': '𝚟', 'w': '𝚠', 'x': '𝚡', 'y': '𝚢', 'z': '𝚣',
      'A': '𝙰', 'B': '𝙱', 'C': '𝙲', 'D': '𝙳', 'E': '𝙴', 'F': '𝙵', 'G': '𝙶',
      'H': '𝙷', 'I': '𝙸', 'J': '𝙹', 'K': '𝙺', 'L': '𝙻', 'M': '𝙼', 'N': '𝙽',
      'O': '𝙾', 'P': '𝙿', 'Q': '𝚀', 'R': '𝚁', 'S': '𝚂', 'T': '𝚃', 'U': '𝚄',
      'V': '𝚅', 'W': '𝚆', 'X': '𝚇', 'Y': '𝚈', 'Z': '𝚉'
    };
    return text.split('').map((c) => monoMap[c] ?? c).join();
  }

  String _toSansSerif(String text) {
    const sansMap = {
      'a': '𝖺', 'b': '𝖻', 'c': '𝖼', 'd': '𝖽', 'e': '𝖾', 'f': '𝖿', 'g': '𝗀',
      'h': '𝗁', 'i': '𝗂', 'j': '𝗃', 'k': '𝗄', 'l': '𝗅', 'm': '𝗆', 'n': '𝗇',
      'o': '𝗈', 'p': '𝗉', 'q': '𝗊', 'r': '𝗋', 's': '𝗌', 't': '𝗍', 'u': '𝗎',
      'v': '𝗏', 'w': '𝗐', 'x': '𝗑', 'y': '𝗒', 'z': '𝗓',
      'A': '𝖠', 'B': '𝖡', 'C': '𝖢', 'D': '𝖣', 'E': '𝖤', 'F': '𝖥', 'G': '𝖦',
      'H': '𝖧', 'I': '𝖨', 'J': '𝖩', 'K': '𝖪', 'L': '𝖫', 'M': '𝖬', 'N': '𝖭',
      'O': '𝖮', 'P': '𝖯', 'Q': '𝖰', 'R': '𝖱', 'S': '𝖲', 'T': '𝖳', 'U': '𝖴',
      'V': '𝖵', 'W': '𝖶', 'X': '𝖷', 'Y': '𝖸', 'Z': '𝖹'
    };
    return text.split('').map((c) => sansMap[c] ?? c).join();
  }

  String _toCursive(String text) {
    const cursiveMap = {
      'a': '𝒶', 'b': '𝒷', 'c': '𝒸', 'd': '𝒹', 'e': 'ℯ', 'f': '𝒻', 'g': 'ℊ',
      'h': '𝒽', 'i': '𝒾', 'j': '𝒿', 'k': '𝓀', 'l': '𝓁', 'm': '𝓂', 'n': '𝓃',
      'o': 'ℴ', 'p': '𝓅', 'q': '𝓆', 'r': '𝓇', 's': '𝓈', 't': '𝓉', 'u': '𝓊',
      'v': '𝓋', 'w': '𝓌', 'x': '𝓍', 'y': '𝓎', 'z': '𝓏',
      'A': '𝒜', 'B': 'ℬ', 'C': '𝒞', 'D': '𝒟', 'E': 'ℰ', 'F': 'ℱ', 'G': '𝒢',
      'H': 'ℋ', 'I': 'ℐ', 'J': '𝒥', 'K': '𝒦', 'L': 'ℒ', 'M': 'ℳ', 'N': '𝒩',
      'O': '𝒪', 'P': '𝒫', 'Q': '𝒬', 'R': 'ℛ', 'S': '𝒮', 'T': '𝒯', 'U': '𝒰',
      'V': '𝒱', 'W': '𝒲', 'X': '𝒳', 'Y': '𝒴', 'Z': '𝒵'
    };
    return text.split('').map((c) => cursiveMap[c] ?? c).join();
  }

  String _toSerif(String text) {
    const serifMap = {
      'a': '𝑎', 'b': '𝑏', 'c': '𝑐', 'd': '𝑑', 'e': '𝑒', 'f': '𝑓', 'g': '𝑔',
      'h': 'ℎ', 'i': '𝑖', 'j': '𝑗', 'k': '𝑘', 'l': '𝑙', 'm': '𝑚', 'n': '𝑛',
      'o': '𝑜', 'p': '𝑝', 'q': '𝑞', 'r': '𝑟', 's': '𝑠', 't': '𝑡', 'u': '𝑢',
      'v': '𝑣', 'w': '𝑤', 'x': '𝑥', 'y': '𝑦', 'z': '𝑧',
      'A': '𝐴', 'B': '𝐵', 'C': '𝐶', 'D': '𝐷', 'E': '𝐸', 'F': '𝐹', 'G': '𝐺',
      'H': '𝐻', 'I': '𝐼', 'J': '𝐽', 'K': '𝐾', 'L': '𝐿', 'M': '𝑀', 'N': '𝑁',
      'O': '𝑂', 'P': '𝑃', 'Q': '𝑄', 'R': '𝑅', 'S': '𝑆', 'T': '𝑇', 'U': '𝑈',
      'V': '𝑉', 'W': '𝑊', 'X': '𝑋', 'Y': '𝑌', 'Z': '𝑍'
    };
    return text.split('').map((c) => serifMap[c] ?? c).join();
  }

  String _toStrikethrough(String text) {
    return text.split('').map((c) => '$c\u{0336}').join();
  }

  String _toUnderline(String text) {
    return text.split('').map((c) => '$c\u{0332}').join();
  }

  String _toTildeStrike(String text) {
    return text.split('').map((c) => '$c\u{0333}').join();
  }

  String _toSlashed(String text) {
    return text.split('').map((c) => '$c\u{0337}').join();
  }

  String _toAlternatingCase(String text) {
    return text.split('').asMap().entries.map((entry) {
      return entry.key % 2 == 0 
          ? entry.value.toUpperCase() 
          : entry.value.toLowerCase();
    }).join();
  }

  String _toRandomCase(String text) {
    return text.split('').map((c) {
      return DateTime.now().millisecondsSinceEpoch % 2 == 0 
          ? c.toUpperCase() 
          : c.toLowerCase();
    }).join();
  }

  String _toWide(String text) {
    return text.split('').map((c) => '$c ').join();
  }

  String _toTiny(String text) {
    const tinyMap = {
      'a': 'ₐ', 'e': 'ₑ', 'h': 'ₕ', 'i': 'ᵢ', 'j': 'ⱼ', 'k': 'ₖ', 'l': 'ₗ',
      'm': 'ₘ', 'n': 'ₙ', 'o': 'ₒ', 'p': 'ₚ', 'r': 'ᵣ', 's': 'ₛ', 't': 'ₜ',
      'u': 'ᵤ', 'v': 'ᵥ', 'x': 'ₓ'
    };
    return text.split('').map((c) => tinyMap[c.toLowerCase()] ?? c).join();
  }

  String _toUpsideDown(String text) {
    const upsideMap = {
      'a': 'ɐ', 'b': 'q', 'c': 'ɔ', 'd': 'p', 'e': 'ǝ', 'f': 'ɟ', 'g': 'ƃ',
      'h': 'ɥ', 'i': 'ı', 'j': 'ɾ', 'k': 'ʞ', 'l': 'ʃ', 'm': 'ɯ', 'n': 'u',
      'o': 'o', 'p': 'd', 'q': 'b', 'r': 'ɹ', 's': 's', 't': 'ʇ', 'u': 'n',
      'v': 'ʌ', 'w': 'ʍ', 'x': 'x', 'y': 'ʎ', 'z': 'z',
      'A': '∀', 'B': 'q', 'C': 'Ɔ', 'D': 'p', 'E': 'Ǝ', 'F': 'Ⅎ', 'G': '⅁',
      'H': 'H', 'I': 'I', 'J': 'ſ', 'K': 'ʞ', 'L': '˥', 'M': 'W', 'N': 'N',
      'O': 'O', 'P': 'Ԁ', 'Q': 'Q', 'R': 'ᴚ', 'S': 'S', 'T': '⊥', 'U': '∩',
      'V': 'Λ', 'W': 'M', 'X': 'X', 'Y': '⅄', 'Z': 'Z'
    };
    return text.split('').map((c) => upsideMap[c] ?? c).join();
  }

  String _toMirror(String text) {
    return text.split('').reversed.join();
  }

  String _toZalgo(String text) {
    const zalgoChars = ['\u0300', '\u0301', '\u0302', '\u0303', '\u0304', '\u0305', '\u0306', '\u0307', '\u0308'];
    return text.split('').map((c) {
      if (c == ' ') return c;
      return c + zalgoChars[DateTime.now().millisecondsSinceEpoch % zalgoChars.length];
    }).join();
  }

  String _toSmallCaps(String text) {
    const smallCapsMap = {
      'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ',
      'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ',
      'o': 'ᴏ', 'p': 'ᴘ', 'q': 'ǫ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ',
      'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'
    };
    return text.split('').map((c) => smallCapsMap[c.toLowerCase()] ?? c).join();
  }

  String _toCircled(String text) {
    const circledMap = {
      'a': '🅐', 'b': '🅑', 'c': '🅒', 'd': '🅓', 'e': '🅔', 'f': '🅕', 'g': '🅖',
      'h': '🅗', 'i': '🅘', 'j': '🅙', 'k': '🅚', 'l': '🅛', 'm': '🅜', 'n': '🅝',
      'o': '🅞', 'p': '🅟', 'q': '🅠', 'r': '🅡', 's': '🅢', 't': '🅣', 'u': '🅤',
      'v': '🅥', 'w': '🅦', 'x': '🅧', 'y': '🅨', 'z': '🅩'
    };
    return text.split('').map((c) => circledMap[c.toLowerCase()] ?? c).join();
  }

  String _toSquared(String text) {
    const squaredMap = {
      'a': '🄰', 'b': '🄱', 'c': '🄲', 'd': '🄳', 'e': '🄴', 'f': '🄵', 'g': '🄶',
      'h': '🄷', 'i': '🄸', 'j': '🄹', 'k': '🄺', 'l': '🄻', 'm': '🄼', 'n': '🄽',
      'o': '🄾', 'p': '🄿', 'q': '🅀', 'r': '🅁', 's': '🅂', 't': '🅃', 'u': '🅄',
      'v': '🅅', 'w': '🅆', 'x': '🅇', 'y': '🅈', 'z': '🅉'
    };
    return text.split('').map((c) => squaredMap[c.toLowerCase()] ?? c).join();
  }

  String _toParenthesis(String text) {
    return '(' + text + ')';
  }

  String _toAngleBrackets(String text) {
    return '<' + text + '>';
  }

  String _toSquareBrackets(String text) {
    return '[' + text + ']';
  }

  String _toCurlyBrackets(String text) {
    return '{' + text + '}';
  }

  String _toDoubleBrackets(String text) {
    return '⟦' + text + '⟧';
  }

  String _toFloorCeiling(String text) {
    return '⌊' + text + '⌋';
  }

  String _toStarred(String text) {
    return '*' + text + '*';
  }

  String _toDotted(String text) {
    return '·' + text + '·';
  }

  String _toHeart(String text) {
    return '♥' + text + '♥';
  }

  String _toWave(String text) {
    return '~' + text + '~';
  }

  String _toStars(String text) {
    return '⭐' + text + '⭐';
  }

  String _toEquals(String text) {
    return '=' + text + '=';
  }

  String _toBoxed(String text) {
    return '📦' + text + '📦';
  }

  String _toSpaced(String text) {
    return text.split('').join('   ');
  }

  String _toDots(String text) {
    return text.split('').join('.');
  }

  String _toGlitch(String text) {
    return text.split('').map((c) => c + '̷').join();
  }

  String _toCamelCase(String text) {
    List<String> words = text.split(' ');
    if (words.isEmpty) return text;
    return words[0].toLowerCase() + words.skip(1).map((w) => 
      w.isNotEmpty ? w[0].toUpperCase() + w.substring(1).toLowerCase() : ''
    ).join();
  }

  String _toSnakeCase(String text) {
    return text.toLowerCase().replaceAll(' ', '_');
  }

  String _toKebabCase(String text) {
    return text.toLowerCase().replaceAll(' ', '-');
  }

  String _toTitleCase(String text) {
    return text.split(' ').map((word) => 
      word.isNotEmpty ? word[0].toUpperCase() + word.substring(1).toLowerCase() : ''
    ).join(' ');
  }

  // Variant generators untuk mencapai 500 gaya
  String _toBoldVariant(String text, int index) {
    const boldChars = ['𝗮','𝗯','𝗰','𝗱','𝗲','𝗳','𝗴','𝗵','𝗶','𝗷','𝗸','𝗹','𝗺','𝗻','𝗼','𝗽','𝗾','𝗿','𝘀','𝘁','𝘂','𝘃','𝘄','𝘅','𝘆','𝘇'];
    return text.split('').map((c) {
      int idx = c.toLowerCase().codeUnitAt(0) - 97;
      if (idx >= 0 && idx < 26) {
        return boldChars[(idx + index) % 26];
      }
      return c;
    }).join();
  }

  String _toItalicVariant(String text, int index) {
    const italicChars = ['𝑎','𝑏','𝑐','𝑑','𝑒','𝑓','𝑔','ℎ','𝑖','𝑗','𝑘','𝑙','𝑚','𝑛','𝑜','𝑝','𝑞','𝑟','𝑠','𝑡','𝑢','𝑣','𝑤','𝑥','𝑦','𝑧'];
    return text.split('').map((c) {
      int idx = c.toLowerCase().codeUnitAt(0) - 97;
      if (idx >= 0 && idx < 26) {
        return italicChars[(idx + index) % 26];
      }
      return c;
    }).join();
  }

  String _toFrakturVariant(String text, int index) {
    const frakturChars = ['𝔞','𝔟','𝔠','𝔡','𝔢','𝔣','𝔤','𝔥','𝔦','𝔧','𝔨','𝔩','𝔪','𝔫','𝔬','𝔭','𝔮','𝔯','𝔰','𝔱','𝔲','𝔳','𝔴','𝔵','𝔶','𝔷'];
    return text.split('').map((c) {
      int idx = c.toLowerCase().codeUnitAt(0) - 97;
      if (idx >= 0 && idx < 26) {
        return frakturChars[(idx + index) % 26];
      }
      return c;
    }).join();
  }

  String _toDecorationVariant(String text, int index) {
    List<String> decors = ['̶', '̷', '̸', '̲', '̳', '̴', '̵', '̢', '̣', '̥', '̦', '̧', '̨', '̩', '̪', '̫', '̬', '̭', '̮', '̯'];
    return text.split('').map((c) => c + decors[index % decors.length]).join();
  }

  String _toBracketVariant(String text, int index) {
    List<List<String>> brackets = [
      ['(', ')'], ['[', ']'], ['{', '}'], ['<', '>'], ['『', '』'], ['【', '】'], 
      ['《', '》'], ['〔', '〕'], ['⦅', '⦆'], ['〘', '〙'], ['﹤', '﹥'], ['‹', '›'],
      ['«', '»'], ['„', '“'], ['‚', '‘'], ['⸢', '⸣'], ['⸤', '⸥'], ['⟦', '⟧'],
      ['⟨', '⟩'], ['〈', '〉']
    ];
    var b = brackets[index % brackets.length];
    return b[0] + text + b[1];
  }

  String _toSymbolVariant(String text, int index) {
    List<String> symbols = ['⭐', '🌟', '💫', '✨', '⚡', '🔥', '💎', '👑', '💜', '💙', '💚', '💛', '❤️', '🖤', '🤍', '💯', '🔱', '♨️', '💢', '💠'];
    return symbols[index % symbols.length] + text + symbols[index % symbols.length];
  }

  String _toCreativeVariant(String text, int index) {
    List<String> separators = [' ', '.', '-', '_', '•', '○', '●', '◇', '◆', '□', '■', '△', '▲', '☆', '★', '♪', '♫', '♩', '🎵', '🎶'];
    return text.split('').join(separators[index % separators.length] + separators[index % separators.length]);
  }

  String _toCaseVariant(String text, int index) {
    if (index % 3 == 0) return text.toUpperCase();
    if (index % 3 == 1) return text.toLowerCase();
    // Alternating case - FIXED: menggunakan asMap
    return text.split('').asMap().entries.map((entry) {
      return entry.key % 2 == 0 
          ? entry.value.toUpperCase() 
          : entry.value.toLowerCase();
    }).join();
  }

  String _toCircledVariant(String text, int index) {
    List<String> styles = ['🅐', '🄐', 'Ⓐ', '🅰', '🄰', '🅐', '🅐', '🅐'];
    return text.split('').map((c) {
      int idx = c.toLowerCase().codeUnitAt(0) - 97;
      if (idx >= 0 && idx < 26) {
        return styles[index % styles.length];
      }
      return c;
    }).join();
  }

  String _toMixedStyle(String text, int index) {
    List<String> styles = [
      _toBold(text), _toItalic(text), _toScript(text), _toFraktur(text),
      _toDoubleStruck(text), _toMonospace(text), _toSansSerif(text), _toCursive(text),
      _toCircled(text), _toSquared(text), _toStrikethrough(text), _toUnderline(text)
    ];
    return styles[index % styles.length];
  }

  String _toExtraStyle(String text, int index) {
    List<String> extras = [
      '🔲$text🔲', '🔳$text🔳', '⬛$text⬛', '⬜$text⬜', '◼️$text◼️', '◻️$text◻️',
      '▪️$text▪️', '▫️$text▫️', '➡️$text⬅️', '⬆️$text⬇️', '🔴$text🔴', '🔵$text🔵',
      '🟢$text🟢', '🟡$text🟡', '🟠$text🟠', '🟣$text🟣', '🟤$text🟤', '⚫$text⚫', '⚪$text⚪'
    ];
    return extras[index % extras.length];
  }

  // ==================== HAPUS BERDASARKAN KATA KUNCI ====================
  void _deleteByKeyword() {
    if (_deleteController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Masukkan kata kunci terlebih dahulu", style: TextStyle(color: orangeAccent)),
          backgroundColor: cardBg,
          duration: const Duration(seconds: 2),
        ),
      );
      return;
    }

    String keyword = _deleteController.text.trim().toLowerCase();
    
    List<String> toDelete = _quotes.where((quote) => 
      quote.toLowerCase().contains(keyword) || 
      quote.toLowerCase().startsWith(keyword)
    ).toList();

    if (toDelete.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Tidak ada teks yang mengandung '$keyword'", style: TextStyle(color: orangeAccent)),
          backgroundColor: cardBg,
          duration: const Duration(seconds: 2),
        ),
      );
      return;
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardBg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: redAccent.withOpacity(0.5)),
        ),
        title: Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: redAccent, size: 28),
            const SizedBox(width: 10),
            Text(
              "Hapus Berdasarkan Kata Kunci",
              style: TextStyle(color: textWhite, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 14),
            ),
          ],
        ),
        content: Text(
          "Yakin ingin menghapus ${toDelete.length} teks yang mengandung kata '$keyword'?",
          style: TextStyle(color: textGrey, fontFamily: 'ShareTechMono'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("BATAL", style: TextStyle(color: cyanAccent, fontFamily: 'Orbitron')),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                _quotes.removeWhere((quote) => 
                  quote.toLowerCase().contains(keyword) || 
                  quote.toLowerCase().startsWith(keyword)
                );
                _saveQuotes();
                _deleteController.clear();
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text("Berhasil menghapus ${toDelete.length} teks", style: TextStyle(color: redAccent)),
                  backgroundColor: cardBg,
                  duration: const Duration(seconds: 2),
                ),
              );
            },
            child: Text("HAPUS", style: TextStyle(color: redAccent, fontFamily: 'Orbitron')),
          ),
        ],
      ),
    );
  }

  void _addQuoteWithVariations() {
    if (_textController.text.trim().isNotEmpty) {
      List<String> variations = _generateVariations(_textController.text.trim());
      setState(() {
        _quotes.insertAll(0, variations);
        _saveQuotes();
        _textController.clear();
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Tersimpan ${variations.length} variasi teks", style: TextStyle(color: cyanAccent)),
          backgroundColor: cardBg,
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  void _deleteAllQuotes() {
    if (_quotes.isEmpty) return;
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardBg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: redAccent.withOpacity(0.5)),
        ),
        title: Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: redAccent, size: 28),
            const SizedBox(width: 10),
            Text("Hapus Semua?", style: TextStyle(color: textWhite, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
          ],
        ),
        content: Text(
          "Yakin ingin menghapus semua ${_quotes.length} teks?",
          style: TextStyle(color: textGrey, fontFamily: 'ShareTechMono'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("BATAL", style: TextStyle(color: cyanAccent, fontFamily: 'Orbitron')),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                _quotes.clear();
                _saveQuotes();
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text("Semua teks telah dihapus", style: TextStyle(color: redAccent)),
                  backgroundColor: cardBg,
                  duration: const Duration(seconds: 2),
                ),
              );
            },
            child: Text("HAPUS", style: TextStyle(color: redAccent, fontFamily: 'Orbitron')),
          ),
        ],
      ),
    );
  }

  Future<void> _loadQuotes() async {
    final prefs = await SharedPreferences.getInstance();
    final savedQuotes = prefs.getStringList('quotes_list') ?? [];
    setState(() {
      _quotes = savedQuotes;
    });
  }

  Future<void> _saveQuotes() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('quotes_list', _quotes);
  }

  void _deleteQuote(int index) {
    setState(() {
      _quotes.removeAt(index);
      _saveQuotes();
    });
  }

  void _copyToClipboard(String text) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Teks disalin", style: TextStyle(color: cyanAccent)),
        backgroundColor: cardBg,
        duration: const Duration(seconds: 1),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _loadQuotes();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryBg,
      appBar: AppBar(
        backgroundColor: cardBg,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: cyanAccent, size: 22),
          onPressed: () => Navigator.pop(context),
        ),
        title: ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [Color(0xFF00E5FF), Color(0xFF00BCD4)],
          ).createShader(bounds),
          child: Text(
            "TEXT KECE",
            style: TextStyle(
              color: textWhite,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
              letterSpacing: 2,
            ),
          ),
        ),
        actions: [
          if (_quotes.isNotEmpty)
            IconButton(
              icon: Icon(Icons.delete_sweep, color: redAccent, size: 24),
              onPressed: _deleteAllQuotes,
              tooltip: "Hapus Semua",
            ),
        ],
      ),
      body: Column(
        children: [
          // Input Section
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: cardBg,
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(20),
                bottomRight: Radius.circular(20),
              ),
              border: Border(bottom: BorderSide(color: borderGlass, width: 1)),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Icon(Icons.edit_note, color: pinkAccent, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      "MASUKAN TEXT KECE",
                      style: TextStyle(color: pinkAccent, fontSize: 12, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, letterSpacing: 1),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Container(
                  decoration: BoxDecoration(
                    color: panelBg,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: borderGlass),
                  ),
                  child: TextField(
                    controller: _textController,
                    style: TextStyle(color: textWhite, fontSize: 14),
                    decoration: InputDecoration(
                      hintText: "Tulis sesuatu... nanti jadi 500 variasi",
                      hintStyle: TextStyle(color: textGrey, fontSize: 12),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.all(16),
                      suffixIcon: IconButton(
                        icon: Icon(Icons.auto_awesome, color: cyanAccent, size: 22),
                        onPressed: _addQuoteWithVariations,
                      ),
                    ),
                    onSubmitted: (_) => _addQuoteWithVariations(),
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: cyanAccent.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    "1 teks akan menjadi 500 variasi gaya berbeda",
                    style: TextStyle(color: cyanAccent, fontSize: 10, fontFamily: 'ShareTechMono'),
                  ),
                ),
              ],
            ),
          ),
          
          // Delete by Keyword Section
          Container(
            margin: const EdgeInsets.all(12),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: redAccent.withOpacity(0.1),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: redAccent.withOpacity(0.3)),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Icon(Icons.delete_outline, color: redAccent, size: 18),
                    const SizedBox(width: 8),
                    Text(
                      "HAPUS BERDASARKAN KATA KUNCI",
                      style: TextStyle(color: redAccent, fontSize: 11, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, letterSpacing: 1),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          color: panelBg,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: borderGlass),
                        ),
                        child: TextField(
                          controller: _deleteController,
                          style: TextStyle(color: textWhite, fontSize: 13),
                          decoration: InputDecoration(
                            hintText: "Contoh: hai (hapus semua teks yang mengandung 'hai')",
                            hintStyle: TextStyle(color: textGrey, fontSize: 11),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    ElevatedButton(
                      onPressed: _deleteByKeyword,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: redAccent,
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: Text(
                        "HAPUS",
                        style: TextStyle(color: Colors.white, fontSize: 12, fontFamily: 'Orbitron', fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          
          // List Header
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Icon(Icons.format_list_bulleted, color: cyanAccent, size: 16),
                const SizedBox(width: 8),
                Text(
                  "LIST TEXT KECE (${_quotes.length})",
                  style: TextStyle(color: cyanAccent, fontSize: 11, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, letterSpacing: 1),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          
          // List View
          Expanded(
            child: _quotes.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.auto_awesome, color: textGrey, size: 48),
                        const SizedBox(height: 12),
                        Text("Belum ada text", style: TextStyle(color: textGrey, fontSize: 14, fontFamily: 'ShareTechMono')),
                        Text("Ketik sesuatu di atas", style: TextStyle(color: textGrey.withOpacity(0.7), fontSize: 12, fontFamily: 'ShareTechMono')),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    itemCount: _quotes.length,
                    itemBuilder: (context, index) {
                      return Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        decoration: BoxDecoration(
                          color: cardBg,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: borderGlass),
                        ),
                        child: Dismissible(
                          key: Key(_quotes[index] + index.toString()),
                          direction: DismissDirection.endToStart,
                          background: Container(
                            alignment: Alignment.centerRight,
                            padding: const EdgeInsets.only(right: 20),
                            decoration: BoxDecoration(
                              color: redAccent.withOpacity(0.8),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Icon(Icons.delete, color: Colors.white, size: 24),
                          ),
                          onDismissed: (_) => _deleteQuote(index),
                          child: ListTile(
                            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                            leading: Container(
                              width: 32,
                              height: 32,
                              decoration: BoxDecoration(
                                color: pinkAccent.withOpacity(0.15),
                                shape: BoxShape.circle,
                              ),
                              child: Center(
                                child: Text(
                                  "${index + 1}",
                                  style: TextStyle(color: pinkAccent, fontSize: 11, fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                            title: SelectableText(
                              _quotes[index],
                              style: TextStyle(color: textWhite, fontSize: 14, fontFamily: 'ShareTechMono'),
                            ),
                            trailing: IconButton(
                              icon: Icon(Icons.copy, color: cyanAccent, size: 18),
                              onPressed: () => _copyToClipboard(_quotes[index]),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}