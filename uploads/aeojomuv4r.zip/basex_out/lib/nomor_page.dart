import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class NomorPage extends StatefulWidget {
  const NomorPage({super.key});

  @override
  State<NomorPage> createState() => _NomorPageState();
}

class _NomorPageState extends State<NomorPage> {
  final TextEditingController _nomorController = TextEditingController();
  String _hasilPengecekan = '';
  bool _isLoading = false;

  final Color primaryBg = const Color(0xFF080C12);
  final Color cardBg = const Color(0xFF0D1520);
  final Color panelBg = const Color(0xFF0A1018);
  final Color cyanAccent = const Color(0xFF00E5FF);
  final Color textWhite = Colors.white;
  final Color textGrey = const Color(0xFF607D8B);
  final Color borderGlass = const Color(0xFF1A3A4A);
  final Color greenAccent = const Color(0xFF4CAF50);
  final Color yellowAccent = const Color(0xFFFFC107);

  // Database kode negara (prefix)
  final Map<String, Map<String, String>> _countryCodes = {
    // Asia
    '+62': {'name': 'Indonesia', 'flag': '🇮🇩', 'continent': 'Asia'},
    '+60': {'name': 'Malaysia', 'flag': '🇲🇾', 'continent': 'Asia'},
    '+65': {'name': 'Singapura', 'flag': '🇸🇬', 'continent': 'Asia'},
    '+66': {'name': 'Thailand', 'flag': '🇹🇭', 'continent': 'Asia'},
    '+63': {'name': 'Filipina', 'flag': '🇵🇭', 'continent': 'Asia'},
    '+84': {'name': 'Vietnam', 'flag': '🇻🇳', 'continent': 'Asia'},
    '+95': {'name': 'Myanmar', 'flag': '🇲🇲', 'continent': 'Asia'},
    '+855': {'name': 'Kamboja', 'flag': '🇰🇭', 'continent': 'Asia'},
    '+856': {'name': 'Laos', 'flag': '🇱🇦', 'continent': 'Asia'},
    '+673': {'name': 'Brunei', 'flag': '🇧🇳', 'continent': 'Asia'},
    '+86': {'name': 'China', 'flag': '🇨🇳', 'continent': 'Asia'},
    '+852': {'name': 'Hong Kong', 'flag': '🇭🇰', 'continent': 'Asia'},
    '+853': {'name': 'Macau', 'flag': '🇲🇴', 'continent': 'Asia'},
    '+886': {'name': 'Taiwan', 'flag': '🇹🇼', 'continent': 'Asia'},
    '+81': {'name': 'Jepang', 'flag': '🇯🇵', 'continent': 'Asia'},
    '+82': {'name': 'Korea Selatan', 'flag': '🇰🇷', 'continent': 'Asia'},
    '+91': {'name': 'India', 'flag': '🇮🇳', 'continent': 'Asia'},
    '+92': {'name': 'Pakistan', 'flag': '🇵🇰', 'continent': 'Asia'},
    '+94': {'name': 'Sri Lanka', 'flag': '🇱🇰', 'continent': 'Asia'},
    '+977': {'name': 'Nepal', 'flag': '🇳🇵', 'continent': 'Asia'},
    '+880': {'name': 'Bangladesh', 'flag': '🇧🇩', 'continent': 'Asia'},
    '+98': {'name': 'Iran', 'flag': '🇮🇷', 'continent': 'Asia'},
    '+964': {'name': 'Irak', 'flag': '🇮🇶', 'continent': 'Asia'},
    '+965': {'name': 'Kuwait', 'flag': '🇰🇼', 'continent': 'Asia'},
    '+966': {'name': 'Arab Saudi', 'flag': '🇸🇦', 'continent': 'Asia'},
    '+967': {'name': 'Yaman', 'flag': '🇾🇪', 'continent': 'Asia'},
    '+968': {'name': 'Oman', 'flag': '🇴🇲', 'continent': 'Asia'},
    '+971': {'name': 'Uni Emirat Arab', 'flag': '🇦🇪', 'continent': 'Asia'},
    '+972': {'name': 'Israel', 'flag': '🇮🇱', 'continent': 'Asia'},
    '+973': {'name': 'Bahrain', 'flag': '🇧🇭', 'continent': 'Asia'},
    '+974': {'name': 'Qatar', 'flag': '🇶🇦', 'continent': 'Asia'},
    '+961': {'name': 'Lebanon', 'flag': '🇱🇧', 'continent': 'Asia'},
    '+962': {'name': 'Yordania', 'flag': '🇯🇴', 'continent': 'Asia'},
    '+963': {'name': 'Suriah', 'flag': '🇸🇾', 'continent': 'Asia'},
    '+996': {'name': 'Kyrgyzstan', 'flag': '🇰🇬', 'continent': 'Asia'},
    '+998': {'name': 'Uzbekistan', 'flag': '🇺🇿', 'continent': 'Asia'},
    '+993': {'name': 'Turkmenistan', 'flag': '🇹🇲', 'continent': 'Asia'},
    '+992': {'name': 'Tajikistan', 'flag': '🇹🇯', 'continent': 'Asia'},
    '+7': {'name': 'Kazakhstan / Rusia', 'flag': '🇰🇿', 'continent': 'Asia/Eropa'},
    
    // Eropa
    '+44': {'name': 'Inggris', 'flag': '🇬🇧', 'continent': 'Eropa'},
    '+33': {'name': 'Prancis', 'flag': '🇫🇷', 'continent': 'Eropa'},
    '+49': {'name': 'Jerman', 'flag': '🇩🇪', 'continent': 'Eropa'},
    '+39': {'name': 'Italia', 'flag': '🇮🇹', 'continent': 'Eropa'},
    '+34': {'name': 'Spanyol', 'flag': '🇪🇸', 'continent': 'Eropa'},
    '+31': {'name': 'Belanda', 'flag': '🇳🇱', 'continent': 'Eropa'},
    '+32': {'name': 'Belgia', 'flag': '🇧🇪', 'continent': 'Eropa'},
    '+41': {'name': 'Swiss', 'flag': '🇨🇭', 'continent': 'Eropa'},
    '+43': {'name': 'Austria', 'flag': '🇦🇹', 'continent': 'Eropa'},
    '+46': {'name': 'Swedia', 'flag': '🇸🇪', 'continent': 'Eropa'},
    '+47': {'name': 'Norwegia', 'flag': '🇳🇴', 'continent': 'Eropa'},
    '+45': {'name': 'Denmark', 'flag': '🇩🇰', 'continent': 'Eropa'},
    '+358': {'name': 'Finlandia', 'flag': '🇫🇮', 'continent': 'Eropa'},
    '+48': {'name': 'Polandia', 'flag': '🇵🇱', 'continent': 'Eropa'},
    '+420': {'name': 'Republik Ceko', 'flag': '🇨🇿', 'continent': 'Eropa'},
    '+421': {'name': 'Slovakia', 'flag': '🇸🇰', 'continent': 'Eropa'},
    '+36': {'name': 'Hungaria', 'flag': '🇭🇺', 'continent': 'Eropa'},
    '+40': {'name': 'Romania', 'flag': '🇷🇴', 'continent': 'Eropa'},
    '+359': {'name': 'Bulgaria', 'flag': '🇧🇬', 'continent': 'Eropa'},
    '+30': {'name': 'Yunani', 'flag': '🇬🇷', 'continent': 'Eropa'},
    '+90': {'name': 'Turki', 'flag': '🇹🇷', 'continent': 'Asia/Eropa'},
    '+7': {'name': 'Rusia', 'flag': '🇷🇺', 'continent': 'Eropa/Asia'},
    '+380': {'name': 'Ukraina', 'flag': '🇺🇦', 'continent': 'Eropa'},
    '+370': {'name': 'Lithuania', 'flag': '🇱🇹', 'continent': 'Eropa'},
    '+371': {'name': 'Latvia', 'flag': '🇱🇻', 'continent': 'Eropa'},
    '+372': {'name': 'Estonia', 'flag': '🇪🇪', 'continent': 'Eropa'},
    
    // Amerika
    '+1': {'name': 'Amerika Serikat / Kanada', 'flag': '🇺🇸', 'continent': 'Amerika'},
    '+52': {'name': 'Meksiko', 'flag': '🇲🇽', 'continent': 'Amerika'},
    '+55': {'name': 'Brasil', 'flag': '🇧🇷', 'continent': 'Amerika'},
    '+54': {'name': 'Argentina', 'flag': '🇦🇷', 'continent': 'Amerika'},
    '+56': {'name': 'Chili', 'flag': '🇨🇱', 'continent': 'Amerika'},
    '+57': {'name': 'Kolombia', 'flag': '🇨🇴', 'continent': 'Amerika'},
    '+58': {'name': 'Venezuela', 'flag': '🇻🇪', 'continent': 'Amerika'},
    '+51': {'name': 'Peru', 'flag': '🇵🇪', 'continent': 'Amerika'},
    '+53': {'name': 'Kuba', 'flag': '🇨🇺', 'continent': 'Amerika'},
    '+507': {'name': 'Panama', 'flag': '🇵🇦', 'continent': 'Amerika'},
    '+506': {'name': 'Kosta Rika', 'flag': '🇨🇷', 'continent': 'Amerika'},
    '+505': {'name': 'Nikaragua', 'flag': '🇳🇮', 'continent': 'Amerika'},
    '+504': {'name': 'Honduras', 'flag': '🇭🇳', 'continent': 'Amerika'},
    '+503': {'name': 'El Salvador', 'flag': '🇸🇻', 'continent': 'Amerika'},
    '+502': {'name': 'Guatemala', 'flag': '🇬🇹', 'continent': 'Amerika'},
    '+501': {'name': 'Belize', 'flag': '🇧🇿', 'continent': 'Amerika'},
    '+509': {'name': 'Haiti', 'flag': '🇭🇹', 'continent': 'Amerika'},
    '+1-809': {'name': 'Republik Dominika', 'flag': '🇩🇴', 'continent': 'Amerika'},
    '+1-876': {'name': 'Jamaika', 'flag': '🇯🇲', 'continent': 'Amerika'},
    '+598': {'name': 'Uruguay', 'flag': '🇺🇾', 'continent': 'Amerika'},
    '+595': {'name': 'Paraguay', 'flag': '🇵🇾', 'continent': 'Amerika'},
    '+591': {'name': 'Bolivia', 'flag': '🇧🇴', 'continent': 'Amerika'},
    '+593': {'name': 'Ekuador', 'flag': '🇪🇨', 'continent': 'Amerika'},
    '+592': {'name': 'Guyana', 'flag': '🇬🇾', 'continent': 'Amerika'},
    '+597': {'name': 'Suriname', 'flag': '🇸🇷', 'continent': 'Amerika'},
    
    // Afrika
    '+20': {'name': 'Mesir', 'flag': '🇪🇬', 'continent': 'Afrika'},
    '+27': {'name': 'Afrika Selatan', 'flag': '🇿🇦', 'continent': 'Afrika'},
    '+234': {'name': 'Nigeria', 'flag': '🇳🇬', 'continent': 'Afrika'},
    '+254': {'name': 'Kenya', 'flag': '🇰🇪', 'continent': 'Afrika'},
    '+255': {'name': 'Tanzania', 'flag': '🇹🇿', 'continent': 'Afrika'},
    '+256': {'name': 'Uganda', 'flag': '🇺🇬', 'continent': 'Afrika'},
    '+250': {'name': 'Rwanda', 'flag': '🇷🇼', 'continent': 'Afrika'},
    '+251': {'name': 'Ethiopia', 'flag': '🇪🇹', 'continent': 'Afrika'},
    '+233': {'name': 'Ghana', 'flag': '🇬🇭', 'continent': 'Afrika'},
    '+225': {'name': 'Pantai Gading', 'flag': '🇨🇮', 'continent': 'Afrika'},
    '+221': {'name': 'Senegal', 'flag': '🇸🇳', 'continent': 'Afrika'},
    '+212': {'name': 'Maroko', 'flag': '🇲🇦', 'continent': 'Afrika'},
    '+216': {'name': 'Tunisia', 'flag': '🇹🇳', 'continent': 'Afrika'},
    '+213': {'name': 'Aljazair', 'flag': '🇩🇿', 'continent': 'Afrika'},
    '+218': {'name': 'Libya', 'flag': '🇱🇾', 'continent': 'Afrika'},
    '+249': {'name': 'Sudan', 'flag': '🇸🇩', 'continent': 'Afrika'},
    '+263': {'name': 'Zimbabwe', 'flag': '🇿🇼', 'continent': 'Afrika'},
    '+260': {'name': 'Zambia', 'flag': '🇿🇲', 'continent': 'Afrika'},
    '+265': {'name': 'Malawi', 'flag': '🇲🇼', 'continent': 'Afrika'},
    '+258': {'name': 'Mozambik', 'flag': '🇲🇿', 'continent': 'Afrika'},
    '+264': {'name': 'Namibia', 'flag': '🇳🇦', 'continent': 'Afrika'},
    '+267': {'name': 'Botswana', 'flag': '🇧🇼', 'continent': 'Afrika'},
    
    // Australia / Oceania
    '+61': {'name': 'Australia', 'flag': '🇦🇺', 'continent': 'Oceania'},
    '+64': {'name': 'Selandia Baru', 'flag': '🇳🇿', 'continent': 'Oceania'},
    '+675': {'name': 'Papua Nugini', 'flag': '🇵🇬', 'continent': 'Oceania'},
    '+679': {'name': 'Fiji', 'flag': '🇫🇯', 'continent': 'Oceania'},
    '+677': {'name': 'Kepulauan Solomon', 'flag': '🇸🇧', 'continent': 'Oceania'},
    '+682': {'name': 'Kepulauan Cook', 'flag': '🇨🇰', 'continent': 'Oceania'},
    '+686': {'name': 'Kiribati', 'flag': '🇰🇮', 'continent': 'Oceania'},
    '+687': {'name': 'Kaledonia Baru', 'flag': '🇳🇨', 'continent': 'Oceania'},
    '+689': {'name': 'Polinesia Prancis', 'flag': '🇵🇫', 'continent': 'Oceania'},
    '+691': {'name': 'Mikronesia', 'flag': '🇫🇲', 'continent': 'Oceania'},
    '+692': {'name': 'Kepulauan Marshall', 'flag': '🇲🇭', 'continent': 'Oceania'},
  };

  String _detectCountry(String phoneNumber) {
    // Bersihkan nomor: hapus spasi, tanda hubung, dll
    String cleanNumber = phoneNumber.trim().replaceAll(RegExp(r'[\s\-\(\)]'), '');
    
    if (cleanNumber.isEmpty) {
      return 'unknown';
    }
    
    // Pastikan dimulai dengan +
    if (!cleanNumber.startsWith('+')) {
      cleanNumber = '+' + cleanNumber;
    }
    
    // Sortir kode dari yang terpanjang ke terpendek (prioritas)
    List<String> sortedCodes = _countryCodes.keys.toList()
      ..sort((a, b) => b.length.compareTo(a.length));
    
    for (String code in sortedCodes) {
      if (cleanNumber.startsWith(code)) {
        return code;
      }
    }
    
    return 'unknown';
  }

  void _checkNumber() {
    String input = _nomorController.text.trim();
    
    if (input.isEmpty) {
      setState(() {
        _hasilPengecekan = '';
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Masukkan nomor telepon terlebih dahulu', style: TextStyle(color: yellowAccent)),
          backgroundColor: cardBg,
        ),
      );
      return;
    }
    
    setState(() {
      _isLoading = true;
    });
    
    // Simulasi loading sebentar
    Future.delayed(const Duration(milliseconds: 500), () {
      String detectedCode = _detectCountry(input);
      
      if (detectedCode == 'unknown') {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            backgroundColor: cardBg,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
              side: BorderSide(color: Colors.red.withOpacity(0.5)),
            ),
            title: Row(
              children: [
                Icon(Icons.error_outline, color: Colors.red, size: 28),
                const SizedBox(width: 10),
                Text(
                  'TIDAK DIKENAL',
                  style: TextStyle(color: textWhite, fontFamily: 'Orbitron', fontWeight: FontWeight.bold),
                ),
              ],
            ),
            content: Text(
              'Nomor $input\nTidak dapat dikenali.\nPastikan format menggunakan kode negara (+62, +1, dll)',
              style: TextStyle(color: textGrey, fontFamily: 'ShareTechMono'),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('OK', style: TextStyle(color: cyanAccent)),
              ),
            ],
          ),
        );
      } else {
        String countryName = _countryCodes[detectedCode]!['name']!;
        String flag = _countryCodes[detectedCode]!['flag']!;
        String continent = _countryCodes[detectedCode]!['continent']!;
        
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            backgroundColor: cardBg,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
              side: BorderSide(color: cyanAccent.withOpacity(0.5)),
            ),
            title: Row(
              children: [
                Text(flag, style: const TextStyle(fontSize: 32)),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'DETEKSI NOMOR',
                    style: TextStyle(color: cyanAccent, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 14),
                  ),
                ),
              ],
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: cyanAccent.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: cyanAccent.withOpacity(0.3)),
                  ),
                  child: Column(
                    children: [
                      Text(
                        flag,
                        style: const TextStyle(fontSize: 48),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        countryName.toUpperCase(),
                        style: TextStyle(
                          color: cyanAccent,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        continent,
                        style: TextStyle(
                          color: textGrey,
                          fontSize: 12,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: panelBg,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.phone, color: cyanAccent, size: 16),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          input,
                          style: TextStyle(color: textWhite, fontFamily: 'ShareTechMono', fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: '$flag $countryName\nNomor: $input'));
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Info disalin', style: TextStyle(color: greenAccent)),
                      backgroundColor: cardBg,
                      duration: const Duration(seconds: 1),
                    ),
                  );
                  Navigator.pop(context);
                },
                child: Text('SALIN', style: TextStyle(color: cyanAccent)),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('TUTUP', style: TextStyle(color: textGrey)),
              ),
            ],
          ),
        );
      }
      
      setState(() {
        _isLoading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryBg,
      appBar: AppBar(
        backgroundColor: cardBg,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: cyanAccent, size: 22),
          onPressed: () => Navigator.pop(context),
        ),
        title: ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [Color(0xFF00E5FF), Color(0xFF00BCD4)],
          ).createShader(bounds),
          child: Text(
            "CEK NOMOR",
            style: TextStyle(
              color: textWhite,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
              letterSpacing: 2,
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: cardBg,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: borderGlass),
              ),
              child: Column(
                children: [
                  Icon(Icons.public, color: cyanAccent, size: 48),
                  const SizedBox(height: 12),
                  Text(
                    "CEK ASAL NEGARA",
                    style: TextStyle(
                      color: cyanAccent,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Masukkan nomor telepon dengan kode negara",
                    style: TextStyle(
                      color: textGrey,
                      fontSize: 12,
                      fontFamily: 'ShareTechMono',
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 20),
                  Container(
                    decoration: BoxDecoration(
                      color: panelBg,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: borderGlass),
                    ),
                    child: TextField(
                      controller: _nomorController,
                      style: TextStyle(color: textWhite, fontSize: 16),
                      keyboardType: TextInputType.phone,
                      decoration: InputDecoration(
                        hintText: "+628123456789",
                        hintStyle: TextStyle(color: textGrey, fontSize: 14),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.all(16),
                        prefixIcon: Icon(Icons.phone_android, color: cyanAccent),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _isLoading ? null : _checkNumber,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: cyanAccent,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                      child: _isLoading
                          ? SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(
                                color: primaryBg,
                                strokeWidth: 2,
                              ),
                            )
                          : Text(
                              "CEK NOMOR",
                              style: TextStyle(
                                color: primaryBg,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1,
                              ),
                            ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: panelBg,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: borderGlass),
              ),
              child: Column(
                children: [
                  Text(
                    "CONTOH FORMAT",
                    style: TextStyle(
                      color: textGrey,
                      fontSize: 10,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _buildExampleChip("+62", "Indonesia"),
                      _buildExampleChip("+1", "USA/Kanada"),
                      _buildExampleChip("+54", "Argentina"),
                      _buildExampleChip("+55", "Brasil"),
                      _buildExampleChip("+44", "Inggris"),
                      _buildExampleChip("+81", "Jepang"),
                      _buildExampleChip("+82", "Korea"),
                      _buildExampleChip("+86", "China"),
                      _buildExampleChip("+91", "India"),
                      _buildExampleChip("+61", "Australia"),
                      _buildExampleChip("+27", "Afrika Selatan"),
                      _buildExampleChip("+501", "Belize"),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildExampleChip(String code, String country) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _nomorController.text = code;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: cyanAccent.withOpacity(0.1),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: cyanAccent.withOpacity(0.3)),
        ),
        child: Text(
          "$code ($country)",
          style: TextStyle(
            color: cyanAccent,
            fontSize: 10,
            fontFamily: 'ShareTechMono',
          ),
        ),
      ),
    );
  }
}