import 'package:http/http.dart' as http;
import '../services/api_config_service.dart';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'partner_page.dart';
import 'dev_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'publik_chat.dart';
import 'tq_to.dart';
import 'anime_home.dart';
import 'musik_page.dart';
import 'shop_page.dart';
import 'shop_chat_page.dart';

// ══════════════════════════════════════════════════════════════════
//  OVALIUM GHOST — DASHBOARD PAGE  (Red × Black Edition)
// ══════════════════════════════════════════════════════════════════

class _C {
  static const bg      = Color(0xFF0A0A0A);
  static const card    = Color(0xFF141414);
  static const card2   = Color(0xFF1C1C1C);
  static const border  = Color(0xFF2A2A2A);
  static const red     = Color(0xFFE53935);
  static const redDark = Color(0xFFB71C1C);
  static const redGlow = Color(0x33E53935);
  static const white   = Colors.white;
  static const grey    = Color(0xFF9E9E9E);
  static const greyDim = Color(0xFF424242);
  static const green   = Color(0xFF00E676);
  static const cyan    = Color(0xFF00E5FF);
  static const gold    = Color(0xFFFFD700);
  static const orange  = Color(0xFFFF9100);
  static const purple  = Color(0xFFBB86FC);
  static const blue    = Color(0xFF448AFF);
}

// ── Gambar dashboard yang bakal di-slide ─────────────────────────
// Diganti dengan asset lokal atau network URL sesuai kebutuhan
const _kSlideImages = [
  'assets/images/kontol.png',
  'assets/images/reyy.png',
  'assets/images/ziper.png',
];

class DashboardPage extends StatefulWidget {
  final String userId, level, username, password, role, expiredDate, sessionKey;
  final List<Map<String, dynamic>> listBug, listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.userId,
    required this.level,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late AnimationController _fadeCtrl;
  late Animation<double>   _fadeAnim;

  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;

  File? _profileImage;
  VideoPlayerController? _videoCtrl;

  int _navIdx = 0;
  late Widget _selectedPage;

  int onlineUsers = 0, activeConnections = 0;

  // ── Slide foto ─────────────────────────────────────────────────
  final PageController _slideCtrl = PageController();
  int _slideIdx = 0;

  // ── Cuaca ──────────────────────────────────────────────────────
  Map<String, dynamic>? _weatherData;
  bool _weatherLoading = true;
  String _weatherError = '';
  double? _userLat, _userLon;
  String _cityName = 'Lokasi Anda';

  // ── Shop Preview ───────────────────────────────────────────────
  List<dynamic> _shopProducts = [];
  bool _shopLoading = true;

  // ── Jadwal Sholat ──────────────────────────────────────────────
  Map<String, dynamic>? _prayerData;
  bool _prayerLoading = true;
  String _nextPrayerName = '';
  String _nextPrayerTime = '';
  final List<String> _prayerOrder = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];

  @override
  void initState() {
    super.initState();
    sessionKey  = widget.sessionKey;
    username    = widget.username;
    password    = widget.password;
    role        = widget.role;
    expiredDate = widget.expiredDate;
    listBug     = widget.listBug;
    listDoos    = widget.listDoos;
    newsList    = widget.news;

    _fadeCtrl = AnimationController(
        duration: const Duration(milliseconds: 500), vsync: this);
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _selectedPage = _homePage();
    _loadProfileImage();
    _initVideo();
    _fetchStats();
    _startAutoSlide();
    _initLocationAndFetch();
    _fetchShopPreview();
  }

  void _startAutoSlide() {
    Future.delayed(const Duration(seconds: 3), () {
      if (!mounted) return;
      final next = (_slideIdx + 1) % _kSlideImages.length;
      _slideCtrl.animateToPage(
        next,
        duration: const Duration(milliseconds: 600),
        curve: Curves.easeInOut,
      );
      _startAutoSlide();
    });
  }

  Future<void> _fetchShopPreview() async {
    setState(() => _shopLoading = true);
    try {
      final res = await http.get(
        Uri.parse('${AppUrls.shopProducts}?key=$sessionKey'),
      ).timeout(const Duration(seconds: 8));
      final d = jsonDecode(res.body);
      if (d['success'] == true) {
        setState(() => _shopProducts = (d['products'] ?? []).take(10).toList());
      }
    } catch (_) {}
    setState(() => _shopLoading = false);
  }

  Future<void> _fetchStats() async {
    try {
      final res = await http.get(
          Uri.parse('${await ApiConfig.baseUrl}/api/dashboard-stats'));
      if (res.statusCode == 200) {
        final d = jsonDecode(res.body);
        if (d['success'] == true) {
          setState(() {
            onlineUsers       = d['onlineUsers'] ?? 0;
            activeConnections = d['activeConnections'] ?? 0;
          });
        }
      }
    } catch (_) {}
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path  = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty) {
      setState(() => _profileImage = File(path));
    }
  }

  void _initVideo() {
    _videoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _videoCtrl?.setLooping(true);
        _videoCtrl?.setVolume(1.0);
        _videoCtrl?.play();
      });
  }


  // ── Lokasi & Fetch cuaca+sholat ────────────────────────────────
  Future<void> _initLocationAndFetch() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        // Fallback ke Jakarta jika GPS mati
        _userLat = -6.2088;
        _userLon = 106.8456;
        _cityName = 'Jakarta';
      } else {
        LocationPermission perm = await Geolocator.checkPermission();
        if (perm == LocationPermission.denied) {
          perm = await Geolocator.requestPermission();
        }
        if (perm == LocationPermission.deniedForever ||
            perm == LocationPermission.denied) {
          _userLat = -6.2088;
          _userLon = 106.8456;
          _cityName = 'Jakarta';
        } else {
          final pos = await Geolocator.getCurrentPosition(
              desiredAccuracy: LocationAccuracy.low);
          _userLat = pos.latitude;
          _userLon = pos.longitude;
          // Reverse geocode sederhana via nominatim
          try {
            final geoRes = await http.get(Uri.parse(
                'https://nominatim.openstreetmap.org/reverse?lat=${pos.latitude}&lon=${pos.longitude}&format=json'),
                headers: {'Accept-Language': 'id'});
            if (geoRes.statusCode == 200) {
              final gd = jsonDecode(geoRes.body);
              final addr = gd['address'] ?? {};
              _cityName = addr['city'] ??
                  addr['town'] ??
                  addr['village'] ??
                  addr['county'] ??
                  'Lokasi Anda';
            }
          } catch (_) {}
        }
      }
    } catch (_) {
      _userLat = -6.2088;
      _userLon = 106.8456;
      _cityName = 'Jakarta';
    }
    await Future.wait([_fetchWeather(), _fetchPrayerTimes()]);
  }

  Future<void> _fetchWeather() async {
    try {
      final url = 'https://api.open-meteo.com/v1/forecast'
          '?latitude=$_userLat&longitude=$_userLon'
          '&current_weather=true'
          '&hourly=relativehumidity_2m,apparent_temperature'
          '&timezone=Asia%2FJakarta'
          '&forecast_days=1';
      final res = await http.get(Uri.parse(url));
      if (res.statusCode == 200) {
        if (mounted) {
          setState(() {
            _weatherData = jsonDecode(res.body);
            _weatherLoading = false;
          });
        }
      } else {
        if (mounted) setState(() { _weatherLoading = false; _weatherError = 'Gagal memuat'; });
      }
    } catch (e) {
      if (mounted) setState(() { _weatherLoading = false; _weatherError = 'No internet'; });
    }
  }

  Future<void> _fetchPrayerTimes() async {
    try {
      final now = DateTime.now();
      final url = 'https://api.aladhan.com/v1/timings/${now.day}-${now.month}-${now.year}'
          '?latitude=$_userLat&longitude=$_userLon&method=11';
      final res = await http.get(Uri.parse(url));
      if (res.statusCode == 200) {
        final d = jsonDecode(res.body);
        if (d['code'] == 200) {
          final timings = d['data']['timings'];
          if (mounted) {
            setState(() {
              _prayerData = timings;
              _prayerLoading = false;
              _updateNextPrayer(timings);
            });
          }
        }
      } else {
        if (mounted) setState(() => _prayerLoading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _prayerLoading = false);
    }
  }

  void _updateNextPrayer(Map<String, dynamic> timings) {
    final now = TimeOfDay.now();
    final nowMin = now.hour * 60 + now.minute;
    for (final name in _prayerOrder) {
      final parts = (timings[name] ?? '00:00').toString().split(':');
      final pMin = int.parse(parts[0]) * 60 + int.parse(parts[1]);
      if (pMin > nowMin) {
        _nextPrayerName = name;
        _nextPrayerTime = timings[name];
        return;
      }
    }
    _nextPrayerName = 'Fajr';
    _nextPrayerTime = timings['Fajr'] ?? '--:--';
  }

  String _weatherDesc(int code) {
    if (code == 0) return 'Cerah';
    if (code <= 3) return 'Berawan';
    if (code <= 49) return 'Berkabut';
    if (code <= 67) return 'Hujan';
    if (code <= 77) return 'Bersalju';
    if (code <= 99) return 'Badai';
    return 'N/A';
  }

  IconData _weatherIcon(int code) {
    if (code == 0) return Icons.wb_sunny_rounded;
    if (code <= 3) return Icons.cloud_rounded;
    if (code <= 49) return Icons.foggy;
    if (code <= 67) return Icons.grain_rounded;
    if (code <= 77) return Icons.ac_unit_rounded;
    return Icons.thunderstorm_rounded;
  }

  Color _weatherColor(int code) {
    if (code == 0) return _C.gold;
    if (code <= 3) return _C.grey;
    if (code <= 49) return _C.greyDim;
    if (code <= 67) return _C.cyan;
    if (code <= 77) return Colors.lightBlueAccent;
    return _C.purple;
  }

  String _prayerArabic(String name) {
    const map = {
      'Fajr': 'الفجر', 'Dhuhr': 'الظهر', 'Asr': 'العصر',
      'Maghrib': 'المغرب', 'Isha': 'العشاء',
    };
    return map[name] ?? name;
  }

  Color _prayerColor(String name) {
    const map = {
      'Fajr': _C.cyan, 'Dhuhr': _C.gold, 'Asr': _C.orange,
      'Maghrib': _C.red, 'Isha': _C.purple,
    };
    return map[name] ?? _C.white;
  }

  Future<void> _openUrl(String url) async =>
      launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);

  // ── Navigasi bottom bar ─────────────────────────────────────────
  void _onNavTap(int i) {
    setState(() {
      _navIdx = i;
      _selectedPage = i == 0
          ? _homePage()
          : i == 1
              ? HomePage(
                  isGroup: false,
                  username: username,
                  password: password,
                  listBug: listBug,
                  role: role,
                  expiredDate: expiredDate,
                  sessionKey: sessionKey,
                )
              : i == 2
                  ? InfoPage(sessionKey: sessionKey)
                  : ToolsPage(
                      username: username,
                      sessionKey: sessionKey,
                      userRole: role,
                      listDoos: listDoos,
                    );
    });
  }

  void _onDrawerNav(int i) {
    // Tutup drawer dulu
    Navigator.pop(context);
    // Setelah drawer tutup, pindah halaman
    Widget page;
    switch (i) {
      case 1: page = SellerPage(keyToken: sessionKey); break;
      case 2: page = AdminPage(sessionKey: sessionKey); break;
      case 3: page = OwnerPage(sessionKey: sessionKey, username: username); break;
      case 4: page = ModeratorPage(sessionKey: sessionKey, username: username); break;
      case 5: page = DevPage(sessionKey: sessionKey, username: username); break;
      default: return;
    }
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  // ════════════════════════════════════════════════════════════════
  //  HOME PAGE (tab pertama)
  // ════════════════════════════════════════════════════════════════
  Widget _homePage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.only(bottom: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Greeting header ─────────────────────────────────
          _buildGreetingCard(),
          const SizedBox(height: 16),

          // ── Stat chips ──────────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(children: [
              Expanded(child: _statChip(Icons.people_alt_rounded, 'Online', '$onlineUsers', _C.green)),
              const SizedBox(width: 10),
              Expanded(child: _statChip(Icons.link_rounded, 'Connected', '$activeConnections', _C.cyan)),
            ]),
          ),
          const SizedBox(height: 16),

          // ── Cuaca & Sholat ──────────────────────────────────
          _buildWeatherAndPrayerRow(),
          const SizedBox(height: 16),

          // ── Auto-slide foto kecil di bawah stat ─────────────
          _buildPhotoSlider(),
          const SizedBox(height: 20),

          // ── Video banner ────────────────────────────────────
          _buildVideoBanner(),
          const SizedBox(height: 20),

          // ── Quick actions ───────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text('Quick Access',
                style: TextStyle(
                    color: _C.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1)),
          ),
          const SizedBox(height: 10),
          _buildActionGrid(),
          const SizedBox(height: 24),

          // ── Shop Preview ─────────────────────────────────────
          _buildShopPreviewSection(),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  // ── Shop Preview Section ───────────────────────────────────────
  Widget _buildShopPreviewSection() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // Header row
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(children: [
          Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [_C.green.withOpacity(0.3), _C.green.withOpacity(0.1)]),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _C.green.withOpacity(0.4)),
              boxShadow: [BoxShadow(color: _C.green.withOpacity(0.2), blurRadius: 8)],
            ),
            child: const Icon(Icons.storefront_rounded, color: _C.green, size: 18),
          ),
          const SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('MARKET NAXSUS', style: TextStyle(
              color: _C.white, fontWeight: FontWeight.w900,
              fontFamily: 'Orbitron', fontSize: 14, letterSpacing: 1.5,
            )),
            Text('${_shopProducts.length} produk tersedia',
                style: TextStyle(color: _C.grey, fontSize: 10)),
          ]),
          const Spacer(),
          GestureDetector(
            onTap: () async {
              await Navigator.push(context, MaterialPageRoute(
                builder: (_) => ShopPage(username: username, sessionKey: sessionKey),
              ));
              _fetchShopPreview();
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(
                color: _C.green.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _C.green.withOpacity(0.35)),
              ),
              child: Row(children: [
                Text('Lihat Semua', style: TextStyle(color: _C.green, fontSize: 11, fontWeight: FontWeight.bold)),
                const SizedBox(width: 4),
                Icon(Icons.arrow_forward_ios_rounded, color: _C.green, size: 11),
              ]),
            ),
          ),
        ]),
      ),
      const SizedBox(height: 12),

      // Scam warning banner
      Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: _C.red.withOpacity(0.07),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: _C.red.withOpacity(0.3)),
        ),
        child: Row(children: [
          Icon(Icons.warning_amber_rounded, color: _C.red, size: 14),
          const SizedBox(width: 8),
          Expanded(child: Text(
            'Penipuan/scam/ilegal → akun dihapus permanen oleh Owner.',
            style: TextStyle(color: _C.red.withOpacity(0.85), fontSize: 9.5, height: 1.4),
          )),
        ]),
      ),
      const SizedBox(height: 12),

      // Horizontal scroll produk
      if (_shopLoading)
        SizedBox(
          height: 190,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: 4,
            itemBuilder: (_, __) => Container(
              width: 130,
              margin: const EdgeInsets.only(right: 12),
              decoration: BoxDecoration(
                color: _C.card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: _C.border),
              ),
            ),
          ),
        )
      else if (_shopProducts.isEmpty)
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          height: 160,
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _C.border),
          ),
          child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.storefront_outlined, color: _C.greyDim, size: 36),
            const SizedBox(height: 8),
            Text('Belum ada produk', style: TextStyle(color: _C.grey, fontSize: 12)),
            const SizedBox(height: 4),
            GestureDetector(
              onTap: () => Navigator.push(context, MaterialPageRoute(
                builder: (_) => ShopPage(username: username, sessionKey: sessionKey),
              )),
              child: Text('Mulai Jualan →', style: TextStyle(color: _C.green, fontSize: 11, fontWeight: FontWeight.bold)),
            ),
          ])),
        )
      else
        SizedBox(
          height: 210,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: _shopProducts.length + 1, // +1 untuk tombol lihat semua
            itemBuilder: (_, i) {
              // Kartu terakhir = tombol ke ShopPage
              if (i == _shopProducts.length) {
                return GestureDetector(
                  onTap: () async {
                    await Navigator.push(context, MaterialPageRoute(
                      builder: (_) => ShopPage(username: username, sessionKey: sessionKey),
                    ));
                    _fetchShopPreview();
                  },
                  child: Container(
                    width: 110,
                    margin: const EdgeInsets.only(right: 4),
                    decoration: BoxDecoration(
                      color: _C.card,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: _C.green.withOpacity(0.35)),
                    ),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: _C.green.withOpacity(0.12),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(Icons.arrow_forward_rounded, color: _C.green, size: 22),
                      ),
                      const SizedBox(height: 10),
                      Text('Lihat\nSemua', textAlign: TextAlign.center,
                          style: TextStyle(color: _C.green, fontSize: 12, fontWeight: FontWeight.bold, height: 1.4)),
                    ]),
                  ),
                );
              }

              final p        = _shopProducts[i];
              final imageUrl = (p['imageUrl'] ?? '').toString();
              final name     = (p['name']     ?? 'Produk').toString();
              final price    = (p['price']    ?? '').toString();
              final seller   = (p['sellerUsername'] ?? '').toString();

              return GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => ShopPage(username: username, sessionKey: sessionKey),
                )),
                child: Container(
                  width: 140,
                  margin: const EdgeInsets.only(right: 12),
                  decoration: BoxDecoration(
                    color: _C.card,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: _C.border),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 3))],
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    // Foto
                    Expanded(
                      flex: 5,
                      child: ClipRRect(
                        borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                        child: imageUrl.isNotEmpty
                            ? Image.network(imageUrl, fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => _shopImgPlaceholder())
                            : _shopImgPlaceholder(),
                      ),
                    ),
                    // Info
                    Expanded(
                      flex: 4,
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(9, 7, 9, 9),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(name,
                              style: const TextStyle(color: _C.white, fontSize: 11, fontWeight: FontWeight.bold),
                              maxLines: 2, overflow: TextOverflow.ellipsis),
                          const Spacer(),
                          if (price.isNotEmpty)
                            Text('Rp $price',
                                style: TextStyle(color: _C.green, fontSize: 11, fontWeight: FontWeight.w900),
                                maxLines: 1, overflow: TextOverflow.ellipsis)
                          else
                            Text('Nego', style: TextStyle(color: _C.gold.withOpacity(0.8), fontSize: 10, fontStyle: FontStyle.italic)),
                          const SizedBox(height: 3),
                          Row(children: [
                            Icon(Icons.person_rounded, color: _C.greyDim, size: 9),
                            const SizedBox(width: 2),
                            Expanded(child: Text(seller,
                                style: TextStyle(color: _C.greyDim, fontSize: 9),
                                overflow: TextOverflow.ellipsis)),
                          ]),
                        ]),
                      ),
                    ),
                  ]),
                ),
              );
            },
          ),
        ),
    ]);
  }

  Widget _shopImgPlaceholder() {
    return Container(
      color: _C.card2,
      child: Center(child: Icon(Icons.image_not_supported_outlined, color: _C.greyDim, size: 28)),
    );
  }

  // ── Weather + Prayer Row ───────────────────────────────────────
  Widget _buildWeatherAndPrayerRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(children: [
        Expanded(child: _buildWeatherCard()),
        const SizedBox(width: 10),
        Expanded(child: _buildPrayerCard()),
      ]),
    );
  }

  Widget _buildWeatherCard() {
    if (_weatherLoading) {
      return _infoCardShimmer(Icons.wb_cloudy_rounded, _C.cyan, 'Cuaca');
    }
    if (_weatherError.isNotEmpty || _weatherData == null) {
      return _infoCardError(Icons.wb_cloudy_rounded, _C.cyan, 'Cuaca', _weatherError);
    }
    final cw = _weatherData!['current_weather'];
    final temp = (cw['temperature'] as num).toStringAsFixed(0);
    final code = (cw['weathercode'] as num).toInt();
    final windspeed = (cw['windspeed'] as num).toStringAsFixed(0);
    final desc = _weatherDesc(code);
    final color = _weatherColor(code);

    return GestureDetector(
      onTap: () => setState(() {
        _weatherLoading = true;
        _fetchWeather();
      }),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [color.withOpacity(0.15), _C.card],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: color.withOpacity(0.35)),
          boxShadow: [BoxShadow(color: color.withOpacity(0.1), blurRadius: 12)],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.all(7),
              decoration: BoxDecoration(
                color: color.withOpacity(0.18),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(_weatherIcon(code), color: color, size: 18),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Cuaca', style: TextStyle(color: _C.grey, fontSize: 9, letterSpacing: 0.8)),
                Text(_cityName, style: const TextStyle(color: _C.white, fontSize: 10, fontWeight: FontWeight.w600),
                    overflow: TextOverflow.ellipsis),
              ]),
            ),
          ]),
          const SizedBox(height: 10),
          Text('$temp°C',
              style: TextStyle(color: color, fontSize: 26, fontWeight: FontWeight.bold, height: 1)),
          const SizedBox(height: 2),
          Text(desc, style: const TextStyle(color: _C.white, fontSize: 11, fontWeight: FontWeight.w500)),
          const SizedBox(height: 6),
          Row(children: [
            Icon(Icons.air_rounded, color: _C.grey, size: 11),
            const SizedBox(width: 3),
            Text('$windspeed km/h', style: const TextStyle(color: _C.grey, fontSize: 9)),
          ]),
        ]),
      ),
    );
  }

  Widget _buildPrayerCard() {
    if (_prayerLoading) {
      return _infoCardShimmer(Icons.mosque_rounded, _C.gold, 'Sholat');
    }
    if (_prayerData == null) {
      return _infoCardError(Icons.mosque_rounded, _C.gold, 'Sholat', 'Gagal memuat');
    }

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [_C.gold.withOpacity(0.12), _C.card],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _C.gold.withOpacity(0.35)),
        boxShadow: [BoxShadow(color: _C.gold.withOpacity(0.08), blurRadius: 12)],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              color: _C.gold.withOpacity(0.18),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.mosque_rounded, color: _C.gold, size: 18),
          ),
          const SizedBox(width: 8),
          const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Jadwal Sholat', style: TextStyle(color: _C.grey, fontSize: 9, letterSpacing: 0.8)),
            Text('Selanjutnya', style: TextStyle(color: _C.white, fontSize: 10, fontWeight: FontWeight.w600)),
          ]),
        ]),
        const SizedBox(height: 10),
        if (_nextPrayerName.isNotEmpty) ...[
          Text(_prayerArabic(_nextPrayerName),
              style: TextStyle(color: _prayerColor(_nextPrayerName), fontSize: 18,
                  fontWeight: FontWeight.bold)),
          Text(_nextPrayerName,
              style: const TextStyle(color: _C.white, fontSize: 11, fontWeight: FontWeight.w500)),
          const SizedBox(height: 4),
          Row(children: [
            const Icon(Icons.access_time_rounded, color: _C.grey, size: 11),
            const SizedBox(width: 3),
            Text(_nextPrayerTime, style: const TextStyle(color: _C.grey, fontSize: 11, fontWeight: FontWeight.w600)),
          ]),
        ],
        const SizedBox(height: 8),
        // Mini prayer list
        ..._prayerOrder.map((name) {
          final time = _prayerData![name] ?? '--:--';
          final isNext = name == _nextPrayerName;
          final color = _prayerColor(name);
          return Padding(
            padding: const EdgeInsets.only(bottom: 1),
            child: Row(children: [
              Container(
                width: 3, height: 3,
                decoration: BoxDecoration(
                  color: isNext ? color : _C.greyDim,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 5),
              Text(name,
                  style: TextStyle(
                    color: isNext ? color : _C.grey,
                    fontSize: 8.5,
                    fontWeight: isNext ? FontWeight.bold : FontWeight.normal,
                  )),
              const Spacer(),
              Text(time,
                  style: TextStyle(
                    color: isNext ? color : _C.grey.withOpacity(0.6),
                    fontSize: 8.5,
                    fontWeight: isNext ? FontWeight.bold : FontWeight.normal,
                  )),
            ]),
          );
        }),
      ]),
    );
  }

  Widget _infoCardShimmer(IconData icon, Color color, String title) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 8),
          Text(title, style: const TextStyle(color: _C.grey, fontSize: 11)),
        ]),
        const SizedBox(height: 12),
        SizedBox(
          height: 16, width: 60,
          child: LinearProgressIndicator(
            backgroundColor: _C.greyDim,
            valueColor: AlwaysStoppedAnimation(color),
          ),
        ),
        const SizedBox(height: 6),
        Container(height: 10, width: 80, color: _C.greyDim),
      ]),
    );
  }

  Widget _infoCardError(IconData icon, Color color, String title, String msg) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, color: color, size: 22),
        const SizedBox(height: 8),
        Text(title, style: const TextStyle(color: _C.white, fontWeight: FontWeight.bold, fontSize: 12)),
        const SizedBox(height: 4),
        Text(msg.isEmpty ? 'Error' : msg, style: const TextStyle(color: _C.grey, fontSize: 9)),
      ]),
    );
  }

    // ── Greeting card ──────────────────────────────────────────────
  Widget _buildGreetingCard() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [_C.redDark.withOpacity(0.25), _C.card],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.red.withOpacity(0.25)),
      ),
      child: Row(children: [
        // Profile pic
        GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => ProfilePage(
                  username: username, password: password,
                  role: role, expiredDate: expiredDate, sessionKey: sessionKey))),
          child: Container(
            width: 54, height: 54,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: _C.red, width: 2),
              boxShadow: [BoxShadow(color: _C.redGlow, blurRadius: 12)],
            ),
            child: ClipOval(
              child: _profileImage != null
                  ? Image.file(_profileImage!, fit: BoxFit.cover)
                  : const Icon(Icons.person_rounded, color: _C.white, size: 26),
            ),
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Welcome back,',
                style: TextStyle(color: _C.grey, fontSize: 11, letterSpacing: 0.5)),
            const SizedBox(height: 2),
            Text(username,
                style: const TextStyle(
                    color: _C.white, fontWeight: FontWeight.bold, fontSize: 18)),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: _C.red.withOpacity(0.15),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: _C.red.withOpacity(0.4)),
              ),
              child: Text(role.toUpperCase(),
                  style: const TextStyle(
                      color: _C.red, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
            ),
          ]),
        ),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text(expiredDate,
              style: const TextStyle(color: _C.grey, fontSize: 9)),
          const SizedBox(height: 4),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: _C.green.withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Text('ACTIVE',
                style: TextStyle(color: _C.green, fontSize: 9, fontWeight: FontWeight.bold)),
          ),
        ]),
      ]),
    );
  }

  // ── Stat chip ──────────────────────────────────────────────────
  Widget _statChip(IconData icon, String label, String val, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.12),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: color, size: 18),
        ),
        const SizedBox(width: 10),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(color: _C.grey, fontSize: 10)),
          Text(val,
              style: const TextStyle(
                  color: _C.white, fontWeight: FontWeight.bold, fontSize: 16)),
        ]),
      ]),
    );
  }

  // ── Auto-slide foto (kecil, di bawah stat) ─────────────────────
  Widget _buildPhotoSlider() {
    return Column(children: [
      SizedBox(
        height: 140,
        child: PageView.builder(
          controller: _slideCtrl,
          itemCount: _kSlideImages.length,
          onPageChanged: (i) => setState(() => _slideIdx = i),
          itemBuilder: (_, i) => Container(
            margin: const EdgeInsets.symmetric(horizontal: 6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _C.red.withOpacity(0.3)),
              boxShadow: [BoxShadow(color: _C.redGlow, blurRadius: 10)],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Image.asset(_kSlideImages[i], fit: BoxFit.cover),
            ),
          ),
        ),
      ),
      const SizedBox(height: 8),
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(_kSlideImages.length, (i) => AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          margin: const EdgeInsets.symmetric(horizontal: 3),
          width: _slideIdx == i ? 18 : 6,
          height: 6,
          decoration: BoxDecoration(
            color: _slideIdx == i ? _C.red : _C.greyDim,
            borderRadius: BorderRadius.circular(4),
          ),
        )),
      ),
    ]);
  }

  // ── Video banner ────────────────────────────────────────────────
  Widget _buildVideoBanner() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 180,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.red.withOpacity(0.3)),
        boxShadow: [BoxShadow(color: _C.redGlow, blurRadius: 16)],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(fit: StackFit.expand, children: [
          if (_videoCtrl != null && _videoCtrl!.value.isInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoCtrl!.value.size.width,
                  height: _videoCtrl!.value.size.height,
                  child: VideoPlayer(_videoCtrl!),
                ),
              ),
            )
          else
            Container(color: _C.card2,
                child: const Center(child: CircularProgressIndicator(color: _C.red, strokeWidth: 2))),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.transparent, _C.bg.withOpacity(0.85)],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
          Positioned(
            bottom: 14, left: 16,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('NAXSUS PROJECT',
                  style: TextStyle(
                      color: _C.white, fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 2)),
              const SizedBox(height: 2),
              Text('Dashboard Control Center',
                  style: TextStyle(color: _C.grey.withOpacity(0.7), fontSize: 11)),
            ]),
          ),
        ]),
      ),
    );
  }

  // ── Action grid ─────────────────────────────────────────────────
  Widget _buildActionGrid() {
    final actions = <_Action>[
      _Action('Channel', FontAwesomeIcons.telegram, _C.cyan,
          () => _openUrl('https://t.me/ANTIBEKU2')),
      _Action('Senders', FontAwesomeIcons.whatsapp, _C.green,
          () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => BugSenderPage(sessionKey: sessionKey, username: username, role: role)))),
      _Action('Public Chat', Icons.chat_bubble_outline_rounded, _C.gold,
          () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => CommunityPage(username: username, role: role)))),
      _Action('Tq To', Icons.favorite_rounded, _C.red,
          () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TqPage()))),
      _Action('Profile', Icons.person_outline_rounded, _C.blue,
          () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => ProfilePage(username: username, password: password,
                  role: role, expiredDate: expiredDate, sessionKey: sessionKey)))),
      if (role == 'reseller')
        _Action('Seller', Icons.store_rounded, _C.orange, () => _onDrawerNav(1)),
      if (role == 'partner')
        _Action('Partner', Icons.admin_panel_settings_rounded, _C.purple, () => _onDrawerNav(2)),
      if (role == 'owner')
        _Action('Owner', Icons.workspace_premium_rounded, _C.red, () => _onDrawerNav(3)),
      if (role == 'moderator')
        _Action('Mod', Icons.shield_rounded, _C.blue, () => _onDrawerNav(4)),
      if (role == 'developer')
        _Action('Dev', Icons.code_rounded, _C.cyan, () => _onDrawerNav(5)),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Wrap(
        spacing: 10,
        runSpacing: 10,
        children: actions.map((a) => _actionCard(a)).toList(),
      ),
    );
  }

  Widget _actionCard(_Action a) {
    final w = (MediaQuery.of(context).size.width - 42) / 2;
    return GestureDetector(
      onTap: a.onTap,
      child: Container(
        width: w,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 14),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: a.color.withOpacity(0.2)),
          boxShadow: [BoxShadow(color: a.color.withOpacity(0.06), blurRadius: 10)],
        ),
        child: Row(children: [
          Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(
              color: a.color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(a.icon, color: a.color, size: 18),
          ),
          const SizedBox(width: 10),
          Expanded(child: Text(a.label,
              style: const TextStyle(
                  color: _C.white, fontWeight: FontWeight.w600, fontSize: 13),
              overflow: TextOverflow.ellipsis)),
        ]),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════
  //  DRAWER
  // ════════════════════════════════════════════════════════════════
  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: _C.card,
      width: MediaQuery.of(context).size.width * 0.78,
      child: Column(children: [
        // Header
        Container(
          height: 150,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [_C.redDark, Color(0xFF1C0000)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: SafeArea(
            child: Row(children: [
              const SizedBox(width: 18),
              Container(
                width: 56, height: 56,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: _C.white.withOpacity(0.4), width: 1.5),
                ),
                child: ClipOval(
                  child: _profileImage != null
                      ? Image.file(_profileImage!, fit: BoxFit.cover)
                      : const Icon(Icons.person_rounded, color: _C.white, size: 28),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(username,
                      style: const TextStyle(color: _C.white, fontWeight: FontWeight.bold, fontSize: 16)),
                  const SizedBox(height: 4),
                  Text(role.toUpperCase(),
                      style: TextStyle(color: _C.white.withOpacity(0.6), fontSize: 10, letterSpacing: 1)),
                ],
              )),
            ]),
          ),
        ),
        // Items
        Expanded(child: ListView(
          padding: const EdgeInsets.symmetric(vertical: 8),
          children: [
            if (role == 'reseller')
              _drawerItem(Icons.store_rounded, 'Seller Page', _C.orange, () => _onDrawerNav(1)),
            if (role == 'partner')
              _drawerItem(Icons.admin_panel_settings_rounded, 'Partner', _C.purple, () => _onDrawerNav(2)),
            if (role == 'owner')
              _drawerItem(Icons.workspace_premium_rounded, 'Owner', _C.red, () => _onDrawerNav(3)),
            if (role == 'moderator')
              _drawerItem(Icons.shield_rounded, 'Moderator', _C.blue, () => _onDrawerNav(4)),
            if (role == 'developer')
              _drawerItem(Icons.code_rounded, 'Developer', _C.cyan, () => _onDrawerNav(5)),
            _drawerItem(Icons.history_rounded, 'Riwayat', _C.cyan, () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(
                  builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role)));
            }),
            _drawerItem(Icons.movie_filter_rounded, 'Anime', _C.purple, () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (_) => const HomeAnimePage()));
            }),
            _drawerItem(Icons.music_note_rounded, 'Smoty Play', _C.gold, () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (_) => const MusikPage()));
            }),
            const Divider(color: Color(0xFF2A2A2A), height: 24),
            _drawerItem(Icons.logout_rounded, 'Logout', Colors.redAccent, () async {
              Navigator.pop(context);
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              if (!mounted) return;
              Navigator.pushAndRemoveUntil(context,
                  MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false);
            }),
          ],
        )),
        // Version
        Padding(
          padding: const EdgeInsets.all(16),
          child: Text('v3.5 • NAXSUS',
              style: TextStyle(color: _C.grey.withOpacity(0.4), fontSize: 11)),
        ),
      ]),
    );
  }

  Widget _drawerItem(IconData icon, String title, Color color, VoidCallback onTap) {
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(7),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, color: color, size: 18),
      ),
      title: Text(title,
          style: const TextStyle(color: _C.white, fontSize: 14, fontWeight: FontWeight.w500)),
      trailing: Icon(Icons.chevron_right_rounded, color: _C.grey.withOpacity(0.4), size: 18),
      onTap: onTap,
    );
  }

  // ════════════════════════════════════════════════════════════════
  //  BUILD
  // ════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      drawer: _buildDrawer(),
      appBar: AppBar(
        backgroundColor: _C.card,
        elevation: 0,
        iconTheme: const IconThemeData(color: _C.white),
        titleSpacing: 0,
        title: const Text('NAXSUS PROJECT',
            style: TextStyle(
                color: _C.red, fontFamily: 'Orbitron',
                fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 3)),
        actions: [

          GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(
                builder: (_) => ProfilePage(
                    username: username, password: password,
                    role: role, expiredDate: expiredDate, sessionKey: sessionKey))),
            child: Padding(
              padding: const EdgeInsets.only(right: 14),
              child: Row(children: [
                Column(mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text(username,
                      style: const TextStyle(color: _C.white, fontWeight: FontWeight.bold, fontSize: 13)),
                  Text('Lvl. ${widget.level}',
                      style: const TextStyle(color: _C.grey, fontSize: 10)),
                ]),
                const SizedBox(width: 10),
                Container(
                  width: 34, height: 34,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: _C.red, width: 1.5),
                  ),
                  child: ClipOval(
                    child: _profileImage != null
                        ? Image.file(_profileImage!, fit: BoxFit.cover)
                        : const Icon(Icons.person_rounded, size: 18, color: _C.grey),
                  ),
                ),
              ]),
            ),
          ),
        ],
      ),
      body: FadeTransition(opacity: _fadeAnim, child: _selectedPage),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: _C.card,
          border: Border(top: BorderSide(color: Color(0xFF2A2A2A))),
        ),
        child: BottomNavigationBar(
          backgroundColor: Colors.transparent,
          type: BottomNavigationBarType.fixed,
          selectedItemColor: _C.red,
          unselectedItemColor: _C.grey.withOpacity(0.5),
          currentIndex: _navIdx,
          onTap: _onNavTap,
          selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 10),
          unselectedLabelStyle: const TextStyle(fontSize: 10),
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'Home'),
            BottomNavigationBarItem(icon: Icon(FontAwesomeIcons.whatsapp), label: 'WA'),
            BottomNavigationBarItem(icon: Icon(Icons.info_outline_rounded), label: 'Info'),
            BottomNavigationBarItem(icon: Icon(Icons.build_rounded), label: 'Tools'),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    _videoCtrl?.dispose();
    _slideCtrl.dispose();
    super.dispose();
  }
}

// ── Data class aksi ────────────────────────────────────────────────
class _Action {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _Action(this.label, this.icon, this.color, this.onTap);
}