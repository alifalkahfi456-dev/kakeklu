import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'change_password_page.dart';

class ProfilePage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;

  const ProfilePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage>
    with TickerProviderStateMixin {
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();

  // ── Palette ─────────────────────────────────────────────────────────────
  static const Color bgBlack     = Color(0xFF090909);
  static const Color surface     = Color(0xFF111116);
  static const Color cardColor   = Color(0xFF15151C);
  static const Color cyanCore    = Color(0xFF00D4FF);
  static const Color cyanDark    = Color(0xFF0077AA);
  static const Color cyanGlow    = Color(0xFF66E8FF);
  static const Color goldCore    = Color(0xFFFFB800);
  static const Color borderDim   = Color(0xFF242430);
  static const Color textPrimary = Color(0xFFF2F2F5);
  static const Color textMuted   = Color(0xFF666674);
  static const Color textGrey    = Color(0xFF9999AA);

  late AnimationController _ringController;
  late AnimationController _pageController;
  late Animation<double> _pageFade;
  late Animation<Offset> _pageSlide;

  @override
  void initState() {
    super.initState();

    _ringController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat();

    _pageController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _pageFade = CurvedAnimation(parent: _pageController, curve: Curves.easeOut);
    _pageSlide = Tween<Offset>(
      begin: const Offset(0, 0.06),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _pageController, curve: Curves.easeOutCubic));

    _pageController.forward();
    _loadProfileImage();
  }

  @override
  void dispose() {
    _ringController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_${widget.username}');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() { _profileImage = File(imagePath); });
    }
  }

  String _censorText(String text, {bool isPassword = false}) {
    if (text.isEmpty) return "N/A";
    if (isPassword) return "••••••••";
    if (text.length <= 2) return "${text.substring(0, 1)}••";
    return "${text.substring(0, 2)}${'•' * (text.length - 2)}";
  }

  Future<void> _showImageSourceDialog() {
    return showModalBottomSheet(
      context: context,
      backgroundColor: cardColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // drag handle
              Center(
                child: Container(
                  width: 40, height: 4,
                  margin: const EdgeInsets.only(bottom: 20),
                  decoration: BoxDecoration(
                    color: borderDim,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const Text(
                'GANTI FOTO',
                style: TextStyle(
                  color: textMuted,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.8,
                ),
              ),
              const SizedBox(height: 14),
              _SheetOption(
                icon: Icons.camera_alt_rounded,
                label: 'Kamera',
                iconColor: cyanCore,
                onTap: () { Navigator.pop(context); _pickImage(ImageSource.camera); },
              ),
              const SizedBox(height: 10),
              _SheetOption(
                icon: Icons.photo_library_rounded,
                label: 'Galeri',
                iconColor: goldCore,
                onTap: () { Navigator.pop(context); _pickImage(ImageSource.gallery); },
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source, imageQuality: 70,
      );
      if (pickedFile != null) {
        final File imageFile = File(pickedFile.path);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('profile_image_${widget.username}', imageFile.path);
        setState(() { _profileImage = imageFile; });
      }
    } catch (e) {
      debugPrint("Error picking image: $e");
    }
  }

  // ── Header ───────────────────────────────────────────────────────────────
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 20, 14),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: borderDim, width: 1)),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: cardColor,
                border: Border.all(color: borderDim, width: 1),
              ),
              child: const Center(
                child: Icon(Icons.arrow_back_ios_new_rounded,
                    color: textGrey, size: 17),
              ),
            ),
          ),
          const Expanded(
            child: Center(
              child: Text(
                'MY PROFILE',
                style: TextStyle(
                  color: textPrimary,
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 2.5,
                ),
              ),
            ),
          ),
          const SizedBox(width: 40), // balance
        ],
      ),
    );
  }

  // ── Avatar ───────────────────────────────────────────────────────────────
  Widget _buildAvatar() {
    return GestureDetector(
      onTap: _showImageSourceDialog,
      child: SizedBox(
        width: 130, height: 130,
        child: Stack(
          alignment: Alignment.center,
          children: [
            // rotating gradient ring
            AnimatedBuilder(
              animation: _ringController,
              builder: (_, __) {
                return Transform.rotate(
                  angle: _ringController.value * 2 * math.pi,
                  child: Container(
                    width: 130, height: 130,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: SweepGradient(
                        colors: [
                          cyanCore,
                          cyanDark,
                          Color(0xFF001122),
                          cyanCore,
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
            // inner photo
            Container(
              width: 118, height: 118,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: surface,
              ),
              child: ClipOval(
                child: _profileImage != null
                    ? Image.file(_profileImage!, fit: BoxFit.cover)
                    : const Icon(
                        FontAwesomeIcons.userAstronaut,
                        size: 48,
                        color: textGrey,
                      ),
              ),
            ),
            // camera badge
            Positioned(
              bottom: 4, right: 4,
              child: Container(
                width: 32, height: 32,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: cyanCore,
                  boxShadow: [
                    BoxShadow(
                      color: cyanCore.withOpacity(0.5),
                      blurRadius: 10,
                    ),
                  ],
                ),
                child: const Icon(Icons.camera_alt_rounded,
                    size: 16, color: bgBlack),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Role Badge ────────────────────────────────────────────────────────────
  Widget _buildRoleBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      decoration: BoxDecoration(
        color: goldCore.withOpacity(0.1),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: goldCore.withOpacity(0.4), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.star_rounded, color: goldCore, size: 13),
          const SizedBox(width: 6),
          Text(
            widget.role.toUpperCase(),
            style: const TextStyle(
              color: goldCore,
              fontSize: 11,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  // ── Info Card ─────────────────────────────────────────────────────────────
  Widget _buildInfoCard({
    required IconData icon,
    required String label,
    required String value,
    Color accentColor = cyanCore,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderDim, width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 30, height: 30,
                decoration: BoxDecoration(
                  color: accentColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(icon, color: accentColor, size: 15),
              ),
              const SizedBox(width: 8),
              Text(
                label.toUpperCase(),
                style: const TextStyle(
                  color: textMuted,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            value,
            style: const TextStyle(
              color: textPrimary,
              fontSize: 14,
              fontWeight: FontWeight.w700,
              fontFamily: 'ShareTechMono',
              letterSpacing: 0.5,
            ),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
        ],
      ),
    );
  }

  // ── Change Password Button ─────────────────────────────────────────────
  Widget _buildChangePasswordButton() {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ChangePasswordPage(
              username: widget.username,
              sessionKey: widget.sessionKey,
            ),
          ),
        );
      },
      child: Container(
        height: 54,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: const LinearGradient(
            colors: [cyanDark, cyanCore],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          boxShadow: [
            BoxShadow(
              color: cyanCore.withOpacity(0.3),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.lock_reset_rounded, color: bgBlack, size: 20),
            SizedBox(width: 10),
            Text(
              'CHANGE PASSWORD',
              style: TextStyle(
                color: bgBlack,
                fontSize: 14,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Build ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          // mesh blob background
          Positioned(
            top: -80, left: -60,
            child: Container(
              width: 280, height: 280,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    cyanCore.withOpacity(0.07),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            child: FadeTransition(
              opacity: _pageFade,
              child: SlideTransition(
                position: _pageSlide,
                child: Column(
                  children: [
                    _buildHeader(),
                    Expanded(
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: Column(
                          children: [
                            const SizedBox(height: 32),

                            // avatar
                            _buildAvatar(),
                            const SizedBox(height: 16),

                            // username
                            Text(
                              widget.username,
                              style: const TextStyle(
                                color: textPrimary,
                                fontSize: 22,
                                fontWeight: FontWeight.w800,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1.0,
                              ),
                            ),
                            const SizedBox(height: 8),

                            // role badge
                            _buildRoleBadge(),
                            const SizedBox(height: 36),

                            // divider label
                            _buildSectionLabel('ACCOUNT INFO'),
                            const SizedBox(height: 12),

                            // info cards 2x2
                            Row(
                              children: [
                                Expanded(
                                  child: _buildInfoCard(
                                    icon: Icons.person_outline_rounded,
                                    label: 'Username',
                                    value: _censorText(widget.username),
                                    accentColor: cyanCore,
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: _buildInfoCard(
                                    icon: Icons.lock_outline_rounded,
                                    label: 'Password',
                                    value: _censorText(widget.password, isPassword: true),
                                    accentColor: cyanCore,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            Row(
                              children: [
                                Expanded(
                                  child: _buildInfoCard(
                                    icon: Icons.verified_user_outlined,
                                    label: 'Role',
                                    value: widget.role.toUpperCase(),
                                    accentColor: goldCore,
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: _buildInfoCard(
                                    icon: Icons.calendar_month_rounded,
                                    label: 'Expired',
                                    value: widget.expiredDate,
                                    accentColor: goldCore,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            _buildInfoCard(
                              icon: Icons.vpn_key_rounded,
                              label: 'Session Key',
                              value: '${widget.sessionKey.substring(0, 8)}...',
                              accentColor: cyanCore,
                            ),

                            const SizedBox(height: 40),

                            // change password
                            _buildSectionLabel('SECURITY'),
                            const SizedBox(height: 12),
                            _buildChangePasswordButton(),

                            const SizedBox(height: 32),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionLabel(String label) {
    return Row(
      children: [
        Container(
          width: 3, height: 14,
          decoration: BoxDecoration(
            color: cyanCore,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 8),
        Text(
          label,
          style: const TextStyle(
            color: textMuted,
            fontSize: 10,
            fontWeight: FontWeight.w700,
            letterSpacing: 1.8,
          ),
        ),
        const SizedBox(width: 10),
        const Expanded(child: Divider(color: borderDim, height: 1)),
      ],
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// Helper Widgets
// ════════════════════════════════════════════════════════════════════════════

class _SheetOption extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color iconColor;
  final VoidCallback onTap;

  const _SheetOption({
    required this.icon,
    required this.label,
    required this.iconColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: _ProfilePageState.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _ProfilePageState.borderDim, width: 1),
        ),
        child: Row(
          children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                color: iconColor.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: iconColor, size: 18),
            ),
            const SizedBox(width: 14),
            Text(
              label,
              style: const TextStyle(
                color: _ProfilePageState.textPrimary,
                fontSize: 15,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
