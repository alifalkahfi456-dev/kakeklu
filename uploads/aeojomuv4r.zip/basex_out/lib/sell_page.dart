import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import '../services/api_config_service.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class SellPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const SellPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<SellPage> createState() => _SellPageState();
}

class _SellPageState extends State<SellPage> {
  // baseUrl is now fetched dynamically via ApiConfig

  static const Color bgBlack    = Color(0xFF0A0A0A);
  static const Color bgCard     = Color(0xFF141414);
  static const Color borderCol  = Color(0xFF2A2A2A);
  static const Color accentGreen = Color(0xFF69F0AE);
  static const Color accentRed  = Color(0xFFE53935);
  static const Color textWhite  = Colors.white;
  static const Color textGrey   = Color(0xFF888888);

  final nameCtrl     = TextEditingController();
  final descCtrl     = TextEditingController();
  final priceCtrl    = TextEditingController();
  final teleCtrl     = TextEditingController();
  final waCtrl       = TextEditingController();

  File? selectedImage;
  bool isLoading = false;
  bool _showMyProducts = false;
  List<dynamic> myProducts = [];
  bool isLoadingMyProducts = false;

  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _fetchMyProducts();
  }

  Future<void> _pickImage() async {
    showModalBottomSheet(
      context: context,
      backgroundColor: bgCard,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40, height: 4,
              decoration: BoxDecoration(
                  color: borderCol, borderRadius: BorderRadius.circular(2)),
            ),
            const SizedBox(height: 20),
            Text('Pilih Foto',
                style: TextStyle(
                    color: textWhite,
                    fontSize: 16,
                    fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            _bottomSheetBtn(
              icon: Icons.camera_alt,
              label: 'Kamera',
              color: accentGreen,
              onTap: () async {
                Navigator.pop(context);
                final img =
                    await _picker.pickImage(source: ImageSource.camera, imageQuality: 70);
                if (img != null) setState(() => selectedImage = File(img.path));
              },
            ),
            const SizedBox(height: 12),
            _bottomSheetBtn(
              icon: Icons.photo_library,
              label: 'Galeri',
              color: const Color(0xFF29B6F6),
              onTap: () async {
                Navigator.pop(context);
                final img =
                    await _picker.pickImage(source: ImageSource.gallery, imageQuality: 70);
                if (img != null) setState(() => selectedImage = File(img.path));
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Widget _bottomSheetBtn({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.12),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(width: 10),
            Text(label,
                style: TextStyle(
                    color: color, fontWeight: FontWeight.bold, fontSize: 14)),
          ],
        ),
      ),
    );
  }

  Future<void> _submitProduct() async {
    final name  = nameCtrl.text.trim();
    final desc  = descCtrl.text.trim();
    final price = priceCtrl.text.trim();
    final tele  = teleCtrl.text.trim();
    final wa    = waCtrl.text.trim();

    if (name.isEmpty) {
      _alert('Peringatan', 'Nama produk wajib diisi.');
      return;
    }
    if (tele.isEmpty && wa.isEmpty) {
      _alert('Peringatan', 'Isi minimal 1 kontak (Telegram atau WhatsApp).');
      return;
    }

    setState(() => isLoading = true);
    try {
      String? imageBase64;
      if (selectedImage != null) {
        final bytes = await selectedImage!.readAsBytes();
        imageBase64 = base64Encode(bytes);
      }

      final body = jsonEncode({
        'key': widget.sessionKey,
        'sellerUsername': widget.username,
        'name': name,
        'description': desc,
        'price': price,
        'telegramContact': tele,
        'whatsappContact': wa,
        if (imageBase64 != null) 'imageBase64': imageBase64,
      });

      final serverUrl = await ApiConfig.baseUrl;
      final res = await http.post(
        Uri.parse('$serverUrl/shop/addProduct'),
        headers: {'Content-Type': 'application/json'},
        body: body,
      );

      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _alert('Berhasil', '✅ Produk berhasil diupload!');
        nameCtrl.clear();
        descCtrl.clear();
        priceCtrl.clear();
        teleCtrl.clear();
        waCtrl.clear();
        setState(() => selectedImage = null);
        _fetchMyProducts();
        await Future.delayed(const Duration(milliseconds: 300));
        if (mounted) Navigator.pop(context, true);
      } else {
        _alert('Gagal', '❌ ${data['message'] ?? 'Gagal upload produk.'}');
      }
    } catch (e) {
      _alert('Error', '❌ Koneksi error: $e');
    }
    setState(() => isLoading = false);
  }

  Future<void> _deleteProduct(String productId) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Hapus Produk',
            style: TextStyle(color: textWhite)),
        content: const Text('Yakin ingin menghapus produk ini?',
            style: TextStyle(color: textGrey)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Batal', style: TextStyle(color: textGrey)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text('Hapus', style: TextStyle(color: accentRed)),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    try {
      final delUrl = await ApiConfig.baseUrl;
      final res = await http.post(
        Uri.parse('$delUrl/shop/deleteProduct'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'productId': productId,
          'sellerUsername': widget.username,
        }),
      );
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _fetchMyProducts();
      } else {
        _alert('Gagal', data['message'] ?? 'Gagal hapus produk.');
      }
    } catch (_) {
      _alert('Error', 'Gagal terhubung ke server.');
    }
  }

  Future<void> _fetchMyProducts() async {
    setState(() => isLoadingMyProducts = true);
    try {
      final myUrl = await ApiConfig.baseUrl;
      final res = await http.get(Uri.parse(
          '$myUrl/shop/myProducts?key=${widget.sessionKey}&username=${widget.username}'));
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        setState(() => myProducts = data['products'] ?? []);
      }
    } catch (_) {}
    setState(() => isLoadingMyProducts = false);
  }

  void _alert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgCard,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: accentGreen.withOpacity(0.3)),
        ),
        title: Text(title,
            style: const TextStyle(color: textWhite, fontWeight: FontWeight.bold)),
        content: Text(msg, style: TextStyle(color: textGrey)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('OK', style: TextStyle(color: accentGreen)),
          ),
        ],
      ),
    );
  }

  Widget _buildInput({
    required String label,
    required TextEditingController ctrl,
    required IconData icon,
    TextInputType type = TextInputType.text,
    String? hint,
    int maxLines = 1,
    bool optional = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: ctrl,
        keyboardType: type,
        maxLines: maxLines,
        style: const TextStyle(color: textWhite),
        decoration: InputDecoration(
          labelText: label + (optional ? ' (opsional)' : ''),
          hintText: hint,
          hintStyle: TextStyle(color: textGrey.withOpacity(0.5)),
          labelStyle: TextStyle(color: accentGreen.withOpacity(0.8)),
          prefixIcon: Icon(icon, color: accentGreen, size: 20),
          filled: true,
          fillColor: const Color(0xFF1A1A1A),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: borderCol),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: borderCol),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: accentGreen, width: 1.5),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF0A0A0A), Color(0xFF001A0A), Color(0xFF0A0A0A)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Header
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: bgCard,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: borderCol),
                        ),
                        child: const Icon(Icons.arrow_back_ios_new,
                            color: textWhite, size: 16),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Icon(Icons.add_business, color: accentGreen, size: 24),
                    const SizedBox(width: 10),
                    const Text(
                      'JUAL PRODUK',
                      style: TextStyle(
                          color: textWhite,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.5),
                    ),
                  ],
                ),
              ),

              // Tab switch
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                child: Row(
                  children: [
                    _tabBtn('Upload Produk', !_showMyProducts, () {
                      setState(() => _showMyProducts = false);
                    }),
                    const SizedBox(width: 10),
                    _tabBtn('Produk Saya', _showMyProducts, () {
                      setState(() => _showMyProducts = true);
                    }),
                  ],
                ),
              ),

              const SizedBox(height: 8),

              Expanded(
                child: _showMyProducts
                    ? _buildMyProductsTab()
                    : _buildUploadTab(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _tabBtn(String label, bool active, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: active ? accentGreen.withOpacity(0.15) : bgCard,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: active ? accentGreen.withOpacity(0.5) : borderCol,
            ),
          ),
          child: Center(
            child: Text(
              label,
              style: TextStyle(
                color: active ? accentGreen : textGrey,
                fontWeight: active ? FontWeight.bold : FontWeight.normal,
                fontSize: 13,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildUploadTab() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Foto produk
          GestureDetector(
            onTap: _pickImage,
            child: Container(
              height: 180,
              decoration: BoxDecoration(
                color: bgCard,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                    color: selectedImage != null
                        ? accentGreen.withOpacity(0.5)
                        : borderCol,
                    style: BorderStyle.solid),
              ),
              child: selectedImage != null
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(15),
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          Image.file(selectedImage!, fit: BoxFit.cover),
                          Positioned(
                            top: 8,
                            right: 8,
                            child: GestureDetector(
                              onTap: () =>
                                  setState(() => selectedImage = null),
                              child: Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.6),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(Icons.close,
                                    color: textWhite, size: 16),
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                  : Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.add_photo_alternate_outlined,
                            color: accentGreen.withOpacity(0.6), size: 48),
                        const SizedBox(height: 10),
                        Text('Tap untuk upload foto',
                            style: TextStyle(color: textGrey, fontSize: 14)),
                        const SizedBox(height: 4),
                        Text('(opsional)',
                            style: TextStyle(
                                color: textGrey.withOpacity(0.5), fontSize: 11)),
                      ],
                    ),
            ),
          ),
          const SizedBox(height: 20),

          // Form fields
          _buildInput(
            label: 'Nama Produk',
            ctrl: nameCtrl,
            icon: Icons.label_outline,
            hint: 'Contoh: Jasa Edit Video',
          ),
          _buildInput(
            label: 'Deskripsi',
            ctrl: descCtrl,
            icon: Icons.description_outlined,
            hint: 'Jelaskan produkmu...',
            maxLines: 3,
            optional: true,
          ),
          _buildInput(
            label: 'Harga',
            ctrl: priceCtrl,
            icon: Icons.attach_money,
            hint: 'Contoh: 50000',
            type: TextInputType.number,
            optional: true,
          ),

          // Divider kontak
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(
              children: [
                Expanded(child: Divider(color: borderCol)),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Text('Kontak Penjual',
                      style: TextStyle(color: textGrey, fontSize: 12)),
                ),
                Expanded(child: Divider(color: borderCol)),
              ],
            ),
          ),

          _buildInput(
            label: 'Username Telegram',
            ctrl: teleCtrl,
            icon: FontAwesomeIcons.telegram,
            hint: '@username atau tanpa @',
            optional: true,
          ),
          _buildInput(
            label: 'Nomor WhatsApp',
            ctrl: waCtrl,
            icon: FontAwesomeIcons.whatsapp,
            hint: '628xxxxxxxxxx',
            type: TextInputType.phone,
            optional: true,
          ),

          const SizedBox(height: 8),

          // Submit button
          Container(
            height: 54,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  accentGreen.withOpacity(0.8),
                  accentGreen,
                ],
              ),
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(
                  color: accentGreen.withOpacity(0.3),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ElevatedButton(
              onPressed: isLoading ? null : _submitProduct,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
              child: isLoading
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(
                          strokeWidth: 2.5, color: Colors.black))
                  : const Text(
                      'UPLOAD PRODUK',
                      style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          letterSpacing: 1),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMyProductsTab() {
    if (isLoadingMyProducts) {
      return Center(child: CircularProgressIndicator(color: accentGreen));
    }
    if (myProducts.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inventory_2_outlined, color: textGrey, size: 60),
            const SizedBox(height: 16),
            Text('Kamu belum punya produk',
                style: TextStyle(color: textGrey, fontSize: 15)),
          ],
        ),
      );
    }

    return RefreshIndicator(
      color: accentGreen,
      backgroundColor: bgCard,
      onRefresh: _fetchMyProducts,
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        itemCount: myProducts.length,
        itemBuilder: (_, i) {
          final p = myProducts[i];
          final _rawImgUrl = (p['imageUrl'] ?? '').toString();
          final imageUrl = _rawImgUrl.isNotEmpty && !_rawImgUrl.startsWith('http')
              ? '${AppUrls.mainServer}$_rawImgUrl'
              : _rawImgUrl;
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: bgCard,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: borderCol),
            ),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: imageUrl.isNotEmpty
                      ? Image.network(imageUrl,
                          width: 70,
                          height: 70,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) =>
                              _miniPlaceholder())
                      : _miniPlaceholder(),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(p['name'] ?? '',
                          style: const TextStyle(
                              color: textWhite, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      if ((p['price'] ?? '').toString().isNotEmpty)
                        Text('Rp ${p['price']}',
                            style:
                                TextStyle(color: accentGreen, fontSize: 13)),
                      Text(
                        (p['description'] ?? '').toString().isEmpty
                            ? '-'
                            : p['description'],
                        style: TextStyle(color: textGrey, fontSize: 12),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: () => _deleteProduct(p['id'].toString()),
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: accentRed.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: accentRed.withOpacity(0.3)),
                    ),
                    child: Icon(Icons.delete_outline,
                        color: accentRed, size: 18),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _miniPlaceholder() {
    return Container(
      width: 70,
      height: 70,
      color: const Color(0xFF1C1C1C),
      child: Icon(Icons.image_not_supported_outlined, color: textGrey, size: 24),
    );
  }
}
