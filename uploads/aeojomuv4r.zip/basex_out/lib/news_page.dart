import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class NewsPage extends StatefulWidget {
  const NewsPage({super.key});

  @override
  State<NewsPage> createState() => _NewsPageState();
}

class _NewsPageState extends State<NewsPage> {
  List<Map<String, String>> _newsList = [];

  final Color primaryBg = const Color(0xFF080C12);
  final Color cardBg = const Color(0xFF0D1520);
  final Color panelBg = const Color(0xFF0A1018);
  final Color cyanAccent = const Color(0xFF00E5FF);
  final Color textWhite = Colors.white;
  final Color textGrey = const Color(0xFF607D8B);
  final Color borderGlass = const Color(0xFF1A3A4A);

  @override
  void initState() {
    super.initState();
    _loadNewsData();
  }

  void _loadNewsData() {
    _newsList = [
      {
        "title": "Presiden RI Resmikan Ibu Kota Nusantara, Pindahan Pusat Pemerintahan Selesai",
        "description": "Upacara peresmian Ibu Kota Nusantara (IKN) berlangsung megah di Kalimantan Timur. Seluruh kementerian dan lembaga negara resmi pindah dari Jakarta.",
        "date": "17 Jun 2026 • 08:30 WIB",
        "image": "https://picsum.photos/id/10/400/200",
        "link": "https://www.kompas.com"
      },
      {
        "title": "Indonesia Lolos Piala Dunia 2026 untuk Pertama Kali!",
        "description": "Kemenangan dramatis Timnas Indonesia atas Arab Saudi 2-1 memastikan langkah Garuda ke putaran final Piala Dunia 2026.",
        "date": "15 Jun 2026 • 22:15 WIB",
        "image": "https://picsum.photos/id/27/400/200",
        "link": "https://www.cnnindonesia.com"
      },
      {
        "title": "Harga Emas Anjlok ke Level Terendah 3 Tahun",
        "description": "Harga emas dunia merosot tajam menyusul kebijakan suku bunga tinggi bank sentral AS. Harga emas Antam hari ini dibanderol Rp 950.000 per gram.",
        "date": "14 Jun 2026 • 10:00 WIB",
        "image": "https://picsum.photos/id/29/400/200",
        "link": "https://www.cnbcindonesia.com"
      },
      {
        "title": "BRI Luncurkan Fitur Baru: Transfer Antar Bank Tanpa Biaya Admin",
        "description": "Bank Rakyat Indonesia (BRI) resmi menghapus biaya admin transfer antar bank. Nasabah cukup menggunakan aplikasi BRImo untuk transfer ke semua bank tanpa potongan.",
        "date": "13 Jun 2026 • 09:30 WIB",
        "image": "https://picsum.photos/id/26/400/200",
        "link": "https://www.liputan6.com"
      },
      {
        "title": "El Nino Akhirnya Berakhir, BMKG Prediksi Musim Hujan Normal",
        "description": "Badan Meteorologi Klimatologi dan Geofisika (BMKG) mengumumkan fenomena El Nino yang berlangsung setahun penuh telah berakhir.",
        "date": "12 Jun 2026 • 14:45 WIB",
        "image": "https://picsum.photos/id/15/400/200",
        "link": "https://www.detik.com"
      },
      {
        "title": "WhatsApp Rilis Fitur AI Translator Real-Time 100 Bahasa",
        "description": "WhatsApp merilis pembaruan besar dengan fitur penerjemah AI real-time yang mendukung 100 bahasa termasuk bahasa daerah Indonesia.",
        "date": "11 Jun 2026 • 11:00 WIB",
        "image": "https://picsum.photos/id/0/400/200",
        "link": "https://www.tekno.com"
      },
      {
        "title": "Prabowo-Hartono Resmi Dilantik sebagai Presiden dan Wakil Presiden 2026-2031",
        "description": "Pasangan Prabowo Subianto dan Hartono resmi dilantik menjadi Presiden dan Wakil Presiden RI periode 2026-2031 dalam sidang paripurna MPR.",
        "date": "20 Okt 2026 • 10:00 WIB",
        "image": "https://picsum.photos/id/1/400/200",
        "link": "https://www.kompas.com"
      },
      {
        "title": "Free Fire X One Piece Kolaborasi Terbesar, Hadirkan 10 Karakter",
        "description": "Game Free Fire mengumumkan kolaborasi epik dengan anime One Piece. Pemain bisa menggunakan karakter Luffy, Zoro, Nami, hingga Sanji.",
        "date": "10 Jun 2026 • 19:00 WIB",
        "image": "https://picsum.photos/id/96/400/200",
        "link": "https://www.ggwp.com"
      },
      {
        "title": "Harga Tiket Pesawat Domestik Turun 20% Jelang Liburan Akhir Tahun",
        "description": "Kementerian Perhubungan mengumumkan penurunan tarif batas atas tiket pesawat domestik. Maskapai menerapkan harga promo hingga 20%.",
        "date": "09 Jun 2026 • 08:00 WIB",
        "image": "https://picsum.photos/id/1/400/200",
        "link": "https://www.cnnindonesia.com"
      },
      {
        "title": "Apple Rilis iPhone 18 Pro dengan Kamera 108MP dan Chip A20",
        "description": "Apple resmi meluncurkan iPhone 18 Pro dengan peningkatan kamera utama 108MP, chip A20 Bionic, dan baterai super tahan 2 hari.",
        "date": "08 Jun 2026 • 13:30 WIB",
        "image": "https://picsum.photos/id/0/400/200",
        "link": "https://www.tekno.com"
      },
      {
        "title": "Utang Negara Turun Drastis Berkat Pendapatan IKN",
        "description": "Menteri Keuangan melaporkan rasio utang terhadap PDB Indonesia turun ke level 28%, terendah dalam sejarah.",
        "date": "07 Jun 2026 • 15:00 WIB",
        "image": "https://picsum.photos/id/2/400/200",
        "link": "https://www.cnbcindonesia.com"
      },
      {
        "title": "Libur Sekolah Mulai 20 Juni, Simak Jadwal Lengkapnya",
        "description": "Kementerian Pendidikan mengumumkan jadwal libur akhir tahun ajaran 2025/2026 dimulai 20 Juni hingga 13 Juli 2026.",
        "date": "06 Jun 2026 • 09:00 WIB",
        "image": "https://picsum.photos/id/20/400/200",
        "link": "https://www.liputan6.com"
      },
      {
        "title": "Gaji PNS Naik 15% Mulai Juli 2026",
        "description": "Pemerintah resmi menaikkan gaji pokok Pegawai Negeri Sipil sebesar 15% efektif Juli 2026. Kenaikan ini juga berlaku untuk pensiunan.",
        "date": "05 Jun 2026 • 11:30 WIB",
        "image": "https://picsum.photos/id/4/400/200",
        "link": "https://www.kompas.com"
      },
      {
        "title": "Tes CPNS 2026 Dibuka, 1 Juta Formasi Tersedia",
        "description": "Badan Kepegawaian Negara (BKN) membuka pendaftaran CPNS 2026 dengan total formasi 1 juta. Pendaftaran dibuka mulai 1 Juli 2026.",
        "date": "04 Jun 2026 • 10:00 WIB",
        "image": "https://picsum.photos/id/4/400/200",
        "link": "https://www.cnnindonesia.com"
      },
      {
        "title": "Toyota Luncurkan Mobil Terbang di Gaikindo 2026",
        "description": "Toyota memperkenalkan mobil terbang perdana di ajang Gaikindo Jakarta Auto Week 2026. Kendaraan ini mampu terbang hingga ketinggian 500 meter.",
        "date": "03 Jun 2026 • 16:00 WIB",
        "image": "https://picsum.photos/id/11/400/200",
        "link": "https://www.oto.com"
      },
      {
        "title": "Starlink Resmi Beroperasi di Indonesia, Internet Cepat ke Seluruh Desa",
        "description": "Layanan internet satelit Starlink resmi beroperasi di Indonesia. Targetnya 10.000 desa terpencil akan terhubung internet cepat.",
        "date": "01 Jun 2026 • 14:00 WIB",
        "image": "https://picsum.photos/id/12/400/200",
        "link": "https://www.tekno.com"
      },
      {
        "title": "Indonesia Tuan Rumah Olimpiade 2036, Pengumuman Resmi dari IOC",
        "description": "International Olympic Committee (IOC) resmi menunjuk Indonesia sebagai tuan rumah Olimpiade 2036. Persiapan akan dimulai tahun ini.",
        "date": "31 Mei 2026 • 20:00 WIB",
        "image": "https://picsum.photos/id/21/400/200",
        "link": "https://www.cnnindonesia.com"
      },
      {
        "title": "Kereta Cepat Jakarta-Surabaya Mulai Beroperasi Desember 2026",
        "description": "Proyek kereta cepat Jakarta-Surabaya rampung 90%. Uji coba perdana dilakukan Oktober, operasi komersial Desember 2026.",
        "date": "28 Mei 2026 • 13:00 WIB",
        "image": "https://picsum.photos/id/7/400/200",
        "link": "https://www.cnbcindonesia.com"
      },
      {
        "title": "Vaksin Kanker Pertama di Dunia Ditemukan Ilmuwan Indonesia",
        "description": "Tim peneliti dari ITB berhasil menemukan vaksin kanker pertama di dunia. Uji klinis akan dilakukan akhir tahun ini.",
        "date": "26 Mei 2026 • 09:30 WIB",
        "image": "https://picsum.photos/id/9/400/200",
        "link": "https://www.kompas.com"
      },
      {
        "title": "Samsung Rilis Galaxy S30 dengan Layar Lipat 3 Sisi",
        "description": "Samsung memperkenalkan Galaxy S30 dengan teknologi layar lipat 3 sisi. Ponsel ini bisa dilipat menjadi ukuran sebesar kartu kredit.",
        "date": "24 Mei 2026 • 12:00 WIB",
        "image": "https://picsum.photos/id/16/400/200",
        "link": "https://www.gizmox.com"
      },
      {
        "title": "Indonesia Ekspor Mobil Listrik Perdana ke Eropa",
        "description": "Presiden melepas ekspor perdana 5.000 unit mobil listrik produksi dalam negeri tujuan Belanda dan Jerman.",
        "date": "23 Mei 2026 • 10:00 WIB",
        "image": "https://picsum.photos/id/17/400/200",
        "link": "https://www.cnnindonesia.com"
      },
      {
        "title": "Tanggul Raksasa Jakarta Rampung, Banjir Akhirnya Berhenti",
        "description": "Proyek tanggul raksasa Giant Sea Wall Jakarta resmi rampung. Banjir rob di ibu kota diprediksi tidak akan terjadi lagi.",
        "date": "22 Mei 2026 • 15:00 WIB",
        "image": "https://picsum.photos/id/18/400/200",
        "link": "https://www.kompas.com"
      },
      {
        "title": "Saham Crypto Meledak, Bitcoin Tembus USD 250.000",
        "description": "Harga Bitcoin menembus level USD 250.000 untuk pertama kalinya. Para analis memprediksi akan terus naik hingga akhir tahun.",
        "date": "21 Mei 2026 • 08:00 WIB",
        "image": "https://picsum.photos/id/19/400/200",
        "link": "https://www.cnbc.com"
      },
      {
        "title": "Shopee Gratis Ongkir Seumur Hidup untuk Pengguna Premium",
        "description": "Shopee meluncurkan program gratis ongkir seumur hidup bagi pengguna premium berlangganan Rp 50.000 per bulan.",
        "date": "20 Mei 2026 • 11:00 WIB",
        "image": "https://picsum.photos/id/22/400/200",
        "link": "https://www.liputan6.com"
      },
      {
        "title": "BTS Comeback dengan Album Baru Setelah 3 Tahun Vakum",
        "description": "Boyband asal Korea Selatan BTS resmi comeback dengan album baru bertajuk 'Forever'. Lagu utamanya langsung trending di 100 negara.",
        "date": "17 Mei 2026 • 19:00 WIB",
        "image": "https://picsum.photos/id/25/400/200",
        "link": "https://www.kpop.com"
      },
      {
        "title": "Piala Dunia 2026 Dimulai, Indonesia vs Brasil di Laga Pembuka",
        "description": "Piala Dunia 2026 resmi dimulai. Laga pembuka mempertemukan timnas Indonesia vs Brasil di stadion utama Los Angeles.",
        "date": "14 Jun 2026 • 01:00 WIB",
        "image": "https://picsum.photos/id/31/400/200",
        "link": "https://www.fifa.com"
      },
      {
        "title": "Indonesia Vs Argentina: Hasilnya Mengejutkan!",
        "description": "Timnas Indonesia sukses menahan imbang Argentina 2-2 di babak grup Piala Dunia 2026. Gol dicetak Marselino dan Ragnar Oratmangoen.",
        "date": "18 Jun 2026 • 03:00 WIB",
        "image": "https://picsum.photos/id/32/400/200",
        "link": "https://www.skor.id"
      },
      {
        "title": "Naruto Live Action Tayang 2026, Ini Daftar Pemainnya",
        "description": "Film live action Naruto resmi tayang di bioskop. Penggemar ramai-ramai membanjiri bioskop sejak hari pertama.",
        "date": "14 Mei 2026 • 18:00 WIB",
        "image": "https://picsum.photos/id/34/400/200",
        "link": "https://www.animenews.com"
      },
      {
        "title": "Squid Game Season 3 Rilis, 10 Pemain Baru Hadir",
        "description": "Netflix merilis Squid Game season 3. 10 pemain baru dengan latar belakang berbeda ikut serta dalam permainan mematikan.",
        "date": "13 Mei 2026 • 20:00 WIB",
        "image": "https://picsum.photos/id/35/400/200",
        "link": "https://www.netflix.com"
      },
      {
        "title": "One Piece Ending: Luffy Jadi Raja Bajak Laut",
        "description": "Manga One Piece resmi berakhir setelah puluhan tahun. Luffy berhasil menjadi Raja Bajak Laut. Eiichiro Oda mengumumkan pensiun.",
        "date": "11 Mei 2026 • 12:00 WIB",
        "image": "https://picsum.photos/id/37/400/200",
        "link": "https://www.shonenjump.com"
      },
    ];
    setState(() {});
  }

  Future<void> _launchUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Tidak bisa membuka link', style: TextStyle(color: cyanAccent)),
          backgroundColor: cardBg,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryBg,
      appBar: AppBar(
        backgroundColor: cardBg,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: cyanAccent, size: 22),
          onPressed: () => Navigator.pop(context),
        ),
        title: ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [Color(0xFF00E5FF), Color(0xFF00BCD4)],
          ).createShader(bounds),
          child: Text(
            "BERITA 2026",
            style: TextStyle(
              color: textWhite,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
              letterSpacing: 2,
            ),
          ),
        ),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _newsList.length,
        itemBuilder: (context, index) {
          final news = _newsList[index];
          return GestureDetector(
            onTap: () => _launchUrl(news['link']!),
            child: Container(
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(
                color: cardBg,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: borderGlass),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(16),
                      topRight: Radius.circular(16),
                    ),
                    child: Image.network(
                      news['image']!,
                      height: 180,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          height: 180,
                          width: double.infinity,
                          color: panelBg,
                          child: Center(
                            child: Icon(Icons.image_not_supported, color: textGrey, size: 40),
                          ),
                        );
                      },
                      loadingBuilder: (context, child, loadingProgress) {
                        if (loadingProgress == null) return child;
                        return Container(
                          height: 180,
                          width: double.infinity,
                          color: panelBg,
                          child: Center(
                            child: CircularProgressIndicator(color: cyanAccent),
                          ),
                        );
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.access_time, color: cyanAccent, size: 14),
                            const SizedBox(width: 6),
                            Text(
                              news['date']!,
                              style: TextStyle(
                                color: cyanAccent,
                                fontSize: 11,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Text(
                          news['title']!,
                          style: TextStyle(
                            color: textWhite,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                            height: 1.3,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          news['description']!,
                          style: TextStyle(
                            color: textGrey,
                            fontSize: 12,
                            fontFamily: 'ShareTechMono',
                            height: 1.4,
                          ),
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(
                              "Baca selengkapnya",
                              style: TextStyle(
                                color: cyanAccent,
                                fontSize: 11,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                            const SizedBox(width: 4),
                            Icon(Icons.arrow_forward, color: cyanAccent, size: 12),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}