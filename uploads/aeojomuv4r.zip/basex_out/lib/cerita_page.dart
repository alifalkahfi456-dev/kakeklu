import 'package:flutter/material.dart';

class CeritaPage extends StatelessWidget {
  const CeritaPage({super.key});

  final Color primaryBg = const Color(0xFF080C12);
  final Color cardBg = const Color(0xFF0D1520);
  final Color panelBg = const Color(0xFF0A1018);
  final Color cyanAccent = const Color(0xFF00E5FF);
  final Color cyanDim = const Color(0xFF0097A7);
  final Color textWhite = Colors.white;
  final Color textGrey = const Color(0xFF607D8B);
  final Color borderGlass = const Color(0xFF1A3A4A);
  final Color green = const Color(0xFF4CAF50);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryBg,
      appBar: AppBar(
        backgroundColor: cardBg,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: cyanAccent, size: 22),
          onPressed: () => Navigator.pop(context),
        ),
        title: ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [Color(0xFF00E5FF), Color(0xFF00BCD4)],
          ).createShader(bounds),
          child: Text(
            'PANDUAN SHOLAT',
            style: TextStyle(
              color: textWhite,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
              letterSpacing: 2,
            ),
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildSholatCard(
            nama: "Sholat Subuh",
            waktu: "Waktu: Terbit fajar hingga terbit matahari",
            rakaat: "2 Rakaat",
            niat: "أُصَلِّي فَرْضَ الصُّبْحِ رَكْعَتَيْنِ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى",
            niatLatin: "Ushallii fardhash shubhi rak'ataini mustaqbilal qiblati adaa'an lillaahi ta'aalaa",
            bacaan: "Surat Al-Fatihah + Surat Pendek (contoh: Al-Kautsar)",
            doa: "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
            tataCara: "1. Niat\n2. Takbiratul Ihram\n3. Baca doa iftitah\n4. Baca Al-Fatihah\n5. Baca surat pendek\n6. Ruku'\n7. I'tidal\n8. Sujud\n9. Duduk antara dua sujud\n10. Sujud kedua\n11. Berdiri untuk rakaat kedua (ulangi langkah 4-10)\n12. Tasyahud akhir\n13. Salam",
          ),
          _buildSholatCard(
            nama: "Sholat Dzuhur",
            waktu: "Waktu: Setelah matahari tergelincir hingga bayangan benda sama panjang",
            rakaat: "4 Rakaat",
            niat: "أُصَلِّي فَرْضَ الظُّهْرِ أَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى",
            niatLatin: "Ushallii fardhazh zhuhri arba'a raka'aatim mustaqbilal qiblati adaa'an lillaahi ta'aalaa",
            bacaan: "Surat Al-Fatihah + Surat Pendek",
            doa: "رَبَّنَا اغْفِرْ لِي وَلِوَالِدَيَّ وَلِلْمُؤْمِنِينَ يَوْمَ يَقُومُ الْحِسَابُ",
            tataCara: "1. Niat\n2. Takbiratul Ihram\n3. Baca doa iftitah\n4. Baca Al-Fatihah\n5. Baca surat pendek\n6. Ruku'\n7. I'tidal\n8. Sujud\n9. Duduk antara dua sujud\n10. Sujud kedua\n11. Berdiri untuk rakaat kedua (ulangi langkah 4-10)\n12. Tasyahud awal (setelah rakaat kedua)\n13. Berdiri untuk rakaat ketiga (cukup Al-Fatihah)\n14. Rakaat keempat (cukup Al-Fatihah)\n15. Tasyahud akhir\n16. Salam",
          ),
          _buildSholatCard(
            nama: "Sholat Ashar",
            waktu: "Waktu: Setelah bayangan benda sama panjang hingga terbenam matahari",
            rakaat: "4 Rakaat",
            niat: "أُصَلِّي فَرْضَ الْعَصْرِ أَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى",
            niatLatin: "Ushallii fardhal 'ashri arba'a raka'aatim mustaqbilal qiblati adaa'an lillaahi ta'aalaa",
            bacaan: "Surat Al-Fatihah + Surat Pendek",
            doa: "رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِنْ لَدُنْكَ رَحْمَةً",
            tataCara: "Sama seperti Sholat Dzuhur (4 rakaat)",
          ),
          _buildSholatCard(
            nama: "Sholat Maghrib",
            waktu: "Waktu: Setelah matahari terbenam hingga hilang cahaya merah",
            rakaat: "3 Rakaat",
            niat: "أُصَلِّي فَرْضَ الْمَغْرِبِ ثَلَاثَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى",
            niatLatin: "Ushallii fardhal maghribi tsalaatsa raka'aatim mustaqbilal qiblati adaa'an lillaahi ta'aalaa",
            bacaan: "Surat Al-Fatihah + Surat Pendek",
            doa: "اللَّهُمَّ أَجِرْنَا مِنَ النَّارِ",
            tataCara: "1-2 rakaat: Al-Fatihah + surat pendek\nRakaat ketiga: Al-Fatihah saja\nKemudian tasyahud akhir dan salam",
          ),
          _buildSholatCard(
            nama: "Sholat Isya",
            waktu: "Waktu: Setelah hilang cahaya merah hingga terbit fajar",
            rakaat: "4 Rakaat",
            niat: "أُصَلِّي فَرْضَ الْعِشَاءِ أَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى",
            niatLatin: "Ushallii fardhal 'isyaa-i arba'a raka'aatim mustaqbilal qiblati adaa'an lillaahi ta'aalaa",
            bacaan: "Surat Al-Fatihah + Surat Pendek",
            doa: "اللَّهُمَّ إِنِّي أَسْأَلُكَ الْجَنَّةَ وَأَعُوذُ بِكَ مِنَ النَّارِ",
            tataCara: "Sama seperti Sholat Dzuhur (4 rakaat)",
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: cardBg,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: green.withOpacity(0.5)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "CATATAN PENTING:",
                  style: TextStyle(
                    color: green,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  "- Membaca niat dalam hati cukup, tidak harus dilafalkan\n"
                  "- Disunnahkan membaca doa qunut pada sholat Subuh\n"
                  "- Membaca surat pendek setelah Al-Fatihah pada 2 rakaat pertama\n"
                  "- Tasyahud awal hanya untuk sholat yang memiliki 3 atau 4 rakaat\n"
                  "- Membaca sholawat pada tasyahud akhir\n"
                  "- Mengucapkan salam dengan menoleh ke kanan dan kiri",
                  style: TextStyle(
                    color: textGrey,
                    fontSize: 12,
                    fontFamily: 'ShareTechMono',
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 30),
        ],
      ),
    );
  }

  Widget _buildSholatCard({
    required String nama,
    required String waktu,
    required String rakaat,
    required String niat,
    required String niatLatin,
    required String bacaan,
    required String doa,
    required String tataCara,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 18),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: borderGlass, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: cyanAccent.withOpacity(0.1),
            blurRadius: 16,
            spreadRadius: 2,
          ),
        ],
      ),
      child: ExpansionTile(
        iconColor: cyanAccent,
        collapsedIconColor: cyanAccent.withOpacity(0.7),
        collapsedTextColor: textGrey,
        textColor: cyanAccent,
        backgroundColor: cardBg,
        collapsedBackgroundColor: cardBg,
        title: Text(
          nama,
          style: TextStyle(
            fontFamily: 'Orbitron',
            color: cyanAccent,
            letterSpacing: 1.5,
            fontWeight: FontWeight.w500,
            fontSize: 15,
          ),
        ),
        subtitle: Text(
          rakaat,
          style: TextStyle(
            fontSize: 11,
            color: textGrey,
            fontFamily: 'ShareTechMono',
          ),
        ),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: cyanAccent.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: cyanAccent.withOpacity(0.3)),
                  ),
                  child: Text(
                    'INFORMASI',
                    style: TextStyle(
                      fontFamily: 'Orbitron',
                      color: cyanAccent,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                _infoRow('Waktu', waktu),
                const SizedBox(height: 8),
                _infoRow('Rakaat', rakaat),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: panelBg,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: borderGlass, width: 1),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'NIAT',
                        style: TextStyle(
                          fontSize: 11,
                          color: cyanAccent,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        niat,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16,
                          color: textWhite,
                          fontFamily: 'ShareTechMono',
                          height: 1.5,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        niatLatin,
                        style: TextStyle(
                          fontSize: 12,
                          color: textGrey,
                          fontFamily: 'ShareTechMono',
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: panelBg,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: borderGlass, width: 1),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'BACAAN',
                        style: TextStyle(
                          fontSize: 11,
                          color: cyanAccent,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        bacaan,
                        style: TextStyle(
                          fontSize: 13,
                          color: textGrey,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: panelBg,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: borderGlass, width: 1),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'DOA SETELAH SHOLAT',
                        style: TextStyle(
                          fontSize: 11,
                          color: cyanAccent,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        doa,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16,
                          color: textWhite,
                          fontFamily: 'ShareTechMono',
                          height: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: panelBg,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: borderGlass, width: 1),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'TATA CARA',
                        style: TextStyle(
                          fontSize: 11,
                          color: cyanAccent,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        tataCara,
                        style: TextStyle(
                          fontSize: 12,
                          color: textGrey,
                          fontFamily: 'ShareTechMono',
                          height: 1.6,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Divider(color: borderGlass, thickness: 1),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: cyanAccent,
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            value,
            style: TextStyle(
              color: textGrey,
              fontSize: 12,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ),
      ],
    );
  }
}