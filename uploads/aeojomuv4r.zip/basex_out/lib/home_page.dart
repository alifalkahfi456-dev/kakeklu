import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import '../services/api_config_service.dart';

class HomePage extends StatefulWidget {
  final bool isGroup;
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;

  const HomePage({
    super.key,
    required this.isGroup,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  static const Color bgDeep = Color(0xFF060606);
  static const Color bgCard = Color(0xFF0F0F0F);
  static const Color bgCardMid = Color(0xFF161616);
  static const Color redDark = Color(0xFF3D0000);
  static const Color redMid = Color(0xFF8B0000);
  static const Color redAccent = Color(0xFFE53935);
  static const Color redBright = Color(0xFFFF1744);
  static const Color redGlow = Color(0xFFFF5252);
  static const Color goldAccent = Color(0xFFFFD700);
  static const Color textSub = Color(0xFF777777);
  static const Color textDim = Color(0xFF444444);

  late VideoPlayerController _videoController;
  final targetController = TextEditingController();

  late AnimationController _fadeCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _slideCtrl;
  late AnimationController _progressCtrl;

  late Animation<double> _fadeAnim;
  late Animation<double> _pulseAnim;
  late Animation<Offset> _slideAnim;
  late Animation<double> _progressAnim;

  int _selectedBugIndex = 0;
  bool _isSending = false;
  bool _isVideoInitialized = false;
  String? _responseMessage;
  bool _isSuccess = false;

  int _currentStep = 0;
  double _progress = 0.0;
  final List<String> _progressSteps = [
    "Initializing...",
    "Connecting...",
    "Validating session...",
    "Preparing payload...",
    "Sending bug...",
    "Success!",
  ];

  final List<Map<String, dynamic>> _countries = [
    {"name": "Indonesia", "code": "+62", "flag": "🇮🇩", "prefix": "62"},
    {"name": "Afghanistan", "code": "+93", "flag": "🇦🇫", "prefix": "93"},
    {"name": "Albania", "code": "+355", "flag": "🇦🇱", "prefix": "355"},
    {"name": "Algeria", "code": "+213", "flag": "🇩🇿", "prefix": "213"},
    {"name": "Andorra", "code": "+376", "flag": "🇦🇩", "prefix": "376"},
    {"name": "Angola", "code": "+244", "flag": "🇦🇴", "prefix": "244"},
    {"name": "Antigua and Barbuda", "code": "+1-268", "flag": "🇦🇬", "prefix": "1268"},
    {"name": "Argentina", "code": "+54", "flag": "🇦🇷", "prefix": "54"},
    {"name": "Armenia", "code": "+374", "flag": "🇦🇲", "prefix": "374"},
    {"name": "Australia", "code": "+61", "flag": "🇦🇺", "prefix": "61"},
    {"name": "Austria", "code": "+43", "flag": "🇦🇹", "prefix": "43"},
    {"name": "Azerbaijan", "code": "+994", "flag": "🇦🇿", "prefix": "994"},
    {"name": "Bahamas", "code": "+1-242", "flag": "🇧🇸", "prefix": "1242"},
    {"name": "Bahrain", "code": "+973", "flag": "🇧🇭", "prefix": "973"},
    {"name": "Bangladesh", "code": "+880", "flag": "🇧🇩", "prefix": "880"},
    {"name": "Barbados", "code": "+1-246", "flag": "🇧🇧", "prefix": "1246"},
    {"name": "Belarus", "code": "+375", "flag": "🇧🇾", "prefix": "375"},
    {"name": "Belgium", "code": "+32", "flag": "🇧🇪", "prefix": "32"},
    {"name": "Belize", "code": "+501", "flag": "🇧🇿", "prefix": "501"},
    {"name": "Benin", "code": "+229", "flag": "🇧🇯", "prefix": "229"},
    {"name": "Bhutan", "code": "+975", "flag": "🇧🇹", "prefix": "975"},
    {"name": "Bolivia", "code": "+591", "flag": "🇧🇴", "prefix": "591"},
    {"name": "Bosnia and Herzegovina", "code": "+387", "flag": "🇧🇦", "prefix": "387"},
    {"name": "Botswana", "code": "+267", "flag": "🇧🇼", "prefix": "267"},
    {"name": "Brazil", "code": "+55", "flag": "🇧🇷", "prefix": "55"},
    {"name": "Brunei", "code": "+673", "flag": "🇧🇳", "prefix": "673"},
    {"name": "Bulgaria", "code": "+359", "flag": "🇧🇬", "prefix": "359"},
    {"name": "Burkina Faso", "code": "+226", "flag": "🇧🇫", "prefix": "226"},
    {"name": "Burundi", "code": "+257", "flag": "🇧🇮", "prefix": "257"},
    {"name": "Cambodia", "code": "+855", "flag": "🇰🇭", "prefix": "855"},
    {"name": "Cameroon", "code": "+237", "flag": "🇨🇲", "prefix": "237"},
    {"name": "Canada", "code": "+1", "flag": "🇨🇦", "prefix": "1"},
    {"name": "Cape Verde", "code": "+238", "flag": "🇨🇻", "prefix": "238"},
    {"name": "Central African Republic", "code": "+236", "flag": "🇨🇫", "prefix": "236"},
    {"name": "Chad", "code": "+235", "flag": "🇹🇩", "prefix": "235"},
    {"name": "Chile", "code": "+56", "flag": "🇨🇱", "prefix": "56"},
    {"name": "China", "code": "+86", "flag": "🇨🇳", "prefix": "86"},
    {"name": "Colombia", "code": "+57", "flag": "🇨🇴", "prefix": "57"},
    {"name": "Comoros", "code": "+269", "flag": "🇰🇲", "prefix": "269"},
    {"name": "Congo", "code": "+242", "flag": "🇨🇬", "prefix": "242"},
    {"name": "Costa Rica", "code": "+506", "flag": "🇨🇷", "prefix": "506"},
    {"name": "Croatia", "code": "+385", "flag": "🇭🇷", "prefix": "385"},
    {"name": "Cuba", "code": "+53", "flag": "🇨🇺", "prefix": "53"},
    {"name": "Cyprus", "code": "+357", "flag": "🇨🇾", "prefix": "357"},
    {"name": "Czech Republic", "code": "+420", "flag": "🇨🇿", "prefix": "420"},
    {"name": "Denmark", "code": "+45", "flag": "🇩🇰", "prefix": "45"},
    {"name": "Djibouti", "code": "+253", "flag": "🇩🇯", "prefix": "253"},
    {"name": "Dominica", "code": "+1-767", "flag": "🇩🇲", "prefix": "1767"},
    {"name": "Dominican Republic", "code": "+1-809", "flag": "🇩🇴", "prefix": "1809"},
    {"name": "Ecuador", "code": "+593", "flag": "🇪🇨", "prefix": "593"},
    {"name": "Egypt", "code": "+20", "flag": "🇪🇬", "prefix": "20"},
    {"name": "El Salvador", "code": "+503", "flag": "🇸🇻", "prefix": "503"},
    {"name": "Equatorial Guinea", "code": "+240", "flag": "🇬🇶", "prefix": "240"},
    {"name": "Eritrea", "code": "+291", "flag": "🇪🇷", "prefix": "291"},
    {"name": "Estonia", "code": "+372", "flag": "🇪🇪", "prefix": "372"},
    {"name": "Eswatini", "code": "+268", "flag": "🇸🇿", "prefix": "268"},
    {"name": "Ethiopia", "code": "+251", "flag": "🇪🇹", "prefix": "251"},
    {"name": "Fiji", "code": "+679", "flag": "🇫🇯", "prefix": "679"},
    {"name": "Finland", "code": "+358", "flag": "🇫🇮", "prefix": "358"},
    {"name": "France", "code": "+33", "flag": "🇫🇷", "prefix": "33"},
    {"name": "Gabon", "code": "+241", "flag": "🇬🇦", "prefix": "241"},
    {"name": "Gambia", "code": "+220", "flag": "🇬🇲", "prefix": "220"},
    {"name": "Georgia", "code": "+995", "flag": "🇬🇪", "prefix": "995"},
    {"name": "Germany", "code": "+49", "flag": "🇩🇪", "prefix": "49"},
    {"name": "Ghana", "code": "+233", "flag": "🇬🇭", "prefix": "233"},
    {"name": "Greece", "code": "+30", "flag": "🇬🇷", "prefix": "30"},
    {"name": "Grenada", "code": "+1-473", "flag": "🇬🇩", "prefix": "1473"},
    {"name": "Guatemala", "code": "+502", "flag": "🇬🇹", "prefix": "502"},
    {"name": "Guinea", "code": "+224", "flag": "🇬🇳", "prefix": "224"},
    {"name": "Guinea-Bissau", "code": "+245", "flag": "🇬🇼", "prefix": "245"},
    {"name": "Guyana", "code": "+592", "flag": "🇬🇾", "prefix": "592"},
    {"name": "Haiti", "code": "+509", "flag": "🇭🇹", "prefix": "509"},
    {"name": "Honduras", "code": "+504", "flag": "🇭🇳", "prefix": "504"},
    {"name": "Hungary", "code": "+36", "flag": "🇭🇺", "prefix": "36"},
    {"name": "Iceland", "code": "+354", "flag": "🇮🇸", "prefix": "354"},
    {"name": "India", "code": "+91", "flag": "🇮🇳", "prefix": "91"},
    {"name": "Iran", "code": "+98", "flag": "🇮🇷", "prefix": "98"},
    {"name": "Iraq", "code": "+964", "flag": "🇮🇶", "prefix": "964"},
    {"name": "Ireland", "code": "+353", "flag": "🇮🇪", "prefix": "353"},
    {"name": "Israel", "code": "+972", "flag": "🇮🇱", "prefix": "972"},
    {"name": "Italy", "code": "+39", "flag": "🇮🇹", "prefix": "39"},
    {"name": "Jamaica", "code": "+1-876", "flag": "🇯🇲", "prefix": "1876"},
    {"name": "Japan", "code": "+81", "flag": "🇯🇵", "prefix": "81"},
    {"name": "Jordan", "code": "+962", "flag": "🇯🇴", "prefix": "962"},
    {"name": "Kazakhstan", "code": "+7", "flag": "🇰🇿", "prefix": "7"},
    {"name": "Kenya", "code": "+254", "flag": "🇰🇪", "prefix": "254"},
    {"name": "Kiribati", "code": "+686", "flag": "🇰🇮", "prefix": "686"},
    {"name": "Kuwait", "code": "+965", "flag": "🇰🇼", "prefix": "965"},
    {"name": "Kyrgyzstan", "code": "+996", "flag": "🇰🇬", "prefix": "996"},
    {"name": "Laos", "code": "+856", "flag": "🇱🇦", "prefix": "856"},
    {"name": "Latvia", "code": "+371", "flag": "🇱🇻", "prefix": "371"},
    {"name": "Lebanon", "code": "+961", "flag": "🇱🇧", "prefix": "961"},
    {"name": "Lesotho", "code": "+266", "flag": "🇱🇸", "prefix": "266"},
    {"name": "Liberia", "code": "+231", "flag": "🇱🇷", "prefix": "231"},
    {"name": "Libya", "code": "+218", "flag": "🇱🇾", "prefix": "218"},
    {"name": "Liechtenstein", "code": "+423", "flag": "🇱🇮", "prefix": "423"},
    {"name": "Lithuania", "code": "+370", "flag": "🇱🇹", "prefix": "370"},
    {"name": "Luxembourg", "code": "+352", "flag": "🇱🇺", "prefix": "352"},
    {"name": "Madagascar", "code": "+261", "flag": "🇲🇬", "prefix": "261"},
    {"name": "Malawi", "code": "+265", "flag": "🇲🇼", "prefix": "265"},
    {"name": "Malaysia", "code": "+60", "flag": "🇲🇾", "prefix": "60"},
    {"name": "Maldives", "code": "+960", "flag": "🇲🇻", "prefix": "960"},
    {"name": "Mali", "code": "+223", "flag": "🇲🇱", "prefix": "223"},
    {"name": "Malta", "code": "+356", "flag": "🇲🇹", "prefix": "356"},
    {"name": "Marshall Islands", "code": "+692", "flag": "🇲🇭", "prefix": "692"},
    {"name": "Mauritania", "code": "+222", "flag": "🇲🇷", "prefix": "222"},
    {"name": "Mauritius", "code": "+230", "flag": "🇲🇺", "prefix": "230"},
    {"name": "Mexico", "code": "+52", "flag": "🇲🇽", "prefix": "52"},
    {"name": "Micronesia", "code": "+691", "flag": "🇫🇲", "prefix": "691"},
    {"name": "Moldova", "code": "+373", "flag": "🇲🇩", "prefix": "373"},
    {"name": "Monaco", "code": "+377", "flag": "🇲🇨", "prefix": "377"},
    {"name": "Mongolia", "code": "+976", "flag": "🇲🇳", "prefix": "976"},
    {"name": "Montenegro", "code": "+382", "flag": "🇲🇪", "prefix": "382"},
    {"name": "Morocco", "code": "+212", "flag": "🇲🇦", "prefix": "212"},
    {"name": "Mozambique", "code": "+258", "flag": "🇲🇿", "prefix": "258"},
    {"name": "Myanmar", "code": "+95", "flag": "🇲🇲", "prefix": "95"},
    {"name": "Namibia", "code": "+264", "flag": "🇳🇦", "prefix": "264"},
    {"name": "Nauru", "code": "+674", "flag": "🇳🇷", "prefix": "674"},
    {"name": "Nepal", "code": "+977", "flag": "🇳🇵", "prefix": "977"},
    {"name": "Netherlands", "code": "+31", "flag": "🇳🇱", "prefix": "31"},
    {"name": "New Zealand", "code": "+64", "flag": "🇳🇿", "prefix": "64"},
    {"name": "Nicaragua", "code": "+505", "flag": "🇳🇮", "prefix": "505"},
    {"name": "Niger", "code": "+227", "flag": "🇳🇪", "prefix": "227"},
    {"name": "Nigeria", "code": "+234", "flag": "🇳🇬", "prefix": "234"},
    {"name": "North Korea", "code": "+850", "flag": "🇰🇵", "prefix": "850"},
    {"name": "North Macedonia", "code": "+389", "flag": "🇲🇰", "prefix": "389"},
    {"name": "Norway", "code": "+47", "flag": "🇳🇴", "prefix": "47"},
    {"name": "Oman", "code": "+968", "flag": "🇴🇲", "prefix": "968"},
    {"name": "Pakistan", "code": "+92", "flag": "🇵🇰", "prefix": "92"},
    {"name": "Palau", "code": "+680", "flag": "🇵🇼", "prefix": "680"},
    {"name": "Palestine", "code": "+970", "flag": "🇵🇸", "prefix": "970"},
    {"name": "Panama", "code": "+507", "flag": "🇵🇦", "prefix": "507"},
    {"name": "Papua New Guinea", "code": "+675", "flag": "🇵🇬", "prefix": "675"},
    {"name": "Paraguay", "code": "+595", "flag": "🇵🇾", "prefix": "595"},
    {"name": "Peru", "code": "+51", "flag": "🇵🇪", "prefix": "51"},
    {"name": "Philippines", "code": "+63", "flag": "🇵🇭", "prefix": "63"},
    {"name": "Poland", "code": "+48", "flag": "🇵🇱", "prefix": "48"},
    {"name": "Portugal", "code": "+351", "flag": "🇵🇹", "prefix": "351"},
    {"name": "Qatar", "code": "+974", "flag": "🇶🇦", "prefix": "974"},
    {"name": "Romania", "code": "+40", "flag": "🇷🇴", "prefix": "40"},
    {"name": "Russia", "code": "+7", "flag": "🇷🇺", "prefix": "7"},
    {"name": "Rwanda", "code": "+250", "flag": "🇷🇼", "prefix": "250"},
    {"name": "Saint Kitts and Nevis", "code": "+1-869", "flag": "🇰🇳", "prefix": "1869"},
    {"name": "Saint Lucia", "code": "+1-758", "flag": "🇱🇨", "prefix": "1758"},
    {"name": "Saint Vincent and the Grenadines", "code": "+1-784", "flag": "🇻🇨", "prefix": "1784"},
    {"name": "Samoa", "code": "+685", "flag": "🇼🇸", "prefix": "685"},
    {"name": "San Marino", "code": "+378", "flag": "🇸🇲", "prefix": "378"},
    {"name": "Sao Tome and Principe", "code": "+239", "flag": "🇸🇹", "prefix": "239"},
    {"name": "Saudi Arabia", "code": "+966", "flag": "🇸🇦", "prefix": "966"},
    {"name": "Senegal", "code": "+221", "flag": "🇸🇳", "prefix": "221"},
    {"name": "Serbia", "code": "+381", "flag": "🇷🇸", "prefix": "381"},
    {"name": "Seychelles", "code": "+248", "flag": "🇸🇨", "prefix": "248"},
    {"name": "Sierra Leone", "code": "+232", "flag": "🇸🇱", "prefix": "232"},
    {"name": "Singapore", "code": "+65", "flag": "🇸🇬", "prefix": "65"},
    {"name": "Slovakia", "code": "+421", "flag": "🇸🇰", "prefix": "421"},
    {"name": "Slovenia", "code": "+386", "flag": "🇸🇮", "prefix": "386"},
    {"name": "Solomon Islands", "code": "+677", "flag": "🇸🇧", "prefix": "677"},
    {"name": "Somalia", "code": "+252", "flag": "🇸🇴", "prefix": "252"},
    {"name": "South Africa", "code": "+27", "flag": "🇿🇦", "prefix": "27"},
    {"name": "South Korea", "code": "+82", "flag": "🇰🇷", "prefix": "82"},
    {"name": "South Sudan", "code": "+211", "flag": "🇸🇸", "prefix": "211"},
    {"name": "Spain", "code": "+34", "flag": "🇪🇸", "prefix": "34"},
    {"name": "Sri Lanka", "code": "+94", "flag": "🇱🇰", "prefix": "94"},
    {"name": "Sudan", "code": "+249", "flag": "🇸🇩", "prefix": "249"},
    {"name": "Suriname", "code": "+597", "flag": "🇸🇷", "prefix": "597"},
    {"name": "Sweden", "code": "+46", "flag": "🇸🇪", "prefix": "46"},
    {"name": "Switzerland", "code": "+41", "flag": "🇨🇭", "prefix": "41"},
    {"name": "Syria", "code": "+963", "flag": "🇸🇾", "prefix": "963"},
    {"name": "Taiwan", "code": "+886", "flag": "🇹🇼", "prefix": "886"},
    {"name": "Tajikistan", "code": "+992", "flag": "🇹🇯", "prefix": "992"},
    {"name": "Tanzania", "code": "+255", "flag": "🇹🇿", "prefix": "255"},
    {"name": "Thailand", "code": "+66", "flag": "🇹🇭", "prefix": "66"},
    {"name": "Timor-Leste", "code": "+670", "flag": "🇹🇱", "prefix": "670"},
    {"name": "Togo", "code": "+228", "flag": "🇹🇬", "prefix": "228"},
    {"name": "Tonga", "code": "+676", "flag": "🇹🇴", "prefix": "676"},
    {"name": "Trinidad and Tobago", "code": "+1-868", "flag": "🇹🇹", "prefix": "1868"},
    {"name": "Tunisia", "code": "+216", "flag": "🇹🇳", "prefix": "216"},
    {"name": "Turkey", "code": "+90", "flag": "🇹🇷", "prefix": "90"},
    {"name": "Turkmenistan", "code": "+993", "flag": "🇹🇲", "prefix": "993"},
    {"name": "Tuvalu", "code": "+688", "flag": "🇹🇻", "prefix": "688"},
    {"name": "Uganda", "code": "+256", "flag": "🇺🇬", "prefix": "256"},
    {"name": "Ukraine", "code": "+380", "flag": "🇺🇦", "prefix": "380"},
    {"name": "United Arab Emirates", "code": "+971", "flag": "🇦🇪", "prefix": "971"},
    {"name": "United Kingdom", "code": "+44", "flag": "🇬🇧", "prefix": "44"},
    {"name": "United States", "code": "+1", "flag": "🇺🇸", "prefix": "1"},
    {"name": "Uruguay", "code": "+598", "flag": "🇺🇾", "prefix": "598"},
    {"name": "Uzbekistan", "code": "+998", "flag": "🇺🇿", "prefix": "998"},
    {"name": "Vanuatu", "code": "+678", "flag": "🇻🇺", "prefix": "678"},
    {"name": "Vatican City", "code": "+379", "flag": "🇻🇦", "prefix": "379"},
    {"name": "Venezuela", "code": "+58", "flag": "🇻🇪", "prefix": "58"},
    {"name": "Vietnam", "code": "+84", "flag": "🇻🇳", "prefix": "84"},
    {"name": "Yemen", "code": "+967", "flag": "🇾🇪", "prefix": "967"},
    {"name": "Zambia", "code": "+260", "flag": "🇿🇲", "prefix": "260"},
    {"name": "Zimbabwe", "code": "+263", "flag": "🇿🇼", "prefix": "263"},
  ];

  String _selectedCountryCode = "+62";
  String _selectedPrefix = "62";
  String _selectedFlag = "🇮🇩";

  @override
  void initState() {
    super.initState();
    _videoController = VideoPlayerController.asset("assets/videos/splash.mp4")
      ..initialize().then((_) {
        setState(() => _isVideoInitialized = true);
        _videoController.setLooping(true);
        _videoController.setVolume(1.0);
        _videoController.play();
      });

    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 700))..forward();
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);

    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.4, end: 1.0).animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _slideCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))..forward();
    _slideAnim = Tween<Offset>(begin: const Offset(0, 0.25), end: Offset.zero).animate(CurvedAnimation(parent: _slideCtrl, curve: Curves.easeOutCubic));

    _progressCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _progressAnim = Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _progressCtrl, curve: Curves.easeInOut));

    if (widget.listBug.isNotEmpty) _selectedBugIndex = 0;
  }

  @override
  void dispose() {
    _videoController.dispose();
    _fadeCtrl.dispose();
    _pulseCtrl.dispose();
    _slideCtrl.dispose();
    _progressCtrl.dispose();
    targetController.dispose();
    super.dispose();
  }

  String _normalizePhone(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d]'), '');
    return _selectedPrefix + cleaned;
  }

  void _showCountryDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: bgCard,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Container(
          height: MediaQuery.of(context).size.height * 0.65,
          decoration: BoxDecoration(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
            border: Border(top: BorderSide(color: redAccent.withOpacity(0.3))),
          ),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  border: Border(bottom: BorderSide(color: redAccent.withOpacity(0.2))),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 3, height: 20,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4),
                        gradient: const LinearGradient(colors: [redBright, redMid])),
                    ),
                    const SizedBox(width: 12),
                    const Text("PILIH NEGARA",
                      style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                    const Spacer(),
                    IconButton(
                      icon: const Icon(Icons.close_rounded, color: textSub),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(8),
                  itemCount: _countries.length,
                  itemBuilder: (context, index) {
                    final country = _countries[index];
                    final isSelected = _selectedCountryCode == country['code'];
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          _selectedCountryCode = country['code'];
                          _selectedPrefix = country['prefix'];
                          _selectedFlag = country['flag'];
                        });
                        Navigator.pop(context);
                      },
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          color: isSelected ? redAccent.withOpacity(0.15) : Colors.transparent,
                          border: Border.all(color: isSelected ? redAccent.withOpacity(0.5) : Colors.white.withOpacity(0.05)),
                        ),
                        child: Row(
                          children: [
                            Text(country['flag'], style: const TextStyle(fontSize: 28)),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(country['name'], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 14)),
                                  const SizedBox(height: 2),
                                  Text(country['code'], style: TextStyle(color: textSub, fontSize: 11)),
                                ],
                              ),
                            ),
                            if (isSelected) Icon(Icons.check_circle_rounded, color: redBright, size: 22),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _updateProgress(int step) async {
    setState(() {
      _currentStep = step;
      _progress = (step + 1) / _progressSteps.length;
    });
    _progressCtrl.reset();
    _progressCtrl.forward();
    await Future.delayed(const Duration(milliseconds: 550));
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    if (rawInput.isEmpty) {
      setState(() {
        _responseMessage = "TARGET NUMBER REQUIRED";
        _isSuccess = false;
      });
      return;
    }
    final target = _normalizePhone(rawInput);
    if (widget.listBug.isEmpty) {
      setState(() {
        _responseMessage = "NO BUG AVAILABLE";
        _isSuccess = false;
      });
      return;
    }

    final bugId = widget.listBug[_selectedBugIndex]['bug_id'];

    setState(() {
      _isSending = true;
      _responseMessage = null;
      _currentStep = 0;
      _progress = 0.0;
    });

    try {
      await _updateProgress(0);
      await _updateProgress(1);
      await _updateProgress(2);
      await _updateProgress(3);
      final url = "${await ApiConfig.baseUrl}/sendBug?key=${widget.sessionKey}&target=$target&bug=$bugId&senderType=private";
      await _updateProgress(4);
      final res = await http.get(Uri.parse(url));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        setState(() {
          _responseMessage = "SYSTEM COOLDOWN — TUNGGU ${data['wait']}s";
          _isSuccess = false;
        });
      } else if (data["valid"] == false) {
        setState(() {
          _responseMessage = "SESSION INVALID / EXPIRED";
          _isSuccess = false;
        });
      } else if (data["sended"] == false) {
        setState(() {
          _responseMessage = "RELAY SERVER ERROR";
          _isSuccess = false;
        });
      } else {
        await _updateProgress(5);
        setState(() {
          _responseMessage = "ATTACK VECTOR DISPATCHED ✓";
          _isSuccess = true;
        });
        targetController.clear();
      }
    } catch (_) {
      setState(() {
        _responseMessage = "PROTOCOL SYNC FAILED";
        _isSuccess = false;
      });
    } finally {
      setState(() {
        _isSending = false;
        _currentStep = 0;
        _progress = 0.0;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDeep,
      body: FadeTransition(
        opacity: _fadeAnim,
        child: Stack(
          children: [
            Positioned(top: -100, right: -80, child: _glow(300, redMid.withOpacity(0.12))),
            Positioned(bottom: -80, left: -60, child: _glow(220, redDark.withOpacity(0.18))),
            SafeArea(
              child: Column(
                children: [
                  _buildHeader(),
                  Expanded(
                    child: SlideTransition(
                      position: _slideAnim,
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                        child: Column(
                          children: [
                            _buildBanner(),
                            const SizedBox(height: 18),
                            _buildAppLabel(),
                            const SizedBox(height: 18),
                            _buildTargetInput(),
                            const SizedBox(height: 16),
                            _buildBugSelector(),
                            const SizedBox(height: 22),
                            if (_isSending) ...[
                              _buildProgressIndicator(),
                              const SizedBox(height: 20),
                            ],
                            _buildFireButton(),
                            if (_responseMessage != null) ...[
                              const SizedBox(height: 14),
                              _buildResponseBadge(),
                            ],
                            const SizedBox(height: 28),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return ClipRRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.55),
            border: Border(bottom: BorderSide(color: redAccent.withOpacity(0.18), width: 1)),
          ),
          child: Row(
            children: [
              AnimatedBuilder(
                animation: _pulseAnim,
                builder: (_, child) => Container(
                  width: 44, height: 44,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(colors: [redMid, redAccent]),
                    boxShadow: [BoxShadow(color: redAccent.withOpacity(_pulseAnim.value * 0.55), blurRadius: 18)],
                  ),
                  child: child,
                ),
                child: ClipOval(
                  child: Image.asset('assets/images/icon.jpg', fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const Icon(Icons.person_rounded, color: Colors.white, size: 22)),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.username, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 0.3)),
                    const SizedBox(height: 4),
                    Row(children: [
                      _rolePill(widget.role),
                      const SizedBox(width: 6),
                      Text("• ${widget.expiredDate}", style: const TextStyle(color: textSub, fontSize: 9)),
                    ]),
                  ],
                ),
              ),
              AnimatedBuilder(
                animation: _pulseAnim,
                builder: (_, __) => Container(
                  width: 9, height: 9,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: redBright,
                    boxShadow: [BoxShadow(color: redBright.withOpacity(_pulseAnim.value), blurRadius: 8, spreadRadius: 2)],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _rolePill(String role) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: const LinearGradient(colors: [redDark, redAccent]),
      ),
      child: Text(role.toUpperCase(), style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
    );
  }

  Widget _buildBanner() {
    return Container(
      height: 195,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: redAccent.withOpacity(0.3), width: 1.5),
        boxShadow: [BoxShadow(color: redMid.withOpacity(0.35), blurRadius: 28, spreadRadius: 1)],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(21),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_isVideoInitialized)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              )
            else
              Image.network(
                'https://files.catbox.moe/vp2vm5.jpg',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(colors: [redDark, bgCard])),
                ),
                loadingBuilder: (_, child, progress) {
                  if (progress == null) return child;
                  return Container(
                    color: redDark,
                    child: const Center(child: CircularProgressIndicator(color: redAccent, strokeWidth: 2)),
                  );
                },
              ),
            Positioned.fill(
              child: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter, end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Color(0xDD060606)]),
                ),
              ),
            ),
            Positioned(
              bottom: 18, left: 18, right: 18,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ShaderMask(
                    shaderCallback: (b) => const LinearGradient(colors: [goldAccent, redGlow]).createShader(b),
                    child: const Text("NAXSUS",
                      style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
                  ),
                  const SizedBox(height: 4),
                  Text("GACORR BY Ganang",
                    style: TextStyle(color: redGlow.withOpacity(0.85), fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 0.8)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppLabel() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: const LinearGradient(colors: [Color(0xFF1A0000), bgCard]),
        border: Border.all(color: redAccent.withOpacity(0.25)),
        boxShadow: [BoxShadow(color: redMid.withOpacity(0.2), blurRadius: 22)],
      ),
      child: Row(
        children: [
          Container(
            width: 50, height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(colors: [redMid, redBright]),
              boxShadow: [BoxShadow(color: redAccent.withOpacity(0.4), blurRadius: 14)],
            ),
            child: const Icon(Icons.bolt_rounded, color: Colors.white, size: 28),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ShaderMask(
                  shaderCallback: (b) => const LinearGradient(colors: [Colors.white, redGlow]).createShader(b),
                  child: const Text("NAXSUS", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                ),
                const SizedBox(height: 3),
                const Text("POWERED BY Ganang", style: TextStyle(color: redAccent, fontSize: 9, fontWeight: FontWeight.w600, letterSpacing: 0.8)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                decoration: BoxDecoration(
                  color: redAccent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: redAccent.withOpacity(0.35)),
                ),
                child: const Text("ACTIVE", style: TextStyle(color: redBright, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1)),
              ),
              const SizedBox(height: 4),
              Text(widget.expiredDate.length > 10 ? widget.expiredDate.substring(0, 10) : widget.expiredDate, style: const TextStyle(color: textSub, fontSize: 9)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTargetInput() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: redAccent.withOpacity(0.25)),
        color: bgCard,
        boxShadow: [BoxShadow(color: redDark.withOpacity(0.2), blurRadius: 14)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
            child: Row(children: [
              const Icon(Icons.language_rounded, color: redAccent, size: 15),
              const SizedBox(width: 6),
              const Text("TARGET NUMBER", style: TextStyle(color: textSub, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: redGlow.withOpacity(0.4)),
                ),
                child: Text("ATTACK", style: TextStyle(color: redGlow.withOpacity(0.9), fontSize: 8, fontWeight: FontWeight.bold)),
              ),
            ]),
          ),
          Row(children: [
            GestureDetector(
              onTap: _showCountryDialog,
              child: Container(
                margin: const EdgeInsets.fromLTRB(12, 0, 0, 12),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                decoration: BoxDecoration(
                  color: redAccent.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: redAccent.withOpacity(0.28)),
                ),
                child: Row(
                  children: [
                    Text(_selectedFlag, style: const TextStyle(fontSize: 20)),
                    const SizedBox(width: 6),
                    Text(_selectedCountryCode, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                    const SizedBox(width: 4),
                    Icon(Icons.arrow_drop_down, color: redAccent, size: 18),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(right: 12, bottom: 12),
                child: TextField(
                  controller: targetController,
                  keyboardType: TextInputType.phone,
                  style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600, letterSpacing: 1),
                  cursorColor: redAccent,
                  decoration: InputDecoration(
                    hintText: "81234567890",
                    hintStyle: TextStyle(color: Colors.white.withOpacity(0.18), fontSize: 15),
                    border: InputBorder.none,
                    isDense: true,
                    contentPadding: const EdgeInsets.symmetric(vertical: 12),
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.close_rounded, color: textSub, size: 18),
                      onPressed: targetController.clear,
                    ),
                  ),
                ),
              ),
            ),
          ]),
        ],
      ),
    );
  }

  // ========== DROP DOWN PILIH BUG (BUKAN SCROLL CARD) ==========
  Widget _buildBugSelector() {
    if (widget.listBug.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: bgCard, borderRadius: BorderRadius.circular(16),
          border: Border.all(color: redAccent.withOpacity(0.15))),
        child: const Center(child: Text("NO BUG AVAILABLE", style: TextStyle(color: textSub, fontSize: 12, letterSpacing: 1))),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          Container(
            width: 3, height: 16,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              gradient: const LinearGradient(colors: [redBright, redMid])),
          ),
          const SizedBox(width: 10),
          const Text("PILIH BUG", style: TextStyle(color: textSub, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 2.2)),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: redAccent.withOpacity(0.1),
              border: Border.all(color: redAccent.withOpacity(0.3))),
            child: Text("TIER ${widget.listBug.length}", style: const TextStyle(color: redAccent, fontSize: 9, fontWeight: FontWeight.bold)),
          ),
        ]),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          decoration: BoxDecoration(
            color: bgCard,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: redAccent.withOpacity(0.3)),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<int>(
              value: _selectedBugIndex,
              dropdownColor: bgCard,
              isExpanded: true,
              icon: Icon(Icons.arrow_drop_down, color: redAccent, size: 24),
              style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w500),
              items: List.generate(widget.listBug.length, (index) {
                final bug = widget.listBug[index];
                final bugName = bug['bug_name']?.toString() ?? 'Unknown';
                return DropdownMenuItem<int>(
                  value: index,
                  child: Row(
                    children: [
                      Container(
                        width: 28, height: 28,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: redAccent.withOpacity(0.15),
                          border: Border.all(color: redAccent.withOpacity(0.4)),
                        ),
                        child: const Icon(FontAwesomeIcons.whatsapp, color: redBright, size: 14),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          bugName,
                          style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w500),
                        ),
                      ),
                      if (_selectedBugIndex == index)
                        Icon(Icons.check_circle_rounded, color: redBright, size: 18),
                    ],
                  ),
                );
              }),
              onChanged: (value) {
                if (value != null) {
                  setState(() => _selectedBugIndex = value);
                }
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _tagPill(String label, bool selected) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(6),
        color: selected ? Colors.white.withOpacity(0.14) : redAccent.withOpacity(0.1),
      ),
      child: Text(label, style: TextStyle(color: selected ? Colors.white60 : textSub, fontSize: 7, fontWeight: FontWeight.bold)),
    );
  }

  Widget _buildProgressIndicator() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [bgCardMid, bgDeep]),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: redAccent.withOpacity(0.3)),
        boxShadow: [BoxShadow(color: redMid.withOpacity(0.15), blurRadius: 18)],
      ),
      child: Column(children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List.generate(_progressSteps.length, (index) {
            final isActive = index <= _currentStep;
            final isCurrent = index == _currentStep;
            return Expanded(
              child: Column(children: [
                Container(
                  width: 36, height: 36,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: isActive ? const LinearGradient(colors: [redMid, redBright]) : null,
                    color: isActive ? null : Colors.white10,
                    border: Border.all(color: isCurrent ? redBright : Colors.white24, width: isCurrent ? 2 : 1),
                    boxShadow: isCurrent ? [BoxShadow(color: redAccent.withOpacity(0.5), blurRadius: 10, spreadRadius: 2)] : [],
                  ),
                  child: Center(
                    child: isActive && index < _currentStep
                        ? const Icon(Icons.check, color: Colors.white, size: 18)
                        : Text('${index + 1}', style: TextStyle(color: isActive ? Colors.white : Colors.grey, fontWeight: FontWeight.bold, fontSize: 13)),
                  ),
                ),
                if (index < _progressSteps.length - 1)
                  Container(margin: const EdgeInsets.only(top: 4), height: 2, color: isActive ? redAccent : Colors.white12),
              ]),
            );
          }),
        ),
        const SizedBox(height: 18),
        AnimatedBuilder(
          animation: _progressAnim,
          builder: (_, __) => Column(children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: LinearProgressIndicator(
                value: _progress * _progressAnim.value,
                minHeight: 8,
                backgroundColor: Colors.white10,
                valueColor: AlwaysStoppedAnimation<Color>(redBright),
              ),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(_progressSteps[_currentStep], style: const TextStyle(color: redAccent, fontSize: 12, fontWeight: FontWeight.bold)),
                Text('${(_progress * 100).toInt()}%', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
              ],
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _buildFireButton() {
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (_, child) => Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          boxShadow: _isSending ? [] : [BoxShadow(color: redAccent.withOpacity(0.3 * _pulseCtrl.value), blurRadius: 18 * _pulseCtrl.value, spreadRadius: 2 * _pulseCtrl.value)],
        ),
        child: child,
      ),
      child: GestureDetector(
        onTap: _isSending ? null : _sendBug,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: double.infinity, height: 58,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: _isSending ? LinearGradient(colors: [redDark.withOpacity(0.5), bgCard]) : const LinearGradient(colors: [redMid, redAccent, redBright]),
            border: Border.all(color: redGlow.withOpacity(_isSending ? 0.1 : 0.4)),
          ),
          child: Center(
            child: _isSending
                ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : ShaderMask(
                    shaderCallback: (b) => const LinearGradient(colors: [Colors.white, goldAccent]).createShader(b),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.send_rounded, color: Colors.white, size: 20),
                        SizedBox(width: 10),
                        Text("KIRIM BUG", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 2.5)),
                      ],
                    ),
                  ),
          ),
        ),
      ),
    );
  }

  Widget _buildResponseBadge() {
    final color = _isSuccess ? redGlow : Colors.redAccent;
    final icon = _isSuccess ? Icons.check_circle_outline_rounded : Icons.warning_amber_rounded;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      decoration: BoxDecoration(
        color: color.withOpacity(0.07),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.3)),
        boxShadow: [BoxShadow(color: color.withOpacity(0.1), blurRadius: 12)],
      ),
      child: Row(children: [
        Icon(icon, color: color, size: 18),
        const SizedBox(width: 12),
        Expanded(child: Text(_responseMessage!, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 1.2))),
      ]),
    );
  }

  Widget _glow(double size, Color color) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
        boxShadow: [BoxShadow(color: color, blurRadius: 100, spreadRadius: 50)],
      ),
    );
  }
}