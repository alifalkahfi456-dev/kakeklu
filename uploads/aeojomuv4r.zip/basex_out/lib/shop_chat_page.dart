import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../services/api_config_service.dart';

class ShopChatPage extends StatefulWidget {
  final String myUsername, peerUsername, sessionKey, productName;
  const ShopChatPage({
    super.key,
    required this.myUsername,
    required this.peerUsername,
    required this.sessionKey,
    required this.productName,
  });
  @override State<ShopChatPage> createState() => _ShopChatPageState();
}

class _ShopChatPageState extends State<ShopChatPage> {
  static const bg     = Color(0xFF080808);
  static const card   = Color(0xFF111111);
  static const card2  = Color(0xFF1A1A1A);
  static const border = Color(0xFF252525);
  static const green  = Color(0xFF00E676);
  static const cyan   = Color(0xFF00E5FF);
  static const white  = Colors.white;
  static const grey   = Color(0xFF777777);
  static const red    = Color(0xFFE53935);

  List<Map<String, dynamic>> _messages = [];
  bool _loading = true;
  bool _sending = false;
  final _msgCtrl  = TextEditingController();
  final _scrollCtrl = ScrollController();

  @override
  void initState() {
    super.initState();
    _loadHistory();
    // Poll setiap 5 detik
    _startPolling();
  }

  void _startPolling() {
    Future.delayed(const Duration(seconds: 5), () {
      if (!mounted) return;
      _loadHistory(silent: true);
      _startPolling();
    });
  }

  Future<void> _loadHistory({bool silent = false}) async {
    if (!silent) setState(() => _loading = true);
    try {
      final res = await http.get(Uri.parse(
        '${AppUrls.chatHistory}'
        '?key=${widget.sessionKey}'
        '&user1=${widget.myUsername}'
        '&user2=${widget.peerUsername}',
      )).timeout(const Duration(seconds: 8));
      final d = jsonDecode(res.body);
      if (d['success'] == true) {
        setState(() => _messages = List<Map<String, dynamic>>.from(d['messages'] ?? []));
        if (_scrollCtrl.hasClients) {
          await Future.delayed(const Duration(milliseconds: 100));
          _scrollCtrl.animateTo(_scrollCtrl.position.maxScrollExtent,
              duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
        }
      }
    } catch (_) {}
    if (!silent) setState(() => _loading = false);
  }

  Future<void> _sendMessage() async {
    final text = _msgCtrl.text.trim();
    if (text.isEmpty || _sending) return;
    setState(() => _sending = true);
    _msgCtrl.clear();
    try {
      final res = await http.post(
        Uri.parse(AppUrls.chatPrivate),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key':    widget.sessionKey,
          'from':   widget.myUsername,
          'to':     widget.peerUsername,
          'message': text,
        }),
      );
      final d = jsonDecode(res.body);
      if (d['success'] == true) {
        await _loadHistory(silent: true);
      }
    } catch (_) {}
    setState(() => _sending = false);
  }

  @override
  void dispose() { _msgCtrl.dispose(); _scrollCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [Color(0xFF080808), Color(0xFF0A140A), Color(0xFF080808)],
          ),
        ),
        child: SafeArea(child: Column(children: [
          _buildHeader(),
          _buildProductBanner(),
          Expanded(child: _loading ? _buildLoader() : _buildMessages()),
          _buildInput(),
        ])),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Row(children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(12), border: Border.all(color: border)),
            child: const Icon(Icons.arrow_back_ios_new, color: white, size: 15),
          ),
        ),
        const SizedBox(width: 12),
        Container(
          width: 40, height: 40,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [cyan.withOpacity(0.3), cyan.withOpacity(0.1)]),
            shape: BoxShape.circle,
            border: Border.all(color: cyan.withOpacity(0.4)),
          ),
          child: Center(child: Text(
            widget.peerUsername.isNotEmpty ? widget.peerUsername[0].toUpperCase() : '?',
            style: TextStyle(color: cyan, fontWeight: FontWeight.bold, fontSize: 16),
          )),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(widget.peerUsername, style: const TextStyle(color: white, fontWeight: FontWeight.bold, fontSize: 15)),
          Row(children: [
            Container(width: 6, height: 6, decoration: BoxDecoration(color: green, shape: BoxShape.circle)),
            const SizedBox(width: 5),
            Text('Chat Privat', style: TextStyle(color: grey, fontSize: 11)),
          ]),
        ])),
        GestureDetector(
          onTap: () => _loadHistory(),
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(12), border: Border.all(color: border)),
            child: Icon(Icons.refresh_rounded, color: green, size: 16),
          ),
        ),
      ]),
    );
  }

  Widget _buildProductBanner() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: cyan.withOpacity(0.07),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: cyan.withOpacity(0.2)),
      ),
      child: Row(children: [
        Icon(Icons.shopping_bag_outlined, color: cyan, size: 16),
        const SizedBox(width: 8),
        Expanded(child: Text(
          'Tanya soal: ${widget.productName}',
          style: TextStyle(color: cyan.withOpacity(0.9), fontSize: 11),
          overflow: TextOverflow.ellipsis,
        )),
      ]),
    );
  }

  Widget _buildLoader() {
    return Center(child: CircularProgressIndicator(color: green, strokeWidth: 2));
  }

  Widget _buildMessages() {
    if (_messages.isEmpty) {
      return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(Icons.chat_bubble_outline_rounded, color: grey, size: 52),
        const SizedBox(height: 12),
        const Text('Belum ada pesan', style: TextStyle(color: white, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text('Mulai tanya ke penjual!', style: TextStyle(color: grey, fontSize: 12)),
      ]));
    }
    return ListView.builder(
      controller: _scrollCtrl,
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      itemCount: _messages.length,
      itemBuilder: (_, i) => _buildBubble(_messages[i]),
    );
  }

  Widget _buildBubble(Map<String, dynamic> msg) {
    final isMine = msg['from'] == widget.myUsername;
    final text   = msg['message'] ?? '';
    final time   = msg['time']    ?? '';
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.72),
        child: Column(
          crossAxisAlignment: isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                gradient: isMine
                    ? LinearGradient(colors: [const Color(0xFF00C853), green])
                    : null,
                color: isMine ? null : card2,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(18),
                  topRight: const Radius.circular(18),
                  bottomLeft: Radius.circular(isMine ? 18 : 4),
                  bottomRight: Radius.circular(isMine ? 4 : 18),
                ),
                border: isMine ? null : Border.all(color: border),
                boxShadow: [BoxShadow(
                  color: isMine ? green.withOpacity(0.2) : Colors.black.withOpacity(0.2),
                  blurRadius: 8, offset: const Offset(0, 2),
                )],
              ),
              child: Text(text, style: TextStyle(
                color: isMine ? Colors.black : white,
                fontSize: 13, height: 1.4, fontWeight: isMine ? FontWeight.w600 : FontWeight.normal,
              )),
            ),
            const SizedBox(height: 3),
            Text(time, style: TextStyle(color: grey, fontSize: 9)),
          ],
        ),
      ),
    );
  }

  Widget _buildInput() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
      decoration: BoxDecoration(
        color: card,
        border: Border(top: BorderSide(color: border)),
      ),
      child: Row(children: [
        Expanded(
          child: TextField(
            controller: _msgCtrl,
            style: const TextStyle(color: white, fontSize: 13),
            maxLines: 3,
            minLines: 1,
            textInputAction: TextInputAction.send,
            onSubmitted: (_) => _sendMessage(),
            decoration: InputDecoration(
              hintText: 'Ketik pesan...',
              hintStyle: TextStyle(color: grey.withOpacity(0.6)),
              filled: true, fillColor: card2,
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: border)),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: border)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: cyan, width: 1.5)),
            ),
          ),
        ),
        const SizedBox(width: 10),
        GestureDetector(
          onTap: _sendMessage,
          child: Container(
            width: 46, height: 46,
            decoration: BoxDecoration(
              gradient: _sending
                  ? null
                  : const LinearGradient(colors: [Color(0xFF00C853), Color(0xFF00E676)]),
              color: _sending ? const Color(0xFF1A1A1A) : null,
              shape: BoxShape.circle,
              boxShadow: _sending ? [] : [BoxShadow(color: green.withOpacity(0.35), blurRadius: 10)],
            ),
            child: _sending
                ? Center(child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: green)))
                : const Icon(Icons.send_rounded, color: Colors.black, size: 20),
          ),
        ),
      ]),
    );
  }
}
