import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/api_config_service.dart';
import 'sell_page.dart';
import 'shop_chat_page.dart';

class ShopPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  const ShopPage({super.key, required this.username, required this.sessionKey});
  @override State<ShopPage> createState() => _ShopPageState();
}

class _ShopPageState extends State<ShopPage> with SingleTickerProviderStateMixin {
  static const bg      = Color(0xFF080808);
  static const card    = Color(0xFF111111);
  static const card2   = Color(0xFF1A1A1A);
  static const border  = Color(0xFF252525);
  static const green   = Color(0xFF00E676);
  static const red     = Color(0xFFE53935);
  static const gold    = Color(0xFFFFD700);
  static const cyan    = Color(0xFF00E5FF);
  static const white   = Colors.white;
  static const grey    = Color(0xFF777777);

  List<dynamic> _allProducts = [];
  List<dynamic> _filtered    = [];
  bool _loading = true;
  String _search = '';
  String _sortBy = 'terbaru'; // terbaru / termurah / termahal
  final _searchCtrl = TextEditingController();
  late AnimationController _shimmerCtrl;

  @override
  void initState() {
    super.initState();
    _shimmerCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat();
    _fetchProducts();
  }

  @override
  void dispose() { _shimmerCtrl.dispose(); super.dispose(); }

  Future<void> _fetchProducts() async {
    setState(() => _loading = true);
    try {
      final res = await http.get(
        Uri.parse('${AppUrls.shopProducts}?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));
      final d = jsonDecode(res.body);
      if (d['success'] == true) {
        _allProducts = d['products'] ?? [];
        _applyFilter();
      }
    } catch (_) {}
    setState(() => _loading = false);
  }

  void _applyFilter() {
    List<dynamic> list = List.from(_allProducts);
    if (_search.isNotEmpty) {
      list = list.where((p) {
        final n = (p['name'] ?? '').toString().toLowerCase();
        final d = (p['description'] ?? '').toString().toLowerCase();
        final s = (p['sellerUsername'] ?? '').toString().toLowerCase();
        return n.contains(_search.toLowerCase()) || d.contains(_search.toLowerCase()) || s.contains(_search.toLowerCase());
      }).toList();
    }
    if (_sortBy == 'termurah') {
      list.sort((a, b) => _parsePrice(a['price']).compareTo(_parsePrice(b['price'])));
    } else if (_sortBy == 'termahal') {
      list.sort((a, b) => _parsePrice(b['price']).compareTo(_parsePrice(a['price'])));
    }
    setState(() => _filtered = list);
  }

  double _parsePrice(dynamic p) {
    if (p == null || p.toString().isEmpty) return 0;
    return double.tryParse(p.toString().replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0;
  }

  void _openDetail(Map product) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _ProductDetailSheet(
        product: product,
        myUsername: widget.username,
        sessionKey: widget.sessionKey,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF080808), Color(0xFF0D1A0D), Color(0xFF080808)],
          ),
        ),
        child: SafeArea(child: Column(children: [
          _buildHeader(),
          _buildSearchAndFilter(),
          _buildScamWarning(),
          Expanded(child: _loading ? _buildShimmerGrid() : _buildGrid()),
        ])),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Row(children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(12), border: Border.all(color: border)),
            child: const Icon(Icons.arrow_back_ios_new, color: white, size: 15),
          ),
        ),
        const SizedBox(width: 12),
        // Logo shop
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [green.withOpacity(0.3), green.withOpacity(0.1)]),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: green.withOpacity(0.4)),
            boxShadow: [BoxShadow(color: green.withOpacity(0.2), blurRadius: 12)],
          ),
          child: const Icon(Icons.storefront_rounded, color: green, size: 22),
        ),
        const SizedBox(width: 10),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('MARKET', style: TextStyle(color: white, fontSize: 18, fontWeight: FontWeight.w900, fontFamily: 'Orbitron', letterSpacing: 2)),
          Text('${_filtered.length} produk tersedia', style: TextStyle(color: grey, fontSize: 10)),
        ]),
        const Spacer(),
        // Tombol Mulai Jualan
        GestureDetector(
          onTap: () async {
            final result = await Navigator.push(context, MaterialPageRoute(
              builder: (_) => SellPage(username: widget.username, sessionKey: widget.sessionKey),
            ));
            if (result == true) _fetchProducts();
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF00C853), Color(0xFF00E676)]),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [BoxShadow(color: green.withOpacity(0.35), blurRadius: 10, offset: const Offset(0, 3))],
            ),
            child: Row(children: const [
              Icon(Icons.add_rounded, color: Colors.black, size: 16),
              SizedBox(width: 5),
              Text('Mulai Jualan', style: TextStyle(color: Colors.black, fontWeight: FontWeight.w900, fontSize: 11)),
            ]),
          ),
        ),
      ]),
    );
  }

  Widget _buildSearchAndFilter() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Column(children: [
        // Search
        TextField(
          controller: _searchCtrl,
          onChanged: (v) { _search = v; _applyFilter(); },
          style: const TextStyle(color: white, fontSize: 13),
          decoration: InputDecoration(
            hintText: 'Cari produk, penjual...',
            hintStyle: TextStyle(color: grey.withOpacity(0.6), fontSize: 13),
            prefixIcon: const Icon(Icons.search_rounded, color: green, size: 20),
            suffixIcon: _search.isNotEmpty ? GestureDetector(
              onTap: () { _searchCtrl.clear(); _search = ''; _applyFilter(); },
              child: Icon(Icons.close_rounded, color: grey, size: 18),
            ) : null,
            filled: true, fillColor: card2,
            contentPadding: const EdgeInsets.symmetric(vertical: 12),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: border)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: border)),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: green, width: 1.5)),
          ),
        ),
        const SizedBox(height: 10),
        // Filter chips
        Row(children: [
          _filterChip('Terbaru', 'terbaru', Icons.access_time_rounded),
          const SizedBox(width: 8),
          _filterChip('Termurah', 'termurah', Icons.arrow_downward_rounded),
          const SizedBox(width: 8),
          _filterChip('Termahal', 'termahal', Icons.arrow_upward_rounded),
          const Spacer(),
          GestureDetector(
            onTap: _fetchProducts,
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: card2, borderRadius: BorderRadius.circular(10), border: Border.all(color: border)),
              child: Icon(Icons.refresh_rounded, color: green, size: 16),
            ),
          ),
        ]),
      ]),
    );
  }

  Widget _filterChip(String label, String val, IconData icon) {
    final active = _sortBy == val;
    return GestureDetector(
      onTap: () { setState(() => _sortBy = val); _applyFilter(); },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: active ? green.withOpacity(0.15) : card2,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: active ? green.withOpacity(0.5) : border),
        ),
        child: Row(children: [
          Icon(icon, color: active ? green : grey, size: 12),
          const SizedBox(width: 4),
          Text(label, style: TextStyle(color: active ? green : grey, fontSize: 11, fontWeight: active ? FontWeight.bold : FontWeight.normal)),
        ]),
      ),
    );
  }

  Widget _buildScamWarning() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: red.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: red.withOpacity(0.35)),
      ),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(color: red.withOpacity(0.15), shape: BoxShape.circle),
          child: const Icon(Icons.warning_amber_rounded, color: red, size: 16),
        ),
        const SizedBox(width: 10),
        Expanded(child: Text(
          '⚠️ Segala bentuk penipuan, scam & aktivitas ilegal dilarang keras. Akun pelanggar akan dihapus permanen oleh Owner.',
          style: TextStyle(color: red.withOpacity(0.9), fontSize: 10, height: 1.5),
        )),
      ]),
    );
  }

  Widget _buildGrid() {
    if (_filtered.isEmpty) {
      return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(Icons.storefront_outlined, color: grey, size: 64),
        const SizedBox(height: 16),
        const Text('Belum ada produk', style: TextStyle(color: white, fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text('Jadilah yang pertama berjualan!', style: TextStyle(color: grey, fontSize: 13)),
      ]));
    }
    return RefreshIndicator(
      color: green, backgroundColor: card,
      onRefresh: _fetchProducts,
      child: GridView.builder(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, childAspectRatio: 0.58, crossAxisSpacing: 12, mainAxisSpacing: 12,
        ),
        itemCount: _filtered.length,
        itemBuilder: (_, i) => _ProductCard(
          product: _filtered[i],
          myUsername: widget.username,
          sessionKey: widget.sessionKey,
          onTap: () => _openDetail(_filtered[i]),
        ),
      ),
    );
  }

  Widget _buildShimmerGrid() {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, childAspectRatio: 0.58, crossAxisSpacing: 12, mainAxisSpacing: 12,
      ),
      itemCount: 6,
      itemBuilder: (_, __) => AnimatedBuilder(
        animation: _shimmerCtrl,
        builder: (_, __) => Container(
          decoration: BoxDecoration(
            color: card,
            borderRadius: BorderRadius.circular(18),
            gradient: LinearGradient(
              colors: [card, card2, card],
              stops: [_shimmerCtrl.value - 0.3, _shimmerCtrl.value, _shimmerCtrl.value + 0.3],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════
//  PRODUCT CARD
// ═══════════════════════════════════════════════════════
class _ProductCard extends StatelessWidget {
  final Map product;
  final String myUsername, sessionKey;
  final VoidCallback onTap;

  static const bg    = Color(0xFF080808);
  static const card  = Color(0xFF111111);
  static const card2 = Color(0xFF1A1A1A);
  static const border = Color(0xFF252525);
  static const green = Color(0xFF00E676);
  static const grey  = Color(0xFF777777);
  static const white = Colors.white;
  static const gold  = Color(0xFFFFD700);

  const _ProductCard({required this.product, required this.myUsername, required this.sessionKey, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final _rawUrl  = (product['imageUrl'] ?? '').toString();
    final imageUrl = _rawUrl.isNotEmpty && !_rawUrl.startsWith('http')
        ? '${AppUrls.mainServer}$_rawUrl'
        : _rawUrl;
    final name     = product['name']  ?? 'Produk';
    final price    = product['price'] ?? '';
    final seller   = product['sellerUsername'] ?? '';
    final isMine   = seller == myUsername;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: card,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: isMine ? green.withOpacity(0.3) : border),
          boxShadow: [BoxShadow(color: isMine ? green.withOpacity(0.06) : Colors.black.withOpacity(0.3), blurRadius: 12, offset: const Offset(0, 4))],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          // Foto
          Expanded(
            flex: 5,
            child: Stack(children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
                child: imageUrl.isNotEmpty
                    ? Image.network(
                        imageUrl,
                        fit: BoxFit.cover,
                        width: double.infinity,
                        height: double.infinity,
                        loadingBuilder: (_, child, loadingProgress) {
                          if (loadingProgress == null) return child;
                          return Container(
                            color: card2,
                            child: Center(child: SizedBox(
                              width: 20, height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: green,
                                value: loadingProgress.expectedTotalBytes != null
                                    ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                                    : null,
                              ),
                            )),
                          );
                        },
                        errorBuilder: (_, __, ___) => _placeholder(),
                      )
                    : _placeholder(),
              ),
              if (isMine)
                Positioned(top: 8, right: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                    decoration: BoxDecoration(color: green.withOpacity(0.9), borderRadius: BorderRadius.circular(8)),
                    child: const Text('Milikmu', style: TextStyle(color: Colors.black, fontSize: 9, fontWeight: FontWeight.bold)),
                  ),
                ),
              // Gradient overlay bawah
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
                    gradient: LinearGradient(
                      begin: Alignment.topCenter, end: Alignment.bottomCenter,
                      colors: [Colors.transparent, Colors.transparent, card.withOpacity(0.7)],
                    ),
                  ),
                ),
              ),
            ]),
          ),
          // Info
          Expanded(
            flex: 4,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(name, style: const TextStyle(color: white, fontWeight: FontWeight.bold, fontSize: 12, height: 1.3), maxLines: 2, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 4),
                if (price.isNotEmpty)
                  Text('Rp $price', style: const TextStyle(color: green, fontWeight: FontWeight.w900, fontSize: 13))
                else
                  Text('Nego', style: TextStyle(color: gold.withOpacity(0.8), fontSize: 11, fontStyle: FontStyle.italic)),
                const Spacer(),
                Row(children: [
                  Icon(Icons.person_rounded, color: grey, size: 10),
                  const SizedBox(width: 3),
                  Expanded(child: Text(seller, style: TextStyle(color: grey, fontSize: 9), overflow: TextOverflow.ellipsis)),
                ]),
                const SizedBox(height: 8),
                // Tombol beli
                Container(
                  height: 30,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFF00C853), Color(0xFF00E676)]),
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [BoxShadow(color: green.withOpacity(0.3), blurRadius: 6, offset: const Offset(0, 2))],
                  ),
                  child: const Center(
                    child: Text('Beli Sekarang', style: TextStyle(color: Colors.black, fontWeight: FontWeight.w900, fontSize: 10)),
                  ),
                ),
              ]),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _placeholder() {
    return ClipRRect(
      child: Image.asset(
        'assets/images/shop.png',
        fit: BoxFit.cover,
        width: double.infinity,
        height: double.infinity,
        errorBuilder: (_, __, ___) => Container(
          color: card2,
          child: Center(child: Icon(Icons.storefront_rounded, color: const Color(0xFF333333), size: 36)),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════
//  PRODUCT DETAIL BOTTOM SHEET
// ═══════════════════════════════════════════════════════
class _ProductDetailSheet extends StatelessWidget {
  final Map product;
  final String myUsername, sessionKey;

  static const bg    = Color(0xFF0E0E0E);
  static const card  = Color(0xFF171717);
  static const border= Color(0xFF252525);
  static const green = Color(0xFF00E676);
  static const red   = Color(0xFFE53935);
  static const cyan  = Color(0xFF00E5FF);
  static const white = Colors.white;
  static const grey  = Color(0xFF777777);
  static const gold  = Color(0xFFFFD700);

  const _ProductDetailSheet({required this.product, required this.myUsername, required this.sessionKey});

  @override
  Widget build(BuildContext context) {
    final _rawUrl2 = (product['imageUrl'] ?? '').toString();
    final imageUrl = _rawUrl2.isNotEmpty && !_rawUrl2.startsWith('http')
        ? '${AppUrls.mainServer}$_rawUrl2'
        : _rawUrl2;
    final name     = product['name']        ?? 'Produk';
    final desc     = product['description'] ?? '';
    final price    = product['price']       ?? '';
    final seller   = product['sellerUsername'] ?? 'Unknown';
    final tele     = (product['telegramContact'] ?? '').toString().trim();
    final wa       = (product['whatsappContact']  ?? '').toString().trim();

    return DraggableScrollableSheet(
      initialChildSize: 0.82, maxChildSize: 0.95, minChildSize: 0.5, expand: false,
      builder: (_, ctrl) => Container(
        decoration: BoxDecoration(color: bg, borderRadius: const BorderRadius.vertical(top: Radius.circular(28))),
        child: Column(children: [
          // Handle
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Container(width: 40, height: 4, decoration: BoxDecoration(color: const Color(0xFF333333), borderRadius: BorderRadius.circular(2))),
          ),
          Expanded(child: SingleChildScrollView(
            controller: ctrl,
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 30),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              // Foto gede di atas
              if (imageUrl.isNotEmpty)
                Container(
                  height: 260,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: green.withOpacity(0.2)),
                    boxShadow: [BoxShadow(color: green.withOpacity(0.08), blurRadius: 20)],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.network(
                      imageUrl,
                      fit: BoxFit.cover,
                      width: double.infinity,
                      height: 260,
                      loadingBuilder: (_, child, loadingProgress) {
                        if (loadingProgress == null) return child;
                        return Container(
                          color: card,
                          child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                            SizedBox(
                              width: 28, height: 28,
                              child: CircularProgressIndicator(
                                strokeWidth: 2.5,
                                color: green,
                                value: loadingProgress.expectedTotalBytes != null
                                    ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                                    : null,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text('Memuat foto...', style: TextStyle(color: grey, fontSize: 11)),
                          ])),
                        );
                      },
                      errorBuilder: (_, __, ___) => Container(
                        color: card,
                        child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(Icons.broken_image_outlined, color: grey, size: 50),
                          const SizedBox(height: 8),
                          Text('Gagal memuat foto', style: TextStyle(color: grey, fontSize: 11)),
                        ])),
                      ),
                    ),
                  ),
                )
              else
                Container(
                  height: 200,
                  decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(20), border: Border.all(color: border)),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.asset(
                      'assets/images/shop.png',
                      fit: BoxFit.cover,
                      width: double.infinity,
                      errorBuilder: (_, __, ___) => Center(child: Icon(Icons.storefront_rounded, color: grey, size: 60)),
                    ),
                  ),
                ),
              const SizedBox(height: 20),
              // Nama + harga
              Text(name, style: const TextStyle(color: white, fontSize: 22, fontWeight: FontWeight.w900, height: 1.2)),
              const SizedBox(height: 8),
              if (price.isNotEmpty)
                Row(children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                    decoration: BoxDecoration(
                      color: green.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: green.withOpacity(0.3)),
                    ),
                    child: Text('Rp $price', style: const TextStyle(color: green, fontWeight: FontWeight.w900, fontSize: 20)),
                  ),
                ])
              else
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                  decoration: BoxDecoration(color: gold.withOpacity(0.1), borderRadius: BorderRadius.circular(10), border: Border.all(color: gold.withOpacity(0.3))),
                  child: Text('Harga bisa nego', style: TextStyle(color: gold, fontWeight: FontWeight.bold, fontSize: 14)),
                ),
              const SizedBox(height: 14),
              // Seller
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(14), border: Border.all(color: border)),
                child: Row(children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(color: green.withOpacity(0.12), shape: BoxShape.circle),
                    child: Icon(Icons.storefront_rounded, color: green, size: 18),
                  ),
                  const SizedBox(width: 10),
                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Penjual', style: TextStyle(color: grey, fontSize: 10)),
                    Text(seller, style: const TextStyle(color: white, fontWeight: FontWeight.bold, fontSize: 14)),
                  ]),
                ]),
              ),
              if (desc.isNotEmpty) ...[
                const SizedBox(height: 16),
                const Text('Deskripsi', style: TextStyle(color: white, fontWeight: FontWeight.bold, fontSize: 15)),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(14), border: Border.all(color: border)),
                  child: Text(desc, style: TextStyle(color: grey, fontSize: 13, height: 1.6)),
                ),
              ],
              const SizedBox(height: 24),
              // Tombol beli — WA & Telegram
              if (tele.isNotEmpty || wa.isNotEmpty) ...[
                const Text('Hubungi Penjual', style: TextStyle(color: white, fontWeight: FontWeight.bold, fontSize: 15)),
                const SizedBox(height: 10),
                if (tele.isNotEmpty)
                  _contactBtn(
                    icon: FontAwesomeIcons.telegram, label: 'Chat via Telegram',
                    color: const Color(0xFF29B6F6),
                    onTap: () {
                      final u = tele.startsWith('@') ? tele.substring(1) : tele;
                      launchUrl(Uri.parse('https://t.me/$u'), mode: LaunchMode.externalApplication);
                    },
                  ),
                if (tele.isNotEmpty && wa.isNotEmpty) const SizedBox(height: 10),
                if (wa.isNotEmpty)
                  _contactBtn(
                    icon: FontAwesomeIcons.whatsapp, label: 'Chat via WhatsApp',
                    color: const Color(0xFF66BB6A),
                    onTap: () {
                      final n = wa.replaceAll(RegExp(r'[^0-9]'), '');
                      launchUrl(Uri.parse('https://wa.me/$n?text=Halo%20saya%20tertarik%20dengan%20${Uri.encodeComponent(name)}'),
                          mode: LaunchMode.externalApplication);
                    },
                  ),
              ],
              const SizedBox(height: 10),
              // Tombol Chat Privat dalam App
              if (seller != myUsername)
                GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(context, MaterialPageRoute(
                      builder: (_) => ShopChatPage(
                        myUsername: myUsername,
                        peerUsername: seller,
                        sessionKey: sessionKey,
                        productName: name,
                      ),
                    ));
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A2E),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: cyan.withOpacity(0.4)),
                      boxShadow: [BoxShadow(color: cyan.withOpacity(0.1), blurRadius: 12)],
                    ),
                    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.chat_bubble_outline_rounded, color: cyan, size: 20),
                      const SizedBox(width: 10),
                      Text('Chat Privat Penjual', style: TextStyle(color: cyan, fontWeight: FontWeight.bold, fontSize: 14)),
                    ]),
                  ),
                ),
            ]),
          )),
        ]),
      ),
    );
  }

  Widget _contactBtn({required IconData icon, required String label, required Color color, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.35)),
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 10),
          Text(label, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 14)),
        ]),
      ),
    );
  }
}
