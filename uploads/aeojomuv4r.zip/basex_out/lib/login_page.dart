import 'dart:convert';
import '../services/api_config_service.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'splash.dart';

// ══════════════════════════════════════════════════════
//  OVALIUM GHOST — LOGIN PAGE  (Red × Black Edition)
// ══════════════════════════════════════════════════════

class _C {
  static const bg       = Color(0xFF0A0A0A);
  static const card     = Color(0xFF141414);
  static const input    = Color(0xFF1C1C1C);
  static const border   = Color(0xFF2A2A2A);
  static const red      = Color(0xFFE53935);
  static const redDark  = Color(0xFFB71C1C);
  static const redGlow  = Color(0x33E53935);
  static const white    = Colors.white;
  static const grey     = Color(0xFF9E9E9E);
  static const greyDark = Color(0xFF424242);
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with SingleTickerProviderStateMixin {
  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _formKey  = GlobalKey<FormState>();

  bool _loading  = false;
  bool _obscure  = true;
  String? _androidId;

  late AnimationController _anim;
  late Animation<double>   _fade;
  late Animation<Offset>   _slide;

  @override
  void initState() {
    super.initState();
    _anim = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();
    _fade  = CurvedAnimation(parent: _anim, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero)
        .animate(CurvedAnimation(parent: _anim, curve: Curves.easeOutCubic));
    _initLogin();
  }

  Future<void> _initLogin() async {
    _androidId = await _getAndroidId();
    final prefs = await SharedPreferences.getInstance();
    final u = prefs.getString('username');
    final p = prefs.getString('password');
    final k = prefs.getString('key');
    if (u != null && p != null && k != null) {
      try {
        final res = await http.get(Uri.parse(
            '${await ApiConfig.baseUrl}/myInfo?username=$u&password=$p&androidId=$_androidId&key=$k'));
        final d = jsonDecode(res.body);
        if (d['valid'] == true && mounted) {
          Navigator.pushReplacement(context,
              MaterialPageRoute(builder: (_) => SplashScreen(
                username: u, password: p,
                role: d['role'], userId: d['userId'] ?? '000000',
                level: d['level'] ?? '1', sessionKey: d['key'],
                expiredDate: d['expiredDate'],
                listBug:  (d['listBug']  as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
                listDoos: (d['listDDoS'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
                news:     (d['news']     as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
              )));
        }
      } catch (_) {}
    }
  }

  Future<String> _getAndroidId() async {
    final info = await DeviceInfoPlugin().androidInfo;
    return info.id ?? 'unknown';
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    final u = _userCtrl.text.trim();
    final p = _passCtrl.text.trim();
    setState(() => _loading = true);
    try {
      final res = await http.post(
        Uri.parse('${await ApiConfig.baseUrl}/validate'),
        body: {'username': u, 'password': p, 'androidId': _androidId ?? 'unknown'},
      );
      final d = jsonDecode(res.body);
      if (d['expired'] == true) {
        _popup('⏳ Access Expired',
            'Masa akses habis.\nSilakan perpanjang akses.', _C.red, showContact: true);
      } else if (d['valid'] != true) {
        final msg = (d['message'] ?? '').toLowerCase();
        if (msg.contains('perangkat') || msg.contains('device') || msg.contains('another')) {
          _popup('⚠️ Sesi Aktif',
              'Akun ini login di perangkat lain.\nLogout dari perangkat lama dulu.', Colors.orange);
        } else {
          _popup('❌ Login Gagal', 'Username atau password salah.', _C.red);
        }
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString('username', u);
        prefs.setString('password', p);
        prefs.setString('key', d['key']);
        if (mounted) {
          Navigator.pushReplacement(context,
              MaterialPageRoute(builder: (_) => SplashScreen(
                username: u, password: p,
                role: d['role'], userId: d['userId'] ?? '000000',
                level: d['level'] ?? '1', sessionKey: d['key'],
                expiredDate: d['expiredDate'],
                listBug:  (d['listBug']  as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
                listDoos: (d['listDDoS'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
                news:     (d['news']     as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
              )));
        }
      }
    } catch (_) {
      _popup('⚠️ Connection Error', 'Gagal terhubung ke server.\nCek koneksi internet.', _C.red);
    }
    setState(() => _loading = false);
  }

  void _popup(String title, String msg, Color color, {bool showContact = false}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _C.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: color.withOpacity(0.3)),
        ),
        title: Text(title, style: TextStyle(color: color, fontWeight: FontWeight.bold)),
        content: Text(msg, style: const TextStyle(color: _C.grey, fontSize: 14, height: 1.5)),
        actions: [
          if (showContact)
            TextButton(
              onPressed: () => launchUrl(Uri.parse('https://t.me/ANTIBEKU2'), mode: LaunchMode.externalApplication),
              child: const Text('Contact Admin', style: TextStyle(color: _C.red)),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup', style: TextStyle(color: _C.grey)),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _anim.dispose();
    _userCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(children: [
        // Background subtle radial glow
        Positioned(
          top: -100, left: -80,
          child: Container(
            width: 350, height: 350,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(colors: [Color(0x22E53935), Colors.transparent]),
            ),
          ),
        ),
        Positioned(
          bottom: -60, right: -100,
          child: Container(
            width: 280, height: 280,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(colors: [Color(0x11E53935), Colors.transparent]),
            ),
          ),
        ),
        SafeArea(
          child: FadeTransition(
            opacity: _fade,
            child: SlideTransition(
              position: _slide,
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 28),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // ── LOGO ──────────────────────────────────────────
                      Hero(
                        tag: 'logo',
                        child: Container(
                          width: 88, height: 88,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(color: _C.red.withOpacity(0.6), width: 1.5),
                            boxShadow: [
                              BoxShadow(color: _C.redGlow, blurRadius: 30, spreadRadius: 4),
                            ],
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(20),
                            child: Image.asset('assets/images/logo.png', fit: BoxFit.cover),
                          ),
                        ),
                      ),
                      const SizedBox(height: 28),

                      // ── TITLE ─────────────────────────────────────────
                      const Text(
                        'NAXSUS',
                        style: TextStyle(
                          color: _C.white,
                          fontSize: 26,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900,
                          letterSpacing: 4,
                        ),
                      ),
                      const SizedBox(height: 2),
                      const Text(
                        'WELCOME',
                        style: TextStyle(
                          color: _C.red,
                          fontSize: 26,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900,
                          letterSpacing: 4,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'PREMIUM CYBER SECURITY PLATFORM',
                        style: TextStyle(
                          color: _C.grey.withOpacity(0.6),
                          fontSize: 9,
                          letterSpacing: 2.5,
                        ),
                      ),
                      const SizedBox(height: 44),

                      // ── FORM CARD ─────────────────────────────────────
                      Container(
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          color: _C.card,
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(color: _C.border),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.4),
                              blurRadius: 30,
                              offset: const Offset(0, 8),
                            ),
                          ],
                        ),
                        child: Form(
                          key: _formKey,
                          child: Column(children: [
                            _field(_userCtrl, 'Username', Icons.person_outline_rounded),
                            const SizedBox(height: 14),
                            _field(_passCtrl, 'Password', Icons.lock_outline_rounded, isPass: true),
                            const SizedBox(height: 24),
                            _loginBtn(),
                          ]),
                        ),
                      ),

                      const SizedBox(height: 24),
                      // ── FOOTER ───────────────────────────────────────
                      Text(
                        'Need help? Contact Admin',
                        style: TextStyle(color: _C.grey.withOpacity(0.5), fontSize: 12),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _field(TextEditingController ctrl, String label, IconData icon, {bool isPass = false}) {
    return TextFormField(
      controller: ctrl,
      obscureText: isPass ? _obscure : false,
      style: const TextStyle(color: _C.white, fontSize: 15),
      validator: (v) => (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: _C.grey, fontSize: 13),
        prefixIcon: Icon(icon, color: _C.red.withOpacity(0.7), size: 20),
        suffixIcon: isPass
            ? IconButton(
                icon: Icon(
                  _obscure ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                  color: _C.greyDark, size: 18,
                ),
                onPressed: () => setState(() => _obscure = !_obscure),
              )
            : null,
        filled: true,
        fillColor: _C.input,
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: _C.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: _C.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: _C.red, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Colors.redAccent),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Colors.redAccent),
        ),
      ),
    );
  }

  Widget _loginBtn() {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_C.red, _C.redDark],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(color: _C.redGlow, blurRadius: 16, offset: const Offset(0, 6)),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: _loading ? null : _login,
            borderRadius: BorderRadius.circular(14),
            splashColor: Colors.white12,
            child: Center(
              child: _loading
                  ? const SizedBox(
                      width: 22, height: 22,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        valueColor: AlwaysStoppedAnimation(_C.white),
                      ),
                    )
                  : const Text(
                      'SIGN IN',
                      style: TextStyle(
                        color: _C.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 2.5,
                        fontFamily: 'Orbitron',
                      ),
                    ),
            ),
          ),
        ),
      ),
    );
  }
}
