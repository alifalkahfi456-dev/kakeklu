import 'package:flutter/material.dart';

class NabiPage extends StatelessWidget {
  const NabiPage({super.key});

  final Color primaryBg = const Color(0xFF080C12);
  final Color cardBg = const Color(0xFF0D1520);
  final Color panelBg = const Color(0xFF0A1018);
  final Color cyanAccent = const Color(0xFF00E5FF);
  final Color cyanDim = const Color(0xFF0097A7);
  final Color textWhite = Colors.white;
  final Color textGrey = const Color(0xFF607D8B);
  final Color borderGlass = const Color(0xFF1A3A4A);
  final Color gold = const Color(0xFFFFD600);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryBg,
      appBar: AppBar(
        backgroundColor: cardBg,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: cyanAccent, size: 22),
          onPressed: () => Navigator.pop(context),
        ),
        title: ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [Color(0xFF00E5FF), Color(0xFF00BCD4)],
          ).createShader(bounds),
          child: Text(
            "25 NABI & RASUL",
            style: TextStyle(
              color: textWhite,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: "Orbitron",
              letterSpacing: 2,
            ),
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            margin: const EdgeInsets.only(bottom: 16),
            decoration: BoxDecoration(
              color: cyanAccent.withOpacity(0.05),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: cyanAccent.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Icon(Icons.info_outline, color: cyanAccent, size: 20),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    "25 Nabi yang wajib diketahui",
                    style: TextStyle(
                      color: cyanAccent,
                      fontSize: 12,
                      fontFamily: "ShareTechMono",
                    ),
                  ),
                ),
              ],
            ),
          ),
          ..._buildNabiList(),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  List<Widget> _buildNabiList() {
    final List<Nabi> nabiList = [
      const Nabi(
        nama: "Adam AS",
        namaLain: "Adam",
        tempatTurun: "Surga / India",
        umur: "930 tahun",
        keturunan: "Syahdan Habil Qabil dan Seth",
        mukjizat: "Diciptakan langsung oleh Allah dari tanah",
        kisah: "Manusia pertama yang diciptakan Allah dari tanah, kemudian ditiupkan ruh. Beliau tinggal di surga sebelum diturunkan ke bumi karena memakan buah khuldi.",
      ),
      const Nabi(
        nama: "Idris AS",
        namaLain: "Enoch",
        tempatTurun: "Irak (Babylon)",
        umur: "365 tahun",
        keturunan: "Methuselah",
        mukjizat: "Pandai menjahit dan menulis, diajarkan ilmu falak dan perbintangan",
        kisah: "Orang pertama yang pandai menulis dan menjahit. Beliau diangkat ke derajat yang tinggi oleh Allah.",
      ),
      const Nabi(
        nama: "Nuh AS",
        namaLain: "Noah",
        tempatTurun: "Irak (Kufah)",
        umur: "950 tahun",
        keturunan: "Sam Ham Yafits",
        mukjizat: "Membuat kapal besar (bahtera)",
        kisah: "Membangun bahtera atas perintah Allah untuk menyelamatkan umat yang beriman dari banjir bandang.",
      ),
      const Nabi(
        nama: "Hud AS",
        namaLain: "Eber",
        tempatTurun: "Yaman (Ahqaf)",
        umur: "465 tahun",
        keturunan: "Shalih",
        mukjizat: "Dilindungi Allah dari angin topan yang dahsyat",
        kisah: "Diutus kepada kaum Aad yang sombong dan kuat, mereka dibinasakan dengan angin topan yang sangat dingin.",
      ),
      const Nabi(
        nama: "Shalih AS",
        namaLain: "Shelah",
        tempatTurun: "Madain Shalih (Arab Saudi)",
        umur: "586 tahun",
        keturunan: "Hud",
        mukjizat: "Mengeluarkan unta betina dari batu karang",
        kisah: "Diutus kepada kaum Tsamud. Allah mengirimkan unta betina sebagai mukjizat, namun kaumnya membunuh unta tersebut dan akhirnya dibinasakan.",
      ),
      const Nabi(
        nama: "Ibrahim AS",
        namaLain: "Abraham",
        tempatTurun: "Irak (Babilonia)",
        umur: "175 tahun",
        keturunan: "Ismail dan Ishaq",
        mukjizat: "Tidak terbakar oleh api, menghidupkan burung yang telah dipotong",
        kisah: "Khalilullah (kekasih Allah). Beliau tidak terbakar saat dilempar ke api oleh Raja Namrud. Membangun Kaabah bersama putranya Ismail.",
      ),
      const Nabi(
        nama: "Luth AS",
        namaLain: "Lot",
        tempatTurun: "Sodom (Palestina)",
        umur: "80 tahun",
        keturunan: "-",
        mukjizat: "Diselamatkan dari azab yang menimpa kaumnya",
        kisah: "Keponakan Nabi Ibrahim. Diutus kepada kaum Sodom yang melakukan perbuatan homoseksual. Kaumnya dibinasakan dengan hujan batu.",
      ),
      const Nabi(
        nama: "Ismail AS",
        namaLain: "Ishmael",
        tempatTurun: "Makkah (Arab Saudi)",
        umur: "137 tahun",
        keturunan: "Nabit dan Qidar",
        mukjizat: "Mata air zam-zam memancar dari injakan kakinya",
        kisah: "Putra Nabi Ibrahim. Hampir disembelih oleh ayahnya namun diganti dengan seekor domba. Menjadi cikal bakal bangsa Arab.",
      ),
      const Nabi(
        nama: "Ishaq AS",
        namaLain: "Isaac",
        tempatTurun: "Palestina",
        umur: "180 tahun",
        keturunan: "Yaqub",
        mukjizat: "Dilahirkan dari ibu yang mandul dan ayah yang sudah tua",
        kisah: "Putra Nabi Ibrahim dari istrinya Sarah. Ayah dari Nabi Yaqub. Beliau dianugerahi Allah sebagai nabi di Palestina.",
      ),
      const Nabi(
        nama: "Yaqub AS",
        namaLain: "Jacob",
        tempatTurun: "Palestina (Kanaan)",
        umur: "147 tahun",
        keturunan: "12 orang putra (termasuk Yusuf)",
        mukjizat: "Dapat menafsirkan mimpi",
        kisah: "Putra Nabi Ishaq. Cucu Nabi Ibrahim. Beliau dikenal dengan nama Israil (hamba Allah) yang menjadi asal nama Bani Israil.",
      ),
      const Nabi(
        nama: "Yusuf AS",
        namaLain: "Joseph",
        tempatTurun: "Mesir",
        umur: "110 tahun",
        keturunan: "Afraim dan Mansyah",
        mukjizat: "Mampu menafsirkan mimpi",
        kisah: "Putra Nabi Yaqub yang tampan dan dibenci saudara-saudaranya. Menjabat sebagai bendahara Mesir setelah melalui berbagai cobaan.",
      ),
      const Nabi(
        nama: "Ayyub AS",
        namaLain: "Job",
        tempatTurun: "Syria",
        umur: "93 tahun",
        keturunan: "-",
        mukjizat: "Kesabarannya yang luar biasa, disembuhkan dari penyakit kulit",
        kisah: "Nabi yang sangat sabar menghadapi cobaan, diuji dengan kehilangan harta, anak, dan penyakit kulit yang parah.",
      ),
      const Nabi(
        nama: "Syuaib AS",
        namaLain: "Jethro",
        tempatTurun: "Madyan (Yordania)",
        umur: "882 tahun",
        keturunan: "-",
        mukjizat: "Diberikan ilmu pidato yang sangat baik",
        kisah: "Diutus kepada kaum Madyan yang suka mengurangi takaran dan timbangan. Beliau adalah mertua Nabi Musa.",
      ),
      const Nabi(
        nama: "Musa AS",
        namaLain: "Moses",
        tempatTurun: "Mesir",
        umur: "120 tahun",
        keturunan: "Harun",
        mukjizat: "Tongkat menjadi ular, tangan bercahaya, membelah laut",
        kisah: "Kalimullah (yang diajak bicara langsung oleh Allah). Memimpin Bani Israil keluar dari Mesir melawan Firaun.",
      ),
      const Nabi(
        nama: "Harun AS",
        namaLain: "Aaron",
        tempatTurun: "Mesir",
        umur: "123 tahun",
        keturunan: "-",
        mukjizat: "Tongkat menjadi ular",
        kisah: "Saudara Nabi Musa yang diangkat menjadi nabi untuk membantu dakwah Nabi Musa. Beliau lebih pandai berbicara.",
      ),
      const Nabi(
        nama: "Dzulkifli AS",
        namaLain: "Ezekiel",
        tempatTurun: "Irak",
        umur: "75 tahun",
        keturunan: "-",
        mukjizat: "Kesabarannya dalam beribadah",
        kisah: "Dikenal sebagai orang yang sangat sabar dan bertanggung jawab. Beliau rela berpuasa di siang hari dan shalat di malam hari.",
      ),
      const Nabi(
        nama: "Daud AS",
        namaLain: "David",
        tempatTurun: "Palestina",
        umur: "100 tahun",
        keturunan: "Sulaiman",
        mukjizat: "Mampu melunakkan besi, suara merdu saat membaca Zabur",
        kisah: "Dianugerahi kitab Zabur. Beliau juga seorang raja yang adil dan mampu mengalahkan raksasa Jalut.",
      ),
      const Nabi(
        nama: "Sulaiman AS",
        namaLain: "Solomon",
        tempatTurun: "Palestina",
        umur: "52 tahun",
        keturunan: "Rehabeam",
        mukjizat: "Memahami bahasa hewan, menguasai angin dan jin",
        kisah: "Putra Nabi Daud. Beliau diberi kekuasaan yang luar biasa, mampu berbicara dengan burung dan semut, serta memerintah jin.",
      ),
      const Nabi(
        nama: "Ilyas AS",
        namaLain: "Elijah",
        tempatTurun: "Palestina (Balabak)",
        umur: "60 tahun",
        keturunan: "-",
        mukjizat: "Menurunkan hujan setelah doanya",
        kisah: "Diutus kepada kaum Balabak yang menyembah berhala Baal. Beliau dinaikkan ke langit dengan kuda berapi.",
      ),
      const Nabi(
        nama: "Ilyasa AS",
        namaLain: "Elisha",
        tempatTurun: "Palestina",
        umur: "90 tahun",
        keturunan: "-",
        mukjizat: "Menyembuhkan orang sakit",
        kisah: "Penerus dakwah Nabi Ilyas. Beliau melanjutkan tugas kenabian setelah Nabi Ilyas diangkat ke langit.",
      ),
      const Nabi(
        nama: "Yunus AS",
        namaLain: "Jonah",
        tempatTurun: "Irak (Ninewe)",
        umur: "70 tahun",
        keturunan: "-",
        mukjizat: "Selamat dari perut ikan paus setelah 40 hari",
        kisah: "Meninggalkan tugasnya tanpa izin Allah, kemudian ditelan ikan paus besar. Beliau berdoa dalam kegelapan dan akhirnya diselamatkan.",
      ),
      const Nabi(
        nama: "Zakariya AS",
        namaLain: "Zechariah",
        tempatTurun: "Palestina",
        umur: "150 tahun",
        keturunan: "Yahya",
        mukjizat: "Mendapat keturunan di usia sangat tua",
        kisah: "Ayah dari Nabi Yahya. Beliau memohon keturunan meskipun usianya sudah sangat tua dan istrinya mandul.",
      ),
      const Nabi(
        nama: "Yahya AS",
        namaLain: "John the Baptist",
        tempatTurun: "Palestina",
        umur: "30 tahun",
        keturunan: "-",
        mukjizat: "Mendapat kitab Taurat sejak kecil",
        kisah: "Putra Nabi Zakariya. Beliau dijuluki sebagai pemuda yang cerdas dan bijak. Wafat karena dipenggal kepala atas perintah penguasa zalim.",
      ),
      const Nabi(
        nama: "Isa AS",
        namaLain: "Jesus",
        tempatTurun: "Palestina (Betlehem)",
        umur: "33 tahun",
        keturunan: "-",
        mukjizat: "Dilahirkan tanpa ayah, menyembuhkan buta dan kusta, menghidupkan orang mati",
        kisah: "Al-Masih. Dilahirkan dari perawan suci Maryam. Beliau diangkat ke langit oleh Allah dan tidak dibunuh oleh musuh-musuhnya.",
      ),
      const Nabi(
        nama: "Muhammad SAW",
        namaLain: "Ahmad",
        tempatTurun: "Makkah (Arab Saudi)",
        umur: "63 tahun",
        keturunan: "Qasim, Abdullah, Ibrahim, Zainab, Ruqayyah, Ummu Kultsum, Fatimah",
        mukjizat: "Al-Quran, Isra Miraj, membelah bulan",
        kisah: "Nabi terakhir dan penutup para nabi. Lahir di Makkah, menerima wahyu Al-Quran melalui perantara Malaikat Jibril. Membawa risalah Islam untuk seluruh alam.",
      ),
    ];

    return nabiList.map((nabi) {
      return Container(
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
          color: cardBg,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: borderGlass, width: 1.5),
          boxShadow: [
            BoxShadow(
              color: cyanAccent.withOpacity(0.05),
              blurRadius: 12,
              spreadRadius: 1,
            ),
          ],
        ),
        child: ExpansionTile(
          iconColor: cyanAccent,
          collapsedIconColor: cyanAccent.withOpacity(0.7),
          collapsedTextColor: textGrey,
          textColor: gold,
          backgroundColor: cardBg,
          collapsedBackgroundColor: cardBg,
          leading: Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: cyanAccent.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: cyanAccent.withOpacity(0.5)),
            ),
            child: Center(
              child: Text(
                nabi.nama[0],
                style: TextStyle(
                  color: cyanAccent,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: "Orbitron",
                ),
              ),
            ),
          ),
          title: Text(
            nabi.nama,
            style: TextStyle(
              fontFamily: "Orbitron",
              color: gold,
              letterSpacing: 1.2,
              fontWeight: FontWeight.w500,
              fontSize: 14,
            ),
          ),
          subtitle: Text(
            nabi.tempatTurun,
            style: TextStyle(
              fontSize: 10,
              color: textGrey,
              fontFamily: "ShareTechMono",
            ),
          ),
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildDetailSection(
                    icon: Icons.person_outline,
                    label: "Nama Lain",
                    value: nabi.namaLain,
                  ),
                  const SizedBox(height: 12),
                  _buildDetailSection(
                    icon: Icons.location_on_outlined,
                    label: "Tempat Turun",
                    value: nabi.tempatTurun,
                  ),
                  const SizedBox(height: 12),
                  _buildDetailSection(
                    icon: Icons.cake_outlined,
                    label: "Umur",
                    value: nabi.umur,
                  ),
                  const SizedBox(height: 12),
                  _buildDetailSection(
                    icon: Icons.family_restroom,
                    label: "Keturunan",
                    value: nabi.keturunan,
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: panelBg,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: borderGlass, width: 1),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.star, color: cyanAccent, size: 16),
                            const SizedBox(width: 6),
                            Text(
                              "MUKJIZAT",
                              style: TextStyle(
                                fontSize: 11,
                                color: cyanAccent,
                                fontFamily: "Orbitron",
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                          nabi.mukjizat,
                          style: TextStyle(
                            fontSize: 12,
                            color: textGrey,
                            fontFamily: "ShareTechMono",
                            height: 1.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: panelBg,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: borderGlass, width: 1),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.history_edu, color: gold, size: 16),
                            const SizedBox(width: 6),
                            Text(
                              "KISAH SINGKAT",
                              style: TextStyle(
                                fontSize: 11,
                                color: gold,
                                fontFamily: "Orbitron",
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                          nabi.kisah,
                          style: TextStyle(
                            fontSize: 12,
                            color: textGrey,
                            fontFamily: "ShareTechMono",
                            height: 1.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Divider(color: borderGlass, thickness: 1),
                ],
              ),
            ),
          ],
        ),
      );
    }).toList();
  }

  Widget _buildDetailSection({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: panelBg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderGlass, width: 1),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: cyanAccent, size: 18),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 10,
                    color: cyanAccent.withOpacity(0.7),
                    fontFamily: "Orbitron",
                    letterSpacing: 0.8,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 13,
                    color: textWhite,
                    fontFamily: "ShareTechMono",
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class Nabi {
  final String nama;
  final String namaLain;
  final String tempatTurun;
  final String umur;
  final String keturunan;
  final String mukjizat;
  final String kisah;

  const Nabi({
    required this.nama,
    required this.namaLain,
    required this.tempatTurun,
    required this.umur,
    required this.keturunan,
    required this.mukjizat,
    required this.kisah,
  });
}