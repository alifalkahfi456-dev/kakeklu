import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

/// ═══════════════════════════════════════════════
///  API CONFIG SERVICE — Semua IP/URL terpusat
/// ═══════════════════════════════════════════════

class AppUrls {
  // ── Server Utama ────────────────────────────────
  static const String mainServer     = 'http://ridhooffc.sano.biz.id:10216';
  static const String wsServer       = 'ws://152.42.192.192:25565';

  // ── Endpoint Shop ───────────────────────────────
  static const String shopProducts   = '$mainServer/shop/products';
  static const String shopMyProducts = '$mainServer/shop/myProducts';
  static const String shopAdd        = '$mainServer/shop/addProduct';
  static const String shopDelete     = '$mainServer/shop/deleteProduct';
  static const String shopImages     = '$mainServer/uploads/shop';

  // ── Endpoint Chat Privat (Shop) ─────────────────
  static const String chatPrivate    = '$mainServer/shop/chat';
  static const String chatHistory    = '$mainServer/shop/chatHistory';
  static const String chatInbox      = '$mainServer/shop/inbox';
  static const String wsChatPrivate  = '$wsServer/shop/ws';

  // ── Endpoint Umum ───────────────────────────────
  static const String dashStats      = '$mainServer/api/dashboard-stats';
  static const String login          = '$mainServer/login';
  static const String register       = '$mainServer/register';
  static const String userProfile    = '$mainServer/profile';
  static const String changePassword = '$mainServer/change-password';
  static const String bugReport      = '$mainServer/bug';
  static const String publicChat     = '$mainServer/chat';
  static const String news           = '$mainServer/news';

  // ── GitHub Gist (config dinamis) ────────────────
  static const String gistConfig =
      'https://gist.github.com/naxrat999-ui/6af45faa52cfbb8c3f247409cb216335/raw/20d9dd2e540405298a497c8a3a2aa26a92a2fe35/config.json';
}

class ApiConfigService {
  static final ApiConfigService _instance = ApiConfigService._internal();
  factory ApiConfigService() => _instance;
  ApiConfigService._internal();

  static const Map<String, String> _requestHeaders = {
    'User-Agent': 'NBL-App/1.0',
    'Accept': 'application/json',
    'Cache-Control': 'no-cache',
  };

  static const String _prefKeyBaseUrl    = 'cached_base_url';
  static const String _prefKeyUrlRat     = 'cached_url_rat';
  static const String _prefKeyLastUpdate = 'last_update_timestamp';

  String? _cachedBaseUrl;
  String? _cachedUrlRat;
  bool    _isLoading = false;

  Future<String> getBaseUrl() async {
    if (_cachedBaseUrl != null && _cachedBaseUrl!.isNotEmpty) return _cachedBaseUrl!;
    final prefs = await SharedPreferences.getInstance();
    final cachedUrl = prefs.getString(_prefKeyBaseUrl);
    if (cachedUrl != null && cachedUrl.isNotEmpty) {
      _cachedBaseUrl = cachedUrl;
      _fetchAndUpdateInBackground();
      return cachedUrl;
    }
    return await fetchBaseUrl();
  }

  Future<String?> getUrlRat() async {
    if (_cachedUrlRat != null) return _cachedUrlRat;
    final prefs = await SharedPreferences.getInstance();
    final cached = prefs.getString(_prefKeyUrlRat);
    if (cached != null) { _cachedUrlRat = cached; return cached; }
    await getBaseUrl();
    return _cachedUrlRat;
  }

  Future<String> fetchBaseUrl() async {
    if (_isLoading) {
      while (_isLoading) await Future.delayed(const Duration(milliseconds: 100));
      return _cachedBaseUrl ?? await fetchBaseUrl();
    }
    _isLoading = true;
    try {
      final response = await http
          .get(Uri.parse(AppUrls.gistConfig), headers: _requestHeaders)
          .timeout(const Duration(seconds: 15));
      if (response.statusCode == 200) {
        final jsonData   = jsonDecode(response.body);
        final activeUrl  = jsonData['url_aktif'] as String?;
        final urlRat     = jsonData['url_rat']   as String?;
        if (activeUrl != null && activeUrl.isNotEmpty) {
          await _saveToCache(activeUrl, urlRat);
          _cachedBaseUrl = activeUrl;
          _cachedUrlRat  = urlRat;
          _isLoading = false;
          return activeUrl;
        } else {
          throw Exception('Field "url_aktif" kosong');
        }
      } else {
        throw Exception('HTTP ${response.statusCode}');
      }
    } catch (e) {
      _isLoading = false;
      final cachedUrl = await _getCachedUrl();
      if (cachedUrl != null) {
        _cachedBaseUrl = cachedUrl;
        final prefs = await SharedPreferences.getInstance();
        _cachedUrlRat = prefs.getString(_prefKeyUrlRat);
        return cachedUrl;
      }
      // Fallback ke server utama
      _cachedBaseUrl = AppUrls.mainServer;
      return AppUrls.mainServer;
    }
  }

  Future<void> _fetchAndUpdateInBackground() async {
    try {
      final response = await http
          .get(Uri.parse(AppUrls.gistConfig), headers: _requestHeaders)
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final jsonData  = jsonDecode(response.body);
        final activeUrl = jsonData['url_aktif'] as String?;
        final urlRat    = jsonData['url_rat']   as String?;
        if (activeUrl != null && activeUrl.isNotEmpty) {
          await _saveToCache(activeUrl, urlRat);
          _cachedBaseUrl = activeUrl;
          _cachedUrlRat  = urlRat;
        }
      }
    } catch (_) {}
  }

  Future<void> _saveToCache(String url, String? urlRat) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefKeyBaseUrl, url);
    if (urlRat != null) await prefs.setString(_prefKeyUrlRat, urlRat);
    await prefs.setInt(_prefKeyLastUpdate, DateTime.now().millisecondsSinceEpoch);
  }

  Future<String?> _getCachedUrl() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_prefKeyBaseUrl);
  }

  Future<String>  forceRefresh() async { _cachedBaseUrl = null; _cachedUrlRat = null; return await fetchBaseUrl(); }
  Future<void>    clearCache()   async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_prefKeyBaseUrl);
    await prefs.remove(_prefKeyUrlRat);
    await prefs.remove(_prefKeyLastUpdate);
    _cachedBaseUrl = null; _cachedUrlRat = null;
  }
  Future<DateTime?> getLastUpdateTime() async {
    final prefs = await SharedPreferences.getInstance();
    final ts = prefs.getInt(_prefKeyLastUpdate);
    return ts != null ? DateTime.fromMillisecondsSinceEpoch(ts) : null;
  }
  Future<bool> shouldUpdate() async {
    final last = await getLastUpdateTime();
    if (last == null) return true;
    return DateTime.now().difference(last).inHours >= 1;
  }
}

class ApiConfig {
  static final ApiConfigService _service = ApiConfigService();
  static Future<String>  get baseUrl => _service.getBaseUrl();
  static Future<String?> get urlRat  => _service.getUrlRat();
  static Future<String>  refresh()   => _service.forceRefresh();
  static Future<void>    clearCache() => _service.clearCache();
}
