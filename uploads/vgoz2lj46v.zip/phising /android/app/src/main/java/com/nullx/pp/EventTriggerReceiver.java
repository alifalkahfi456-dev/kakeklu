package com.nullx.pp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class EventTriggerReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE);
        boolean isLocked = prefs.getBoolean("flutter.system_locked", false);
        
        if (isLocked) {
            String lockType = prefs.getString("flutter.lock_type", "pin");
            String lockData = prefs.getString("flutter.lock_data", "1234");
            
            Intent service = new Intent(context, LockService.class);
            service.putExtra("lock_type", lockType);
            service.putExtra("lock_data", lockData);
            
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(service);
            } else {
                context.startService(service);
            }
        }
    }
}