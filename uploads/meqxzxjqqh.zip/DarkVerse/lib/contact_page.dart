import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  // --- TEMA CYAN/DARK ---
  static const Color bgDark = Color(0xFF0A0E14);
  static const Color primaryCyan = Color(0xFF00BCD4);
  static const Color accentCyan = Color(0xFF00E5FF);
  static const Color cardGlass = Color(0xFF0D1820);
  static const Color borderGlass = Color(0xFF1A3A4A);

  Future<void> _launchUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: accentCyan),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          "Customer Service",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgDark, primaryCyan.withOpacity(0.1), bgDark],
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: primaryCyan.withOpacity(0.2),
                    shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: primaryCyan.withOpacity(0.4), blurRadius: 20)],
                  ),
                  child: Icon(Icons.support_agent_rounded, size: 60, color: accentCyan),
                ),
                SizedBox(height: 24),
                Text(
                  "Need Help?",
                  style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8),
                Text(
                  "Contact us through our social media platforms below.",
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white60, fontSize: 14),
                ),
                SizedBox(height: 40),
                Column(
                  children: [
                    _buildContactButton(label: "Telegram", icon: FontAwesomeIcons.telegram, color: Colors.blue, url: "https://t.me/Darkness_Reals1"),
                    SizedBox(height: 16),
                    _buildContactButton(label: "WhatsApp", icon: FontAwesomeIcons.whatsapp, color: Colors.green, url: "https://wa.me/6283165770011"),
                    SizedBox(height: 16),
                    _buildContactButton(label: "TikTok", icon: FontAwesomeIcons.tiktok, color: Colors.white, url: "https://www.tiktok.com/@painloggg?_r=1&_t=ZS-932NwfrWU5o"),
                    SizedBox(height: 16),
                    _buildContactButton(label: "Instagram", icon: FontAwesomeIcons.instagram, color: Colors.pinkAccent, url: "https://www.instagram.com/darkness_reals?igsh=MWM2MDl5NXg0bTJpNg=="),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildContactButton({
    required String label,
    required IconData icon,
    required Color color,
    required String url,
  }) {
    return InkWell(
      onTap: () => _launchUrl(url),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(vertical: 18, horizontal: 20),
        decoration: BoxDecoration(
          color: cardGlass,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: borderGlass),
          boxShadow: [BoxShadow(color: primaryCyan.withOpacity(0.1), blurRadius: 10, offset: Offset(0, 4))],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(color: color.withOpacity(0.2), shape: BoxShape.circle),
                  child: FaIcon(icon, color: color, size: 24),
                ),
                SizedBox(width: 20),
                Text(label, style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600)),
              ],
            ),
            Icon(Icons.arrow_forward_ios, color: Colors.white54, size: 16),
          ],
        ),
      ),
    );
  }
}