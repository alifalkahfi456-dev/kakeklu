import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _fadeController;
  late AnimationController _pulseController;
  String selectedBugId = "";

  String _selectedBugMode = "number";

  bool _isSending = false;
  String? _responseMessage;
  String _selectedSender = "private"; // "private" or "global"

  // Sender stats
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  Timer? _statsTimer;

  // ─── Cyber Dark Navy Theme (sesuai screenshot) ───────────────────────────
  final Color primaryBg  = const Color(0xFF080C12);
  final Color cardBg     = const Color(0xFF0D1520);
  final Color panelBg    = const Color(0xFF0A1018);
  final Color cyanAccent = const Color(0xFF00E5FF);
  final Color cyanDim    = const Color(0xFF0097A7);
  final Color redAccent  = const Color(0xFFE53935);
  final Color textWhite  = Colors.white;
  final Color textGrey   = const Color(0xFF607D8B);

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    if (widget.listBug.isNotEmpty) {
      final numberBugs = widget.listBug.where((b) => b['bug_name'] != null).toList();
      selectedBugId = numberBugs.isNotEmpty ? numberBugs[0]['bug_id'] : widget.listBug[0]['bug_id'];
    }

    // Fetch sender stats
    _fetchSenderStats();
    
    // Refresh stats every 30 seconds
    _statsTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
      _fetchSenderStats();
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _pulseController.dispose();
    targetController.dispose();
    _statsTimer?.cancel();
    super.dispose();
  }

  // ─── Fetch Sender Stats from API ─────────────────────────────────────────
  Future<void> _fetchSenderStats() async {
    try {
      final response = await http.get(
        Uri.parse("http://fourzprivat.servervoidvitality.my.id:3371/getSenderStats?key=${widget.sessionKey}")
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
          });
        }
      }
    } catch (e) {
      print("Error fetching sender stats: $e");
    }
  }

  // ─── Helpers ─────────────────────────────────────────────────────────────
  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) =>
      input.contains('chat.whatsapp.com') && input.contains('https://');

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert(
            "❌ Invalid Number",
            "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert(
            "❌ Invalid Link",
            "Masukkan link group WA yang valid (contoh: https://chat.whatsapp.com/...).");
        return;
      }
    }

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });

    try {
      final res = await http.get(Uri.parse(
          "http://fourzprivat.servervoidvitality.my.id:3371/sendBug?key=$key&target=$rawInput&bug=$selectedBugId&sender=$_selectedSender"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        setState(() => _responseMessage = "⏳ Cooldown: Tunggu beberapa saat.");
      } else if (data["valid"] == false) {
        setState(() => _responseMessage = "❌ Key Invalid: Silakan login ulang.");
      } else if (data["sended"] == false) {
        setState(() => _responseMessage = "⚠️ Gagal: Server sedang maintenance.");
      } else {
        setState(() => _responseMessage = "✅ Berhasil mengirim bug!");
        targetController.clear();
      }
    } catch (_) {
      setState(() => _responseMessage = "❌ Error: Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() => _isSending = false);
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardBg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: cyanAccent.withOpacity(0.4)),
        ),
        title: Text(title,
            style: TextStyle(
              color: cyanAccent,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.bold,
            )),
        content: Text(msg,
            style: const TextStyle(
                color: Colors.grey, fontFamily: 'ShareTechMono')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK",
                style: TextStyle(
                    color: cyanAccent, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  // ─── HEADER PANEL ── sesuai Gambar 1 ─────────────────────────────────────
  Widget _buildHeaderPanel() {
    return AnimatedBuilder(
      animation: _fadeController,
      builder: (context, _) {
        return Container(
          padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 24),
          decoration: BoxDecoration(
            color: const Color(0xFF0B1320),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: cyanAccent
                  .withOpacity(0.20 + _fadeController.value * 0.15),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: cyanAccent.withOpacity(0.06),
                blurRadius: 24,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 34,
                    height: 34,
                    child: CustomPaint(
                      painter: _PixelBugPainter(color: redAccent),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Text(
                    "WHATSAPP CRASH",
                    style: TextStyle(
                      color: textWhite,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: 20,
                      letterSpacing: 2.5,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                "Advanced Payload Injection Tool",
                style: TextStyle(
                  color: cyanAccent
                      .withOpacity(0.65 + _fadeController.value * 0.35),
                  fontFamily: 'ShareTechMono',
                  fontSize: 12.5,
                  letterSpacing: 1.4,
                ),
              ),
              const SizedBox(height: 18),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 30, vertical: 9),
                decoration: BoxDecoration(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(
                    color: cyanAccent.withOpacity(0.6),
                    width: 1.5,
                  ),
                ),
                child: Text(
                  widget.role.toUpperCase(),
                  style: TextStyle(
                    color: textWhite,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                    letterSpacing: 3,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ─── MODE SELECTOR ── sesuai Gambar 2 ────────────────────────────────────
  Widget _buildModeSelector() {
    return Row(
      children: [
        Expanded(
            child: _buildModeButton(
                "number", Icons.phone_android_rounded, "BUG NOMOR")),
        const SizedBox(width: 14),
        Expanded(child: _buildModeButton("group", Icons.group_add, "BUG GROUP")),
      ],
    );
  }

  Widget _buildModeButton(String mode, IconData icon, String label) {
    final bool isSelected = _selectedBugMode == mode;
    return GestureDetector(
      onTap: () => setState(() {
        _selectedBugMode = mode;
        targetController.clear();
        final filtered = widget.listBug.where((bug) =>
            mode == "group" ? bug['bug_gb'] != null : bug['bug_name'] != null).toList();
        selectedBugId = filtered.isNotEmpty ? filtered[0]['bug_id'] : "";
      }),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: isSelected
              ? const Color(0xFF0C2233)
              : const Color(0xFF0D1520),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected ? cyanAccent : const Color(0xFF1A2A3A),
            width: isSelected ? 2 : 1.5,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: cyanAccent.withOpacity(0.15),
                    blurRadius: 14,
                    spreadRadius: 1,
                  )
                ]
              : [],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon,
                color: isSelected ? cyanAccent : textGrey, size: 20),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: isSelected ? cyanAccent : textGrey,
                fontWeight: FontWeight.bold,
                fontSize: 13,
                fontFamily: 'Orbitron',
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── INPUT PANEL ── sesuai Gambar 2 ──────────────────────────────────────
  Widget _buildInputPanel() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildModeSelector(),
        const SizedBox(height: 28),

        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Text(
            _selectedBugMode == "number" ? "NOMOR TARGET" : "LINK GROUP WA",
            style: TextStyle(
              color: textWhite,
              fontWeight: FontWeight.w700,
              fontSize: 12,
              fontFamily: 'Orbitron',
              letterSpacing: 2,
            ),
          ),
        ),

        Container(
          decoration: BoxDecoration(
            color: const Color(0xFF0D1520),
            borderRadius: BorderRadius.circular(14),
            border:
                Border.all(color: const Color(0xFF1A2A3A), width: 1.5),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(0.4),
                  blurRadius: 8,
                  offset: const Offset(0, 4)),
            ],
          ),
          child: TextField(
            controller: targetController,
            style: TextStyle(
                color: textWhite,
                fontSize: 14,
                fontFamily: 'ShareTechMono'),
            cursorColor: cyanAccent,
            keyboardType: _selectedBugMode == "number"
                ? TextInputType.phone
                : TextInputType.url,
            decoration: InputDecoration(
              hintText: _selectedBugMode == "number"
                  ? "Contoh: +62xxxxxxxxxx"
                  : "Contoh: https://chat.whatsapp.com/...",
              hintStyle: TextStyle(
                  color: textGrey.withOpacity(0.55),
                  fontFamily: 'ShareTechMono'),
              filled: true,
              fillColor: Colors.transparent,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide:
                    BorderSide(color: cyanAccent.withOpacity(0.5), width: 1.5),
              ),
              prefixIcon: Icon(
                _selectedBugMode == "number"
                    ? Icons.phone_android_rounded
                    : Icons.link,
                color: cyanAccent,
              ),
              contentPadding:
                  const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
            ),
          ),
        ),

        const SizedBox(height: 28),

        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Text(
            "PILIH ENGINE BUG",
            style: TextStyle(
              color: textWhite,
              fontWeight: FontWeight.w700,
              fontSize: 12,
              fontFamily: 'Orbitron',
              letterSpacing: 2,
            ),
          ),
        ),

        Container(
          padding: const EdgeInsets.symmetric(horizontal: 18),
          decoration: BoxDecoration(
            color: const Color(0xFF0D1520),
            borderRadius: BorderRadius.circular(14),
            border:
                Border.all(color: const Color(0xFF1A2A3A), width: 1.5),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              dropdownColor: const Color(0xFF0D1520),
              value: selectedBugId.isNotEmpty ? selectedBugId : null,
              isExpanded: true,
              iconEnabledColor: cyanAccent,
              iconSize: 26,
              style: TextStyle(
                  color: textWhite,
                  fontSize: 14,
                  fontFamily: 'ShareTechMono'),
              items: widget.listBug.where((bug) {
                if (_selectedBugMode == "group") {
                  return bug['bug_gb'] != null;
                } else {
                  return bug['bug_name'] != null;
                }
              }).map((bug) {
                final displayName = _selectedBugMode == "group"
                    ? bug['bug_gb']
                    : bug['bug_name'];
                return DropdownMenuItem<String>(
                  value: bug['bug_id'],
                  child: Row(
                    children: [
                      Container(
                        width: 18,
                        height: 18,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: cyanAccent.withOpacity(0.5), width: 1.5),
                          color: cyanAccent.withOpacity(0.08),
                        ),
                        child: Center(
                          child: Icon(Icons.close,
                              color: cyanAccent, size: 10),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text(
                        displayName,
                        style: TextStyle(
                            color: textWhite,
                            fontFamily: 'ShareTechMono',
                            fontSize: 14),
                      ),
                    ],
                  ),
                );
              }).toList(),
              onChanged: (value) =>
                  setState(() => selectedBugId = value ?? ""),
            ),
          ),
        ),
      ],
    );
  }

  // ─── SENDER SELECTOR ─────────────────────────────────────────────────────
  Widget _buildSenderSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Text(
            "PILIH SENDER",
            style: TextStyle(
              color: textWhite,
              fontWeight: FontWeight.w700,
              fontSize: 12,
              fontFamily: 'Orbitron',
              letterSpacing: 2,
            ),
          ),
        ),
        Row(
          children: [
            Expanded(child: _buildSenderButton("private", "SENDER PRIVATE")),
            const SizedBox(width: 14),
            Expanded(child: _buildSenderButton("global", "SENDER GLOBAL")),
          ],
        ),
      ],
    );
  }

  Widget _buildSenderButton(String sender, String label) {
    final bool isSelected = _selectedSender == sender;
    
    // Get active count based on sender type
    int activeCount = sender == "private" ? _privateSenderCount : _globalSenderCount;
    
    return GestureDetector(
      onTap: () => setState(() => _selectedSender = sender),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: const EdgeInsets.symmetric(vertical: 18),
        decoration: BoxDecoration(
          color: isSelected
              ? const Color(0xFF061A22)
              : const Color(0xFF0D1520),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected ? cyanAccent : const Color(0xFF1A2A3A),
            width: isSelected ? 2 : 1.5,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: cyanAccent.withOpacity(0.18),
                    blurRadius: 16,
                    spreadRadius: 1,
                  )
                ]
              : [],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              label,
              style: TextStyle(
                color: isSelected ? cyanAccent : textGrey,
                fontWeight: FontWeight.bold,
                fontSize: 13,
                fontFamily: 'Orbitron',
                letterSpacing: 0.8,
              ),
            ),
            const SizedBox(height: 6),
            AnimatedBuilder(
              animation: _pulseController,
              builder: (context, _) {
                return Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 7,
                      height: 7,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isSelected
                            ? cyanAccent.withOpacity(
                                0.6 + _pulseController.value * 0.4)
                            : textGrey.withOpacity(0.4),
                        boxShadow: isSelected
                            ? [
                                BoxShadow(
                                  color: cyanAccent.withOpacity(0.5),
                                  blurRadius: 6,
                                )
                              ]
                            : [],
                      ),
                    ),
                    const SizedBox(width: 5),
                    Text(
                      "$activeCount Active",
                      style: TextStyle(
                        color: isSelected
                            ? cyanAccent.withOpacity(0.7)
                            : textGrey.withOpacity(0.5),
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  // ─── SEND BUTTON → "LAUNCH ATTACK" ── sesuai Gambar 3 ────────────────────
  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, _) {
        return Container(
          height: 62,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            color: const Color(0xFF0D1117),
            border: Border.all(
              color: redAccent
                  .withOpacity(0.6 + _pulseController.value * 0.4),
              width: 1.8,
            ),
            boxShadow: [
              BoxShadow(
                color: redAccent
                    .withOpacity(0.10 + _pulseController.value * 0.15),
                blurRadius: 22,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: _isSending ? null : _sendBug,
              child: Center(
                child: _isSending
                    ? SizedBox(
                        height: 24,
                        width: 24,
                        child: CircularProgressIndicator(
                          color: redAccent,
                          strokeWidth: 2.5,
                        ),
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.gps_fixed_rounded,
                              color: redAccent, size: 22),
                          const SizedBox(width: 14),
                          Text(
                            "LAUNCH ATTACK",
                            style: TextStyle(
                              color: textWhite,
                              fontWeight: FontWeight.w800,
                              fontSize: 16,
                              letterSpacing: 3.5,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();

    Color bgColor, borderColor, textColor;
    IconData icon;

    if (_responseMessage!.startsWith('✅')) {
      bgColor = Colors.green.withOpacity(0.1);
      borderColor = Colors.greenAccent;
      textColor = Colors.greenAccent;
      icon = Icons.check_circle_outline_rounded;
    } else if (_responseMessage!.startsWith('❌')) {
      bgColor = redAccent.withOpacity(0.1);
      borderColor = redAccent;
      textColor = redAccent;
      icon = Icons.error_outline_rounded;
    } else {
      bgColor = cyanAccent.withOpacity(0.07);
      borderColor = cyanAccent;
      textColor = cyanAccent;
      icon = Icons.info_outline_rounded;
    }

    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: borderColor.withOpacity(0.4), width: 1),
        ),
        child: Row(
          children: [
            Icon(icon, color: textColor, size: 22),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                _responseMessage!,
                style: TextStyle(
                  color: textColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryBg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              _buildHeaderPanel(),
              const SizedBox(height: 24),
              _buildInputPanel(),
              const SizedBox(height: 36),
              _buildSenderSelector(),
              const SizedBox(height: 20),
              _buildSendButton(),
              _buildResponseMessage(),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Pixel-art bug icon painter ────────────────────────────────────────────
class _PixelBugPainter extends CustomPainter {
  final Color color;
  const _PixelBugPainter({required this.color});

  static const List<List<int>> _grid = [
    [0, 0, 1, 1, 1, 1, 0, 0],
    [0, 1, 1, 1, 1, 1, 1, 0],
    [1, 1, 0, 1, 1, 0, 1, 1],
    [1, 1, 1, 1, 1, 1, 1, 1],
    [1, 1, 0, 1, 1, 0, 1, 1],
    [0, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 1, 0, 0, 1, 0, 0],
    [0, 0, 1, 0, 0, 1, 0, 0],
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color;
    final pw = size.width / 8;
    final ph = size.height / 8;

    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        if (_grid[r][c] == 1) {
          canvas.drawRect(
            Rect.fromLTWH(c * pw, r * ph, pw - 0.6, ph - 0.6),
            paint,
          );
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}