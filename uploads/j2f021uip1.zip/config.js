module.exports = {
  BOT_TOKEN: "8930601261:AAGrSxI0Cc4t6aM9RdcEmJIPLwHmfS7G9nQ",
  OWNER_ID: ["8669188963"],
  
  /// NGGAK TAU BUAT APA POKOK NYA BUAT START WINGS🗿🗿GK USH LU APA APAIN NIH BASH
  tokeninstall: "revan",
  bash: "bash <(curl https://raw.githubusercontent.com/zerodevxc/revan/refs/heads/main/install.sh)",
  
  // Domain Reseller Panel 
  domain: 'https://michie48.web.id', // domain
  plta: 'ptla_xAPdrf3d5cL9hONOmsL087BmSD5S4DEjSYvAC8ktVjc', // pltc reseller 
  pltc: 'ptlc_a2Vrl8Pe7wBwseYyfwf118oTsj6tJ1jAkwWtzD7Yjc3', // pltc reseller 
  
  // Domain Khusus Admin
  domainv2: 'domainlu', // domain
  pltav2: 'plta_abcdefghij', // plta khusus admin
  pltcv2: 'pltc_abcdefghij', // pltc khusus admin 
  
  loc: '1', // 
  eggs: '15'
};