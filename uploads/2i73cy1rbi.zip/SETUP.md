# Lumina Flutter App — Setup Guide

## Apa yang sudah dibuat

1. **`app/api/stream/route.js`** (backend, di project Lumina web)
   Endpoint baru `/api/stream?videoId=xxx` (atau `?title=&artist=`) yang resolve ke
   URL audio stream langsung pakai `ytmusic-api` + `@distube/ytdl-core`.

2. **`lib/nativeBridge.js`** (web)
   Helper JS untuk deteksi apakah jalan di dalam Flutter app, dan kirim
   command play/pause/seek/volume ke native player.

3. **`lumina_app/`** (project Flutter baru)
   - `lib/audio_handler.dart` — native background audio player (just_audio + audio_service)
   - `lib/main.dart` — WebView + JS bridge yang nyambungin web ↔ native audio
   - `android/app/src/main/AndroidManifest.xml` — permission foreground service

## Langkah selanjutnya

### 1. Backend (web Lumina)
```bash
cd Lumina-main
npm install
```
Lalu integrasikan `lib/nativeBridge.js` ke `app/page.jsx` — lihat komentar
di file tersebut untuk contoh pemakaian di `loadTrack()`.

Deploy ulang ke Vercel.

### 2. Flutter app
```bash
cd lumina_app
flutter pub get
flutter run        # test di device/emulator
flutter build apk  # build APK release
```

Pastikan ganti `kLuminaUrl` di `lib/main.dart` kalau domain berubah.

### 3. Generate icon Android (opsional)
Pakai `flutter_launcher_icons` dengan source `icon-512.png` dari project web.

## Catatan penting

- **Stream URL YouTube expire** (~5-6 jam). Untuk lagu yang lama di-pause,
  mungkin perlu re-fetch `/api/stream` sebelum resume jika error.
- **`@distube/ytdl-core`** kadang butuh update karena YouTube sering ubah
  internal API — pantau repo-nya untuk update rutin.
- Background audio sudah full native (notification + lock screen controls)
  via `audio_service`, lepas dari status WebView (background/suspended).
- Untuk iOS, perlu setup tambahan di `Info.plist` (background audio mode) —
  belum termasuk di scaffold ini.
