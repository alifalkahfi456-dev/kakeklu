import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:audio_service/audio_service.dart';
import 'audio_handler.dart';

const String kLuminaUrl = 'https://lumina-mu-snowy.vercel.app/';

late LuminaAudioHandler audioHandler;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  audioHandler = await AudioService.init(
    builder: () => LuminaAudioHandler(),
    config: const AudioServiceConfig(
      androidNotificationChannelId: 'com.lumina.app.audio',
      androidNotificationChannelName: 'Lumina Playback',
      androidNotificationOngoing: true,
      androidStopForegroundOnPause: false,
    ),
  );
  runApp(const LuminaApp());
}

class LuminaApp extends StatelessWidget {
  const LuminaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Lumina',
      theme: ThemeData.dark(),
      home: const LuminaWebView(),
    );
  }
}

class LuminaWebView extends StatefulWidget {
  const LuminaWebView({super.key});

  @override
  State<LuminaWebView> createState() => _LuminaWebViewState();
}

class _LuminaWebViewState extends State<LuminaWebView> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();

    // Forward "track ended" events from native player back to JS
    audioHandler.onTrackEnded = () {
      _controller.runJavaScript("window.__luminaNative?.onEnded?.()");
    };

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF000000))
      ..addJavaScriptChannel(
        'LuminaNative',
        onMessageReceived: _handleMessage,
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (_) => _injectBridge(),
        ),
      )
      ..loadRequest(Uri.parse(kLuminaUrl));
  }

  /// Injects a JS object the web app can call to control native audio.
  void _injectBridge() {
    _controller.runJavaScript('''
      window.__luminaNative = window.__luminaNative || {};
      window.LuminaBridge = {
        play: (data) => LuminaNative.postMessage(JSON.stringify({ type: 'play', ...data })),
        pause: () => LuminaNative.postMessage(JSON.stringify({ type: 'pause' })),
        resume: () => LuminaNative.postMessage(JSON.stringify({ type: 'resume' })),
        seek: (seconds) => LuminaNative.postMessage(JSON.stringify({ type: 'seek', position: seconds })),
        setVolume: (vol) => LuminaNative.postMessage(JSON.stringify({ type: 'volume', value: vol })),
      };
      window.dispatchEvent(new Event('luminaBridgeReady'));
    ''');
  }

  /// Handles JSON messages sent from the web app via LuminaBridge.*
  Future<void> _handleMessage(JavaScriptMessage message) async {
    try {
      final data = jsonDecode(message.message) as Map<String, dynamic>;
      switch (data['type']) {
        case 'play':
          await audioHandler.loadAndPlay(
            url: data['url'] as String,
            title: data['title'] as String? ?? '',
            artist: data['artist'] as String? ?? '',
            artUri: data['artwork'] as String?,
            duration: data['duration'] != null
                ? Duration(seconds: (data['duration'] as num).toInt())
                : null,
            headers: const {
              'User-Agent':
                  'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36',
            },
          );
          break;
        case 'pause':
          await audioHandler.pause();
          break;
        case 'resume':
          await audioHandler.play();
          break;
        case 'seek':
          final pos = (data['position'] as num).toDouble();
          await audioHandler.seek(Duration(milliseconds: (pos * 1000).toInt()));
          break;
        case 'volume':
          final vol = (data['value'] as num).toDouble();
          await audioHandler.setVolume(vol);
          break;
      }
    } catch (e) {
      // ignore malformed messages
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        top: false,
        child: WebViewWidget(controller: _controller),
      ),
    );
  }
}
