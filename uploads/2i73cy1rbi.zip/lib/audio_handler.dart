import 'package:audio_service/audio_service.dart';
import 'package:just_audio/just_audio.dart';

/// Handles native background audio playback.
/// Receives commands (load/play/pause/seek) from the WebView JS bridge
/// via [LuminaAudioHandler] static methods.
class LuminaAudioHandler extends BaseAudioHandler {
  final AudioPlayer _player = AudioPlayer();

  LuminaAudioHandler() {
    _player.playbackEventStream.listen((event) {
      playbackState.add(playbackState.value.copyWith(
        controls: [
          MediaControl.skipToPrevious,
          if (_player.playing) MediaControl.pause else MediaControl.play,
          MediaControl.stop,
          MediaControl.skipToNext,
        ],
        systemActions: const {
          MediaAction.seek,
          MediaAction.seekForward,
          MediaAction.seekBackward,
        },
        androidCompactActionIndices: const [0, 1, 3],
        processingState: const {
          ProcessingState.idle: AudioProcessingState.idle,
          ProcessingState.loading: AudioProcessingState.loading,
          ProcessingState.buffering: AudioProcessingState.buffering,
          ProcessingState.ready: AudioProcessingState.ready,
          ProcessingState.completed: AudioProcessingState.completed,
        }[_player.processingState]!,
        playing: _player.playing,
        updatePosition: _player.position,
        bufferedPosition: _player.bufferedPosition,
        speed: _player.speed,
      ));
    });

    _player.durationStream.listen((d) {
      final item = mediaItem.value;
      if (item != null && d != null) {
        mediaItem.add(item.copyWith(duration: d));
      }
    });

    _player.playerStateStream.listen((state) {
      if (state.processingState == ProcessingState.completed) {
        // Notify JS side that track ended (so it can advance queue)
        onTrackEnded?.call();
      }
    });
  }

  /// Callback fired when playback completes — wired to JS bridge.
  void Function()? onTrackEnded;

  /// Load and start playing a track from a direct stream URL.
  Future<void> loadAndPlay({
    required String url,
    required String title,
    required String artist,
    String? artUri,
    Duration? duration,
    Map<String, String>? headers,
  }) async {
    final item = MediaItem(
      id: url,
      title: title,
      artist: artist,
      artUri: artUri != null ? Uri.parse(artUri) : null,
      duration: duration,
    );
    mediaItem.add(item);

    await _player.setAudioSource(
      AudioSource.uri(Uri.parse(url), headers: headers),
    );
    await _player.play();
  }

  @override
  Future<void> play() => _player.play();

  @override
  Future<void> pause() => _player.pause();

  @override
  Future<void> stop() async {
    await _player.stop();
    return super.stop();
  }

  @override
  Future<void> seek(Duration position) => _player.seek(position);

  Future<void> setVolume(double volume) => _player.setVolume(volume);

  Duration get position => _player.position;
  Duration? get duration => _player.duration;
  bool get isPlaying => _player.playing;
}
