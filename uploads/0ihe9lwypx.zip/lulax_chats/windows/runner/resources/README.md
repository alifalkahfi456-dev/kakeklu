app_icon.ico - Convert /windows/runner/resources/app_icon.png to .ico format using any image tool, or run `flutter create --platforms=windows .` to regenerate.
