#ifndef RUNNER_WIN32_WINDOW_H_
#define RUNNER_WIN32_WINDOW_H_

#include <windows.h>
#include <functional>
#include <memory>
#include <string>

class Win32Window {
 public:
  struct Point { unsigned int x; unsigned int y; Point(unsigned int x_, unsigned int y_) : x(x_), y(y_) {} };
  struct Size { unsigned int width; unsigned int height; Size(unsigned int w, unsigned int h) : width(w), height(h) {} };

  Win32Window();
  virtual ~Win32Window();

  bool Create(const std::wstring& title, const Point& origin, const Size& size);
  bool Show();
  void Destroy();
  void SetChildContent(HWND content);
  HWND GetHandle();
  void SetQuitOnClose(bool quit_on_close);
  RECT GetClientArea();

 protected:
  virtual bool OnCreate();
  virtual void OnDestroy();
  virtual LRESULT MessageHandler(HWND window, UINT const message,
                                 WPARAM const wparam, LPARAM const lparam) noexcept;
  static LRESULT CALLBACK WndProc(HWND const window, UINT const message,
                                  WPARAM const wparam, LPARAM const lparam) noexcept;
  static Win32Window* GetThisFromHandle(HWND const window) noexcept;

 private:
  bool quit_on_close_ = false;
  HWND window_handle_ = nullptr;
  HWND child_content_ = nullptr;
  static int Scale(int source, double scale_factor);
};

class WindowClassRegistrar {
 public:
  static WindowClassRegistrar* GetInstance();
  WNDCLASS GetWindowClass();
  void UnregisterWindowClass();
 private:
  WindowClassRegistrar() = default;
  static WindowClassRegistrar* instance_;
  bool class_registered_ = false;
};

#endif
