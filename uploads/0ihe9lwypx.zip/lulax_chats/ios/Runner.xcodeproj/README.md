# iOS Xcode project files

The full `Runner.xcodeproj/project.pbxproj` is a large auto-generated binary-ish
file (>2000 lines) that Flutter regenerates whenever you run:

    flutter create --platforms=ios --org com.barz .

inside the project root. Run that command once on a Mac with Xcode installed to
regenerate `project.pbxproj`, the workspace files, and any missing scheme.

All hand-written iOS source files (Info.plist, AppDelegate.swift, storyboards,
Assets.xcassets, Podfile, xcconfig files) are already included and won't be
overwritten.
