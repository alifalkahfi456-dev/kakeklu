import 'package:flutter_test/flutter_test.dart';
import 'package:lulax_chats/main.dart';

void main() {
  testWidgets('App boots without throwing', (WidgetTester tester) async {
    await tester.pumpWidget(const LulaxChatsApp());
    expect(find.byType(LulaxChatsApp), findsOneWidget);
  });
}
