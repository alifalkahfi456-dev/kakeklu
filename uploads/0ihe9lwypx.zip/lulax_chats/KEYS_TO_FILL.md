# Keys to Fill — Lulax Chats

Status update terbaru.

## ✅ Firebase (sudah diisi sebagian)

File: `lib/firebase_options.dart`

- **Web**: ✅ Lengkap (apiKey, appId, senderId, projectId, storageBucket, authDomain)
- **Android**: ⚠️ apiKey/senderId/projectId udah diisi pakai data project `lulax-chats`,
  tapi `appId` Android masih placeholder (`1:820478835670:android:REPLACE_WITH_ANDROID_APP_ID`).
  
  Cara fix:
  1. Buka Firebase Console → Project `lulax-chats` → Project Settings.
  2. Klik **Add app → Android**, package name: `com.barz.lulax_chats`.
  3. Download `google-services.json`, taruh di `android/app/google-services.json`.
  4. Copy nilai App ID (`1:820478835670:android:xxxxxxxx`) → ganti di `firebase_options.dart`
     pada bagian `android.appId`.

- **iOS**: ❌ Belum diisi (opsional, skip kalau cuma build APK).

## ❌ Gemini API Key (BELUM)

File: `lib/utils/constants.dart` → `geminiApiKeyFallback`

Saat ini masih: `PASTE_GEMINI_API_KEY_HERE`

Cara isi:
1. Ambil API key dari https://aistudio.google.com/app/apikey
2. Ganti string `PASTE_GEMINI_API_KEY_HERE` dengan key tersebut.
3. Atau (lebih fleksibel): isi field `gemini_api_key` di Firestore document
   `app_config/main` → akan otomatis override fallback.

## Build

```bash
flutter pub get
flutter build apk --release
```

APK output: `build/app/outputs/flutter-apk/app-release.apk`
