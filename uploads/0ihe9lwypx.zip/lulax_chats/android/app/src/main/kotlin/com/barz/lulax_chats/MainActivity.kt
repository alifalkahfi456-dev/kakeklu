package com.barz.lulax_chats

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
