import 'package:cloud_firestore/cloud_firestore.dart';

import '../utils/constants.dart';
import '../services/firebase_service.dart';

class ModerationService {
  FirebaseFirestore get _db => FirebaseService.instance.db;

  Future<void> reportUser({
    required String reporterId,
    required String reportedUsername,
    required String description,
  }) async {
    await _db.collection(AppConstants.reportsCol).add({
      'reporterId': reporterId,
      'reportedUsername': reportedUsername,
      'description': description,
      'status': 'open',
      'createdAt': Timestamp.now(),
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> openReports() {
    return _db
        .collection(AppConstants.reportsCol)
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  Future<void> resolveReport(String id) async {
    await _db
        .collection(AppConstants.reportsCol)
        .doc(id)
        .update({'status': 'resolved'});
  }

  Future<void> warnUser(String userId, String message) async {
    await _db.collection('warnings').add({
      'userId': userId,
      'message': message,
      'createdAt': Timestamp.now(),
    });
  }
}
