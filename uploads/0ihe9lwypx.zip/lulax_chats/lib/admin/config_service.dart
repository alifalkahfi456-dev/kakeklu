import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';

import '../utils/constants.dart';
import '../services/firebase_service.dart';

class ConfigService extends ChangeNotifier {
  Map<String, dynamic> _data = {};

  bool get maintenanceMode => _data['maintenance_mode'] == true;
  String get geminiApiKey {
    final live = (_data['gemini_api_key'] ?? '').toString().trim();
    if (live.isNotEmpty) return live;
    // Fallback ke key hardcoded di constants.dart kalau Firestore belum di-set.
    return AppConstants.geminiApiKeyFallback;
  }
  String get broadcast => (_data['broadcast_message'] ?? '').toString();
  Map<String, dynamic> get featureFlags =>
      Map<String, dynamic>.from(_data['feature_flags'] ?? {});
  Map<String, dynamic> get rateLimits =>
      Map<String, dynamic>.from(_data['rate_limits'] ?? {});

  bool feature(String key, {bool fallback = true}) {
    final v = featureFlags[key];
    if (v is bool) return v;
    return fallback;
  }

  void listen() {
    FirebaseService.instance.db
        .collection(AppConstants.configCol)
        .doc(AppConstants.configDoc)
        .snapshots()
        .listen((snap) {
      _data = snap.data() ?? {};
      notifyListeners();
    });
  }

  Future<void> update(Map<String, dynamic> updates) async {
    await FirebaseService.instance.db
        .collection(AppConstants.configCol)
        .doc(AppConstants.configDoc)
        .set(updates, SetOptions(merge: true));
  }
}
