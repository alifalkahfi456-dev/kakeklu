import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

import '../admin/config_service.dart';
import '../models/status_model.dart';
import '../services/auth_service.dart';
import '../services/storage_service.dart';
import '../utils/constants.dart';
import '../utils/helpers.dart';

class StatusScreen extends StatelessWidget {
  const StatusScreen({super.key});

  Stream<List<StatusModel>> _activeStatus() {
    return FirebaseFirestore.instance
        .collection(AppConstants.statusCol)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) => s.docs
            .map((d) => StatusModel.fromMap(d.data()))
            .where((st) => !st.isExpired)
            .toList());
  }

  @override
  Widget build(BuildContext context) {
    final cfg = context.watch<ConfigService>();
    if (!cfg.feature('status')) {
      return const Center(child: Text('Status feature is disabled by admin'));
    }
    return Stack(
      children: [
        StreamBuilder<List<StatusModel>>(
          stream: _activeStatus(),
          builder: (_, snap) {
            if (!snap.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            final list = snap.data!;
            if (list.isEmpty) {
              return const Center(
                  child: Text('No status updates yet — be the first!'));
            }
            return ListView.separated(
              itemCount: list.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                final s = list[i];
                return ListTile(
                  leading: CircleAvatar(
                    radius: 26,
                    backgroundColor: Colors.teal,
                    child: CircleAvatar(
                      radius: 23,
                      backgroundColor: Colors.white,
                      backgroundImage: s.userPhoto.isNotEmpty
                          ? CachedNetworkImageProvider(s.userPhoto)
                          : null,
                      child: s.userPhoto.isEmpty
                          ? Text(s.username.isEmpty
                              ? '?'
                              : s.username[0].toUpperCase())
                          : null,
                    ),
                  ),
                  title: Text(s.username),
                  subtitle: Text(Helpers.formatTime(s.createdAt)),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.remove_red_eye,
                          size: 14, color: Colors.black45),
                      const SizedBox(width: 4),
                      Text('${s.viewCount}'),
                    ],
                  ),
                  onTap: () => _viewStatus(context, s),
                );
              },
            );
          },
        ),
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton(
            backgroundColor: const Color(0xFF128C7E),
            onPressed: () => _createStatus(context),
            child: const Icon(Icons.add, color: Colors.white),
          ),
        ),
      ],
    );
  }

  Future<void> _createStatus(BuildContext context) async {
    final me = context.read<AuthService>().currentUser!;
    final action = await showModalBottomSheet<String>(
      context: context,
      builder: (_) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.text_fields),
              title: const Text('Text status'),
              onTap: () => Navigator.pop(context, 'text'),
            ),
            ListTile(
              leading: const Icon(Icons.image),
              title: const Text('Image status'),
              onTap: () => Navigator.pop(context, 'image'),
            ),
          ],
        ),
      ),
    );
    if (action == null) return;
    if (action == 'text') {
      final ctrl = TextEditingController();
      final res = await showDialog<String>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('What\'s on your mind?'),
          content: TextField(controller: ctrl, maxLines: 3),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cancel')),
            TextButton(
                onPressed: () => Navigator.pop(context, ctrl.text),
                child: const Text('Post')),
          ],
        ),
      );
      if (res == null || res.trim().isEmpty) return;
      await _post(me.id, me.username, me.photoUrl, text: res.trim(), type: 'text');
    } else {
      final picker = ImagePicker();
      final img = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
      if (img == null) return;
      final url = await StorageService().uploadImage(File(img.path), 'status');
      await _post(me.id, me.username, me.photoUrl, mediaUrl: url, type: 'image');
    }
  }

  Future<void> _post(String uid, String username, String photo,
      {String text = '', String mediaUrl = '', required String type}) async {
    final id = const Uuid().v4();
    final now = DateTime.now();
    final st = StatusModel(
      id: id,
      userId: uid,
      username: username,
      userPhoto: photo,
      text: text,
      mediaUrl: mediaUrl,
      type: type,
      createdAt: now,
      expiresAt: now.add(const Duration(hours: 24)),
      seenBy: const [],
    );
    await FirebaseFirestore.instance
        .collection(AppConstants.statusCol)
        .doc(id)
        .set(st.toMap());
  }

  void _viewStatus(BuildContext context, StatusModel s) {
    final me = context.read<AuthService>().currentUser!;
    if (!s.seenBy.contains(me.id)) {
      FirebaseFirestore.instance
          .collection(AppConstants.statusCol)
          .doc(s.id)
          .update({'seenBy': FieldValue.arrayUnion([me.id])});
    }
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          title: Text(s.username),
        ),
        body: Center(
          child: s.type == 'image' && s.mediaUrl.isNotEmpty
              ? CachedNetworkImage(imageUrl: s.mediaUrl)
              : Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(s.text,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white, fontSize: 24)),
                ),
        ),
        bottomNavigationBar: Container(
          color: Colors.black87,
          padding: const EdgeInsets.all(12),
          child: Text('Seen by ${s.viewCount}',
              style: const TextStyle(color: Colors.white70)),
        ),
      ),
    ));
  }
}
