import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../admin/config_service.dart';
import '../models/call_model.dart';
import '../models/chat_model.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';
import '../services/call_service.dart';
import '../services/chat_service.dart';
import '../utils/constants.dart';
import '../utils/helpers.dart';
import 'admin_panel.dart';
import 'ai_screen.dart';
import 'call_screen.dart';
import 'chat_screen.dart';
import 'group_screen.dart';
import 'help_center.dart';
import 'login_screen.dart';
import 'profile_screen.dart';
import 'status_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tab;
  final ChatService _chat = ChatService();
  final CallService _calls = CallService();

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 4, vsync: this);
    _listenIncomingCalls();
  }

  void _listenIncomingCalls() {
    final user = context.read<AuthService>().currentUser;
    if (user == null) return;
    _calls.incomingCalls(user.id).listen((c) {
      if (c != null && mounted) {
        Navigator.of(context).push(
          MaterialPageRoute(
              builder: (_) => CallScreen(call: c, isIncoming: true)),
        );
      }
    });
  }

  Future<void> _logout() async {
    await context.read<AuthService>().logout();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthService>().currentUser;
    final cfg = context.watch<ConfigService>();
    if (user == null) return const Scaffold();
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConstants.appName),
        backgroundColor: const Color(0xFF128C7E),
        foregroundColor: Colors.white,
        actions: [
          if (user.isAdmin)
            IconButton(
              icon: const Icon(Icons.admin_panel_settings),
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const AdminPanel()),
              ),
            ),
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'profile') {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => const ProfileScreen()));
              } else if (v == 'help') {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => const HelpCenter()));
              } else if (v == 'logout') {
                _logout();
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'profile', child: Text('Profile')),
              PopupMenuItem(value: 'help', child: Text('Help center')),
              PopupMenuItem(value: 'logout', child: Text('Logout')),
            ],
          ),
        ],
        bottom: TabBar(
          controller: _tab,
          indicatorColor: Colors.white,
          tabs: const [
            Tab(icon: Icon(Icons.chat), text: 'Chats'),
            Tab(icon: Icon(Icons.circle_outlined), text: 'Status'),
            Tab(icon: Icon(Icons.smart_toy), text: 'Lulax AI'),
            Tab(icon: Icon(Icons.people), text: 'Users'),
          ],
        ),
      ),
      body: Column(
        children: [
          if (cfg.broadcast.isNotEmpty)
            Container(
              width: double.infinity,
              color: Colors.amber.shade100,
              padding: const EdgeInsets.all(8),
              child: Text('📢 ${cfg.broadcast}',
                  style: const TextStyle(color: Colors.black87)),
            ),
          Expanded(
            child: TabBarView(
              controller: _tab,
              children: [
                _ChatsTab(chat: _chat, me: user),
                const StatusScreen(),
                if (cfg.feature('ai'))
                  const AiScreen()
                else
                  const Center(child: Text('AI is disabled by admin')),
                _UsersTab(me: user),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: _tab.index == 0
          ? FloatingActionButton(
              backgroundColor: const Color(0xFF128C7E),
              onPressed: () => _tab.animateTo(3),
              child: const Icon(Icons.message, color: Colors.white),
            )
          : null,
    );
  }
}

class _ChatsTab extends StatelessWidget {
  final ChatService chat;
  final UserModel me;
  const _ChatsTab({required this.chat, required this.me});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<ChatModel>>(
      stream: chat.myChats(me.id),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final chats = snap.data!;
        if (chats.isEmpty) {
          return const Center(
              child: Text('No chats yet. Tap a user to start chatting.'));
        }
        return ListView.separated(
          itemCount: chats.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (_, i) {
            final c = chats[i];
            return _ChatTile(chat: c, me: me);
          },
        );
      },
    );
  }
}

class _ChatTile extends StatelessWidget {
  final ChatModel chat;
  final UserModel me;
  const _ChatTile({required this.chat, required this.me});

  @override
  Widget build(BuildContext context) {
    if (chat.isGroup && chat.groupId != null) {
      return FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        future: FirebaseFirestore.instance
            .collection(AppConstants.groupsCol)
            .doc(chat.groupId)
            .get(),
        builder: (_, snap) {
          final name = snap.data?.data()?['name'] ?? 'Group';
          return ListTile(
            leading: const CircleAvatar(child: Icon(Icons.groups)),
            title: Text(name),
            subtitle: Text(chat.lastMessage,
                maxLines: 1, overflow: TextOverflow.ellipsis),
            trailing: Text(Helpers.formatTime(chat.lastUpdated),
                style: const TextStyle(fontSize: 11)),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => ChatScreen(chat: chat, title: name),
              ),
            ),
          );
        },
      );
    }
    final otherId = chat.members.firstWhere((m) => m != me.id, orElse: () => '');
    if (otherId.isEmpty) return const SizedBox.shrink();
    return FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      future: FirebaseFirestore.instance
          .collection(AppConstants.usersCol)
          .doc(otherId)
          .get(),
      builder: (_, snap) {
        final data = snap.data?.data();
        if (data == null) return const SizedBox.shrink();
        final other = UserModel.fromMap(data);
        final unread = chat.unread[me.id] ?? 0;
        return ListTile(
          leading: CircleAvatar(
            backgroundColor: Colors.teal.shade100,
            child: Text(
                (other.displayName.isNotEmpty
                        ? other.displayName[0]
                        : other.username[0])
                    .toUpperCase(),
                style: const TextStyle(color: Colors.teal)),
          ),
          title: Text(other.displayName.isEmpty
              ? other.username
              : other.displayName),
          subtitle: Text(chat.lastMessage,
              maxLines: 1, overflow: TextOverflow.ellipsis),
          trailing: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(Helpers.formatTime(chat.lastUpdated),
                  style: const TextStyle(fontSize: 11)),
              if (unread > 0)
                Container(
                  margin: const EdgeInsets.only(top: 4),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.teal,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text('$unread',
                      style: const TextStyle(
                          color: Colors.white, fontSize: 11)),
                ),
            ],
          ),
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => ChatScreen(chat: chat, title: other.displayName.isEmpty ? other.username : other.displayName, other: other),
            ),
          ),
        );
      },
    );
  }
}

class _UsersTab extends StatelessWidget {
  final UserModel me;
  const _UsersTab({required this.me});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: FirebaseFirestore.instance
              .collection(AppConstants.usersCol)
              .snapshots(),
          builder: (_, snap) {
            if (!snap.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            final users = snap.data!.docs
                .map((d) => UserModel.fromMap(d.data()))
                .where((u) => u.id != me.id && !u.isBanned)
                .toList();
            return ListView.separated(
              itemCount: users.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                final u = users[i];
                return ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.teal.shade100,
                    child: Text(
                        (u.displayName.isNotEmpty
                                ? u.displayName[0]
                                : u.username[0])
                            .toUpperCase()),
                  ),
                  title: Text(u.displayName.isEmpty
                      ? u.username
                      : u.displayName),
                  subtitle: Text('@${u.username}'),
                  trailing: u.isOnline
                      ? const Icon(Icons.circle, color: Colors.green, size: 10)
                      : null,
                  onTap: () async {
                    final c = await ChatService()
                        .ensureOneToOneChat(me.id, u.id);
                    if (!context.mounted) return;
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => ChatScreen(
                            chat: c,
                            title: u.displayName.isEmpty
                                ? u.username
                                : u.displayName,
                            other: u),
                      ),
                    );
                  },
                );
              },
            );
          },
        ),
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton.extended(
            backgroundColor: const Color(0xFF128C7E),
            foregroundColor: Colors.white,
            icon: const Icon(Icons.group_add),
            label: const Text('New Group'),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const GroupScreen()),
            ),
          ),
        ),
      ],
    );
  }
}
