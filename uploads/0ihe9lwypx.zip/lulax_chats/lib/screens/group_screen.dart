import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/group_model.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';
import '../services/group_service.dart';
import '../utils/constants.dart';

class GroupScreen extends StatefulWidget {
  const GroupScreen({super.key});

  @override
  State<GroupScreen> createState() => _GroupScreenState();
}

class _GroupScreenState extends State<GroupScreen> {
  final _name = TextEditingController();
  final _desc = TextEditingController();
  final Set<String> _selected = {};
  bool _busy = false;

  Future<void> _create() async {
    final me = context.read<AuthService>().currentUser!;
    if (_name.text.trim().isEmpty || _selected.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter a name and select members')),
      );
      return;
    }
    setState(() => _busy = true);
    await GroupService().createGroup(
      name: _name.text.trim(),
      description: _desc.text.trim(),
      createdBy: me.id,
      members: _selected.toList(),
    );
    if (!mounted) return;
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final me = context.watch<AuthService>().currentUser!;
    return Scaffold(
      appBar: AppBar(
        title: const Text('New Group'),
        backgroundColor: const Color(0xFF128C7E),
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.check),
            onPressed: _busy ? null : _create,
          )
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                TextField(
                  controller: _name,
                  decoration: const InputDecoration(
                    labelText: 'Group name',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _desc,
                  decoration: const InputDecoration(
                    labelText: 'Description',
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 12),
            child: Align(
                alignment: Alignment.centerLeft,
                child: Text('Select members',
                    style: TextStyle(fontWeight: FontWeight.bold))),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: FirebaseFirestore.instance
                  .collection(AppConstants.usersCol)
                  .snapshots(),
              builder: (_, snap) {
                if (!snap.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final users = snap.data!.docs
                    .map((d) => UserModel.fromMap(d.data()))
                    .where((u) => u.id != me.id && !u.isBanned)
                    .toList();
                return ListView.builder(
                  itemCount: users.length,
                  itemBuilder: (_, i) {
                    final u = users[i];
                    final selected = _selected.contains(u.id);
                    return CheckboxListTile(
                      value: selected,
                      title: Text(u.displayName.isEmpty
                          ? u.username
                          : u.displayName),
                      subtitle: Text('@${u.username}'),
                      onChanged: (v) {
                        setState(() {
                          if (v == true) {
                            _selected.add(u.id);
                          } else {
                            _selected.remove(u.id);
                          }
                        });
                      },
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

/// Group settings/admin view (used by admin to manage members)
class GroupSettingsScreen extends StatelessWidget {
  final GroupModel group;
  const GroupSettingsScreen({super.key, required this.group});

  @override
  Widget build(BuildContext context) {
    final me = context.watch<AuthService>().currentUser!;
    final isAdmin = group.admins.contains(me.id) || me.isAdmin;
    return Scaffold(
      appBar: AppBar(title: Text(group.name)),
      body: StreamBuilder<GroupModel>(
        stream: GroupService().watch(group.id),
        builder: (_, snap) {
          final g = snap.data ?? group;
          return ListView(
            children: [
              ListTile(
                title: const Text('Admin only messages'),
                trailing: Switch(
                  value: g.adminOnlyMessages,
                  onChanged: isAdmin
                      ? (v) =>
                          GroupService().setAdminOnlyMessages(g.id, v)
                      : null,
                ),
              ),
              const Divider(),
              const Padding(
                padding: EdgeInsets.all(12),
                child: Text('Members',
                    style: TextStyle(fontWeight: FontWeight.bold)),
              ),
              ...g.members.map((id) => FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                    future: FirebaseFirestore.instance
                        .collection(AppConstants.usersCol)
                        .doc(id)
                        .get(),
                    builder: (_, s) {
                      final data = s.data?.data();
                      if (data == null) return const SizedBox();
                      final u = UserModel.fromMap(data);
                      final isGroupAdmin = g.admins.contains(u.id);
                      return ListTile(
                        leading: CircleAvatar(
                            child: Text(u.username[0].toUpperCase())),
                        title: Text(u.displayName.isEmpty
                            ? u.username
                            : u.displayName),
                        subtitle: Text(isGroupAdmin ? 'Admin' : 'Member'),
                        trailing: isAdmin && u.id != g.createdBy
                            ? PopupMenuButton<String>(
                                onSelected: (v) {
                                  if (v == 'promote') {
                                    GroupService().promoteAdmin(g.id, u.id);
                                  } else if (v == 'demote') {
                                    GroupService().demoteAdmin(g.id, u.id);
                                  } else if (v == 'remove') {
                                    GroupService().removeMember(g.id, u.id);
                                  }
                                },
                                itemBuilder: (_) => [
                                  if (!isGroupAdmin)
                                    const PopupMenuItem(
                                        value: 'promote',
                                        child: Text('Promote to admin')),
                                  if (isGroupAdmin)
                                    const PopupMenuItem(
                                        value: 'demote',
                                        child: Text('Demote admin')),
                                  const PopupMenuItem(
                                      value: 'remove',
                                      child: Text('Remove from group')),
                                ],
                              )
                            : null,
                      );
                    },
                  )),
            ],
          );
        },
      ),
    );
  }
}
