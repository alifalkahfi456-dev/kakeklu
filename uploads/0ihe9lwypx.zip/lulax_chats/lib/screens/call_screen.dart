import 'package:flutter/material.dart';

import '../models/call_model.dart';
import '../services/call_service.dart';
import '../widgets/call_ui.dart';

class CallScreen extends StatefulWidget {
  final CallModel call;
  final CallService? service;
  final bool isIncoming;
  const CallScreen({
    super.key,
    required this.call,
    this.service,
    required this.isIncoming,
  });

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  late CallService _service;
  bool _accepted = false;
  bool _muted = false;

  @override
  void initState() {
    super.initState();
    _service = widget.service ?? CallService();
    if (!widget.isIncoming) _accepted = true;
  }

  Future<void> _accept() async {
    await _service.answerCall(widget.call.id);
    if (mounted) setState(() => _accepted = true);
  }

  Future<void> _reject() async {
    await _service.rejectCall(widget.call.id);
    if (mounted) Navigator.pop(context);
  }

  Future<void> _end() async {
    await _service.endCall();
    if (mounted) Navigator.pop(context);
  }

  void _toggleMute() {
    final tracks = _service.localStream?.getAudioTracks() ?? [];
    for (final t in tracks) {
      t.enabled = !t.enabled;
    }
    setState(() => _muted = !_muted);
  }

  @override
  void dispose() {
    if (widget.service == null) {
      _service.endCall();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final name = widget.isIncoming ? widget.call.callerName : widget.call.calleeName;
    return Scaffold(
      body: CallUI(
        name: name,
        state: _accepted ? 'in_call' : 'ringing',
        onAccept: widget.isIncoming ? _accept : null,
        onReject: widget.isIncoming ? _reject : null,
        onEnd: _end,
        onMute: _toggleMute,
        muted: _muted,
      ),
    );
  }
}
