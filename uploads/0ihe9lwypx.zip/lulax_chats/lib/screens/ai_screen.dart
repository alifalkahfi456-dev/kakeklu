import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../admin/config_service.dart';
import '../services/ai_service.dart';

class AiScreen extends StatefulWidget {
  const AiScreen({super.key});

  @override
  State<AiScreen> createState() => _AiScreenState();
}

class _AiScreenState extends State<AiScreen> {
  final List<Map<String, String>> _history = [];
  final TextEditingController _ctrl = TextEditingController();
  bool _busy = false;
  final ScrollController _scroll = ScrollController();

  Future<void> _send() async {
    final txt = _ctrl.text.trim();
    if (txt.isEmpty) return;
    setState(() {
      _history.add({'role': 'user', 'text': txt});
      _busy = true;
    });
    _ctrl.clear();
    try {
      final cfg = context.read<ConfigService>();
      final ai = AiService(cfg);
      final reply = await ai.ask(txt, history: _history.take(_history.length - 1).toList());
      setState(() {
        _history.add({'role': 'model', 'text': reply});
      });
    } catch (e) {
      setState(() {
        _history.add({'role': 'model', 'text': 'Error: ${e.toString().replaceAll('Exception: ', '')}'});
      });
    } finally {
      setState(() => _busy = false);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scroll.hasClients) {
          _scroll.animateTo(_scroll.position.maxScrollExtent,
              duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          color: Colors.teal.shade50,
          child: const Row(
            children: [
              Icon(Icons.smart_toy, color: Colors.teal),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Lulax AI — powered by Gemini. Ask anything!',
                  style: TextStyle(color: Colors.teal, fontWeight: FontWeight.w500),
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            controller: _scroll,
            padding: const EdgeInsets.all(8),
            itemCount: _history.length + (_busy ? 1 : 0),
            itemBuilder: (_, i) {
              if (i >= _history.length) {
                return const Padding(
                  padding: EdgeInsets.all(12),
                  child: Row(
                    children: [
                      SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2)),
                      SizedBox(width: 8),
                      Text('Lulax is thinking...'),
                    ],
                  ),
                );
              }
              final m = _history[i];
              final isUser = m['role'] == 'user';
              return Align(
                alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 6),
                  padding: const EdgeInsets.all(10),
                  constraints: const BoxConstraints(maxWidth: 300),
                  decoration: BoxDecoration(
                    color: isUser ? const Color(0xFFDCF8C6) : Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 4,
                          offset: const Offset(0, 2))
                    ],
                  ),
                  child: Text(m['text'] ?? ''),
                ),
              );
            },
          ),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _ctrl,
                    decoration: InputDecoration(
                      hintText: 'Ask Lulax AI...',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 10),
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                CircleAvatar(
                  backgroundColor: Colors.teal,
                  child: IconButton(
                    icon: const Icon(Icons.send, color: Colors.white),
                    onPressed: _busy ? null : _send,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
