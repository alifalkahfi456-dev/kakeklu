import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../admin/config_service.dart';
import '../admin/moderation_service.dart';
import '../models/user_model.dart';
import '../services/admin_service.dart';
import '../services/auth_service.dart';
import '../utils/constants.dart';

class AdminPanel extends StatefulWidget {
  const AdminPanel({super.key});

  @override
  State<AdminPanel> createState() => _AdminPanelState();
}

class _AdminPanelState extends State<AdminPanel>
    with SingleTickerProviderStateMixin {
  late final TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 4, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Super Panel'),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
        bottom: TabBar(
          controller: _tab,
          isScrollable: true,
          indicatorColor: Colors.white,
          tabs: const [
            Tab(icon: Icon(Icons.tune), text: 'Config'),
            Tab(icon: Icon(Icons.people), text: 'Users'),
            Tab(icon: Icon(Icons.flag), text: 'Reports'),
            Tab(icon: Icon(Icons.campaign), text: 'Broadcast'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: const [
          _ConfigTab(),
          _UsersTab(),
          _ReportsTab(),
          _BroadcastTab(),
        ],
      ),
    );
  }
}

class _ConfigTab extends StatefulWidget {
  const _ConfigTab();
  @override
  State<_ConfigTab> createState() => _ConfigTabState();
}

class _ConfigTabState extends State<_ConfigTab> {
  final _gemini = TextEditingController();
  final _broadcast = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final cfg = context.watch<ConfigService>();
    if (_gemini.text.isEmpty) _gemini.text = cfg.geminiApiKey;
    if (_broadcast.text.isEmpty) _broadcast.text = cfg.broadcast;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        SwitchListTile(
          title: const Text('Maintenance mode'),
          subtitle: const Text('Only admin can login when ON'),
          value: cfg.maintenanceMode,
          onChanged: (v) => cfg.update({'maintenance_mode': v}),
        ),
        const Divider(),
        const Text('Gemini API key (live)',
            style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        TextField(
          controller: _gemini,
          decoration: const InputDecoration(border: OutlineInputBorder()),
        ),
        const SizedBox(height: 8),
        ElevatedButton(
          onPressed: () => cfg.update({'gemini_api_key': _gemini.text.trim()}),
          child: const Text('Save Gemini key'),
        ),
        const Divider(height: 32),
        const Text('Feature flags',
            style: TextStyle(fontWeight: FontWeight.bold)),
        SwitchListTile(
          title: const Text('AI'),
          value: cfg.feature('ai'),
          onChanged: (v) => cfg.update({'feature_flags.ai': v}),
        ),
        SwitchListTile(
          title: const Text('Calls'),
          value: cfg.feature('calls'),
          onChanged: (v) => cfg.update({'feature_flags.calls': v}),
        ),
        SwitchListTile(
          title: const Text('Status'),
          value: cfg.feature('status'),
          onChanged: (v) => cfg.update({'feature_flags.status': v}),
        ),
        const Divider(height: 32),
        const Text('Rate limit (msg/min)',
            style: TextStyle(fontWeight: FontWeight.bold)),
        TextField(
          keyboardType: TextInputType.number,
          decoration: InputDecoration(
            border: const OutlineInputBorder(),
            hintText:
                '${cfg.rateLimits['messages_per_minute'] ?? 60}',
          ),
          onSubmitted: (v) {
            final n = int.tryParse(v);
            if (n != null) {
              cfg.update({'rate_limits.messages_per_minute': n});
            }
          },
        ),
      ],
    );
  }
}

class _UsersTab extends StatelessWidget {
  const _UsersTab();
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection(AppConstants.usersCol)
          .snapshots(),
      builder: (_, snap) {
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final users =
            snap.data!.docs.map((d) => UserModel.fromMap(d.data())).toList();
        return ListView.separated(
          itemCount: users.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (_, i) {
            final u = users[i];
            return ListTile(
              leading: CircleAvatar(
                  backgroundColor:
                      u.isBanned ? Colors.red : Colors.teal.shade100,
                  child: Text(u.username[0].toUpperCase())),
              title: Text(u.username),
              subtitle: Text(
                  '${u.role} • ${u.isBanned ? 'BANNED' : (u.isOnline ? 'online' : 'offline')}'),
              trailing: PopupMenuButton<String>(
                onSelected: (v) {
                  if (v == 'ban') AdminService().banUser(u.id);
                  if (v == 'unban') AdminService().unbanUser(u.id);
                },
                itemBuilder: (_) => [
                  if (!u.isBanned)
                    const PopupMenuItem(value: 'ban', child: Text('Ban')),
                  if (u.isBanned)
                    const PopupMenuItem(value: 'unban', child: Text('Unban')),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class _ReportsTab extends StatelessWidget {
  const _ReportsTab();
  @override
  Widget build(BuildContext context) {
    final mod = ModerationService();
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: mod.openReports(),
      builder: (_, snap) {
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final docs = snap.data!.docs;
        if (docs.isEmpty) return const Center(child: Text('No reports'));
        return ListView.separated(
          itemCount: docs.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (_, i) {
            final r = docs[i].data();
            return ListTile(
              leading: const Icon(Icons.flag, color: Colors.red),
              title: Text('@${r['reportedUsername']}'),
              subtitle: Text(r['description'] ?? ''),
              trailing: r['status'] == 'open'
                  ? TextButton(
                      onPressed: () => mod.resolveReport(docs[i].id),
                      child: const Text('Resolve'),
                    )
                  : const Text('done'),
            );
          },
        );
      },
    );
  }
}

class _BroadcastTab extends StatefulWidget {
  const _BroadcastTab();
  @override
  State<_BroadcastTab> createState() => _BroadcastTabState();
}

class _BroadcastTabState extends State<_BroadcastTab> {
  final _ctrl = TextEditingController();
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          TextField(
            controller: _ctrl,
            maxLines: 4,
            decoration: const InputDecoration(
              labelText: 'Broadcast message',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(
              onPressed: _busy
                  ? null
                  : () async {
                      final me = context.read<AuthService>().currentUser!;
                      setState(() => _busy = true);
                      await AdminService().broadcast(_ctrl.text.trim(), me.id);
                      if (mounted) {
                        setState(() => _busy = false);
                        _ctrl.clear();
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Broadcast sent!')),
                        );
                      }
                    },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple,
                foregroundColor: Colors.white,
              ),
              child: _busy
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text('Send to all users'),
            ),
          ),
        ],
      ),
    );
  }
}
