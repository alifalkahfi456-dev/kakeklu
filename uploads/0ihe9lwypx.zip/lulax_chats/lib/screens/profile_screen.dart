import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../services/auth_service.dart';
import '../services/storage_service.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _displayName = TextEditingController();
  final _bio = TextEditingController();
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final u = context.read<AuthService>().currentUser!;
    _displayName.text = u.displayName;
    _bio.text = u.bio;
  }

  Future<void> _changePhoto() async {
    final picker = ImagePicker();
    final x = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (x == null) return;
    setState(() => _busy = true);
    final url = await StorageService().uploadImage(File(x.path), 'avatars');
    await context.read<AuthService>().updateProfile(photoUrl: url);
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _save() async {
    setState(() => _busy = true);
    await context.read<AuthService>().updateProfile(
          displayName: _displayName.text.trim(),
          bio: _bio.text.trim(),
        );
    if (mounted) {
      setState(() => _busy = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Profile saved')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthService>().currentUser!;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        backgroundColor: const Color(0xFF128C7E),
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: Stack(
              children: [
                CircleAvatar(
                  radius: 56,
                  backgroundColor: Colors.teal.shade100,
                  backgroundImage: user.photoUrl.isNotEmpty
                      ? CachedNetworkImageProvider(user.photoUrl)
                      : null,
                  child: user.photoUrl.isEmpty
                      ? Text(user.username[0].toUpperCase(),
                          style: const TextStyle(fontSize: 40))
                      : null,
                ),
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: CircleAvatar(
                    backgroundColor: Colors.teal,
                    child: IconButton(
                      icon: const Icon(Icons.camera_alt, color: Colors.white),
                      onPressed: _busy ? null : _changePhoto,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Center(
            child: Text('@${user.username}',
                style: const TextStyle(color: Colors.black54)),
          ),
          const SizedBox(height: 24),
          TextField(
            controller: _displayName,
            decoration: const InputDecoration(
              labelText: 'Display name',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _bio,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'Bio',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.circle, color: Colors.green, size: 12),
                  title: const Text('Status'),
                  subtitle: Text(user.isOnline ? 'Online' : 'Offline'),
                ),
                ListTile(
                  leading: const Icon(Icons.access_time),
                  title: const Text('Last seen'),
                  subtitle: Text(user.lastSeen.toString()),
                ),
                ListTile(
                  leading: const Icon(Icons.shield_outlined),
                  title: const Text('Role'),
                  subtitle: Text(user.role),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 48,
            child: ElevatedButton(
              onPressed: _busy ? null : _save,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF128C7E),
                foregroundColor: Colors.white,
              ),
              child: _busy
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text('Save'),
            ),
          ),
        ],
      ),
    );
  }
}
