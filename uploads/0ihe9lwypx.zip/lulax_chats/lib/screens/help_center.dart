import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../admin/moderation_service.dart';
import '../services/auth_service.dart';
import '../utils/constants.dart';

class HelpCenter extends StatelessWidget {
  const HelpCenter({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Help Center'),
        backgroundColor: const Color(0xFF128C7E),
        foregroundColor: Colors.white,
      ),
      body: ListView(
        children: [
          const _SectionTitle('About'),
          const ListTile(
            leading: Icon(Icons.info_outline),
            title: Text(AppConstants.appName),
            subtitle: Text('Developer: ${AppConstants.developer}'),
          ),
          const Divider(),
          const _SectionTitle('Contact'),
          const ListTile(
            leading: Icon(Icons.chat, color: Colors.green),
            title: Text('WhatsApp'),
            subtitle: Text(AppConstants.contactWhatsApp),
          ),
          const ListTile(
            leading: Icon(Icons.send, color: Colors.blue),
            title: Text('Telegram'),
            subtitle: Text(AppConstants.contactTelegram),
          ),
          const ListTile(
            leading: Icon(Icons.music_note, color: Colors.black),
            title: Text('TikTok'),
            subtitle: Text(AppConstants.contactTikTok),
          ),
          const Divider(),
          const _SectionTitle('FAQ'),
          ExpansionTile(
            title: const Text('How to register?'),
            children: const [
              Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                    'Tap "Register" on the login screen, choose a unique username and password, then tap Register.'),
              )
            ],
          ),
          ExpansionTile(
            title: const Text('How to chat?'),
            children: const [
              Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                    'Open the Users tab, tap any user to start chatting. You can send text, images, voice notes, and reply or forward messages.'),
              )
            ],
          ),
          ExpansionTile(
            title: const Text('How to use AI?'),
            children: const [
              Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                    'Tap the Lulax AI tab. Ask anything and Lulax will respond. The AI is powered by Gemini.'),
              )
            ],
          ),
          ExpansionTile(
            title: const Text('How does Status work?'),
            children: const [
              Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                    'Tap the Status tab → +. Add text or an image. Status disappears after 24 hours and shows view count.'),
              )
            ],
          ),
          const Divider(),
          const _SectionTitle('Report a problem'),
          const _ReportForm(),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 6),
      child: Text(text,
          style: const TextStyle(
              color: Colors.teal, fontWeight: FontWeight.bold)),
    );
  }
}

class _ReportForm extends StatefulWidget {
  const _ReportForm();
  @override
  State<_ReportForm> createState() => _ReportFormState();
}

class _ReportFormState extends State<_ReportForm> {
  final _username = TextEditingController();
  final _desc = TextEditingController();
  bool _busy = false;

  Future<void> _send() async {
    if (_username.text.trim().isEmpty || _desc.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Fill all fields')),
      );
      return;
    }
    setState(() => _busy = true);
    final me = context.read<AuthService>().currentUser!;
    await ModerationService().reportUser(
      reporterId: me.id,
      reportedUsername: _username.text.trim(),
      description: _desc.text.trim(),
    );
    if (!mounted) return;
    setState(() => _busy = false);
    _username.clear();
    _desc.clear();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Report submitted')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          TextField(
            controller: _username,
            decoration: const InputDecoration(
              labelText: 'Reported username',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _desc,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'Issue description',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            height: 44,
            child: ElevatedButton(
              onPressed: _busy ? null : _send,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF128C7E),
                foregroundColor: Colors.white,
              ),
              child: _busy
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text('Submit report'),
            ),
          ),
        ],
      ),
    );
  }
}
