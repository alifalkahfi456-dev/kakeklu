import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/call_model.dart';
import '../models/chat_model.dart';
import '../models/group_model.dart';
import '../models/message_model.dart';
import '../models/user_model.dart';
import '../services/admin_service.dart';
import '../services/auth_service.dart';
import '../services/call_service.dart';
import '../services/chat_service.dart';
import '../services/group_service.dart';
import '../services/storage_service.dart';
import '../utils/constants.dart';
import '../widgets/chat_bubble.dart';
import '../widgets/message_input.dart';
import 'call_screen.dart';

class ChatScreen extends StatefulWidget {
  final ChatModel chat;
  final String title;
  final UserModel? other;
  const ChatScreen({super.key, required this.chat, required this.title, this.other});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final ChatService _chat = ChatService();
  final StorageService _storage = StorageService();
  final ScrollController _scroll = ScrollController();
  MessageModel? _replyTo;
  GroupModel? _group;

  @override
  void initState() {
    super.initState();
    final me = context.read<AuthService>().currentUser;
    if (me != null) _chat.markRead(widget.chat.id, me.id);
    if (widget.chat.isGroup && widget.chat.groupId != null) {
      GroupService().get(widget.chat.groupId!).then((g) {
        if (mounted) setState(() => _group = g);
      });
    }
  }

  Future<void> _send(String text) async {
    final me = context.read<AuthService>().currentUser!;
    if (_group?.adminOnlyMessages == true && !_group!.admins.contains(me.id) && !me.isAdmin) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Only admins can send messages here.')),
      );
      return;
    }
    await _chat.sendMessage(
      chatId: widget.chat.id,
      senderId: me.id,
      members: widget.chat.members,
      text: text,
      replyToId: _replyTo?.id,
      replyToText: _replyTo?.text,
      replyToSender: _replyTo?.senderId,
    );
    setState(() => _replyTo = null);
  }

  Future<void> _sendImage(File file) async {
    final me = context.read<AuthService>().currentUser!;
    final url = await _storage.uploadImage(file, 'chat_images/${widget.chat.id}');
    await _chat.sendMessage(
      chatId: widget.chat.id,
      senderId: me.id,
      members: widget.chat.members,
      mediaUrl: url,
      type: MessageType.image,
    );
  }

  Future<void> _sendVoice(File file) async {
    final me = context.read<AuthService>().currentUser!;
    final url = await _storage.uploadAudio(file, 'voice_notes/${widget.chat.id}');
    await _chat.sendMessage(
      chatId: widget.chat.id,
      senderId: me.id,
      members: widget.chat.members,
      mediaUrl: url,
      type: MessageType.voice_note,
    );
  }

  Future<void> _onTyping(bool typing) async {
    final me = context.read<AuthService>().currentUser!;
    await _chat.setTyping(widget.chat.id, me.id, typing);
  }

  void _showMessageActions(MessageModel m) {
    final me = context.read<AuthService>().currentUser!;
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.reply),
              title: const Text('Reply'),
              onTap: () {
                Navigator.pop(context);
                setState(() => _replyTo = m);
              },
            ),
            if (m.senderId == me.id && !m.deletedForEveryone)
              ListTile(
                leading: const Icon(Icons.edit),
                title: const Text('Edit'),
                onTap: () async {
                  Navigator.pop(context);
                  final ctrl = TextEditingController(text: m.text);
                  final res = await showDialog<String>(
                    context: context,
                    builder: (_) => AlertDialog(
                      title: const Text('Edit message'),
                      content: TextField(controller: ctrl),
                      actions: [
                        TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text('Cancel')),
                        TextButton(
                            onPressed: () =>
                                Navigator.pop(context, ctrl.text),
                            child: const Text('Save')),
                      ],
                    ),
                  );
                  if (res != null) {
                    await _chat.editMessage(widget.chat.id, m.id, res);
                  }
                },
              ),
            ListTile(
              leading: const Icon(Icons.push_pin),
              title: Text(m.pinned ? 'Unpin' : 'Pin'),
              onTap: () {
                Navigator.pop(context);
                _chat.pinMessage(widget.chat.id, m.id, !m.pinned);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline),
              title: const Text('Delete for me'),
              onTap: () {
                Navigator.pop(context);
                _chat.deleteForMe(widget.chat.id, m.id, me.id);
              },
            ),
            if (m.senderId == me.id || me.isAdmin)
              ListTile(
                leading: const Icon(Icons.delete_forever, color: Colors.red),
                title: const Text('Delete for everyone'),
                onTap: () {
                  Navigator.pop(context);
                  if (me.isAdmin && m.senderId != me.id) {
                    AdminService().deleteAnyMessage(widget.chat.id, m.id);
                  } else {
                    _chat.deleteForEveryone(widget.chat.id, m.id);
                  }
                },
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _searchMessages() async {
    final ctrl = TextEditingController();
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Search messages'),
        content: TextField(controller: ctrl, autofocus: true),
        actions: [
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              final results =
                  await _chat.searchMessages(widget.chat.id, ctrl.text);
              if (!mounted) return;
              showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  title: Text('${results.length} results'),
                  content: SizedBox(
                    width: double.maxFinite,
                    child: ListView(
                      shrinkWrap: true,
                      children: results
                          .map((r) => ListTile(
                                title: Text(r.text,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis),
                                subtitle: Text(r.createdAt.toString()),
                              ))
                          .toList(),
                    ),
                  ),
                ),
              );
            },
            child: const Text('Search'),
          ),
        ],
      ),
    );
  }

  Future<void> _startCall() async {
    final me = context.read<AuthService>().currentUser!;
    final other = widget.other;
    if (other == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Voice call only in 1-to-1 chats')),
      );
      return;
    }
    final cs = CallService();
    final id = await cs.startCall(
      callerId: me.id,
      callerName: me.displayName.isEmpty ? me.username : me.displayName,
      calleeId: other.id,
      calleeName: other.displayName.isEmpty ? other.username : other.displayName,
    );
    if (!mounted) return;
    final doc = await FirebaseFirestore.instance
        .collection(AppConstants.callsCol)
        .doc(id)
        .get();
    final call = CallModel.fromMap(doc.data()!);
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => CallScreen(call: call, service: cs, isIncoming: false),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final me = context.watch<AuthService>().currentUser!;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        backgroundColor: const Color(0xFF128C7E),
        foregroundColor: Colors.white,
        actions: [
          if (!widget.chat.isGroup)
            IconButton(icon: const Icon(Icons.call), onPressed: _startCall),
          IconButton(icon: const Icon(Icons.search), onPressed: _searchMessages),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<List<MessageModel>>(
              stream: _chat.chatMessages(widget.chat.id),
              builder: (_, snap) {
                if (!snap.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final all = snap.data!
                    .where((m) => !m.deletedFor.contains(me.id))
                    .toList();
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (_scroll.hasClients) {
                    _scroll.animateTo(
                      _scroll.position.maxScrollExtent,
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeOut,
                    );
                  }
                  _chat.markRead(widget.chat.id, me.id);
                });
                return ListView.builder(
                  controller: _scroll,
                  itemCount: all.length,
                  itemBuilder: (_, i) {
                    final m = all[i];
                    return ChatBubble(
                      message: m,
                      isMe: m.senderId == me.id,
                      senderName: m.senderId == me.id ? 'You' : widget.title,
                      onLongPress: () => _showMessageActions(m),
                    );
                  },
                );
              },
            ),
          ),
          if (_replyTo != null)
            Container(
              color: Colors.grey.shade200,
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  const Icon(Icons.reply, size: 16),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(_replyTo!.text,
                        maxLines: 1, overflow: TextOverflow.ellipsis),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, size: 18),
                    onPressed: () => setState(() => _replyTo = null),
                  ),
                ],
              ),
            ),
          _TypingIndicator(chatId: widget.chat.id, meId: me.id),
          MessageInput(
            onSendText: _send,
            onSendImage: _sendImage,
            onSendVoice: _sendVoice,
            onTyping: _onTyping,
          ),
        ],
      ),
    );
  }
}

class _TypingIndicator extends StatelessWidget {
  final String chatId;
  final String meId;
  const _TypingIndicator({required this.chatId, required this.meId});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection(AppConstants.chatsCol)
          .doc(chatId)
          .snapshots(),
      builder: (_, snap) {
        final typing =
            Map<String, dynamic>.from(snap.data?.data()?['typing'] ?? {});
        final isOtherTyping =
            typing.entries.any((e) => e.key != meId && e.value == true);
        if (!isOtherTyping) return const SizedBox.shrink();
        return const Padding(
          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text('typing...',
                style: TextStyle(
                    color: Colors.teal, fontStyle: FontStyle.italic)),
          ),
        );
      },
    );
  }
}

