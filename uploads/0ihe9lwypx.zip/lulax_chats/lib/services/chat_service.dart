import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/chat_model.dart';
import '../models/message_model.dart';
import '../utils/constants.dart';
import '../utils/helpers.dart';
import 'firebase_service.dart';

class ChatService {
  FirebaseFirestore get _db => FirebaseService.instance.db;

  CollectionReference<Map<String, dynamic>> get chats =>
      _db.collection(AppConstants.chatsCol);

  CollectionReference<Map<String, dynamic>> messagesOf(String chatId) =>
      chats.doc(chatId).collection(AppConstants.messagesCol);

  Future<ChatModel> ensureOneToOneChat(String myId, String otherId) async {
    final id = Helpers.chatIdFor(myId, otherId);
    final doc = await chats.doc(id).get();
    if (!doc.exists) {
      final chat = ChatModel(
        id: id,
        members: [myId, otherId],
        isGroup: false,
        lastMessage: '',
        lastSenderId: '',
        lastUpdated: DateTime.now(),
        unread: {myId: 0, otherId: 0},
        typing: {myId: false, otherId: false},
      );
      await chats.doc(id).set(chat.toMap());
      return chat;
    }
    return ChatModel.fromMap(doc.data()!);
  }

  Stream<List<ChatModel>> myChats(String myId) {
    return chats
        .where('members', arrayContains: myId)
        .orderBy('lastUpdated', descending: true)
        .snapshots()
        .map((s) => s.docs.map((d) => ChatModel.fromMap(d.data())).toList());
  }

  Stream<List<MessageModel>> chatMessages(String chatId) {
    return messagesOf(chatId)
        .orderBy('createdAt', descending: false)
        .snapshots()
        .map((s) => s.docs.map((d) => MessageModel.fromMap(d.data())).toList());
  }

  Future<void> sendMessage({
    required String chatId,
    required String senderId,
    required List<String> members,
    String text = '',
    String mediaUrl = '',
    MessageType type = MessageType.text,
    String? replyToId,
    String? replyToText,
    String? replyToSender,
    bool forwarded = false,
  }) async {
    final id = messagesOf(chatId).doc().id;
    final msg = MessageModel(
      id: id,
      chatId: chatId,
      senderId: senderId,
      text: text,
      mediaUrl: mediaUrl,
      type: type,
      createdAt: DateTime.now(),
      readBy: [senderId],
      deletedFor: const [],
      deletedForEveryone: false,
      edited: false,
      replyToId: replyToId,
      replyToText: replyToText,
      replyToSender: replyToSender,
      forwarded: forwarded,
    );
    await messagesOf(chatId).doc(id).set(msg.toMap());

    final unreadUpdates = <String, dynamic>{};
    for (final m in members) {
      if (m != senderId) {
        unreadUpdates['unread.$m'] = FieldValue.increment(1);
      }
    }
    await chats.doc(chatId).set({
      'lastMessage': type == MessageType.text
          ? text
          : '[${type.name.replaceAll('_', ' ')}]',
      'lastSenderId': senderId,
      'lastUpdated': Timestamp.now(),
      'members': members,
      ...unreadUpdates,
    }, SetOptions(merge: true));
  }

  Future<void> markRead(String chatId, String userId) async {
    await chats.doc(chatId).set({
      'unread': {userId: 0},
    }, SetOptions(merge: true));
    final msgs = await messagesOf(chatId)
        .where('readBy', whereNotIn: [
          [userId]
        ])
        .limit(50)
        .get()
        .catchError((_) async => await messagesOf(chatId).limit(50).get());
    for (final d in msgs.docs) {
      final readBy = List<String>.from(d.data()['readBy'] ?? []);
      if (!readBy.contains(userId)) {
        readBy.add(userId);
        await d.reference.update({'readBy': readBy});
      }
    }
  }

  Future<void> setTyping(String chatId, String userId, bool typing) async {
    await chats.doc(chatId).set({
      'typing': {userId: typing},
    }, SetOptions(merge: true));
  }

  Future<void> deleteForMe(String chatId, String messageId, String userId) async {
    await messagesOf(chatId).doc(messageId).update({
      'deletedFor': FieldValue.arrayUnion([userId]),
    });
  }

  Future<void> deleteForEveryone(String chatId, String messageId) async {
    await messagesOf(chatId).doc(messageId).update({
      'deletedForEveryone': true,
      'text': '',
      'mediaUrl': '',
    });
  }

  Future<void> editMessage(String chatId, String messageId, String newText) async {
    await messagesOf(chatId).doc(messageId).update({
      'text': newText,
      'edited': true,
    });
  }

  Future<void> pinMessage(String chatId, String messageId, bool pin) async {
    await messagesOf(chatId).doc(messageId).update({'pinned': pin});
  }

  Future<List<MessageModel>> searchMessages(String chatId, String query) async {
    final snap = await messagesOf(chatId).get();
    final all = snap.docs.map((d) => MessageModel.fromMap(d.data())).toList();
    final q = query.toLowerCase();
    return all.where((m) => m.text.toLowerCase().contains(q)).toList();
  }
}
