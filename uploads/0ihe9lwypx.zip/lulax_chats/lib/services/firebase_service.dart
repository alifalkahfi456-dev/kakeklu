import 'package:cloud_firestore/cloud_firestore.dart';
import '../utils/constants.dart';
import '../utils/helpers.dart';

class FirebaseService {
  FirebaseService._();
  static final FirebaseService instance = FirebaseService._();

  FirebaseFirestore get db => FirebaseFirestore.instance;

  Future<void> bootstrap() async {
    try {
      // Ensure default admin exists
      final users = db.collection(AppConstants.usersCol);
      final existing = await users
          .where('username', isEqualTo: AppConstants.defaultAdminUsername)
          .limit(1)
          .get();
      if (existing.docs.isEmpty) {
        final id = users.doc().id;
        await users.doc(id).set({
          'id': id,
          'username': AppConstants.defaultAdminUsername,
          'password': Helpers.hashPassword(AppConstants.defaultAdminPassword),
          'displayName': 'barz',
          'photoUrl': '',
          'bio': 'Lulax Chats Developer',
          'lastSeen': Timestamp.now(),
          'isOnline': false,
          'role': 'admin',
          'isBanned': false,
          'createdAt': Timestamp.now(),
        });
      }

      // Ensure config doc
      final cfg = db
          .collection(AppConstants.configCol)
          .doc(AppConstants.configDoc);
      final cfgSnap = await cfg.get();
      if (!cfgSnap.exists) {
        await cfg.set({
          'maintenance_mode': false,
          'gemini_api_key': '',
          'broadcast_message': '',
          'feature_flags': {
            'ai': true,
            'calls': true,
            'status': true,
          },
          'rate_limits': {
            'messages_per_minute': 60,
          },
        });
      }
    } catch (e) {
      // Bootstrap may fail before Firebase is configured; ignore.
    }
  }
}
