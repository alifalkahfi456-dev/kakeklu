import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/message_model.dart';
import '../utils/constants.dart';
import 'chat_service.dart';
import 'firebase_service.dart';

class AdminService {
  FirebaseFirestore get _db => FirebaseService.instance.db;

  Future<void> banUser(String userId) async {
    await _db
        .collection(AppConstants.usersCol)
        .doc(userId)
        .update({'isBanned': true});
    await _log('ban', {'userId': userId});
  }

  Future<void> unbanUser(String userId) async {
    await _db
        .collection(AppConstants.usersCol)
        .doc(userId)
        .update({'isBanned': false});
    await _log('unban', {'userId': userId});
  }

  Future<void> deleteAnyMessage(String chatId, String messageId) async {
    await _db
        .collection(AppConstants.chatsCol)
        .doc(chatId)
        .collection(AppConstants.messagesCol)
        .doc(messageId)
        .update({
      'deletedForEveryone': true,
      'text': '[removed by admin]',
      'mediaUrl': '',
    });
    await _log('delete_message', {'chatId': chatId, 'messageId': messageId});
  }

  Future<void> broadcast(String text, String adminId) async {
    final users = await _db.collection(AppConstants.usersCol).get();
    final chatService = ChatService();
    for (final u in users.docs) {
      final uid = u.data()['id'] as String?;
      if (uid == null || uid == adminId) continue;
      final chat = await chatService.ensureOneToOneChat(adminId, uid);
      await chatService.sendMessage(
        chatId: chat.id,
        senderId: adminId,
        members: chat.members,
        text: '[BROADCAST] $text',
        type: MessageType.system_message,
      );
    }
    await _db
        .collection(AppConstants.configCol)
        .doc(AppConstants.configDoc)
        .set({'broadcast_message': text}, SetOptions(merge: true));
    await _log('broadcast', {'text': text});
  }

  Future<void> sendSystemNotification(String userId, String text, String adminId) async {
    final chatService = ChatService();
    final chat = await chatService.ensureOneToOneChat(adminId, userId);
    await chatService.sendMessage(
      chatId: chat.id,
      senderId: adminId,
      members: chat.members,
      text: text,
      type: MessageType.system_message,
    );
  }

  Future<void> _log(String action, Map<String, dynamic> data) async {
    await _db.collection(AppConstants.logsCol).add({
      'action': action,
      'data': data,
      'at': Timestamp.now(),
    });
  }
}
