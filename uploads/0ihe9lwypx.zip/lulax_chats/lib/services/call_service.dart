import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import '../models/call_model.dart';
import '../utils/constants.dart';
import 'firebase_service.dart';

/// Lightweight WebRTC voice call service using Firestore as signaling.
class CallService {
  FirebaseFirestore get _db => FirebaseService.instance.db;

  static const Map<String, dynamic> _config = {
    'iceServers': [
      {'urls': 'stun:stun.l.google.com:19302'},
      {'urls': 'stun:stun1.l.google.com:19302'},
    ],
  };

  RTCPeerConnection? pc;
  MediaStream? localStream;
  MediaStream? remoteStream;
  String? activeCallId;
  StreamSubscription? _callSub;

  CollectionReference<Map<String, dynamic>> get _calls =>
      _db.collection(AppConstants.callsCol);

  Future<MediaStream> _getLocal() async {
    final stream = await navigator.mediaDevices.getUserMedia({
      'audio': true,
      'video': false,
    });
    localStream = stream;
    return stream;
  }

  Future<String> startCall({
    required String callerId,
    required String callerName,
    required String calleeId,
    required String calleeName,
  }) async {
    pc = await createPeerConnection(_config);
    final stream = await _getLocal();
    for (final t in stream.getTracks()) {
      await pc!.addTrack(t, stream);
    }

    pc!.onTrack = (event) {
      if (event.streams.isNotEmpty) {
        remoteStream = event.streams.first;
      }
    };

    final callDoc = _calls.doc();
    activeCallId = callDoc.id;

    pc!.onIceCandidate = (c) async {
      if (c.candidate == null) return;
      await callDoc.update({
        'callerCandidates': FieldValue.arrayUnion([c.toMap()])
      });
    };

    final offer = await pc!.createOffer({'offerToReceiveAudio': 1});
    await pc!.setLocalDescription(offer);

    final call = CallModel(
      id: callDoc.id,
      callerId: callerId,
      callerName: callerName,
      calleeId: calleeId,
      calleeName: calleeName,
      startedAt: DateTime.now(),
      status: CallStatus.ringing,
      offer: {'sdp': offer.sdp, 'type': offer.type},
    );
    await callDoc.set(call.toMap());

    _callSub = callDoc.snapshots().listen((snap) async {
      final data = snap.data();
      if (data == null) return;
      if (data['answer'] != null && pc?.getRemoteDescription() == null) {
        final answer = data['answer'] as Map<String, dynamic>;
        await pc!.setRemoteDescription(
          RTCSessionDescription(answer['sdp'], answer['type']),
        );
      }
      final candidates = List.from(data['calleeCandidates'] ?? []);
      for (final c in candidates) {
        await pc?.addCandidate(RTCIceCandidate(
          c['candidate'],
          c['sdpMid'],
          c['sdpMLineIndex'],
        ));
      }
    });

    return callDoc.id;
  }

  Future<void> answerCall(String callId) async {
    final callDoc = _calls.doc(callId);
    final snap = await callDoc.get();
    if (!snap.exists) return;
    final data = snap.data()!;
    pc = await createPeerConnection(_config);
    final stream = await _getLocal();
    for (final t in stream.getTracks()) {
      await pc!.addTrack(t, stream);
    }
    pc!.onTrack = (event) {
      if (event.streams.isNotEmpty) {
        remoteStream = event.streams.first;
      }
    };
    pc!.onIceCandidate = (c) async {
      if (c.candidate == null) return;
      await callDoc.update({
        'calleeCandidates': FieldValue.arrayUnion([c.toMap()])
      });
    };

    final offer = data['offer'] as Map<String, dynamic>;
    await pc!.setRemoteDescription(
      RTCSessionDescription(offer['sdp'], offer['type']),
    );
    final answer = await pc!.createAnswer({'offerToReceiveAudio': 1});
    await pc!.setLocalDescription(answer);

    await callDoc.update({
      'answer': {'sdp': answer.sdp, 'type': answer.type},
      'status': CallStatus.accepted.name,
    });

    _callSub = callDoc.snapshots().listen((s) async {
      final d = s.data();
      if (d == null) return;
      final candidates = List.from(d['callerCandidates'] ?? []);
      for (final c in candidates) {
        await pc?.addCandidate(RTCIceCandidate(
          c['candidate'],
          c['sdpMid'],
          c['sdpMLineIndex'],
        ));
      }
    });

    activeCallId = callId;
  }

  Future<void> rejectCall(String callId) async {
    await _calls.doc(callId).update({
      'status': CallStatus.rejected.name,
      'endedAt': Timestamp.now(),
    });
  }

  Future<void> endCall() async {
    if (activeCallId != null) {
      await _calls.doc(activeCallId!).update({
        'status': CallStatus.ended.name,
        'endedAt': Timestamp.now(),
      }).catchError((_) {});
    }
    await _callSub?.cancel();
    _callSub = null;
    localStream?.getTracks().forEach((t) => t.stop());
    await localStream?.dispose();
    await pc?.close();
    pc = null;
    localStream = null;
    remoteStream = null;
    activeCallId = null;
  }

  Stream<CallModel?> incomingCalls(String userId) {
    return _calls
        .where('calleeId', isEqualTo: userId)
        .where('status', isEqualTo: CallStatus.ringing.name)
        .snapshots()
        .map((s) {
      if (s.docs.isEmpty) return null;
      return CallModel.fromMap(s.docs.first.data());
    });
  }
}
