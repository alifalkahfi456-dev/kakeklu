import 'dart:convert';
import 'package:http/http.dart' as http;

import '../admin/config_service.dart';
import '../utils/constants.dart';

class AiService {
  final ConfigService config;
  AiService(this.config);

  Future<String> ask(String prompt, {List<Map<String, String>> history = const []}) async {
    final apiKey = config.geminiApiKey;
    if (apiKey.isEmpty) {
      throw Exception('Gemini API key not configured by admin yet.');
    }
    final url = Uri.parse('${AppConstants.geminiEndpoint}?key=$apiKey');

    final contents = <Map<String, dynamic>>[];
    for (final h in history) {
      contents.add({
        'role': h['role'] ?? 'user',
        'parts': [
          {'text': h['text'] ?? ''}
        ],
      });
    }
    contents.add({
      'role': 'user',
      'parts': [
        {'text': prompt}
      ],
    });

    final body = jsonEncode({'contents': contents});
    final res = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: body,
    );
    if (res.statusCode != 200) {
      throw Exception('Gemini error ${res.statusCode}: ${res.body}');
    }
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final candidates = data['candidates'] as List?;
    if (candidates == null || candidates.isEmpty) return 'No response.';
    final parts = (candidates.first['content']?['parts'] as List?) ?? [];
    if (parts.isEmpty) return 'No response.';
    return (parts.first['text'] ?? '').toString();
  }
}
