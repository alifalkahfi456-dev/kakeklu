import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/chat_model.dart';
import '../models/group_model.dart';
import '../utils/constants.dart';
import 'firebase_service.dart';

class GroupService {
  FirebaseFirestore get _db => FirebaseService.instance.db;

  CollectionReference<Map<String, dynamic>> get groups =>
      _db.collection(AppConstants.groupsCol);

  CollectionReference<Map<String, dynamic>> get chats =>
      _db.collection(AppConstants.chatsCol);

  Future<GroupModel> createGroup({
    required String name,
    required String description,
    required String createdBy,
    required List<String> members,
  }) async {
    final groupId = groups.doc().id;
    final chatId = 'group_$groupId';
    final allMembers = {...members, createdBy}.toList();
    final group = GroupModel(
      id: groupId,
      name: name,
      description: description,
      photoUrl: '',
      chatId: chatId,
      members: allMembers,
      admins: [createdBy],
      createdBy: createdBy,
      createdAt: DateTime.now(),
      adminOnlyMessages: false,
    );
    await groups.doc(groupId).set(group.toMap());

    final chat = ChatModel(
      id: chatId,
      members: allMembers,
      isGroup: true,
      groupId: groupId,
      lastMessage: 'Group created',
      lastSenderId: createdBy,
      lastUpdated: DateTime.now(),
      unread: {for (final m in allMembers) m: 0},
      typing: {for (final m in allMembers) m: false},
    );
    await chats.doc(chatId).set(chat.toMap());
    return group;
  }

  Future<void> addMember(String groupId, String userId) async {
    final group = await groups.doc(groupId).get();
    if (!group.exists) return;
    final chatId = group.data()!['chatId'] as String;
    await groups.doc(groupId).update({
      'members': FieldValue.arrayUnion([userId]),
    });
    await chats.doc(chatId).update({
      'members': FieldValue.arrayUnion([userId]),
    });
  }

  Future<void> removeMember(String groupId, String userId) async {
    final group = await groups.doc(groupId).get();
    if (!group.exists) return;
    final chatId = group.data()!['chatId'] as String;
    await groups.doc(groupId).update({
      'members': FieldValue.arrayRemove([userId]),
      'admins': FieldValue.arrayRemove([userId]),
    });
    await chats.doc(chatId).update({
      'members': FieldValue.arrayRemove([userId]),
    });
  }

  Future<void> promoteAdmin(String groupId, String userId) async {
    await groups.doc(groupId).update({
      'admins': FieldValue.arrayUnion([userId]),
    });
  }

  Future<void> demoteAdmin(String groupId, String userId) async {
    await groups.doc(groupId).update({
      'admins': FieldValue.arrayRemove([userId]),
    });
  }

  Future<void> setAdminOnlyMessages(String groupId, bool value) async {
    await groups.doc(groupId).update({'adminOnlyMessages': value});
  }

  Future<GroupModel?> get(String groupId) async {
    final doc = await groups.doc(groupId).get();
    if (!doc.exists) return null;
    return GroupModel.fromMap(doc.data()!);
  }

  Stream<GroupModel> watch(String groupId) {
    return groups.doc(groupId).snapshots().map((d) => GroupModel.fromMap(d.data() ?? {}));
  }
}
