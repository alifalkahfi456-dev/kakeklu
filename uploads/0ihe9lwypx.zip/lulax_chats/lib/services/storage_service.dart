import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

class StorageService {
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final _uuid = const Uuid();

  Future<File> _compressImage(File file) async {
    final dir = await getTemporaryDirectory();
    final target = '${dir.path}/${_uuid.v4()}.jpg';
    final result = await FlutterImageCompress.compressAndGetFile(
      file.absolute.path,
      target,
      quality: 70,
      minWidth: 1080,
      minHeight: 1080,
    );
    return result == null ? file : File(result.path);
  }

  Future<String> uploadImage(File file, String folder) async {
    final compressed = await _compressImage(file);
    final ref = _storage.ref('$folder/${_uuid.v4()}.jpg');
    final snap = await ref.putFile(compressed);
    return snap.ref.getDownloadURL();
  }

  Future<String> uploadAudio(File file, String folder) async {
    final ref = _storage.ref('$folder/${_uuid.v4()}.m4a');
    final snap = await ref.putFile(file);
    return snap.ref.getDownloadURL();
  }

  Future<String> uploadFile(File file, String folder, String ext) async {
    final ref = _storage.ref('$folder/${_uuid.v4()}.$ext');
    final snap = await ref.putFile(file);
    return snap.ref.getDownloadURL();
  }
}
