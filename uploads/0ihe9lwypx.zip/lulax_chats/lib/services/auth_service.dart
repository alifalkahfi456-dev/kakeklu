import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/user_model.dart';
import '../utils/constants.dart';
import '../utils/helpers.dart';
import 'firebase_service.dart';

class AuthService extends ChangeNotifier {
  UserModel? _currentUser;
  UserModel? get currentUser => _currentUser;
  bool get isLoggedIn => _currentUser != null;

  FirebaseFirestore get _db => FirebaseService.instance.db;

  Future<bool> tryAutoLogin() async {
    final sp = await SharedPreferences.getInstance();
    final id = sp.getString('uid');
    if (id == null) return false;
    final doc = await _db.collection(AppConstants.usersCol).doc(id).get();
    if (!doc.exists) return false;
    _currentUser = UserModel.fromMap(doc.data()!);
    if (_currentUser!.isBanned) {
      _currentUser = null;
      return false;
    }
    await _setOnline(true);
    notifyListeners();
    return true;
  }

  Future<UserModel> register({
    required String username,
    required String password,
    required String displayName,
  }) async {
    final users = _db.collection(AppConstants.usersCol);
    final existing =
        await users.where('username', isEqualTo: username).limit(1).get();
    if (existing.docs.isNotEmpty) {
      throw Exception('Username already taken');
    }
    final id = users.doc().id;
    final user = UserModel(
      id: id,
      username: username,
      password: Helpers.hashPassword(password),
      displayName: displayName.isEmpty ? username : displayName,
      photoUrl: '',
      bio: '',
      lastSeen: DateTime.now(),
      isOnline: true,
      role: 'user',
      isBanned: false,
      createdAt: DateTime.now(),
    );
    await users.doc(id).set(user.toMap());
    _currentUser = user;
    final sp = await SharedPreferences.getInstance();
    await sp.setString('uid', id);
    notifyListeners();
    return user;
  }

  Future<UserModel> login(String username, String password) async {
    final users = _db.collection(AppConstants.usersCol);
    final snap =
        await users.where('username', isEqualTo: username).limit(1).get();
    if (snap.docs.isEmpty) throw Exception('User not found');
    final data = snap.docs.first.data();
    final user = UserModel.fromMap(data);
    if (user.password != Helpers.hashPassword(password)) {
      throw Exception('Wrong password');
    }
    if (user.isBanned) throw Exception('Your account has been banned');
    _currentUser = user;
    await _setOnline(true);
    final sp = await SharedPreferences.getInstance();
    await sp.setString('uid', user.id);
    notifyListeners();
    return user;
  }

  Future<void> logout() async {
    await _setOnline(false);
    _currentUser = null;
    final sp = await SharedPreferences.getInstance();
    await sp.remove('uid');
    notifyListeners();
  }

  Future<void> _setOnline(bool online) async {
    if (_currentUser == null) return;
    await _db.collection(AppConstants.usersCol).doc(_currentUser!.id).update({
      'isOnline': online,
      'lastSeen': Timestamp.now(),
    });
  }

  Future<void> updateProfile({
    String? displayName,
    String? bio,
    String? photoUrl,
  }) async {
    if (_currentUser == null) return;
    final updates = <String, dynamic>{};
    if (displayName != null) updates['displayName'] = displayName;
    if (bio != null) updates['bio'] = bio;
    if (photoUrl != null) updates['photoUrl'] = photoUrl;
    if (updates.isEmpty) return;
    await _db
        .collection(AppConstants.usersCol)
        .doc(_currentUser!.id)
        .update(updates);
    final doc = await _db
        .collection(AppConstants.usersCol)
        .doc(_currentUser!.id)
        .get();
    _currentUser = UserModel.fromMap(doc.data()!);
    notifyListeners();
  }
}
