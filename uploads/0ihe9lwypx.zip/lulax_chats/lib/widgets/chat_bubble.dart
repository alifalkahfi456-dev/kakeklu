import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../models/message_model.dart';
import '../utils/helpers.dart';
import 'voice_player.dart';

class ChatBubble extends StatelessWidget {
  final MessageModel message;
  final bool isMe;
  final String senderName;
  final VoidCallback? onLongPress;
  final VoidCallback? onReply;

  const ChatBubble({
    super.key,
    required this.message,
    required this.isMe,
    required this.senderName,
    this.onLongPress,
    this.onReply,
  });

  @override
  Widget build(BuildContext context) {
    final align = isMe ? Alignment.centerRight : Alignment.centerLeft;
    final color = isMe
        ? const Color(0xFFDCF8C6)
        : Theme.of(context).colorScheme.surface;
    final textColor = Colors.black87;

    if (message.type == MessageType.system_message) {
      return Center(
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 24),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: Colors.amber.shade100,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(message.text,
              style: const TextStyle(fontSize: 12, color: Colors.black87)),
        ),
      );
    }

    Widget content;
    if (message.deletedForEveryone) {
      content = const Text(
        'This message was deleted',
        style: TextStyle(fontStyle: FontStyle.italic, color: Colors.black54),
      );
    } else {
      switch (message.type) {
        case MessageType.image:
          content = ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: CachedNetworkImage(
              imageUrl: message.mediaUrl,
              width: 220,
              fit: BoxFit.cover,
              placeholder: (_, __) =>
                  Container(width: 220, height: 200, color: Colors.grey.shade300),
            ),
          );
          break;
        case MessageType.voice_note:
          content = VoicePlayer(url: message.mediaUrl);
          break;
        case MessageType.sticker:
          content = CachedNetworkImage(imageUrl: message.mediaUrl, width: 120);
          break;
        default:
          content = Text(message.text, style: TextStyle(color: textColor, fontSize: 15));
      }
    }

    return Align(
      alignment: align,
      child: GestureDetector(
        onLongPress: onLongPress,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 3, horizontal: 8),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          constraints: const BoxConstraints(maxWidth: 280),
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(0.06),
                  blurRadius: 4,
                  offset: const Offset(0, 2))
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              if (!isMe)
                Padding(
                  padding: const EdgeInsets.only(bottom: 2),
                  child: Text(senderName,
                      style: TextStyle(
                          color: Colors.teal.shade700,
                          fontSize: 12,
                          fontWeight: FontWeight.w600)),
                ),
              if (message.replyToText != null && message.replyToText!.isNotEmpty)
                Container(
                  padding: const EdgeInsets.all(6),
                  margin: const EdgeInsets.only(bottom: 4),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    '${message.replyToSender ?? ''}: ${message.replyToText}',
                    style: const TextStyle(fontSize: 12, color: Colors.black54),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              if (message.forwarded)
                const Padding(
                  padding: EdgeInsets.only(bottom: 2),
                  child: Text('Forwarded',
                      style: TextStyle(
                          fontSize: 11,
                          fontStyle: FontStyle.italic,
                          color: Colors.black45)),
                ),
              content,
              const SizedBox(height: 2),
              Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  if (message.edited)
                    const Text('edited ',
                        style: TextStyle(fontSize: 10, color: Colors.black45)),
                  if (message.pinned)
                    const Icon(Icons.push_pin, size: 11, color: Colors.black45),
                  Text(Helpers.formatTime(message.createdAt),
                      style:
                          const TextStyle(fontSize: 10, color: Colors.black54)),
                  if (isMe) const SizedBox(width: 4),
                  if (isMe)
                    Icon(
                      message.readBy.length > 1
                          ? Icons.done_all
                          : Icons.check,
                      size: 14,
                      color: message.readBy.length > 1
                          ? Colors.blue
                          : Colors.black45,
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
