import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';

class MessageInput extends StatefulWidget {
  final void Function(String text) onSendText;
  final void Function(File file) onSendImage;
  final void Function(File file) onSendVoice;
  final void Function(bool typing)? onTyping;

  const MessageInput({
    super.key,
    required this.onSendText,
    required this.onSendImage,
    required this.onSendVoice,
    this.onTyping,
  });

  @override
  State<MessageInput> createState() => _MessageInputState();
}

class _MessageInputState extends State<MessageInput> {
  final TextEditingController _ctrl = TextEditingController();
  final AudioRecorder _recorder = AudioRecorder();
  bool _recording = false;
  bool _cancelled = false;
  String? _recordPath;
  Timer? _typingTimer;

  @override
  void dispose() {
    _ctrl.dispose();
    _recorder.dispose();
    _typingTimer?.cancel();
    super.dispose();
  }

  void _onChanged(String v) {
    widget.onTyping?.call(true);
    _typingTimer?.cancel();
    _typingTimer = Timer(const Duration(seconds: 2), () {
      widget.onTyping?.call(false);
    });
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final x = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (x != null) widget.onSendImage(File(x.path));
  }

  Future<void> _startRecord() async {
    final mic = await Permission.microphone.request();
    if (!mic.isGranted) return;
    final dir = await getTemporaryDirectory();
    final path = '${dir.path}/${DateTime.now().millisecondsSinceEpoch}.m4a';
    await _recorder.start(const RecordConfig(), path: path);
    _recordPath = path;
    setState(() {
      _recording = true;
      _cancelled = false;
    });
  }

  Future<void> _stopRecord() async {
    final path = await _recorder.stop();
    setState(() => _recording = false);
    if (_cancelled || path == null) return;
    final f = File(path);
    if (await f.exists()) {
      widget.onSendVoice(f);
    }
  }

  void _send() {
    final txt = _ctrl.text.trim();
    if (txt.isEmpty) return;
    widget.onSendText(txt);
    _ctrl.clear();
    widget.onTyping?.call(false);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        color: Colors.grey.shade100,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            IconButton(
              icon: const Icon(Icons.image, color: Colors.teal),
              onPressed: _pickImage,
            ),
            Expanded(
              child: _recording
                  ? GestureDetector(
                      onHorizontalDragUpdate: (d) {
                        if (d.delta.dx < -3) {
                          _cancelled = true;
                        }
                      },
                      onHorizontalDragEnd: (_) async {
                        if (_cancelled) await _stopRecord();
                      },
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.red.shade50,
                          borderRadius: BorderRadius.circular(24),
                        ),
                        child: Row(
                          children: const [
                            Icon(Icons.mic, color: Colors.red),
                            SizedBox(width: 8),
                            Text('Recording... slide to cancel'),
                          ],
                        ),
                      ),
                    )
                  : TextField(
                      controller: _ctrl,
                      onChanged: _onChanged,
                      minLines: 1,
                      maxLines: 4,
                      decoration: InputDecoration(
                        hintText: 'Message',
                        filled: true,
                        fillColor: Colors.white,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: BorderSide.none,
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 10),
                      ),
                    ),
            ),
            const SizedBox(width: 4),
            _ctrl.text.trim().isEmpty
                ? GestureDetector(
                    onLongPressStart: (_) => _startRecord(),
                    onLongPressEnd: (_) => _stopRecord(),
                    child: CircleAvatar(
                      backgroundColor: Colors.teal,
                      child: Icon(_recording ? Icons.stop : Icons.mic,
                          color: Colors.white),
                    ),
                  )
                : CircleAvatar(
                    backgroundColor: Colors.teal,
                    child: IconButton(
                      icon: const Icon(Icons.send, color: Colors.white),
                      onPressed: _send,
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}
