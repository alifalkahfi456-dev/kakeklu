import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../models/user_model.dart';

class UserTile extends StatelessWidget {
  final UserModel user;
  final String? subtitle;
  final VoidCallback? onTap;
  final Widget? trailing;
  const UserTile({
    super.key,
    required this.user,
    this.subtitle,
    this.onTap,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: Stack(
        children: [
          CircleAvatar(
            radius: 24,
            backgroundColor: Colors.teal.shade100,
            backgroundImage: user.photoUrl.isNotEmpty
                ? CachedNetworkImageProvider(user.photoUrl)
                : null,
            child: user.photoUrl.isEmpty
                ? Text(
                    (user.displayName.isNotEmpty
                            ? user.displayName[0]
                            : user.username[0])
                        .toUpperCase(),
                    style: const TextStyle(
                        color: Colors.teal, fontWeight: FontWeight.bold),
                  )
                : null,
          ),
          if (user.isOnline)
            Positioned(
              right: 0,
              bottom: 0,
              child: Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  color: Colors.green,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 2),
                ),
              ),
            ),
        ],
      ),
      title: Row(
        children: [
          Expanded(
              child: Text(user.displayName.isEmpty ? user.username : user.displayName,
                  maxLines: 1, overflow: TextOverflow.ellipsis)),
          if (user.isAdmin)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.amber.shade200,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Text('ADMIN', style: TextStyle(fontSize: 10)),
            ),
        ],
      ),
      subtitle: subtitle != null
          ? Text(subtitle!, maxLines: 1, overflow: TextOverflow.ellipsis)
          : Text('@${user.username}',
              style: const TextStyle(color: Colors.black54)),
      trailing: trailing,
    );
  }
}
