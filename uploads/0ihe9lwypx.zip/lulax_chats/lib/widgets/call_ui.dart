import 'package:flutter/material.dart';

class CallUI extends StatelessWidget {
  final String name;
  final String state; // 'ringing' | 'in_call' | 'ended'
  final VoidCallback? onAccept;
  final VoidCallback? onReject;
  final VoidCallback? onEnd;
  final VoidCallback? onMute;
  final bool muted;

  const CallUI({
    super.key,
    required this.name,
    required this.state,
    this.onAccept,
    this.onReject,
    this.onEnd,
    this.onMute,
    this.muted = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF075E54), Color(0xFF128C7E)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(height: 80),
            Column(
              children: [
                CircleAvatar(
                  radius: 60,
                  backgroundColor: Colors.white24,
                  child: Text(
                    name.isNotEmpty ? name[0].toUpperCase() : '?',
                    style: const TextStyle(fontSize: 48, color: Colors.white),
                  ),
                ),
                const SizedBox(height: 24),
                Text(name,
                    style: const TextStyle(color: Colors.white, fontSize: 28)),
                const SizedBox(height: 8),
                Text(
                  state == 'ringing'
                      ? 'Ringing...'
                      : state == 'in_call'
                          ? 'Voice call'
                          : 'Call ended',
                  style: const TextStyle(color: Colors.white70, fontSize: 16),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 60),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  if (state == 'ringing' && onReject != null)
                    _circleButton(Icons.call_end, Colors.red, onReject!),
                  if (state == 'ringing' && onAccept != null)
                    _circleButton(Icons.call, Colors.green, onAccept!),
                  if (state == 'in_call') ...[
                    _circleButton(
                      muted ? Icons.mic_off : Icons.mic,
                      Colors.white24,
                      onMute ?? () {},
                    ),
                    _circleButton(Icons.call_end, Colors.red, onEnd ?? () {}),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _circleButton(IconData icon, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 64,
        height: 64,
        decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        child: Icon(icon, color: Colors.white, size: 28),
      ),
    );
  }
}
