import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../models/status_model.dart';
import '../utils/helpers.dart';

class StatusTile extends StatelessWidget {
  final StatusModel status;
  final VoidCallback? onTap;
  const StatusTile({super.key, required this.status, this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: CircleAvatar(
        radius: 26,
        backgroundColor: Colors.teal,
        child: CircleAvatar(
          radius: 23,
          backgroundColor: Colors.white,
          backgroundImage: status.userPhoto.isNotEmpty
              ? CachedNetworkImageProvider(status.userPhoto)
              : null,
          child: status.userPhoto.isEmpty
              ? Text(status.username.isNotEmpty
                  ? status.username[0].toUpperCase()
                  : '?')
              : null,
        ),
      ),
      title: Text(status.username),
      subtitle: Text(Helpers.formatTime(status.createdAt)),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.remove_red_eye, size: 14, color: Colors.black45),
          const SizedBox(width: 4),
          Text('${status.viewCount}'),
        ],
      ),
    );
  }
}
