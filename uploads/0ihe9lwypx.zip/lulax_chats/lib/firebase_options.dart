// ============================================================================
// Firebase Options - Lulax Chats
// ----------------------------------------------------------------------------
// Project: lulax-chats
// Diisi manual berdasarkan config dari Firebase Console (Web app).
//
// CATATAN PENTING:
// - Slot WEB udah lengkap (sesuai data yang dikasih).
// - Slot ANDROID sementara reuse apiKey/senderId/projectId yang sama.
//   appId Android-nya MASIH placeholder. Buat APK production yang bener,
//   lo wajib daftarin Android app di Firebase Console (package name:
//   com.barz.lulax_chats), download google-services.json, lalu ganti
//   nilai `appId` Android di bawah dengan yang format `1:...:android:...`.
// - Slot iOS belum diisi (opsional).
// ============================================================================

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  // ---- ANDROID ----
  // TODO: Ganti `appId` di bawah dengan App ID Android dari Firebase Console
  // setelah lo daftarin Android app (format: 1:820478835670:android:xxxxxxxx).
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAhv70i7NXCv-qiVW-NlEW_QhMk0STc0aI',
    appId: '1:820478835670:android:REPLACE_WITH_ANDROID_APP_ID',
    messagingSenderId: '820478835670',
    projectId: 'lulax-chats',
    storageBucket: 'lulax-chats.firebasestorage.app',
  );

  // ---- iOS ---- (opsional)
  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyAhv70i7NXCv-qiVW-NlEW_QhMk0STc0aI',
    appId: '1:820478835670:ios:REPLACE_WITH_IOS_APP_ID',
    messagingSenderId: '820478835670',
    projectId: 'lulax-chats',
    storageBucket: 'lulax-chats.firebasestorage.app',
    iosBundleId: 'com.barz.lulaxChats',
  );

  // ---- WEB ---- (lengkap)
  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyAhv70i7NXCv-qiVW-NlEW_QhMk0STc0aI',
    appId: '1:820478835670:web:e6453b9cbe476ebfc40277',
    messagingSenderId: '820478835670',
    projectId: 'lulax-chats',
    storageBucket: 'lulax-chats.firebasestorage.app',
    authDomain: 'lulax-chats.firebaseapp.com',
  );
}
