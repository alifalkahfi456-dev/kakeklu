import 'package:cloud_firestore/cloud_firestore.dart';

enum MessageType { text, image, voice_note, sticker, system_message, reply, forwarded }

MessageType messageTypeFromString(String s) {
  return MessageType.values.firstWhere(
    (e) => e.name == s,
    orElse: () => MessageType.text,
  );
}

class MessageModel {
  final String id;
  final String chatId;
  final String senderId;
  final String text;
  final String mediaUrl;
  final MessageType type;
  final DateTime createdAt;
  final List<String> readBy;
  final List<String> deletedFor;
  final bool deletedForEveryone;
  final bool edited;
  final String? replyToId;
  final String? replyToText;
  final String? replyToSender;
  final bool forwarded;
  final bool pinned;

  MessageModel({
    required this.id,
    required this.chatId,
    required this.senderId,
    required this.text,
    required this.mediaUrl,
    required this.type,
    required this.createdAt,
    required this.readBy,
    required this.deletedFor,
    required this.deletedForEveryone,
    required this.edited,
    this.replyToId,
    this.replyToText,
    this.replyToSender,
    this.forwarded = false,
    this.pinned = false,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'chatId': chatId,
        'senderId': senderId,
        'text': text,
        'mediaUrl': mediaUrl,
        'type': type.name,
        'createdAt': Timestamp.fromDate(createdAt),
        'readBy': readBy,
        'deletedFor': deletedFor,
        'deletedForEveryone': deletedForEveryone,
        'edited': edited,
        'replyToId': replyToId,
        'replyToText': replyToText,
        'replyToSender': replyToSender,
        'forwarded': forwarded,
        'pinned': pinned,
      };

  factory MessageModel.fromMap(Map<String, dynamic> m) => MessageModel(
        id: m['id'] ?? '',
        chatId: m['chatId'] ?? '',
        senderId: m['senderId'] ?? '',
        text: m['text'] ?? '',
        mediaUrl: m['mediaUrl'] ?? '',
        type: messageTypeFromString(m['type'] ?? 'text'),
        createdAt: (m['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
        readBy: List<String>.from(m['readBy'] ?? []),
        deletedFor: List<String>.from(m['deletedFor'] ?? []),
        deletedForEveryone: m['deletedForEveryone'] ?? false,
        edited: m['edited'] ?? false,
        replyToId: m['replyToId'],
        replyToText: m['replyToText'],
        replyToSender: m['replyToSender'],
        forwarded: m['forwarded'] ?? false,
        pinned: m['pinned'] ?? false,
      );
}
