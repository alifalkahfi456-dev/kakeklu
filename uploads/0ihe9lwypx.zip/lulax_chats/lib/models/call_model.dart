import 'package:cloud_firestore/cloud_firestore.dart';

enum CallStatus { ringing, accepted, rejected, ended, missed }

class CallModel {
  final String id;
  final String callerId;
  final String callerName;
  final String calleeId;
  final String calleeName;
  final DateTime startedAt;
  final DateTime? endedAt;
  final CallStatus status;
  final Map<String, dynamic>? offer;
  final Map<String, dynamic>? answer;
  final List<dynamic> callerCandidates;
  final List<dynamic> calleeCandidates;

  CallModel({
    required this.id,
    required this.callerId,
    required this.callerName,
    required this.calleeId,
    required this.calleeName,
    required this.startedAt,
    this.endedAt,
    required this.status,
    this.offer,
    this.answer,
    this.callerCandidates = const [],
    this.calleeCandidates = const [],
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'callerId': callerId,
        'callerName': callerName,
        'calleeId': calleeId,
        'calleeName': calleeName,
        'startedAt': Timestamp.fromDate(startedAt),
        'endedAt': endedAt != null ? Timestamp.fromDate(endedAt!) : null,
        'status': status.name,
        'offer': offer,
        'answer': answer,
        'callerCandidates': callerCandidates,
        'calleeCandidates': calleeCandidates,
      };

  factory CallModel.fromMap(Map<String, dynamic> m) => CallModel(
        id: m['id'] ?? '',
        callerId: m['callerId'] ?? '',
        callerName: m['callerName'] ?? '',
        calleeId: m['calleeId'] ?? '',
        calleeName: m['calleeName'] ?? '',
        startedAt: (m['startedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
        endedAt: (m['endedAt'] as Timestamp?)?.toDate(),
        status: CallStatus.values.firstWhere(
          (e) => e.name == (m['status'] ?? 'ringing'),
          orElse: () => CallStatus.ringing,
        ),
        offer: m['offer'] == null ? null : Map<String, dynamic>.from(m['offer']),
        answer:
            m['answer'] == null ? null : Map<String, dynamic>.from(m['answer']),
        callerCandidates: List.from(m['callerCandidates'] ?? []),
        calleeCandidates: List.from(m['calleeCandidates'] ?? []),
      );
}
