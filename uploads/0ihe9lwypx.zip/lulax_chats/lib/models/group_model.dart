import 'package:cloud_firestore/cloud_firestore.dart';

class GroupModel {
  final String id;
  final String name;
  final String description;
  final String photoUrl;
  final String chatId;
  final List<String> members;
  final List<String> admins;
  final String createdBy;
  final DateTime createdAt;
  final bool adminOnlyMessages;

  GroupModel({
    required this.id,
    required this.name,
    required this.description,
    required this.photoUrl,
    required this.chatId,
    required this.members,
    required this.admins,
    required this.createdBy,
    required this.createdAt,
    required this.adminOnlyMessages,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'description': description,
        'photoUrl': photoUrl,
        'chatId': chatId,
        'members': members,
        'admins': admins,
        'createdBy': createdBy,
        'createdAt': Timestamp.fromDate(createdAt),
        'adminOnlyMessages': adminOnlyMessages,
      };

  factory GroupModel.fromMap(Map<String, dynamic> m) => GroupModel(
        id: m['id'] ?? '',
        name: m['name'] ?? '',
        description: m['description'] ?? '',
        photoUrl: m['photoUrl'] ?? '',
        chatId: m['chatId'] ?? '',
        members: List<String>.from(m['members'] ?? []),
        admins: List<String>.from(m['admins'] ?? []),
        createdBy: m['createdBy'] ?? '',
        createdAt: (m['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
        adminOnlyMessages: m['adminOnlyMessages'] ?? false,
      );
}
