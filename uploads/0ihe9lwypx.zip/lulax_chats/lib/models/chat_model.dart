import 'package:cloud_firestore/cloud_firestore.dart';

class ChatModel {
  final String id;
  final List<String> members;
  final bool isGroup;
  final String? groupId;
  final String lastMessage;
  final String lastSenderId;
  final DateTime lastUpdated;
  final Map<String, int> unread;
  final Map<String, bool> typing;

  ChatModel({
    required this.id,
    required this.members,
    required this.isGroup,
    this.groupId,
    required this.lastMessage,
    required this.lastSenderId,
    required this.lastUpdated,
    required this.unread,
    required this.typing,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'members': members,
        'isGroup': isGroup,
        'groupId': groupId,
        'lastMessage': lastMessage,
        'lastSenderId': lastSenderId,
        'lastUpdated': Timestamp.fromDate(lastUpdated),
        'unread': unread,
        'typing': typing,
      };

  factory ChatModel.fromMap(Map<String, dynamic> m) => ChatModel(
        id: m['id'] ?? '',
        members: List<String>.from(m['members'] ?? []),
        isGroup: m['isGroup'] ?? false,
        groupId: m['groupId'],
        lastMessage: m['lastMessage'] ?? '',
        lastSenderId: m['lastSenderId'] ?? '',
        lastUpdated:
            (m['lastUpdated'] as Timestamp?)?.toDate() ?? DateTime.now(),
        unread: Map<String, int>.from(m['unread'] ?? {}),
        typing: Map<String, bool>.from(m['typing'] ?? {}),
      );
}
