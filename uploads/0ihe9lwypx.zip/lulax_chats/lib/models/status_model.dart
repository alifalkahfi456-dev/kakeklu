import 'package:cloud_firestore/cloud_firestore.dart';

class StatusModel {
  final String id;
  final String userId;
  final String username;
  final String userPhoto;
  final String text;
  final String mediaUrl; // image
  final String type; // 'text' | 'image'
  final DateTime createdAt;
  final DateTime expiresAt;
  final List<String> seenBy;

  StatusModel({
    required this.id,
    required this.userId,
    required this.username,
    required this.userPhoto,
    required this.text,
    required this.mediaUrl,
    required this.type,
    required this.createdAt,
    required this.expiresAt,
    required this.seenBy,
  });

  int get viewCount => seenBy.length;
  bool get isExpired => DateTime.now().isAfter(expiresAt);

  Map<String, dynamic> toMap() => {
        'id': id,
        'userId': userId,
        'username': username,
        'userPhoto': userPhoto,
        'text': text,
        'mediaUrl': mediaUrl,
        'type': type,
        'createdAt': Timestamp.fromDate(createdAt),
        'expiresAt': Timestamp.fromDate(expiresAt),
        'seenBy': seenBy,
      };

  factory StatusModel.fromMap(Map<String, dynamic> m) => StatusModel(
        id: m['id'] ?? '',
        userId: m['userId'] ?? '',
        username: m['username'] ?? '',
        userPhoto: m['userPhoto'] ?? '',
        text: m['text'] ?? '',
        mediaUrl: m['mediaUrl'] ?? '',
        type: m['type'] ?? 'text',
        createdAt: (m['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
        expiresAt: (m['expiresAt'] as Timestamp?)?.toDate() ??
            DateTime.now().add(const Duration(hours: 24)),
        seenBy: List<String>.from(m['seenBy'] ?? []),
      );
}
