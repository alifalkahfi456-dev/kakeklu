import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String id;
  final String username;
  final String password; // hashed
  final String displayName;
  final String photoUrl;
  final String bio;
  final DateTime lastSeen;
  final bool isOnline;
  final String role; // 'user' | 'admin'
  final bool isBanned;
  final DateTime createdAt;

  UserModel({
    required this.id,
    required this.username,
    required this.password,
    required this.displayName,
    required this.photoUrl,
    required this.bio,
    required this.lastSeen,
    required this.isOnline,
    required this.role,
    required this.isBanned,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'username': username,
        'password': password,
        'displayName': displayName,
        'photoUrl': photoUrl,
        'bio': bio,
        'lastSeen': Timestamp.fromDate(lastSeen),
        'isOnline': isOnline,
        'role': role,
        'isBanned': isBanned,
        'createdAt': Timestamp.fromDate(createdAt),
      };

  factory UserModel.fromMap(Map<String, dynamic> m) => UserModel(
        id: m['id'] ?? '',
        username: m['username'] ?? '',
        password: m['password'] ?? '',
        displayName: m['displayName'] ?? '',
        photoUrl: m['photoUrl'] ?? '',
        bio: m['bio'] ?? '',
        lastSeen: (m['lastSeen'] as Timestamp?)?.toDate() ?? DateTime.now(),
        isOnline: m['isOnline'] ?? false,
        role: m['role'] ?? 'user',
        isBanned: m['isBanned'] ?? false,
        createdAt: (m['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      );

  bool get isAdmin => role == 'admin';
}
