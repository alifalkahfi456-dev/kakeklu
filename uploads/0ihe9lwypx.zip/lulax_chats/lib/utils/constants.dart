class AppConstants {
  static const String appName = 'Lulax Chats';
  static const String developer = 'barz';

  // Firestore collections
  static const String usersCol = 'users';
  static const String chatsCol = 'chats';
  static const String messagesCol = 'messages';
  static const String groupsCol = 'groups';
  static const String statusCol = 'status';
  static const String callsCol = 'calls';
  static const String configCol = 'app_config';
  static const String configDoc = 'main';
  static const String reportsCol = 'reports';
  static const String logsCol = 'logs';

  // Default admin
  static const String defaultAdminUsername = 'barz';
  static const String defaultAdminPassword = '1';

  // Contact
  static const String contactWhatsApp = '6285813973702';
  static const String contactTelegram = '@barzpuqi';
  static const String contactTikTok = '@barzwlee';

  // ===========================================================================
  // GEMINI API
  // ---------------------------------------------------------------------------
  // Primary key di-load LIVE dari Firestore: app_config/main -> gemini_api_key
  // (lihat ConfigService). Nilai di bawah ini hanya FALLBACK saat dokumen
  // app_config belum ada / kosong. Ganti string PASTE_GEMINI_API_KEY_HERE
  // dengan API key dari https://aistudio.google.com/app/apikey
  // ===========================================================================
  static const String geminiApiKeyFallback = 'PASTE_GEMINI_API_KEY_HERE';

  static const String geminiEndpoint =
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';
}
