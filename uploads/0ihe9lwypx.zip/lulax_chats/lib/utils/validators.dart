class Validators {
  static String? username(String? v) {
    if (v == null || v.trim().isEmpty) return 'Username is required';
    if (v.length < 3) return 'At least 3 characters';
    if (v.length > 20) return 'Max 20 characters';
    if (!RegExp(r'^[a-zA-Z0-9_.]+$').hasMatch(v)) {
      return 'Only letters, numbers, _ and .';
    }
    return null;
  }

  static String? password(String? v) {
    if (v == null || v.isEmpty) return 'Password is required';
    if (v.length < 1) return 'Password too short';
    return null;
  }

  static String? notEmpty(String? v) {
    if (v == null || v.trim().isEmpty) return 'Required';
    return null;
  }
}
