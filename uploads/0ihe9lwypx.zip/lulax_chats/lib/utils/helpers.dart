import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:intl/intl.dart';

class Helpers {
  static String hashPassword(String password) {
    final bytes = utf8.encode('lulax_salt::$password');
    return sha256.convert(bytes).toString();
  }

  static String formatTime(DateTime dt) {
    final now = DateTime.now();
    if (now.day == dt.day && now.month == dt.month && now.year == dt.year) {
      return DateFormat('HH:mm').format(dt);
    }
    if (now.difference(dt).inDays < 7) {
      return DateFormat('EEE HH:mm').format(dt);
    }
    return DateFormat('dd/MM/yyyy HH:mm').format(dt);
  }

  static String chatIdFor(String a, String b) {
    final list = [a, b]..sort();
    return list.join('_');
  }
}
