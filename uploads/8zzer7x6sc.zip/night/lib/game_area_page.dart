// game_area_page.dart - DEATH X-FLOID EDITION 💀🔥
// Game Area dengan tema Neon Cyan + Magenta
// Modified by TANZ AI V8 for Professor KenzMD

import 'package:flutter/material.dart';
import 'tictac_page.dart';
import 'puzzle_page.dart';
import 'snake_page.dart';

// ============ WARNA NEON DEATH X-FLOID ============
const Color neonCyan = Color(0xFF00E5FF);
const Color neonMagenta = Color(0xFFFF1744);
const Color neonPurple = Color(0xFF9C4DCC);
const Color deepBlack = Color(0xFF070B12);
const Color darkPurple = Color(0xFF1A1A2E);
const Color cardDark = Color(0xFF0F0F1A);

class GameAreaPage extends StatelessWidget {
  const GameAreaPage({super.key});

  @override
  Widget build(BuildContext context) {
    final games = [
      {
        "title": "Tic Tac Toe",
        "subtitle": "Classic Strategy Game",
        "icon": Icons.grid_3x3,
        "color": neonCyan,
        "gradientColors": [neonCyan, neonPurple],
        "page": const TicTacPage(),
      },
      {
        "title": "Puzzle Game",
        "subtitle": "Slide & Solve",
        "icon": Icons.extension,
        "color": neonPurple,
        "gradientColors": [neonPurple, neonMagenta],
        "page": const PuzzlePage(),
      },
      {
        "title": "Snake Game",
        "subtitle": "Retro Arcade Fun",
        "icon": Icons.sports_esports,
        "color": neonMagenta,
        "gradientColors": [neonMagenta, neonCyan],
        "page": const SnakePage(),
      },
    ];

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              deepBlack,
              darkPurple,
              const Color(0xFF0A0A1A),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 20),
              // Header dengan efek glitch
              ShaderMask(
                shaderCallback: (bounds) => LinearGradient(
                  colors: [neonCyan, neonPurple, neonMagenta],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ).createShader(bounds),
                child: const Text(
                  "🎮 GAME AREA 🎮",
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    letterSpacing: 3,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Container(
                width: 80,
                height: 3,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [neonCyan, neonPurple, neonMagenta],
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 20),
              Expanded(
                child: GridView.builder(
                  padding: const EdgeInsets.all(20),
                  itemCount: games.length,
                  gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 20,
                    mainAxisSpacing: 20,
                    childAspectRatio: 0.9,
                  ),
                  itemBuilder: (context, index) {
                    final game = games[index];

                    return TweenAnimationBuilder(
                      duration: Duration(milliseconds: 300 + (index * 100)),
                      tween: Tween<double>(begin: 0.0, end: 1.0),
                      builder: (context, double value, child) {
                        return Transform.scale(
                          scale: value,
                          child: child,
                        );
                      },
                      child: InkWell(
                        borderRadius: BorderRadius.circular(25),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => game["page"] as Widget,
                            ),
                          );
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(25),
                            gradient: LinearGradient(
                              colors: [
                                (game["gradientColors"] as List<Color>)[0],
                                (game["gradientColors"] as List<Color>)[1],
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: (game["color"] as Color).withOpacity(0.5),
                                blurRadius: 20,
                                spreadRadius: 3,
                                offset: const Offset(0, 5),
                              ),
                              BoxShadow(
                                color: neonCyan.withOpacity(0.2),
                                blurRadius: 30,
                                spreadRadius: 1,
                              ),
                            ],
                            border: Border.all(
                              color: (game["color"] as Color).withOpacity(0.3),
                              width: 1,
                            ),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                padding: const EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white.withOpacity(0.1),
                                  border: Border.all(
                                    color: (game["color"] as Color).withOpacity(0.5),
                                    width: 2,
                                  ),
                                ),
                                child: Icon(
                                  game["icon"] as IconData,
                                  size: 55,
                                  color: Colors.white,
                                ),
                              ),
                              const SizedBox(height: 20),
                              Text(
                                game["title"].toString(),
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                  letterSpacing: 1,
                                ),
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(height: 8),
                              Text(
                                game["subtitle"].toString(),
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: Colors.white70,
                                  letterSpacing: 0.5,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),
              // Footer text
              Container(
                padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: cardDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: neonCyan.withOpacity(0.3)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.games, color: neonCyan, size: 14),
                    const SizedBox(width: 8),
                    Text(
                      "Choose your game",
                      style: TextStyle(
                        color: neonCyan.withOpacity(0.8),
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}