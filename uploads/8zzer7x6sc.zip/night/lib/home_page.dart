// home_page.dart - DEATH X-FLOID EDITION 💀🔥
// Dark theme dengan Neon Cyan + Magenta
// Global Senders hanya untuk Owner & Moderator
// Modified by TANZ AI V8 for Professor KenzMD

import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'services/api_config_service.dart';

// ============ WARNA NEON DEATH X-FLOID ============
const Color neonCyan = Color(0xFF00E5FF);
const Color neonMagenta = Color(0xFFFF1744);
const Color neonPurple = Color(0xFF9C4DCC);
const Color deepBlack = Color(0xFF070B12);
const Color cardDark = Color(0xFF0F0F1A);
const Color darkPurple = Color(0xFF1A1A2E);
const Color neonYellow = Color(0xFFFFE600);

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin, SingleTickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _slideController;
  late AnimationController _pulseController;
  late Animation<Offset> _slideAnimation;
  String selectedBugId = "";
  String selectedBugName = "";

  String _selectedBugMode = "number";

  bool _isSending = false;
  String? _responseMessage;

  // ==================== SENDER MANAGEMENT ====================
  late TabController _tabController;
  int _currentTabIndex = 0;
  
  List<dynamic> mySenders = [];
  List<dynamic> globalSenders = [];
  List<dynamic> allUsers = [];
  
  bool isLoadingMySenders = false;
  bool isLoadingGlobalSenders = false;
  bool isLoadingUsers = false;
  String? mySendersError;
  String? globalSendersError;

  // ✅ Cek apakah user memiliki akses ke Global Senders
  bool get canAccessGlobal =>
      widget.role.toLowerCase() == "owner" ||
      widget.role.toLowerCase() == "moderator" ||
      widget.role.toLowerCase() == "pemilikan";

  // Warna NEON
  final Color baseDark = const Color(0xFF0A0A0F);
  final Color borderNeon = neonCyan;
  final Color borderLight = neonMagenta;
  final Color goldColor = neonYellow;
  final Color purpleColor = neonPurple;

  final ApiConfigService _apiService = ApiConfigService();

  @override
  void initState() {
    super.initState();
    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.5),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));

    int tabCount = canAccessGlobal ? 3 : 2;
    _tabController = TabController(length: tabCount, vsync: this);
    _tabController.addListener(() {
      setState(() {
        _currentTabIndex = _tabController.index;
      });
      if (_currentTabIndex == 1 && mySenders.isEmpty && !isLoadingMySenders) {
        _fetchMySenders();
      }
      if (canAccessGlobal && _currentTabIndex == 2 && globalSenders.isEmpty && !isLoadingGlobalSenders) {
        _fetchGlobalSenders();
      }
    });

    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
      selectedBugName = widget.listBug[0]['bug_name'];
    }
    
    _fetchMySenders();
    if (canAccessGlobal) {
      _fetchGlobalSenders();
    }
  }

  @override
  void dispose() {
    _slideController.dispose();
    _pulseController.dispose();
    _tabController.dispose();
    targetController.dispose();
    super.dispose();
  }

  // ==================== SENDER FUNCTIONS ====================
  
  Future<void> _fetchMySenders() async {
    setState(() {
      isLoadingMySenders = true;
      mySendersError = null;
    });

    try {
      final baseUrl = await _apiService.getBaseUrl();
      final response = await http.get(
        Uri.parse("$baseUrl/mySender?key=${widget.sessionKey}"),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          setState(() {
            mySenders = data["connections"] ?? [];
          });
        } else {
          setState(() {
            mySendersError = data["message"] ?? "Failed to fetch senders";
          });
        }
      } else {
        setState(() {
          mySendersError = "Server error: ${response.statusCode}";
        });
      }
    } catch (e) {
      setState(() {
        mySendersError = "Connection failed: $e";
      });
    } finally {
      setState(() {
        isLoadingMySenders = false;
      });
    }
  }

  Future<void> _fetchGlobalSenders() async {
    if (!canAccessGlobal) return;
    
    setState(() {
      isLoadingGlobalSenders = true;
      globalSendersError = null;
    });

    try {
      final baseUrl = await _apiService.getBaseUrl();
      final response = await http.get(
        Uri.parse("$baseUrl/globalSenders?key=${widget.sessionKey}"),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          setState(() {
            globalSenders = data["senders"] ?? [];
          });
        } else {
          setState(() {
            globalSendersError = data["message"] ?? "Failed to fetch global senders";
          });
        }
      } else {
        setState(() {
          globalSendersError = "Server error: ${response.statusCode}";
        });
      }
    } catch (e) {
      setState(() {
        globalSendersError = "Connection failed: $e";
      });
    } finally {
      setState(() {
        isLoadingGlobalSenders = false;
      });
    }
  }

  Future<void> _stealSender(String owner, String session) async {
    if (!canAccessGlobal) {
      _showSnackBar("Anda tidak memiliki izin untuk mencuri sender!", isSuccess: false);
      return;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: neonCyan.withOpacity(0.3)),
        ),
        title: Row(
          children: [
            Icon(Icons.content_copy, color: goldColor),
            const SizedBox(width: 12),
            Text("Steal Sender", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Text(
          "Yakin ingin mencuri sender '$session' milik $owner?",
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text("BATAL", style: TextStyle(color: neonMagenta)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: goldColor.withOpacity(0.2),
              foregroundColor: goldColor,
            ),
            onPressed: () => Navigator.pop(context, true),
            child: Text("STEAL", style: TextStyle(color: goldColor)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() => _isSending = true);

      try {
        final baseUrl = await _apiService.getBaseUrl();
        final response = await http.get(
          Uri.parse("$baseUrl/stealSender?key=${widget.sessionKey}&owner=$owner&session=$session"),
        );

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data["valid"] == true) {
            _showSnackBar(data["message"] ?? "Berhasil mencuri sender!", isSuccess: true);
            await _fetchMySenders();
            await _fetchGlobalSenders();
          } else {
            _showSnackBar(data["message"] ?? "Gagal mencuri sender", isSuccess: false);
          }
        } else {
          _showSnackBar("Server error: ${response.statusCode}", isSuccess: false);
        }
      } catch (e) {
        _showSnackBar("Connection failed: $e", isSuccess: false);
      } finally {
        setState(() => _isSending = false);
      }
    }
  }

  Future<void> _deleteMySender(String senderId) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: neonMagenta.withOpacity(0.3)),
        ),
        title: Row(
          children: [
            Icon(Icons.warning, color: neonMagenta),
            const SizedBox(width: 12),
            Text("Confirm Delete", style: TextStyle(color: Colors.white)),
          ],
        ),
        content: Text("Hapus sender ini?", style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text("BATAL", style: TextStyle(color: neonCyan)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: neonMagenta.withOpacity(0.2), foregroundColor: neonMagenta),
            onPressed: () => Navigator.pop(context, true),
            child: Text("DELETE", style: TextStyle(color: neonMagenta)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() => _isSending = true);

      try {
        final baseUrl = await _apiService.getBaseUrl();
        final response = await http.delete(
          Uri.parse("$baseUrl/deleteSender?key=${widget.sessionKey}&id=$senderId"),
        );

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data["valid"] == true) {
            _showSnackBar("Sender deleted!", isSuccess: true);
            await _fetchMySenders();
          } else {
            _showSnackBar(data["message"] ?? "Failed to delete", isSuccess: false);
          }
        }
      } catch (e) {
        _showSnackBar("Connection failed: $e", isSuccess: false);
      } finally {
        setState(() => _isSending = false);
      }
    }
  }

  void _showSnackBar(String message, {bool isSuccess = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isSuccess ? neonCyan : neonMagenta,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  void _showAddSenderDialog() {
    final phoneController = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: neonCyan.withOpacity(0.3)),
        ),
        title: Row(
          children: [
            Icon(Icons.add_circle, color: neonCyan),
            const SizedBox(width: 12),
            Text("Add New Sender", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ],
        ),
        content: TextField(
          controller: phoneController,
          keyboardType: TextInputType.phone,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            labelText: "Phone Number",
            labelStyle: TextStyle(color: neonCyan),
            hintText: "62xxx",
            hintStyle: const TextStyle(color: Colors.white54),
            prefixIcon: Icon(Icons.phone, color: neonCyan),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: neonCyan)),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: neonCyan)),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text("CANCEL", style: TextStyle(color: neonMagenta))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: neonCyan, foregroundColor: deepBlack),
            onPressed: () async {
              final number = phoneController.text.trim();
              if (number.isEmpty) {
                _showSnackBar("Masukkan nomor!", isSuccess: false);
                return;
              }
              Navigator.pop(context);
              await _addSender(number);
            },
            child: const Text("ADD"),
          ),
        ],
      ),
    );
  }

  Future<void> _addSender(String number) async {
    setState(() => _isSending = true);

    try {
      final baseUrl = await _apiService.getBaseUrl();
      final response = await http.get(
        Uri.parse("$baseUrl/getPairing?key=${widget.sessionKey}&number=$number"),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          _showPairingCodeDialog(number, data['pairingCode']);
        } else {
          _showSnackBar(data['message'] ?? "Failed", isSuccess: false);
        }
      } else {
        _showSnackBar("Server error: ${response.statusCode}", isSuccess: false);
      }
    } catch (e) {
      _showSnackBar("Connection failed: $e", isSuccess: false);
    } finally {
      setState(() => _isSending = false);
      _fetchMySenders();
    }
  }

  void _showPairingCodeDialog(String number, String code) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: cardDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: neonCyan.withOpacity(0.3)),
        ),
        title: Column(
          children: [
            Icon(Icons.qr_code_2, color: neonCyan, size: 50),
            const SizedBox(height: 10),
            Text("Pairing Required", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.3),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: neonCyan.withOpacity(0.3)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("Number: $number", style: TextStyle(color: Colors.white)),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: neonCyan),
                ),
                child: Text(
                  code,
                  style: TextStyle(
                    color: neonCyan,
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 4,
                    fontFamily: 'Courier',
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                "Open WhatsApp → Settings → Linked Devices → Link a Device\nEnter this code to complete pairing",
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white70, fontSize: 12),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text("CLOSE", style: TextStyle(color: Colors.white))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: neonCyan, foregroundColor: deepBlack),
            onPressed: () { Navigator.pop(context); _fetchMySenders(); },
            child: const Text("REFRESH"),
          ),
        ],
      ),
    );
  }

  // ==================== BUG FUNCTIONS ====================
  
  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert("❌ Invalid Number",
            "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert("❌ Invalid Link",
            "Masukkan link group WA yang valid (contoh: https://chat.whatsapp.com/...).");
        return;
      }
    }

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });

    try {
      final baseUrl = await _apiService.getBaseUrl();
      final res = await http.get(Uri.parse(
          "$baseUrl/sendBug?key=$key&target=$rawInput&bug=$selectedBugId"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        setState(() => _responseMessage = "⏳ Cooldown: Tunggu beberapa saat.");
      } else if (data["valid"] == false) {
        setState(() => _responseMessage = "❌ Key Invalid: Silakan login ulang.");
      } else if (data["sended"] == false) {
        setState(() => _responseMessage = "⚠️ Gagal: Server sedang maintenance.");
      } else {
        setState(() => _responseMessage = "✅ Berhasil mengirim bug ke $rawInput!");
        targetController.clear();
      }
    } catch (_) {
      setState(() => _responseMessage = "❌ Error: Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: AlertDialog(
          backgroundColor: cardDark,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
            side: BorderSide(color: neonCyan, width: 1.5),
          ),
          title: Text(title, style: TextStyle(color: neonCyan, fontWeight: FontWeight.bold)),
          content: Text(msg, style: const TextStyle(color: Colors.white70)),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("OK", style: TextStyle(color: neonCyan)),
            ),
          ],
        ),
      ),
    );
  }

  void _showBugSelector() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: baseDark,
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: neonCyan, width: 1.5),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 60,
              height: 4,
              decoration: BoxDecoration(
                color: neonCyan,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            ShaderMask(
              shaderCallback: (bounds) => LinearGradient(
                colors: [neonCyan, neonPurple],
              ).createShader(bounds),
              child: const Text(
                "PILIH BUG",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5,
                ),
              ),
            ),
            const SizedBox(height: 20),
            ListView.builder(
              shrinkWrap: true,
              physics: const BouncingScrollPhysics(),
              itemCount: widget.listBug.length,
              itemBuilder: (context, index) {
                final bug = widget.listBug[index];
                final isSelected = selectedBugId == bug['bug_id'];
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      selectedBugId = bug['bug_id'];
                      selectedBugName = bug['bug_name'];
                    });
                    Navigator.pop(context);
                  },
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: isSelected ? neonCyan.withOpacity(0.1) : cardDark,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: isSelected ? neonCyan : neonCyan.withOpacity(0.3),
                        width: isSelected ? 1.5 : 1,
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: baseDark,
                            border: Border.all(color: neonCyan, width: 1),
                          ),
                          child: Icon(
                            Icons.bug_report,
                            color: isSelected ? neonCyan : Colors.white54,
                            size: 20,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                bug['bug_name'],
                                style: TextStyle(
                                  color: isSelected ? neonCyan : Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                              ),
                              if (bug.containsKey('description'))
                                Text(
                                  bug['description'],
                                  style: const TextStyle(
                                    color: Colors.white54,
                                    fontSize: 11,
                                  ),
                                ),
                            ],
                          ),
                        ),
                        if (isSelected)
                          Icon(
                            Icons.check_circle_rounded,
                            color: neonCyan,
                            size: 22,
                          ),
                      ],
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }

  // ==================== WIDGETS ====================
  
  Widget _buildTabBar() {
    List<Widget> tabs = [
      const Tab(text: "BUG SENDER"),
      const Tab(text: "PRIVATE"),
    ];
    
    if (canAccessGlobal) {
      tabs.add(const Tab(text: "GLOBAL"));
    }
    
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      height: 45,
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: neonCyan.withOpacity(0.3)),
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          color: neonCyan.withOpacity(0.2),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: neonCyan),
        ),
        labelColor: neonCyan,
        unselectedLabelColor: Colors.white54,
        labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11),
        tabs: tabs,
      ),
    );
  }

  Widget _buildBugSenderTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          _buildHeaderPanel(),
          const SizedBox(height: 12),
          _buildWhatsAppCrashCard(),
          const SizedBox(height: 12),
          _buildInputPanel(),
          _buildSendButton(),
          _buildResponseMessage(),
        ],
      ),
    );
  }

  Widget _buildPrivateSendersTab() {
    if (isLoadingMySenders) {
      return const Center(child: CircularProgressIndicator(color: neonCyan));
    }
    
    if (mySendersError != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, color: neonMagenta, size: 50),
            const SizedBox(height: 16),
            Text(mySendersError!, style: TextStyle(color: Colors.white54)),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _fetchMySenders,
              style: ElevatedButton.styleFrom(backgroundColor: neonCyan, foregroundColor: deepBlack),
              child: const Text("RETRY"),
            ),
          ],
        ),
      );
    }
    
    if (mySenders.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.phone_android, color: neonCyan, size: 60),
            const SizedBox(height: 16),
            Text("No Private Senders", style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text("Add your first WhatsApp sender", style: TextStyle(color: Colors.white54)),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              icon: const Icon(Icons.add),
              label: const Text("ADD SENDER"),
              style: ElevatedButton.styleFrom(backgroundColor: neonCyan, foregroundColor: deepBlack),
              onPressed: _showAddSenderDialog,
            ),
          ],
        ),
      );
    }
    
    return RefreshIndicator(
      color: neonCyan,
      onRefresh: _fetchMySenders,
      child: ListView.builder(
        physics: const AlwaysScrollableScrollPhysics(),
        itemCount: mySenders.length,
        itemBuilder: (context, index) {
          final sender = mySenders[index];
          final name = sender['sessionName'] ?? 'Unknown';
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            color: cardDark,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: BorderSide(color: neonCyan.withOpacity(0.3)),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.3),
                      shape: BoxShape.circle,
                      border: Border.all(color: neonCyan),
                    ),
                    child: Icon(Icons.phone_android, color: neonCyan),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      name,
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.delete, color: neonMagenta),
                    onPressed: () => _deleteMySender(sender['id']),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildGlobalSendersTab() {
    if (!canAccessGlobal) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: cardDark,
                shape: BoxShape.circle,
                border: Border.all(color: neonMagenta, width: 2),
              ),
              child: Icon(Icons.lock, color: neonMagenta, size: 60),
            ),
            const SizedBox(height: 20),
            Text(
              "Access Denied",
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              "Fitur Global Senders hanya untuk Owner & Moderator",
              style: TextStyle(color: Colors.white54, fontSize: 14),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }
    
    if (isLoadingGlobalSenders) {
      return const Center(child: CircularProgressIndicator(color: neonCyan));
    }
    
    if (globalSendersError != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, color: neonMagenta, size: 50),
            const SizedBox(height: 16),
            Text(globalSendersError!, style: TextStyle(color: Colors.white54)),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _fetchGlobalSenders,
              style: ElevatedButton.styleFrom(backgroundColor: neonCyan, foregroundColor: deepBlack),
              child: const Text("RETRY"),
            ),
          ],
        ),
      );
    }
    
    if (globalSenders.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.public, color: goldColor, size: 60),
            const SizedBox(height: 16),
            Text("No Global Senders", style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text("No senders from other users", style: TextStyle(color: Colors.white54)),
          ],
        ),
      );
    }
    
    return RefreshIndicator(
      color: neonCyan,
      onRefresh: _fetchGlobalSenders,
      child: ListView.builder(
        physics: const AlwaysScrollableScrollPhysics(),
        itemCount: globalSenders.length,
        itemBuilder: (context, index) {
          final sender = globalSenders[index];
          final name = sender['sessionName'] ?? 'Unknown';
          final owner = sender['owner'] ?? 'Unknown';
          final isMine = sender['isMine'] == true;
          
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            color: cardDark,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: BorderSide(color: neonCyan.withOpacity(0.3)),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.3),
                          shape: BoxShape.circle,
                          border: Border.all(color: isMine ? neonCyan : goldColor),
                        ),
                        child: Icon(isMine ? Icons.person : Icons.public, color: isMine ? neonCyan : goldColor),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                            const SizedBox(height: 4),
                            Text("Owner: $owner", style: TextStyle(color: isMine ? neonCyan : goldColor, fontSize: 11)),
                          ],
                        ),
                      ),
                      if (!isMine)
                        ElevatedButton.icon(
                          icon: Icon(Icons.content_copy, size: 16),
                          label: const Text("STEAL"),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: goldColor.withOpacity(0.2),
                            foregroundColor: goldColor,
                          ),
                          onPressed: () => _stealSender(owner, name),
                        ),
                      if (isMine)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: neonCyan.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: neonCyan.withOpacity(0.3)),
                          ),
                          child: Text("MINE", style: TextStyle(color: neonCyan, fontSize: 11, fontWeight: FontWeight.bold)),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ==================== ORIGINAL WIDGETS ====================
  
  Widget _buildHeaderPanel() {
    return SlideTransition(
      position: _slideAnimation,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: cardDark,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: neonCyan, width: 1.5),
          boxShadow: [
            BoxShadow(
              color: neonCyan.withOpacity(0.2),
              blurRadius: 15,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: neonCyan, width: 2),
              ),
              child: ClipOval(
                child: Image.asset(
                  'assets/images/logo.jpg',
                  width: 56,
                  height: 56,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                    return Container(
                      width: 56,
                      height: 56,
                      color: baseDark,
                      child: Icon(Icons.person, color: neonCyan, size: 40),
                    );
                  },
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.username,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      letterSpacing: 1.0,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: baseDark,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: neonCyan.withOpacity(0.5), width: 1),
                    ),
                    child: Text(
                      "Role: ${widget.role.toUpperCase()} • Exp: ${widget.expiredDate}",
                      style: TextStyle(
                        color: neonCyan,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWhatsAppCrashCard() {
    return SlideTransition(
      position: _slideAnimation,
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
        decoration: BoxDecoration(
          color: cardDark,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: neonCyan, width: 1.5),
          boxShadow: [
            BoxShadow(
              color: neonCyan.withOpacity(0.15),
              blurRadius: 12,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: baseDark,
                    border: Border.all(color: neonCyan, width: 1),
                  ),
                  child: const Icon(
                    Icons.flash_on_rounded,
                    color: Colors.white,
                    size: 18,
                  ),
                ),
                const SizedBox(width: 8),
                ShaderMask(
                  shaderCallback: (bounds) => LinearGradient(
                    colors: [neonCyan, neonPurple],
                  ).createShader(bounds),
                  child: const Text(
                    "WHATSAPP CRASH",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.2,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            
            Wrap(
              spacing: 6,
              runSpacing: 4,
              alignment: WrapAlignment.center,
              children: [
                _buildBadge("EXPLOIT READY"),
                _buildBadge("INSTANT CRASH"),
                _buildBadge("CUSTOM PAYLOAD"),
              ],
            ),
            
            const SizedBox(height: 6),
            
            Text(
              "Send custom payloads to crash target WhatsApp instantly",
              style: TextStyle(
                fontSize: 9,
                color: Colors.white60,
                height: 1.2,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBadge(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: baseDark,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: neonCyan.withOpacity(0.5), width: 1),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 8,
          color: neonCyan,
          fontWeight: FontWeight.bold,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  Widget _buildModeSelector() {
    return Row(
      children: [
        Expanded(
          child: GestureDetector(
            onTap: () {
              setState(() {
                _selectedBugMode = "number";
                targetController.clear();
              });
            },
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: _selectedBugMode == "number" ? neonCyan.withOpacity(0.1) : baseDark,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _selectedBugMode == "number" ? neonCyan : neonCyan.withOpacity(0.3),
                  width: _selectedBugMode == "number" ? 1.5 : 1,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.phone_android_rounded,
                    color: _selectedBugMode == "number" ? neonCyan : Colors.white54,
                    size: 16,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    "NOMOR",
                    style: TextStyle(
                      color: _selectedBugMode == "number" ? neonCyan : Colors.white54,
                      fontWeight: FontWeight.bold,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: GestureDetector(
            onTap: () {
              setState(() {
                _selectedBugMode = "group";
                targetController.clear();
              });
            },
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: _selectedBugMode == "group" ? neonCyan.withOpacity(0.1) : baseDark,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _selectedBugMode == "group" ? neonCyan : neonCyan.withOpacity(0.3),
                  width: _selectedBugMode == "group" ? 1.5 : 1,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.group_add,
                    color: _selectedBugMode == "group" ? neonCyan : Colors.white54,
                    size: 16,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    "GROUP",
                    style: TextStyle(
                      color: _selectedBugMode == "group" ? neonCyan : Colors.white54,
                      fontWeight: FontWeight.bold,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildInputPanel() {
    return SlideTransition(
      position: _slideAnimation,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: cardDark,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: neonCyan, width: 1.5),
          boxShadow: [
            BoxShadow(
              color: neonCyan.withOpacity(0.15),
              blurRadius: 20,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildModeSelector(),
            const SizedBox(height: 16),
            Row(
              children: [
                Icon(_selectedBugMode == "number" ? Icons.phone_android : Icons.link, 
                    color: neonCyan, size: 16),
                const SizedBox(width: 6),
                Text(
                  _selectedBugMode == "number" ? "TARGET" : "LINK GROUP",
                  style: TextStyle(
                    color: neonCyan,
                    fontWeight: FontWeight.bold,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            TextField(
              controller: targetController,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              cursorColor: neonCyan,
              keyboardType: _selectedBugMode == "number" 
                  ? TextInputType.phone 
                  : TextInputType.url,
              decoration: InputDecoration(
                hintText: _selectedBugMode == "number"
                    ? "Contoh: +62xxxxxxxxxx"
                    : "Contoh: https://chat.whatsapp.com/...",
                hintStyle: TextStyle(color: Colors.white54, fontSize: 11),
                filled: true,
                fillColor: baseDark,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: neonCyan.withOpacity(0.3)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: neonCyan, width: 1.5),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: neonCyan.withOpacity(0.3), width: 1),
                ),
                prefixIcon: Icon(
                  _selectedBugMode == "number" ? Icons.phone_android : Icons.link,
                  color: neonCyan,
                  size: 16,
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
              ),
            ),
            const SizedBox(height: 16),
            GestureDetector(
              onTap: _showBugSelector,
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                decoration: BoxDecoration(
                  color: baseDark,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: neonCyan, width: 1.5),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.bug_report, color: neonCyan, size: 18),
                        const SizedBox(width: 10),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "PILIH BUG",
                              style: TextStyle(
                                color: neonCyan,
                                fontWeight: FontWeight.bold,
                                fontSize: 10,
                                letterSpacing: 1,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              selectedBugName.isNotEmpty ? selectedBugName : "Pilih bug",
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    Icon(Icons.arrow_drop_down, color: neonCyan, size: 24),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSendButton() {
    return SlideTransition(
      position: _slideAnimation,
      child: AnimatedBuilder(
        animation: _pulseController,
        builder: (context, child) {
          final scale = 1.0 + (0.05 * _pulseController.value);
          final glowIntensity = 0.2 * _pulseController.value;
          
          return Transform.scale(
            scale: scale,
            child: Container(
              height: 52,
              margin: const EdgeInsets.only(top: 16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                gradient: LinearGradient(
                  colors: [neonCyan, neonPurple],
                ),
                boxShadow: [
                  BoxShadow(
                    color: neonCyan.withOpacity(glowIntensity),
                    blurRadius: 20 * _pulseController.value,
                    spreadRadius: 2 * _pulseController.value,
                  ),
                ],
              ),
              child: ElevatedButton(
                onPressed: _isSending ? null : _sendBug,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                child: _isSending
                    ? const SizedBox(
                        height: 24,
                        width: 24,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2.5,
                        ),
                      )
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.rocket_launch_rounded,
                            color: Colors.white,
                            size: 18,
                          ),
                          SizedBox(width: 10),
                          Text(
                            "SERANG",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                              letterSpacing: 1.2,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();

    Color bgColor;
    Color borderColor;
    Color textColor;
    IconData icon;

    if (_responseMessage!.startsWith('✅')) {
      bgColor = neonCyan.withOpacity(0.15);
      borderColor = neonCyan;
      textColor = neonCyan;
      icon = Icons.check_circle_outline_rounded;
    } else if (_responseMessage!.startsWith('❌')) {
      bgColor = neonMagenta.withOpacity(0.15);
      borderColor = neonMagenta;
      textColor = neonMagenta;
      icon = Icons.error_outline_rounded;
    } else {
      bgColor = neonCyan.withOpacity(0.1);
      borderColor = neonCyan;
      textColor = neonCyan;
      icon = Icons.info_outline_rounded;
    }

    return SlideTransition(
      position: _slideAnimation,
      child: Padding(
        padding: const EdgeInsets.only(top: 12),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: bgColor,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: borderColor.withOpacity(0.5),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: borderColor.withOpacity(0.1),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            children: [
              Icon(icon, color: textColor, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  _responseMessage!,
                  style: TextStyle(
                    color: textColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 11,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: baseDark,
      body: Stack(
        children: [
          Positioned(
            top: -100,
            right: -100,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: neonCyan.withOpacity(0.05),
              ),
            ),
          ),
          Positioned(
            bottom: -150,
            left: -100,
            child: Container(
              width: 400,
              height: 400,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: neonMagenta.withOpacity(0.03),
              ),
            ),
          ),
          Positioned(
            top: MediaQuery.of(context).size.height / 2,
            right: -80,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: neonPurple.withOpacity(0.04),
              ),
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                _buildTabBar(),
                Expanded(
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      _buildBugSenderTab(),
                      _buildPrivateSendersTab(),
                      if (canAccessGlobal) _buildGlobalSendersTab(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}