// snake_page.dart - DEATH X-FLOID EDITION (FIXED) 💀🔥
// Dark theme dengan Neon Cyan + Magenta
// Modified by TANZ AI V8 for Professor KenzMD

import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

// ============ WARNA NEON DEATH X-FLOID ============
const Color neonCyan = Color(0xFF00E5FF);
const Color neonMagenta = Color(0xFFFF1744);
const Color neonPurple = Color(0xFF9C4DCC);
const Color deepBlack = Color(0xFF070B12);
const Color darkPurple = Color(0xFF1A1A2E);
const Color cardDark = Color(0xFF0F0F1A);

class SnakePage extends StatefulWidget {
  const SnakePage({super.key});

  @override
  State<SnakePage> createState() => _SnakePageState();
}

class _SnakePageState extends State<SnakePage> with SingleTickerProviderStateMixin {
  static const int rowSize = 20;
  static const int totalSquares = rowSize * rowSize;

  List<int> snake = [45, 65, 85];
  int food = 100;
  String direction = "down";
  Timer? timer;
  int score = 0;
  late AnimationController _pulseController;

  void startGame() {
    timer = Timer.periodic(const Duration(milliseconds: 150), (timer) {
      moveSnake();
    });
  }

  void moveSnake() {
    setState(() {
      int newHead;

      switch (direction) {
        case "down":
          newHead = snake.last + rowSize;
          break;
        case "up":
          newHead = snake.last - rowSize;
          break;
        case "left":
          newHead = snake.last - 1;
          break;
        default:
          newHead = snake.last + 1;
      }

      // Cek tabrakan
      if (newHead >= totalSquares ||
          newHead < 0 ||
          (snake.contains(newHead) && newHead != snake.last)) {
        timer?.cancel();
        showGameOver();
        return;
      }

      snake.add(newHead);

      if (newHead == food) {
        score++;
        // Generate food baru, pastikan tidak di posisi ular
        do {
          food = Random().nextInt(totalSquares);
        } while (snake.contains(food));
        _pulseController.forward(from: 0);
      } else {
        snake.removeAt(0);
      }
    });
  }

  void showGameOver() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: neonMagenta.withOpacity(0.3)),
        ),
        title: Row(
          children: [
            // FIX: Ganti Icons.skull dengan Icons.mood_bad (tersedia di Flutter)
            Icon(Icons.mood_bad, color: neonMagenta, size: 28),
            const SizedBox(width: 10),
            const Text(
              "GAME OVER",
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        content: Text(
          "🐍 Score: $score",
          style: TextStyle(color: neonCyan, fontSize: 18, fontWeight: FontWeight.bold),
        ),
        actions: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [neonCyan, neonPurple]),
              borderRadius: BorderRadius.circular(12),
            ),
            child: TextButton(
              onPressed: () {
                Navigator.pop(context);
                resetGame();
              },
              style: TextButton.styleFrom(
                foregroundColor: Colors.white,
              ),
              child: const Text(
                "RESTART",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          )
        ],
      ),
    );
  }

  void resetGame() {
    setState(() {
      snake = [45, 65, 85];
      direction = "down";
      score = 0;
      food = Random().nextInt(totalSquares);
    });
    startGame();
  }

  @override
  void initState() {
    super.initState();
    startGame();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
  }

  @override
  void dispose() {
    timer?.cancel();
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [deepBlack, darkPurple],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 20),

              /// SCORE CARD dengan efek neon
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [neonCyan.withOpacity(0.2), neonPurple.withOpacity(0.1)],
                  ),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: neonCyan.withOpacity(0.3)),
                  boxShadow: [
                    BoxShadow(
                      color: neonCyan.withOpacity(0.2),
                      blurRadius: 10,
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.sports_esports, color: neonCyan, size: 24),
                    const SizedBox(width: 10),
                    Text(
                      "Score: $score",
                      style: TextStyle(
                        fontSize: 22,
                        color: neonCyan,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              /// GAME BOARD
              Expanded(
                child: GestureDetector(
                  onVerticalDragUpdate: (details) {
                    if (details.delta.dy > 0 && direction != "up") {
                      direction = "down";
                    } else if (details.delta.dy < 0 && direction != "down") {
                      direction = "up";
                    }
                  },
                  onHorizontalDragUpdate: (details) {
                    if (details.delta.dx > 0 && direction != "left") {
                      direction = "right";
                    } else if (details.delta.dx < 0 && direction != "right") {
                      direction = "left";
                    }
                  },
                  child: GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: totalSquares,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: rowSize,
                    ),
                    itemBuilder: (context, index) {
                      final isHead = snake.isNotEmpty && index == snake.last;
                      final isBody = snake.contains(index) && !isHead;
                      
                      if (isHead) {
                        return AnimatedContainer(
                          duration: const Duration(milliseconds: 100),
                          margin: const EdgeInsets.all(1),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [neonCyan, neonPurple],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(6),
                            boxShadow: [
                              BoxShadow(
                                color: neonCyan.withOpacity(0.6),
                                blurRadius: 8,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                          child: Icon(
                            _getDirectionIcon(),
                            color: Colors.white,
                            size: 14,
                          ),
                        );
                      } else if (isBody) {
                        return Container(
                          margin: const EdgeInsets.all(1),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [neonCyan.withOpacity(0.7), neonPurple.withOpacity(0.5)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(4),
                          ),
                        );
                      } else if (index == food) {
                        return AnimatedBuilder(
                          animation: _pulseController,
                          builder: (context, child) {
                            return Container(
                              margin: const EdgeInsets.all(3),
                              decoration: BoxDecoration(
                                color: neonMagenta,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: neonMagenta.withOpacity(0.6 + _pulseController.value * 0.3),
                                    blurRadius: 8 + _pulseController.value * 4,
                                    spreadRadius: 1,
                                  ),
                                ],
                              ),
                            );
                          },
                        );
                      } else {
                        return Container(
                          margin: const EdgeInsets.all(1),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.03),
                            borderRadius: BorderRadius.circular(2),
                          ),
                        );
                      }
                    },
                  ),
                ),
              ),
              
              const SizedBox(height: 16),
              
              /// CONTROL INFO
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: cardDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: neonCyan.withOpacity(0.2)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.swipe, color: neonCyan, size: 14),
                    const SizedBox(width: 8),
                    Text(
                      "Swipe to control the snake",
                      style: TextStyle(
                        color: Colors.white54,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  IconData _getDirectionIcon() {
    switch (direction) {
      case "up":
        return Icons.arrow_upward_rounded;
      case "down":
        return Icons.arrow_downward_rounded;
      case "left":
        return Icons.arrow_back_rounded;
      default:
        return Icons.arrow_forward_rounded;
    }
  }
}