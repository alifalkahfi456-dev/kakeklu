// thxto_page.dart - DEATH X-FLOID EDITION 💀🔥
// Dark theme dengan Neon Cyan + Magenta
// Modified by TANZ AI V8 for Professor KenzMD

//JANGAN LUPA MALING
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

// ============ WARNA NEON DEATH X-FLOID ============
const Color neonCyan = Color(0xFF00E5FF);
const Color neonMagenta = Color(0xFFFF1744);
const Color neonPurple = Color(0xFF9C4DCC);
const Color deepBlack = Color(0xFF070B12);
const Color cardDark = Color(0xFF0F0F1A);
const Color darkPurple = Color(0xFF1A1A2E);

/// ==========================
/// CONFIG DATA (MUDAH EDIT)
/// ==========================
final List<Map<String, String>> thanksToList = [
  {
    "name": "Yuzi",
    "role": "Developer",
    "photo": "https://files.catbox.moe/lz8mi6.jpg",
    "telegram": "https://t.me/YuziStr",
  },
  {
    "name": "milkyta",
    "role": "security",
    "photo": "https://files.catbox.moe/wq81w4.jpg",
    "telegram": "https://t.me/Milkytakuadd",
  },
  {
    "name": "Zhidan",
    "role": "security",
    "photo": "https://files.catbox.moe/6wvnht.jpg",
    "telegram": "https://t.me/Officiall_supportt_binancee_DANZ",
  },
  {
    "name": "Dapz",
    "role": "Babu jir",
    "photo": "https://files.catbox.moe/3sgdty.jpg",
    "telegram": "https://t.me/dipzzyy1",
  },
  {
    "name": "Hafz",
    "role": "Beban",
    "photo": "https://files.catbox.moe/bna7gt.jpg",
    "telegram": "https://t.me/hafz_reals",
  },
  {
    "name": "Depan",
    "role": "Si jarang on",
    "photo": "https://files.catbox.moe/vv1sk6.jpg",
    "telegram": "https://t.me/devvlz",
  },
  {
    "name": "Yukiizumi",
    "role": "Si doyan yapping",
    "photo": "https://files.catbox.moe/5igp18.jpg",
    "telegram": "https://t.me/yuukiizumiiii",
  },
  {
    "name": "Lyzz",
    "role": "Babu ke 2",
    "photo": "https://files.catbox.moe/f8am8f.jpg",
    "telegram": "https://t.me/alwaysLyzz",
  },
  {
    "name": "Yuu",
    "role": "Si jarang on ke 2",
    "photo": "https://files.catbox.moe/z7wzdj.jpg",
    "telegram": "https://t.me/Yuunotpemes",
  },
];

class ThanksToPage extends StatelessWidget {
  const ThanksToPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: deepBlack,
      appBar: AppBar(
        backgroundColor: cardDark,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: ShaderMask(
          shaderCallback: (bounds) => LinearGradient(
            colors: [neonCyan, neonPurple, neonMagenta],
          ).createShader(bounds),
          child: const Text(
            "Thanks To",
            style: TextStyle(
              fontWeight: FontWeight.w600,
              letterSpacing: 1.5,
              color: Colors.white,
            ),
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [neonCyan, neonPurple, neonMagenta],
              ),
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [neonCyan.withOpacity(0.2), neonPurple.withOpacity(0.1)],
                    ),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: neonCyan.withOpacity(0.3)),
                  ),
                  child: Icon(Icons.favorite, color: neonMagenta, size: 20),
                ),
                const SizedBox(width: 12),
                ShaderMask(
                  shaderCallback: (bounds) => LinearGradient(
                    colors: [neonCyan, neonPurple],
                  ).createShader(bounds),
                  child: const Text(
                    "Special Appreciation",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Padding(
              padding: const EdgeInsets.only(left: 8),
              child: Text(
                "Support & contribution behind this application",
                style: TextStyle(
                  color: neonCyan.withOpacity(0.7),
                  fontSize: 13,
                ),
              ),
            ),
            const SizedBox(height: 20),

            Expanded(
              child: ListView.builder(
                itemCount: thanksToList.length,
                itemBuilder: (context, index) {
                  final item = thanksToList[index];
                  return ThanksCard(
                    name: item["name"]!,
                    role: item["role"]!,
                    photo: item["photo"]!,
                    telegram: item["telegram"]!,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// ==========================
/// THANKS CARD
/// ==========================
class ThanksCard extends StatelessWidget {
  final String name;
  final String role;
  final String photo;
  final String telegram;

  const ThanksCard({
    super.key,
    required this.name,
    required this.role,
    required this.photo,
    required this.telegram,
  });

  Future<void> _openTelegram() async {
    final uri = Uri.parse(telegram);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Color _getRoleColor(String role) {
    final roleLower = role.toLowerCase();
    if (roleLower == "developer") {
      return neonCyan;
    } else if (roleLower == "security") {
      return neonPurple;
    } else {
      return neonMagenta;
    }
  }

  @override
  Widget build(BuildContext context) {
    final roleColor = _getRoleColor(role);
    
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: cardDark,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: neonCyan.withOpacity(0.15),
              ),
              boxShadow: [
                BoxShadow(
                  color: neonCyan.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                /// FOTO dengan border gradient
                Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [neonCyan, neonPurple],
                    ),
                    border: Border.all(color: roleColor, width: 2),
                  ),
                  child: CircleAvatar(
                    radius: 24,
                    backgroundImage: NetworkImage(photo),
                    backgroundColor: Colors.transparent,
                    onBackgroundImageError: (_, __) {},
                  ),
                ),

                const SizedBox(width: 14),

                /// TEXT
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: roleColor.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: roleColor.withOpacity(0.3)),
                        ),
                        child: Text(
                          role,
                          style: TextStyle(
                            color: roleColor,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                /// BUTTON TELEGRAM
                InkWell(
                  onTap: _openTelegram,
                  borderRadius: BorderRadius.circular(10),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [neonCyan.withOpacity(0.15), neonPurple.withOpacity(0.1)],
                      ),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: neonCyan.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          FontAwesomeIcons.telegram,
                          color: neonCyan,
                          size: 14,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          "Telegram",
                          style: TextStyle(
                            color: neonCyan,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}