// tk_page.dart - DEATH X-FLOID EDITION 💀🔥
// Dark theme dengan Neon Cyan + Magenta
// Modified by TANZ AI V8 for Professor KenzMD

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:ui';
import 'services/api_config_service.dart';

// ============ WARNA NEON DEATH X-FLOID ============
const Color neonCyan = Color(0xFF00E5FF);
const Color neonMagenta = Color(0xFFFF1744);
const Color neonPurple = Color(0xFF9C4DCC);
const Color deepBlack = Color(0xFF070B12);
const Color cardDark = Color(0xFF0F0F1A);
const Color darkPurple = Color(0xFF1A1A2E);
const Color neonYellow = Color(0xFFFFE600);

class TkPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const TkPage({
    super.key, 
    required this.sessionKey,
    required this.username,
  });

  @override
  State<TkPage> createState() => _TkPageState();
}

class _TkPageState extends State<TkPage> with SingleTickerProviderStateMixin {
  late String sessionKey;
  late String apiBaseUrl;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];
  
  final List<String> roleOptions = ['reseller', 'member', 'vip'];
  String selectedRole = 'member';
  
  int currentPage = 1;
  int itemsPerPage = 10;

  final deleteController = TextEditingController();
  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  String newUserRole = 'member';
  bool isLoading = false;

  late AnimationController _animController;
  late Animation<double> _fadeAnimation;

  // === WARNA NEON ===
  final Color deepBg = deepBlack;
  final Color mainNeon = neonCyan;
  final Color lightNeon = neonPurple;
  final Color accentNeon = neonCyan;
  final Color bgBlack = deepBlack;
  final Color cardBlack = cardDark;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();
    _fadeAnimation = CurvedAnimation(parent: _animController, curve: Curves.easeOut);

    _loadBaseUrl();
  }

  Future<void> _loadBaseUrl() async {
    try {
      final apiConfig = ApiConfigService();
      apiBaseUrl = await apiConfig.getBaseUrl();
      _fetchUsers();
    } catch (e) {
      apiBaseUrl = 'http://yuzianakbaik.dhangantenk.biz.id:2002';
      _fetchUsers();
    }
  }

  @override
  void dispose() {
    _animController.dispose();
    deleteController.dispose();
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    editUsernameController.dispose();
    editDayController.dispose();
    super.dispose();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$apiBaseUrl/listUsers?key=$sessionKey'),
      );
      
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['authorized'] == true) {
          setState(() {
            fullUserList = (data['users'] ?? []).where((u) {
              final role = u['role'].toString();
              return roleOptions.contains(role);
            }).toList();
            _filterAndPaginate();
          });
        } else {
          _showSnack("Error: ${data['message'] ?? 'Akses ditolak.'}");
        }
      } else {
        _showSnack("Server error: ${res.statusCode}");
      }
    } catch (e) {
      _showSnack("Gagal memuat data user: $e");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    if (start >= filteredList.length) return [];
    return filteredList.sublist(start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => filteredList.isEmpty ? 1 : (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _showSnack("Masukkan username!");
      return;
    }

    final targetUser = fullUserList.firstWhere(
      (u) => u['username'] == username,
      orElse: () => null,
    );

    if (targetUser == null) {
      _showSnack("User '$username' tidak ditemukan!");
      return;
    }

    final targetRole = targetUser['role'].toString();
    
    if (!roleOptions.contains(targetRole)) {
      _showSnack("Anda tidak memiliki izin untuk menghapus user dengan role '$targetRole'!");
      return;
    }

    final confirm = await _showConfirmDialog(
      "Hapus User",
      "Yakin ingin menghapus user '$username' dengan role ${targetRole.toUpperCase()}?",
    );
    
    if (confirm != true) return;

    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$apiBaseUrl/deleteUser?key=$sessionKey&username=$username'),
      );
      
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['deleted'] == true) {
          _showSnack("User '$username' berhasil dihapus!", isSuccess: true);
          deleteController.clear();
          _fetchUsers();
        } else {
          _showSnack("Gagal: ${data['message'] ?? 'Unknown error'}");
        }
      } else {
        _showSnack("Server error: ${res.statusCode}");
      }
    } catch (e) {
      _showSnack("Error koneksi: $e");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final username = createUsernameController.text.trim();
    final password = createPasswordController.text.trim();
    final day = createDayController.text.trim();

    if (username.isEmpty || password.isEmpty || day.isEmpty) {
      _showSnack("Semua field wajib diisi!");
      return;
    }

    if (username.length < 3) {
      _showSnack("Username minimal 3 karakter!");
      return;
    }

    if (password.length < 4) {
      _showSnack("Password minimal 4 karakter!");
      return;
    }

    final dayInt = int.tryParse(day);
    if (dayInt == null || dayInt <= 0) {
      _showSnack("Durasi harus berupa angka positif!");
      return;
    }

    final existingUser = fullUserList.any((u) => 
      u['username'].toString().toLowerCase() == username.toLowerCase()
    );
    if (existingUser) {
      _showSnack("Username '$username' sudah terdaftar!");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        '$apiBaseUrl/userAdd?key=$sessionKey&username=$username&password=$password&day=$day&role=$newUserRole',
      );
      final res = await http.get(url);
      
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);

        if (data['created'] == true) {
          _showSnack("Akun '$username' berhasil dibuat sebagai ${newUserRole.toUpperCase()}!", isSuccess: true);
          createUsernameController.clear();
          createPasswordController.clear();
          createDayController.clear();
          newUserRole = 'member';
          _fetchUsers();
        } else {
          _showSnack("Gagal: ${data['message'] ?? 'Unknown error'}");
        }
      } else {
        _showSnack("Server error: ${res.statusCode}");
      }
    } catch (e) {
      _showSnack("Error koneksi: $e");
    }
    setState(() => isLoading = false);
  }

  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  Future<void> _extendDuration() async {
    final username = editUsernameController.text.trim();
    final days = editDayController.text.trim();

    if (username.isEmpty || days.isEmpty) {
      _showSnack("Semua field wajib diisi!");
      return;
    }

    final targetUser = fullUserList.firstWhere(
      (u) => u['username'] == username,
      orElse: () => null,
    );

    if (targetUser == null) {
      _showSnack("User '$username' tidak ditemukan!");
      return;
    }

    final targetRole = targetUser['role'].toString();
    
    if (!roleOptions.contains(targetRole)) {
      _showSnack("Anda tidak memiliki izin untuk memperpanjang durasi user dengan role '$targetRole'!");
      return;
    }

    final daysInt = int.tryParse(days);
    if (daysInt == null || daysInt <= 0) {
      _showSnack("Jumlah hari harus berupa angka positif!");
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$apiBaseUrl/editUser?key=$sessionKey&username=$username&addDays=$days'),
      );
      
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['edited'] == true) {
          _showSnack("Durasi user '$username' berhasil ditambah +$days hari!", isSuccess: true);
          editUsernameController.clear();
          editDayController.clear();
          _fetchUsers();
        } else {
          _showSnack("Gagal: ${data['message'] ?? 'Unknown error'}");
        }
      } else {
        _showSnack("Server error: ${res.statusCode}");
      }
    } catch (e) {
      _showSnack("Error koneksi: $e");
    }
    setState(() => isLoading = false);
  }

  Future<bool?> _showConfirmDialog(String title, String message) {
    return showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: cardBlack,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: neonCyan.withOpacity(0.3)),
          ),
          title: Row(
            children: [
              Icon(Icons.warning, color: neonMagenta),
              const SizedBox(width: 8),
              Text(title, style: const TextStyle(color: Colors.white)),
            ],
          ),
          content: Text(message, style: const TextStyle(color: Colors.white70)),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: Text("Batal", style: TextStyle(color: neonCyan)),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: Text("Hapus", style: TextStyle(color: neonMagenta)),
            ),
          ],
        );
      },
    );
  }

  void _showSnack(String msg, {bool isSuccess = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(color: Colors.white)),
      backgroundColor: isSuccess ? neonCyan : deepBg,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          // Background Glow Effects
          Positioned(
            top: -100,
            right: -100,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [neonCyan.withOpacity(0.12), Colors.transparent]),
              ),
            ),
          ),
          Positioned(
            bottom: -100,
            left: -100,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [neonMagenta.withOpacity(0.08), Colors.transparent]),
              ),
            ),
          ),
          
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    _buildHeader(),
                    const SizedBox(height: 25),

                    _buildSectionTitle("Create New User", Icons.person_add),
                    const SizedBox(height: 10),
                    _buildCreateUserCard(),

                    const SizedBox(height: 30),

                    _buildSectionTitle("Extend Duration", Icons.timer),
                    const SizedBox(height: 10),
                    _buildExtendDurationCard(),

                    const SizedBox(height: 30),

                    _buildSectionTitle("Danger Zone", Icons.warning_amber_rounded),
                    const SizedBox(height: 10),
                    _buildDeleteUserCard(),

                    const SizedBox(height: 30),

                    _buildSectionTitle("Database Users", Icons.storage),
                    const SizedBox(height: 10),
                    _buildUserListSection(),
                    
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
          
          if (isLoading)
            Container(
              color: Colors.black.withOpacity(0.7),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(color: neonCyan),
                    const SizedBox(height: 20),
                    Text(
                      "Processing...",
                      style: TextStyle(color: neonCyan),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  // --- WIDGET COMPONENTS ---

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [cardDark, darkPurple],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(color: neonCyan.withOpacity(0.2), blurRadius: 20, offset: const Offset(0, 5))
        ],
        border: Border.all(color: neonCyan.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: neonCyan.withOpacity(0.1),
              borderRadius: BorderRadius.circular(15),
              border: Border.all(color: neonCyan),
            ),
            child: const Icon(Icons.school, color: Colors.white, size: 32),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ShaderMask(
                  shaderCallback: (bounds) => LinearGradient(
                    colors: [neonCyan, neonPurple],
                  ).createShader(bounds),
                  child: const Text(
                    "TK DASHBOARD",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "Welcome, ${widget.username}",
                  style: TextStyle(color: neonCyan, fontSize: 12),
                ),
                Text(
                  "Manage: Reseller | Member | VIP",
                  style: TextStyle(color: Colors.white54, fontSize: 10),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: neonCyan, size: 18),
        const SizedBox(width: 8),
        Text(
          title.toUpperCase(),
          style: TextStyle(
            color: neonCyan,
            fontWeight: FontWeight.bold,
            fontSize: 14,
            letterSpacing: 1,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(child: Container(height: 1, color: neonCyan.withOpacity(0.2))),
      ],
    );
  }

  Widget _buildCreateUserCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardBlack,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: neonCyan.withOpacity(0.2)),
      ),
      child: Column(
        children: [
          _buildInput(createUsernameController, "Username", Icons.person_outline),
          const SizedBox(height: 15),
          _buildInput(createPasswordController, "Password", Icons.lock_outline),
          const SizedBox(height: 15),
          Row(
            children: [
              Expanded(
                flex: 1,
                child: _buildInput(createDayController, "Days", Icons.calendar_today, isNumber: true),
              ),
              const SizedBox(width: 15),
              Expanded(
                flex: 2,
                child: _buildRoleDropdown(newUserRole, (val) => setState(() => newUserRole = val!)),
              ),
            ],
          ),
          const SizedBox(height: 20),
          _buildGradientButton("CREATE ACCOUNT", Icons.add_circle, _createAccount, neonCyan),
        ],
      ),
    );
  }

  Widget _buildExtendDurationCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardBlack,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: neonCyan.withOpacity(0.2)),
      ),
      child: Column(
        children: [
          _buildInput(editUsernameController, "Username Target", Icons.person),
          const SizedBox(height: 15),
          Row(
            children: [
              Expanded(
                flex: 2,
                child: _buildInput(editDayController, "Add Days", Icons.calendar_today, isNumber: true),
              ),
              const SizedBox(width: 15),
              Expanded(
                flex: 1,
                child: _buildGradientButton("EXTEND", Icons.add, _extendDuration, neonPurple),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDeleteUserCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: neonMagenta.withOpacity(0.05),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: neonMagenta.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: neonMagenta, size: 20),
              const SizedBox(width: 10),
              Text("Delete User", style: TextStyle(color: neonMagenta, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 15),
          Row(
            children: [
              Expanded(
                child: _buildInput(deleteController, "Username to Delete", Icons.delete_outline),
              ),
              const SizedBox(width: 10),
              Container(
                decoration: BoxDecoration(
                  color: neonMagenta.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: neonMagenta.withOpacity(0.5)),
                ),
                child: IconButton(
                  onPressed: _deleteUser,
                  icon: Icon(Icons.delete_forever, color: neonMagenta),
                ),
              )
            ],
          ),
          const SizedBox(height: 8),
          Text(
            "⚠️ Hanya bisa menghapus user dengan role: RESELLER, MEMBER, VIP",
            style: TextStyle(color: neonMagenta.withOpacity(0.7), fontSize: 10),
          ),
        ],
      ),
    );
  }

  Widget _buildUserListSection() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: cardBlack,
            borderRadius: BorderRadius.circular(15),
            border: Border.all(color: neonCyan.withOpacity(0.2)),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              dropdownColor: cardBlack,
              value: selectedRole,
              isExpanded: true,
              icon: Icon(Icons.filter_list, color: neonCyan),
              items: roleOptions.map((role) {
                return DropdownMenuItem(
                  value: role,
                  child: Text(
                    "Filter: ${role.toUpperCase()}",
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                );
              }).toList(),
              onChanged: (val) {
                setState(() {
                  selectedRole = val!;
                  _filterAndPaginate();
                });
              },
            ),
          ),
        ),
        const SizedBox(height: 15),

        if (filteredList.isEmpty)
          Container(
            padding: const EdgeInsets.all(30),
            child: Column(
              children: [
                Icon(Icons.person_off, color: Colors.grey, size: 40),
                const SizedBox(height: 10),
                Text("No users found for '$selectedRole'", style: const TextStyle(color: Colors.grey)),
              ],
            ),
          )
        else
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _getCurrentPageData().length,
            itemBuilder: (context, index) {
              final user = _getCurrentPageData()[index];
              return _buildUserItem(user);
            },
          ),
        
        const SizedBox(height: 20),
        
        if (totalPages > 1) _buildPagination(),
      ],
    );
  }

  Widget _buildUserItem(Map user) {
    final role = user['role']?.toString() ?? 'member';
    final isVip = role == 'vip';
    final isReseller = role == 'reseller';
    
    Color roleColor;
    if (isVip) {
      roleColor = neonPurple;
    } else if (isReseller) {
      roleColor = neonCyan;
    } else {
      roleColor = const Color(0xFF4CAF50);
    }
    
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: cardBlack,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: roleColor.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 5, offset: const Offset(0, 2))
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: roleColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: roleColor.withOpacity(0.3)),
            ),
            child: Icon(
              isVip ? Icons.star : (isReseller ? Icons.store : Icons.person),
              color: roleColor,
              size: 20,
            ),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['username']?.toString() ?? 'Unknown',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    _buildMiniBadge(role.toUpperCase(), roleColor),
                    const SizedBox(width: 8),
                    _buildMiniBadge("Exp: ${user['expiredDate']?.toString() ?? 'N/A'}", Colors.grey),
                  ],
                ),
              ],
            ),
          ),
          IconButton(
            icon: Icon(Icons.delete_outline, color: neonMagenta.withOpacity(0.5)),
            onPressed: () {
              deleteController.text = user['username']?.toString() ?? '';
              _showSnack("Klik tombol merah di 'Danger Zone' untuk menghapus.");
            },
          ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(totalPages, (index) {
          final page = index + 1;
          final isActive = currentPage == page;
          return GestureDetector(
            onTap: () => setState(() => currentPage = page),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 4),
              width: 35,
              height: 35,
              decoration: BoxDecoration(
                gradient: isActive 
                    ? LinearGradient(colors: [neonCyan, neonPurple])
                    : null,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: isActive ? neonCyan : Colors.grey.shade800),
              ),
              child: Center(
                child: Text(
                  "$page",
                  style: TextStyle(
                    color: isActive ? Colors.white : Colors.grey,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  // --- Helper Widgets ---

  Widget _buildInput(TextEditingController controller, String hint, IconData icon, {bool isNumber = false}) {
    return Container(
      decoration: BoxDecoration(
        color: bgBlack,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: neonCyan.withOpacity(0.2)),
      ),
      child: TextField(
        controller: controller,
        keyboardType: isNumber ? TextInputType.number : TextInputType.text,
        style: const TextStyle(color: Colors.white),
        cursorColor: neonCyan,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: Colors.grey.shade600),
          prefixIcon: Icon(icon, color: neonCyan, size: 20),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        ),
      ),
    );
  }

  Widget _buildRoleDropdown(String val, Function(String?) onChanged) {
    Map<String, Color> roleColors = {
      'reseller': neonCyan,
      'member': const Color(0xFF4CAF50),
      'vip': neonPurple,
    };
    
    Map<String, IconData> roleIcons = {
      'reseller': Icons.store,
      'member': Icons.person,
      'vip': Icons.star,
    };
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: bgBlack,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: neonCyan.withOpacity(0.2)),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          dropdownColor: cardBlack,
          value: val,
          isExpanded: true,
          icon: Icon(Icons.arrow_drop_down, color: neonCyan),
          items: roleOptions.map((role) {
            return DropdownMenuItem(
              value: role,
              child: Row(
                children: [
                  Icon(roleIcons[role], size: 16, color: roleColors[role]),
                  const SizedBox(width: 8),
                  Text(
                    role.toUpperCase(),
                    style: TextStyle(color: roleColors[role], fontSize: 13, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            );
          }).toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }

  Widget _buildGradientButton(String text, IconData icon, VoidCallback onTap, [Color? customColor]) {
    final gradientColor = customColor ?? neonCyan;
    return Container(
      width: double.infinity,
      height: 50,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [gradientColor, gradientColor.withOpacity(0.6)]),
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(color: gradientColor.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 4))
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(15),
          onTap: onTap,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: Colors.white, size: 20),
              const SizedBox(width: 10),
              Text(
                text,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMiniBadge(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withOpacity(0.5), width: 0.5),
      ),
      child: Text(
        text,
        style: TextStyle(color: color.withOpacity(0.9), fontSize: 10, fontWeight: FontWeight.bold),
      ),
    );
  }
}