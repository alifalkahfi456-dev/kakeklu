// owner_page.dart - DEATH X-FLOID EDITION 💀🔥
// Dark theme dengan Neon Cyan + Magenta
// Modified by TANZ AI V8 for Professor KenzMD

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'services/api_config_service.dart';

// ============ WARNA NEON DEATH X-FLOID ============
const Color neonCyan = Color(0xFF00E5FF);
const Color neonMagenta = Color(0xFFFF1744);
const Color neonPurple = Color(0xFF9C4DCC);
const Color deepBlack = Color(0xFF070B12);
const Color cardDark = Color(0xFF0F0F1A);
const Color darkPurple = Color(0xFF1A1A2E);
const Color neonYellow = Color(0xFFFFE600);

class OwnerPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const OwnerPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<OwnerPage> createState() => _OwnerPageState();
}

class _OwnerPageState extends State<OwnerPage> {
  late String sessionKey;
  late String apiBaseUrl;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['owner', 'pt', 'tk', 'moderator', 'reseller', 'member'];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();
  final changeRoleController = TextEditingController();
  String selectedNewRole = 'member';

  String newUserRole = 'member';
  bool isLoading = false;

  // Warna NEON
  final Color bgDark = deepBlack;
  final Color surfaceDark = cardDark;
  final Color primaryWhite = Colors.white;
  final Color textGrey = Colors.grey.shade400;
  final Color cardGlass = darkPurple;
  final Color borderGlass = neonCyan.withOpacity(0.3);
  final Color buttonDark = const Color(0xFF1A1A2E);
  final Color deleteColor = neonMagenta;
  final Color editColor = neonCyan;
  final Color successColor = neonCyan;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _loadBaseUrl();
  }

  Future<void> _loadBaseUrl() async {
    try {
      final apiConfig = ApiConfigService();
      apiBaseUrl = await apiConfig.getBaseUrl();
      _fetchUsers();
    } catch (e) {
      apiBaseUrl = 'http://yuzianakbaik.dhangantenk.biz.id:2002';
      _fetchUsers();
    }
  }

  @override
  void dispose() {
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    deleteController.dispose();
    editUsernameController.dispose();
    editDayController.dispose();
    changeRoleController.dispose();
    super.dispose();
  }

  Future<void> _fetchUsers() async {
    if (!mounted) return;
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$apiBaseUrl/listUsers?key=$sessionKey'),
      );
      if (!mounted) return;
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        setState(() {
          fullUserList = data['users'] ?? [];
          _filterAndPaginate();
        });
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (e) {
      if (!mounted) return;
      _alert("Error", "Gagal terhubung ke server: ${e.toString()}");
    }
    if (mounted) {
      setState(() => isLoading = false);
    }
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList
          .where((u) => u['role'].toString() == selectedRole)
          .toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    if (start >= filteredList.length) return [];
    return filteredList.sublist(
      start,
      end > filteredList.length ? filteredList.length : end,
    );
  }

  int get totalPages => filteredList.isEmpty ? 1 : (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }

    if (username == widget.username) {
      _alert("Peringatan", "Anda tidak dapat menghapus akun OWNER sendiri!");
      return;
    }

    final userExists = fullUserList.any((u) => u['username'] == username);
    if (!userExists) {
      _alert("Peringatan", "Username '$username' tidak ditemukan!");
      return;
    }

    if (!mounted) return;
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$apiBaseUrl/deleteUser?key=$sessionKey&username=$username'),
      );
      if (!mounted) return;
      final data = jsonDecode(res.body);

      if (data['deleted'] == true) {
        _alert("Sukses", "User '$username' berhasil dihapus.");
        deleteController.clear();
        await _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (e) {
      if (!mounted) return;
      _alert("Error", "Gagal menghubungi server: ${e.toString()}");
    }
    if (mounted) {
      setState(() => isLoading = false);
    }
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();

    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    if (u.length < 3) {
      _alert("Peringatan", "Username minimal 3 karakter.");
      return;
    }

    if (p.length < 4) {
      _alert("Peringatan", "Password minimal 4 karakter.");
      return;
    }

    final dayInt = int.tryParse(d);
    if (dayInt == null || dayInt <= 0) {
      _alert("Peringatan", "Durasi harus berupa angka positif.");
      return;
    }

    final existingUser = fullUserList.any((user) => 
      user['username'].toString().toLowerCase() == u.toLowerCase()
    );
    if (existingUser) {
      _alert("Peringatan", "Username '$u' sudah terdaftar!");
      return;
    }

    if (!mounted) return;
    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        '$apiBaseUrl/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$newUserRole',
      );
      final res = await http.get(url);
      if (!mounted) return;
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _alert("Sukses", "Akun berhasil dibuat sebagai ${newUserRole.toUpperCase()}.\nUsername: $u\nDurasi: $d hari");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        setState(() {
          newUserRole = 'member';
        });
        await _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (e) {
      if (!mounted) return;
      _alert("Error", "Gagal menghubungi server: ${e.toString()}");
    }
    if (mounted) {
      setState(() => isLoading = false);
    }
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();

    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    final dayInt = int.tryParse(d);
    if (dayInt == null || dayInt <= 0) {
      _alert("Peringatan", "Jumlah hari harus berupa angka positif.");
      return;
    }

    final userExists = fullUserList.any((user) => user['username'] == u);
    if (!userExists) {
      _alert("Peringatan", "Username '$u' tidak ditemukan!");
      return;
    }

    if (!mounted) return;
    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        '$apiBaseUrl/editUser?key=$sessionKey&username=$u&addDays=$d',
      );
      final res = await http.get(url);
      if (!mounted) return;
      final data = jsonDecode(res.body);

      if (data['edited'] == true) {
        _alert("Sukses", "Durasi user '$u' berhasil diperbarui (+$d hari).");
        editUsernameController.clear();
        editDayController.clear();
        await _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (e) {
      if (!mounted) return;
      _alert("Error", "Gagal menghubungi server: ${e.toString()}");
    }
    if (mounted) {
      setState(() => isLoading = false);
    }
  }

  Future<void> _changeUserRole() async {
    final u = changeRoleController.text.trim();
    
    if (u.isEmpty) {
      _alert("Peringatan", "Masukkan username target.");
      return;
    }

    if (u == widget.username) {
      _alert("Peringatan", "Anda tidak dapat mengubah role OWNER sendiri!");
      return;
    }

    final targetUser = fullUserList.firstWhere(
      (user) => user['username'] == u,
      orElse: () => null,
    );
    
    if (targetUser == null) {
      _alert("Peringatan", "Username '$u' tidak ditemukan!");
      return;
    }

    final currentRole = targetUser['role'].toString();
    final ownerCount = fullUserList.where((u) => u['role'] == 'owner').length;
    
    if (currentRole == 'owner' && ownerCount <= 1 && selectedNewRole != 'owner') {
      _alert("Peringatan", "Tidak dapat mengubah role OWNER terakhir! Buat owner baru terlebih dahulu.");
      return;
    }

    if (!mounted) return;
    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        '$apiBaseUrl/changeRole?key=$sessionKey&username=$u&role=$selectedNewRole',
      );
      final res = await http.get(url);
      if (!mounted) return;
      final data = jsonDecode(res.body);

      if (data['changed'] == true || data['success'] == true) {
        _alert("Sukses", "Role user '$u' berhasil diubah menjadi ${selectedNewRole.toUpperCase()}.");
        changeRoleController.clear();
        setState(() {
          selectedNewRole = 'member';
        });
        await _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah role user.');
      }
    } catch (e) {
      if (!mounted) return;
      _alert("Error", "Gagal menghubungi server: ${e.toString()}");
    }
    if (mounted) {
      setState(() => isLoading = false);
    }
  }

  void _alert(String title, String message) {
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: surfaceDark,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: borderGlass),
          ),
          title: Row(
            children: [
              Icon(
                title == "Sukses" ? Icons.check_circle : Icons.warning_rounded,
                color: title == "Sukses" ? successColor : deleteColor,
              ),
              const SizedBox(width: 10),
              Text(
                title,
                style: const TextStyle(color: Colors.white),
              ),
            ],
          ),
          content: Text(
            message,
            style: const TextStyle(color: Colors.grey),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                "OK",
                style: TextStyle(color: neonCyan),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
    String? hint,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          hintStyle: TextStyle(color: textGrey.withOpacity(0.5)),
          labelStyle: TextStyle(color: neonCyan),
          prefixIcon: Icon(icon, color: neonCyan),
          filled: true,
          fillColor: cardDark,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: borderGlass),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: borderGlass),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: neonCyan, width: 1.5),
          ),
        ),
      ),
    );
  }

  Widget _buildRoleDropdown({
    required String value,
    required Function(String) onChanged,
    List<String>? roles,
  }) {
    final roleList = roles ?? roleOptions;
    
    Map<String, IconData> roleIcons = {
      'owner': FontAwesomeIcons.crown,
      'pt': FontAwesomeIcons.userTie,
      'tk': FontAwesomeIcons.userGraduate,
      'moderator': FontAwesomeIcons.userShield,
      'reseller': FontAwesomeIcons.store,
      'member': FontAwesomeIcons.user,
    };
    
    Map<String, Color> roleColors = {
      'owner': neonYellow,
      'pt': neonPurple,
      'tk': neonCyan,
      'moderator': neonMagenta,
      'reseller': const Color(0xFF4CAF50),
      'member': Colors.grey,
    };

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderGlass),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          dropdownColor: surfaceDark,
          style: TextStyle(color: roleColors[value] ?? Colors.white),
          iconEnabledColor: neonCyan,
          isExpanded: true,
          items: roleList.map((role) {
            return DropdownMenuItem(
              value: role,
              child: Row(
                children: [
                  Icon(roleIcons[role], size: 16, color: roleColors[role]),
                  const SizedBox(width: 10),
                  Text(
                    role.toUpperCase(),
                    style: TextStyle(
                      color: roleColors[role],
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
          onChanged: (val) {
            if (val != null && mounted) {
              onChanged(val);
            }
          },
        ),
      ),
    );
  }

  Widget _buildGlassCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 25),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderGlass),
        boxShadow: [
          BoxShadow(
            color: neonCyan.withOpacity(0.08),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [neonCyan.withOpacity(0.2), neonPurple.withOpacity(0.1)],
                  ),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: neonCyan.withOpacity(0.3)),
                ),
                child: Icon(icon, color: neonCyan),
              ),
              const SizedBox(width: 12),
              ShaderMask(
                shaderCallback: (bounds) => LinearGradient(
                  colors: [neonCyan, neonPurple],
                ).createShader(bounds),
                child: Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          ...children,
        ],
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    String role = user['role']?.toString() ?? 'member';
    String username = user['username'] ?? 'Unknown';
    
    Color roleColor;
    switch(role) {
      case 'owner':
        roleColor = neonYellow;
        break;
      case 'pt':
        roleColor = neonPurple;
        break;
      case 'tk':
        roleColor = neonCyan;
        break;
      case 'moderator':
        roleColor = neonMagenta;
        break;
      case 'reseller':
        roleColor = const Color(0xFF4CAF50);
        break;
      default:
        roleColor = textGrey;
    }
    
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderGlass),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: roleColor.withOpacity(0.2),
              shape: BoxShape.circle,
              border: Border.all(color: roleColor.withOpacity(0.3)),
            ),
            child: Icon(Icons.person, color: roleColor),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      username,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    if (username == widget.username) ...[
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: neonYellow.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(4),
                          border: Border.all(color: neonYellow.withOpacity(0.3)),
                        ),
                        child: const Text(
                          "YOU",
                          style: TextStyle(color: neonYellow, fontSize: 8, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: roleColor.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: roleColor.withOpacity(0.3)),
                      ),
                      child: Text(
                        role.toUpperCase(),
                        style: TextStyle(color: roleColor, fontSize: 10, fontWeight: FontWeight.bold),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      "EXP: ${user['expiredDate'] ?? 'N/A'}",
                      style: TextStyle(color: textGrey, fontSize: 12),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: deleteColor.withOpacity(0.1),
              shape: BoxShape.circle,
              border: Border.all(color: deleteColor.withOpacity(0.3)),
            ),
            child: IconButton(
              icon: Icon(Icons.delete_outline, color: deleteColor),
              onPressed: username == widget.username ? null : () async {
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      backgroundColor: surfaceDark,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                        side: BorderSide(color: borderGlass),
                      ),
                      title: Row(
                        children: [
                          Icon(Icons.warning, color: deleteColor),
                          const SizedBox(width: 8),
                          const Text("Konfirmasi", style: TextStyle(color: Colors.white)),
                        ],
                      ),
                      content: Text("Hapus user '$username'?", style: const TextStyle(color: Colors.grey)),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context, false),
                          child: Text("Batal", style: TextStyle(color: neonCyan)),
                        ),
                        TextButton(
                          onPressed: () => Navigator.pop(context, true),
                          child: Text("Hapus", style: TextStyle(color: deleteColor)),
                        ),
                      ],
                    );
                  },
                );
                if (confirm == true && mounted) {
                  deleteController.text = username;
                  await _deleteUser();
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    if (totalPages <= 1) return const SizedBox();
    
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        return Container(
          decoration: BoxDecoration(
            gradient: currentPage == page
                ? LinearGradient(colors: [neonCyan, neonPurple])
                : null,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: borderGlass),
          ),
          child: ElevatedButton(
            onPressed: () {
              if (mounted) {
                setState(() => currentPage = page);
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: currentPage == page ? Colors.transparent : cardDark,
              foregroundColor: currentPage == page ? Colors.white : textGrey,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: Text("$page", style: const TextStyle(fontSize: 12)),
          ),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        title: ShaderMask(
          shaderCallback: (bounds) => LinearGradient(
            colors: [neonYellow, neonCyan, neonMagenta],
          ).createShader(bounds),
          child: const Text(
            "OWNER DASHBOARD",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.white,
              letterSpacing: 1.5,
            ),
          ),
        ),
        backgroundColor: cardDark,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [neonCyan, neonPurple, neonMagenta],
              ),
            ),
          ),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgDark, surfaceDark, bgDark],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [neonYellow.withOpacity(0.2), neonCyan.withOpacity(0.1)],
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: neonYellow, width: 2),
                  ),
                  child: Icon(Icons.workspace_premium, color: neonYellow, size: 40),
                ),
                const SizedBox(height: 10),
                ShaderMask(
                  shaderCallback: (bounds) => LinearGradient(
                    colors: [neonYellow, neonCyan],
                  ).createShader(bounds),
                  child: const Text(
                    "OWNER DASHBOARD",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                    ),
                  ),
                ),
                Text(
                  "Welcome, ${widget.username}",
                  style: TextStyle(color: neonYellow, fontSize: 14),
                ),
                const SizedBox(height: 40),

                // DELETE USER CARD
                _buildGlassCard(
                  title: "DELETE USER",
                  icon: FontAwesomeIcons.userSlash,
                  children: [
                    _buildInput(
                      label: "Username Target",
                      controller: deleteController,
                      icon: FontAwesomeIcons.user,
                      hint: "Masukkan username yang akan dihapus",
                    ),
                    const SizedBox(height: 10),
                    Container(
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [neonMagenta, neonMagenta.withOpacity(0.7)],
                        ),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: neonMagenta.withOpacity(0.3),
                            blurRadius: 8,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: ElevatedButton(
                        onPressed: isLoading ? null : _deleteUser,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.delete, size: 18, color: Colors.white),
                            SizedBox(width: 8),
                            Text(
                              "DELETE ACCOUNT",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),

                // CHANGE ROLE CARD
                _buildGlassCard(
                  title: "CHANGE USER ROLE",
                  icon: FontAwesomeIcons.userTag,
                  children: [
                    _buildInput(
                      label: "Username Target",
                      controller: changeRoleController,
                      icon: FontAwesomeIcons.user,
                      hint: "Masukkan username",
                    ),
                    const SizedBox(height: 10),
                    Text(
                      "Role Baru",
                      style: TextStyle(color: neonCyan, fontSize: 12),
                    ),
                    const SizedBox(height: 5),
                    _buildRoleDropdown(
                      value: selectedNewRole,
                      onChanged: (val) {
                        if (mounted) setState(() => selectedNewRole = val);
                      },
                    ),
                    const SizedBox(height: 20),
                    Container(
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [neonCyan, neonPurple],
                        ),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: neonCyan.withOpacity(0.3),
                            blurRadius: 8,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: ElevatedButton(
                        onPressed: isLoading ? null : _changeUserRole,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: isLoading
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.swap_horiz, size: 18, color: Colors.white),
                                  SizedBox(width: 8),
                                  Text(
                                    "CHANGE ROLE",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 1,
                                    ),
                                  ),
                                ],
                              ),
                      ),
                    ),
                  ],
                ),

                // CREATE ACCOUNT CARD
                _buildGlassCard(
                  title: "CREATE ACCOUNT",
                  icon: FontAwesomeIcons.userPlus,
                  children: [
                    _buildInput(
                      label: "Username",
                      controller: createUsernameController,
                      icon: FontAwesomeIcons.user,
                      hint: "Minimal 3 karakter",
                    ),
                    _buildInput(
                      label: "Password",
                      controller: createPasswordController,
                      icon: FontAwesomeIcons.lock,
                      hint: "Minimal 4 karakter",
                    ),
                    _buildInput(
                      label: "Durasi (Hari)",
                      controller: createDayController,
                      icon: FontAwesomeIcons.calendarDay,
                      type: TextInputType.number,
                      hint: "Contoh: 30",
                    ),
                    const SizedBox(height: 10),
                    Text(
                      "Pilih Role",
                      style: TextStyle(color: neonCyan, fontSize: 12),
                    ),
                    const SizedBox(height: 5),
                    _buildRoleDropdown(
                      value: newUserRole,
                      onChanged: (val) {
                        if (mounted) setState(() => newUserRole = val);
                      },
                    ),
                    const SizedBox(height: 20),
                    Container(
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [neonCyan, neonPurple],
                        ),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: neonCyan.withOpacity(0.3),
                            blurRadius: 8,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: ElevatedButton(
                        onPressed: isLoading ? null : _createAccount,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: isLoading
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Text(
                                "CREATE ACCOUNT",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1,
                                ),
                              ),
                      ),
                    ),
                  ],
                ),

                // EXTEND DURATION CARD
                _buildGlassCard(
                  title: "EXTEND DURATION",
                  icon: FontAwesomeIcons.clock,
                  children: [
                    _buildInput(
                      label: "Username Target",
                      controller: editUsernameController,
                      icon: FontAwesomeIcons.userEdit,
                      hint: "Masukkan username",
                    ),
                    _buildInput(
                      label: "Tambah Hari",
                      controller: editDayController,
                      icon: FontAwesomeIcons.calendarPlus,
                      type: TextInputType.number,
                      hint: "Contoh: 7",
                    ),
                    const SizedBox(height: 10),
                    Container(
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [neonPurple, neonCyan],
                        ),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: neonPurple.withOpacity(0.3),
                            blurRadius: 8,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: ElevatedButton(
                        onPressed: isLoading ? null : _editUser,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: isLoading
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Text(
                                "ADD DAYS",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1,
                                ),
                              ),
                      ),
                    ),
                  ],
                ),

                // USER LIST CARD
                _buildGlassCard(
                  title: "USER LIST",
                  icon: FontAwesomeIcons.users,
                  children: [
                    _buildRoleDropdown(
                      value: selectedRole,
                      onChanged: (val) {
                        if (mounted) {
                          setState(() {
                            selectedRole = val;
                            _filterAndPaginate();
                          });
                        }
                      },
                    ),
                    const SizedBox(height: 20),
                    isLoading
                        ? const Center(
                            child: CircularProgressIndicator(
                              color: neonCyan,
                            ),
                          )
                        : Column(
                            children: [
                              ..._getCurrentPageData()
                                  .map((u) => _buildUserItem(u))
                                  .toList(),
                              const SizedBox(height: 20),
                              _buildPagination(),
                            ],
                          ),
                  ],
                ),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }
}