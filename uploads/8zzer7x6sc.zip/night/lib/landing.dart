// landing.dart - DEATH X-FLOID EDITION 💀🔥
// Dark theme dengan Neon Cyan + Magenta
// Modified by TANZ AI V8 for Professor KenzMD

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'login_page.dart';

// ============ WARNA NEON DEATH X-FLOID ============
const Color neonCyan = Color(0xFF00E5FF);
const Color neonMagenta = Color(0xFFFF1744);
const Color neonPurple = Color(0xFF9C4DCC);
const Color deepBlack = Color(0xFF070B12);
const Color cardDark = Color(0xFF0F0F1A);
const Color darkPurple = Color(0xFF1A1A2E);
const Color glassCyan = Color(0xFF00E5FF);

void main() {
  runApp(const MaterialApp(
    home: LandingPage(),
    debugShowCheckedModeBanner: false,
  ));
}

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  // Warna NEON
  static const Color _darkBg = Color(0xFF070B12);      // deepBlack
  static const Color _accentNeon = neonCyan;            // Bright Cyan
  static const Color _darkNeon = Color(0xFF0088AA);     // Dark Cyan
  static const Color _cardBg = Color(0xFF0F0F1A);       // cardDark
  static const Color _innerCardBg = Color(0xFF1A1A2E);  // darkPurple
  static const Color _telegramBlue = Color(0xFF24A1DE);
  static const Color _tiktokNeon = neonMagenta;

  Future<void> _launchSocialUrl(String urlString) async {
    final Uri url = Uri.parse(urlString);
    try {
      if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
        debugPrint("Could not launch $urlString");
      }
    } catch (e) {
      debugPrint("Error launching URL: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _darkBg,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              _buildLogoSection(),
              _buildHeaderTitle(),
              const SizedBox(height: 40),
              _buildFeatureCard(),
              const SizedBox(height: 35),
              _buildActionButtons(context),
              const SizedBox(height: 25),
              _buildSocialSection(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLogoSection() {
    return Container(
      width: double.infinity,
      height: 200,
      margin: const EdgeInsets.only(bottom: 10),
      child: Image.asset(
        'assets/images/logo.jpg',
        fit: BoxFit.contain,
        errorBuilder: (context, error, stackTrace) =>
            const Icon(Icons.broken_image, color: Colors.white10, size: 80),
      ),
    );
  }

  Widget _buildHeaderTitle() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.baseline,
          textBaseline: TextBaseline.alphabetic,
          children: [
            ShaderMask(
              blendMode: BlendMode.srcIn,
              shaderCallback: (bounds) => const LinearGradient(
                colors: [neonCyan, neonPurple, neonMagenta],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ).createShader(Rect.fromLTWH(0, 0, bounds.width, bounds.height)),
              child: const Text(
                "Tr4nsFlow'",
                style: TextStyle(
                  fontFamily: 'Orbitron',
                  fontSize: 40,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 10,
                ),
              ),
            ),
            ShaderMask(
              blendMode: BlendMode.srcIn,
              shaderCallback: (bounds) => const LinearGradient(
                colors: [neonCyan, neonPurple, neonMagenta],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ).createShader(Rect.fromLTWH(0, 0, bounds.width, bounds.height)),
              child: const Text(
                "S",
                style: TextStyle(
                  fontFamily: 'Orbitron',
                  fontSize: 40,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 10,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          "GACOR  •  TERUPDATE  •  STABIL",
          style: TextStyle(
            color: neonCyan.withOpacity(0.6),
            fontSize: 11,
            letterSpacing: 4,
            fontWeight: FontWeight.w300,
          ),
        ),
      ],
    );
  }

  Widget _buildFeatureCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 20),
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: neonCyan.withOpacity(0.2)),
        boxShadow: [
          BoxShadow(
            color: neonCyan.withOpacity(0.1),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [neonCyan.withOpacity(0.2), neonMagenta.withOpacity(0.1)],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: neonCyan.withOpacity(0.3)),
            ),
            child: Icon(Icons.shield_outlined, color: neonCyan, size: 32),
          ),
          const SizedBox(height: 20),
          ShaderMask(
            shaderCallback: (bounds) => LinearGradient(
              colors: [neonCyan, neonPurple],
            ).createShader(bounds),
            child: const Text(
              "Tr4nsFlow BUG",
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                letterSpacing: 2,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 15),
          Text(
            "Aplikasi dengan desain elegan dan fitur terbaru.\nPengembangan langsung oleh TEAM Tr4nsFlow.",
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white.withOpacity(0.6),
              fontSize: 13,
              height: 1.6,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons(BuildContext context) {
    const TextStyle rajdhaniStyle = TextStyle(
      fontFamily: 'Orbitron',
      fontWeight: FontWeight.w600,
      fontSize: 16,
    );

    return Column(
      children: [
        _customButton(
          title: "LOGIN TO Tr4nsFlow",
          icon: FontAwesomeIcons.rocket,
          isPrimary: true,
          textStyle: rajdhaniStyle,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const LoginPage()),
          ),
        ),
        const SizedBox(height: 16),
        _customButton(
          title: "CONTACT SUPPORT",
          icon: Icons.support_agent,
          isPrimary: false,
          textStyle: rajdhaniStyle,
          onTap: () => _launchSocialUrl("https://t.me/testiYuziz"),
        ),
      ],
    );
  }

  Widget _buildSocialSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 25, horizontal: 20),
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: neonCyan.withOpacity(0.15)),
      ),
      child: Column(
        children: [
          Text(
            "HUBUNGI KAMI",
            style: TextStyle(
              fontFamily: 'Orbitron',
              color: neonCyan.withOpacity(0.5),
              fontSize: 11,
              letterSpacing: 3,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _socialIconItem(FontAwesomeIcons.telegram, "Telegram Ch", "https://t.me/testiYuziz", _telegramBlue),
              _socialIconItem(FontAwesomeIcons.telegram, "Channel Tr4nsFlow", "https://t.me/Emakloewe", _telegramBlue),
              _socialIconItem(FontAwesomeIcons.tiktok, "TikTok Official", "https://tiktok.com/@YuziStr", _tiktokNeon),
            ],
          ),
        ],
      ),
    );
  }

  Widget _customButton({
    required String title,
    required IconData icon,
    required bool isPrimary,
    required VoidCallback onTap,
    TextStyle? textStyle,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(15),
        child: Container(
          width: double.infinity,
          height: 60,
          decoration: BoxDecoration(
            gradient: isPrimary
                ? LinearGradient(
                    colors: [neonCyan.withOpacity(0.1), neonPurple.withOpacity(0.05)],
                  )
                : null,
            color: isPrimary ? null : Colors.white.withOpacity(0.015),
            borderRadius: BorderRadius.circular(15),
            border: Border.all(
              color: isPrimary ? neonCyan.withOpacity(0.5) : neonCyan.withOpacity(0.15),
              width: 1.2,
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: isPrimary ? neonCyan : neonCyan.withOpacity(0.6), size: 18),
              const SizedBox(width: 12),
              Text(
                title,
                style: (textStyle ?? const TextStyle()).copyWith(
                  color: isPrimary ? neonCyan : Colors.white60,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _socialIconItem(IconData icon, String label, String url, Color color) {
    return InkWell(
      onTap: () => _launchSocialUrl(url),
      borderRadius: BorderRadius.circular(15),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Container(
              width: 45,
              height: 45,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _innerCardBg,
                border: Border.all(color: neonCyan.withOpacity(0.2)),
                boxShadow: [
                  BoxShadow(
                    color: color.withOpacity(0.3),
                    blurRadius: 8,
                  ),
                ],
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                fontFamily: 'Orbitron',
                color: Colors.white.withOpacity(0.6),
                fontSize: 10,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}