// dashboard_page.dart - DEATH X-FLOID EDITION 💀🔥
// Dark theme dengan Neon Cyan + Magenta
// Header sesuai gambar: foto lingkaran + username + role + session id + account exp + key sessions
// Modified by TANZ AI V8 for Professor KenzMD

import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';

import 'anime_home.dart';
import 'change_password.dart';
import 'bug_sender.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'services/api_config_service.dart';
import 'thxto_page.dart';
import 'game_area_page.dart';
import 'publik_chat.dart';
import 'moderator_page.dart';
import 'owner_page.dart';
import 'music_page.dart';
import 'partner_page.dart';
import 'tk_page.dart';
import 'TestFunction.Page.dart';
import 'jadwal_sholat.dart';

// ============ WARNA NEON DEATH X-FLOID ============
const Color neonCyan = Color(0xFF00E5FF);
const Color neonMagenta = Color(0xFFFF1744);
const Color deepBlack = Color(0xFF070B12);
const Color cardDark = Color(0xFF0F0F1A);
const Color darkPurple = Color(0xFF1A1A2E);
const Color neonPurple = Color(0xFF9C4DCC);
const Color neonYellow = Color(0xFFFFE600);

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  WebSocketChannel? channel;
  late PageController _newsPageController;
  Timer? _autoSlideTimer;

  late VideoPlayerController _videoController;
  late VideoPlayerController _appBarVideoController;
  bool _isVideoInitialized = false;
  bool _isAppBarVideoInitialized = false;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const SizedBox();
  int _currentNewsIndex = 0;

  // Warna NEON
  final Color baseDark = const Color(0xFF0A0A0F);
  final Color borderCyan = neonCyan;
  final Color borderMagenta = neonMagenta;
  final Color primaryWhite = Colors.white;
  final Color accentGrey = Colors.grey.shade400;

  final ApiConfigService _apiService = ApiConfigService();

  int onlineUsers = 0;
  int activeConnections = 0;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _initializeVideos();
    _initializeNewsCarousel();

    _controller = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _selectedPage = _buildEnhancedNewsPage();
    _initAndroidIdAndConnect();
  }

  void _initializeVideos() async {
    _videoController = VideoPlayerController.asset('assets/videos/bg.mp4')
      ..initialize().then((_) {
        if (mounted) {
          _videoController.setVolume(0.0);
          _videoController.setLooping(true);
          _videoController.play();
          setState(() {
            _isVideoInitialized = true;
          });
        }
      }).catchError((e) {
        print('Error loading bg video: $e');
        if (mounted) {
          setState(() {
            _isVideoInitialized = true;
          });
        }
      });
    
    _appBarVideoController = VideoPlayerController.asset('assets/videos/aw.mp4')
      ..initialize().then((_) {
        if (mounted) {
          _appBarVideoController.setVolume(0.5);
          _appBarVideoController.setLooping(true);
          _appBarVideoController.play();
          setState(() {
            _isAppBarVideoInitialized = true;
          });
        }
      }).catchError((e) {
        print('Error loading appbar video: $e');
        if (mounted) {
          setState(() {
            _isAppBarVideoInitialized = true;
          });
        }
      });
  }

  void _initializeNewsCarousel() {
    _newsPageController = PageController(viewportFraction: 1.0);
    
    if (newsList.isNotEmpty && mounted) {
      _autoSlideTimer = Timer.periodic(const Duration(milliseconds: 3000), (timer) {
        if (_newsPageController.hasClients && mounted && newsList.isNotEmpty) {
          final nextPage = (_currentNewsIndex + 1) % newsList.length;
          _newsPageController.animateToPage(
            nextPage,
            duration: const Duration(milliseconds: 800),
            curve: Curves.easeInOutCubic,
          );
        }
      });
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    try {
      await DeviceInfoPlugin().androidInfo;
    } catch (e) {
      print('Device info error: $e');
    }
    _connectToWebSocket();
  }

  Future<void> _connectToWebSocket() async {
    try {
      final baseUrl = await _apiService.getBaseUrl();
      final uri = Uri.parse(baseUrl);
      final host = uri.host;
      final wsUrl = 'wss://$host';
      
      channel = WebSocketChannel.connect(Uri.parse(wsUrl));
      channel?.sink.add(jsonEncode({
        "type": "validate",
        "key": sessionKey,
      }));
      channel?.sink.add(jsonEncode({"type": "stats"}));

      channel?.stream.listen((event) {
        final data = jsonDecode(event);
        if (data['type'] == 'myInfo' && data['valid'] == false) {
          _handleInvalidSession("Session invalid, please re-login.");
        }
        if (data['type'] == 'stats') {
          if (mounted) {
            setState(() {
              onlineUsers = data['online'] ?? 0;
              activeConnections = data['connections'] ?? 0;
            });
          }
        }
      }, onError: (error) {
        print('WebSocket error: $error');
      });
    } catch (e) {
      print('Failed to connect WebSocket: $e');
    }
  }

  void _handleInvalidSession(String message) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: cardDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: neonMagenta, width: 1.5),
        ),
        title: Row(
          children: [
            Icon(Icons.warning_rounded, color: neonMagenta),
            const SizedBox(width: 10),
            Text("Session Expired", style: TextStyle(color: neonMagenta)),
          ],
        ),
        content: Text(message, style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
            child: Text("OK", style: TextStyle(color: neonCyan)),
          ),
        ],
      ),
    );
  }

  void _onBottomNavTapped(int index) {
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) {
        _selectedPage = _buildEnhancedNewsPage();
      } else if (index == 1) {
        _showWhatsAppMenu();
      } else if (index == 2) {
        _selectedPage = ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos);
      } else if (index == 3) {
        _selectedPage = const HomeAnimePage();
      }
    });
  }

  void _showWhatsAppMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildWhatsAppMenuSheet(),
    );
  }

  Widget _buildWhatsAppMenuSheet() {
    return Container(
      decoration: BoxDecoration(
        color: baseDark,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(30),
          topRight: Radius.circular(30),
        ),
        border: Border(
          top: BorderSide(color: neonCyan, width: 2),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            margin: const EdgeInsets.only(top: 12),
            width: 50,
            height: 5,
            decoration: BoxDecoration(
              color: neonCyan,
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          const SizedBox(height: 20),
          ShaderMask(
            shaderCallback: (bounds) => LinearGradient(
              colors: [neonCyan, neonPurple, neonMagenta],
            ).createShader(bounds),
            child: const Text(
              "WhatsApp Tools",
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            "Pilih fitur WhatsApp yang ingin digunakan",
            style: TextStyle(color: Colors.white54, fontSize: 14),
          ),
          const SizedBox(height: 20),
          _buildWhatsAppMenuItem(
            icon: Icons.bug_report,
            title: "Bug Sender",
            subtitle: "Kirim pesan bug ke nomor target",
            color: neonCyan,
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => BugSenderPage(
                    sessionKey: sessionKey,
                    username: username,
                    role: role,
                  ),
                ),
              );
            },
          ),
          const Divider(color: Colors.white24, height: 1),
          _buildWhatsAppMenuItem(
            icon: FontAwesomeIcons.whatsapp,
            title: "Bug WhatsApp",
            subtitle: "Fitur WhatsApp lainnya",
            color: neonMagenta,
            onTap: () {
              Navigator.pop(context);
              setState(() {
                _selectedPage = HomePage(
                  username: username,
                  password: password,
                  listBug: listBug,
                  role: role,
                  expiredDate: expiredDate,
                  sessionKey: sessionKey,
                );
              });
            },
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildWhatsAppMenuItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(color: neonCyan.withOpacity(0.3)),
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: cardDark,
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: neonCyan, width: 1.5),
              ),
              child: Icon(icon, color: neonCyan, size: 28),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: const TextStyle(color: Colors.white54, fontSize: 12),
                  ),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios, color: neonCyan, size: 20),
          ],
        ),
      ),
    );
  }

  // ==================== FUNGSI NAVIGASI ====================
  
  void _navigateToAdminPage() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => AdminPage(sessionKey: sessionKey),
      ),
    );
  }

  void _navigateToSellerPage() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => SellerPage(keyToken: sessionKey),
      ),
    );
  }

  void _navigateToOwnerPage() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => OwnerPage(
          sessionKey: sessionKey,
          username: username,
        ),
      ),
    );
  }

  void _navigateToModeratorPage() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ModeratorPage(
          sessionKey: sessionKey,
          username: username,
        ),
      ),
    );
  }

  void _navigateToPartnerPage() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PartnerPage(
          sessionKey: sessionKey,
          username: username,
        ),
      ),
    );
  }

  void _navigateToTkPage() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TkPage(
          sessionKey: sessionKey,
          username: username,
        ),
      ),
    );
  }

  void _navigateToThanksToPage() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const ThanksToPage()),
    );
  }

  void _navigateToMusicPage() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const MusicPage()),
    );
  }
  
  void _navigateJadwalSholat() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const JadwalSholat()),
    );
  }
  
  void _navigateToTestFunctionPage() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const TestFunctionPage()),
    );
  }

  void _navigateToGameArea() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const GameAreaPage()),
    );
  }

  void _navigateToPublicChat() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CommunityPage(
          username: username,
          role: role,
        ),
      ),
    );
  }

  // ==================== END FUNGSI NAVIGASI ====================

  Widget _buildVideoBackground() {
    if (_isVideoInitialized && _videoController.value.isInitialized) {
      return SizedBox.expand(
        child: FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: _videoController.value.size.width,
            height: _videoController.value.size.height,
            child: VideoPlayer(_videoController),
          ),
        ),
      );
    }
    return Container(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          colors: [baseDark, deepBlack],
          center: Alignment.center,
          radius: 1.5,
        ),
      ),
    );
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case "owner": return neonYellow;
      case "moderator": return neonMagenta;
      case "pt": return neonPurple;
      case "tk": return neonCyan;
      case "partner": return const Color(0xFF00BFA5);
      case "reseller": return const Color(0xFF4CAF50);
      default: return neonCyan;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: _buildDrawer(),
      backgroundColor: baseDark,
      extendBody: true,
      appBar: _buildAppBar(),
      body: FadeTransition(opacity: _animation, child: _selectedPage),
      bottomNavigationBar: _buildGlassBottomNavBar(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: false,
      title: Stack(
        alignment: Alignment.centerLeft,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Container(
              height: 40,
              width: 140,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: neonCyan, width: 1),
              ),
              child: _isAppBarVideoInitialized && _appBarVideoController.value.isInitialized
                  ? VideoPlayer(_appBarVideoController)
                  : Container(
                      color: Colors.black.withOpacity(0.5),
                      child: const Center(
                        child: SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: neonCyan,
                          ),
                        ),
                      ),
                    ),
            ),
          ),
          const Padding(
            padding: EdgeInsets.only(left: 20),
            child: Text(
              "Tr4nsFlow",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 22,
                color: Colors.white,
                shadows: [
                  Shadow(
                    color: Colors.black54,
                    blurRadius: 5,
                    offset: Offset(1, 1),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: Icon(Icons.notifications, color: neonCyan),
          onPressed: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text("No new notifications"), backgroundColor: neonCyan),
            );
          },
        ),
        IconButton(
          icon: const Icon(Icons.logout, color: Colors.white),
          onPressed: () => _showLogoutDialog(),
        ),
      ],
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: neonMagenta, width: 1.5),
        ),
        title: const Text("Logout", style: TextStyle(color: Colors.white)),
        content: const Text("Are you sure you want to logout?", style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel", style: TextStyle(color: neonCyan)),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              if (!mounted) return;
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
            child: Text("Logout", style: TextStyle(color: neonMagenta)),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawer() {
    final String userRole = role.toLowerCase();
    
    return Drawer(
      backgroundColor: baseDark,
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: cardDark,
              border: Border(
                bottom: BorderSide(color: neonCyan, width: 2),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: neonCyan, width: 2),
                      ),
                      child: ClipOval(
                        child: Image.asset(
                          'assets/images/logo.jpg',
                          width: 60,
                          height: 60,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return Container(
                              width: 60,
                              height: 60,
                              color: baseDark,
                              child: Icon(Icons.person, color: neonCyan, size: 40),
                            );
                          },
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            username,
                            style: TextStyle(
                              color: primaryWhite,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: baseDark,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: neonCyan, width: 1),
                            ),
                            child: Text(
                              role.toUpperCase(),
                              style: TextStyle(
                                color: neonCyan,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: baseDark,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: neonCyan.withOpacity(0.5), width: 1),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.devices, color: neonCyan, size: 16),
                      const SizedBox(width: 8),
                      Text(
                        "Sessions id : ",
                        style: TextStyle(color: accentGrey, fontSize: 12),
                      ),
                      Expanded(
                        child: Text(
                          sessionKey.length > 20 ? "${sessionKey.substring(0, 20)}..." : sessionKey,
                          style: TextStyle(color: primaryWhite, fontSize: 12),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: baseDark,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: neonCyan.withOpacity(0.5), width: 1),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.calendar_today, color: neonCyan, size: 16),
                      const SizedBox(width: 8),
                      Text(
                        "Account Exp : ",
                        style: TextStyle(color: accentGrey, fontSize: 12),
                      ),
                      Text(
                        expiredDate,
                        style: TextStyle(color: primaryWhite, fontSize: 12),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: baseDark,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: neonCyan.withOpacity(0.5), width: 1),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildMenuText(Icons.vpn_key, "Key Sessions"),
                      const SizedBox(height: 6),
                      _buildMenuText(Icons.explore, "Expedition"),
                      const SizedBox(height: 6),
                      _buildMenuText(Icons.security, "Safety"),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: ListView(
              children: [
                if (userRole == "owner" || userRole == "admin" || userRole == "pemilikan")
                  _buildDrawerTile(
                    icon: Icons.admin_panel_settings,
                    title: 'Admin Page',
                    onTap: () {
                      Navigator.pop(context);
                      _navigateToAdminPage();
                    },
                  ),
                if (userRole == "owner" || userRole == "dev" || userRole == "pemilikan")
                  _buildDrawerTile(
                    icon: Icons.verified_user,
                    title: 'Owner Page',
                    onTap: () {
                      Navigator.pop(context);
                      _navigateToOwnerPage();
                    },
                  ),
                if (userRole == "moderator" || userRole == "admin" || userRole == "pemilikan")
                  _buildDrawerTile(
                    icon: Icons.shield,
                    title: 'Moderator Page',
                    onTap: () {
                      Navigator.pop(context);
                      _navigateToModeratorPage();
                    },
                  ),
                if (userRole == "reseller" || userRole == "owner" || userRole == "pemilikan")
                  _buildDrawerTile(
                    icon: Icons.store,
                    title: 'Seller Page',
                    onTap: () {
                      Navigator.pop(context);
                      _navigateToSellerPage();
                    },
                  ),
                if (userRole == "partner" || userRole == "pt" || userRole == "owner" || userRole == "pemilikan")
                  _buildDrawerTile(
                    icon: Icons.handshake,
                    title: 'Partner Page',
                    onTap: () {
                      Navigator.pop(context);
                      _navigateToPartnerPage();
                    },
                  ),
                if (userRole == "tk" || userRole == "owner" || userRole == "pemilikan")
                  _buildDrawerTile(
                    icon: Icons.assignment_ind,
                    title: 'TK Page',
                    onTap: () {
                      Navigator.pop(context);
                      _navigateToTkPage();
                    },
                  ),
                _buildDrawerTile(
                  icon: Icons.lock_clock,
                  title: 'Change Password',
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ChangePasswordPage(username: username, sessionKey: sessionKey),
                      ),
                    );
                  },
                ),
                _buildDrawerTile(
                  icon: Icons.person,
                  title: 'NIK Check',
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const NikCheckerPage()),
                    );
                  },
                ),
                _buildDrawerTile(
                  icon: Icons.Jadwal_Sholat,
                  title: '🕌 Jadwal Sholat',
                  onTap: () {
                    Navigator.pop(context);
                   _navigateToJadwalSholat();
                  },
                ),
                _buildDrawerTile(
                  icon: Icons.music_note,
                  title: '🎵 Spotify Music',
                  onTap: () {
                    Navigator.pop(context);
                    _navigateToMusicPage();
                  },
                ),
                _buildDrawerTile(
                  icon: Icons.Testfunction,
                  title: '🛠️ TestFunction',
                  onTap: () {
                    Navigator.pop(context);
                   _navigateToTestFunctionPage();
                  },
                ),
                _buildDrawerTile(
                  icon: Icons.games,
                  title: '🎮 Game Area',
                  onTap: () {
                    Navigator.pop(context);
                    _navigateToGameArea();
                  },
                ),
                _buildDrawerTile(
                  icon: Icons.chat,
                  title: 'Public Chat',
                  onTap: () {
                    Navigator.pop(context);
                    _navigateToPublicChat();
                  },
                ),
                _buildDrawerTile(
                  icon: Icons.favorite,
                  title: '🙏 Thanks To',
                  onTap: () {
                    Navigator.pop(context);
                    _navigateToThanksToPage();
                  },
                ),
                const Divider(color: neonCyan, height: 1),
                _buildDrawerTile(
                  icon: Icons.logout,
                  title: 'Logout',
                  onTap: _showLogoutDialog,
                  danger: true,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMenuText(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, color: neonCyan, size: 14),
        const SizedBox(width: 8),
        Text(
          text,
          style: TextStyle(color: primaryWhite, fontSize: 12),
        ),
      ],
    );
  }

  Widget _buildDrawerTile({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    bool danger = false,
  }) {
    return ListTile(
      leading: Icon(icon, color: danger ? neonMagenta : neonCyan, size: 22),
      title: Text(
        title,
        style: TextStyle(
          color: danger ? neonMagenta : primaryWhite,
          fontSize: 14,
        ),
      ),
      trailing: danger
          ? null
          : Icon(Icons.arrow_forward_ios_rounded, color: neonCyan.withOpacity(0.5), size: 14),
      onTap: onTap,
    );
  }

  Widget _buildGlassBottomNavBar() {
    return Container(
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: neonCyan, width: 1.5),
        boxShadow: [
          BoxShadow(color: neonCyan.withOpacity(0.2), blurRadius: 10),
          BoxShadow(color: neonMagenta.withOpacity(0.1), blurRadius: 5),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: BottomNavigationBar(
          backgroundColor: cardDark,
          selectedItemColor: neonCyan,
          unselectedItemColor: Colors.white54,
          currentIndex: _bottomNavIndex,
          onTap: _onBottomNavTapped,
          elevation: 0,
          type: BottomNavigationBarType.fixed,
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: "Home"),
            BottomNavigationBarItem(icon: Icon(FontAwesomeIcons.whatsapp), label: "WhatsApp"),
            BottomNavigationBarItem(icon: Icon(Icons.build_circle_outlined), label: "Tools"),
            BottomNavigationBarItem(icon: Icon(Icons.movie_filter_outlined), label: "Anime"),
          ],
        ),
      ),
    );
  }

  Widget _buildEnhancedNewsPage() {
    return Container(
      color: baseDark,
      child: Stack(
        children: [
          _buildVideoBackground(),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.black.withOpacity(0.5),
                  Colors.transparent,
                  Colors.black.withOpacity(0.3),
                  neonCyan.withOpacity(0.1),
                  neonMagenta.withOpacity(0.05),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                stops: const [0.0, 0.3, 0.7, 0.9, 1.0],
              ),
            ),
          ),
          SingleChildScrollView(
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
            child: Column(
              children: [
                _buildHeaderCard(),
                const SizedBox(height: 20),
                if (newsList.isNotEmpty) _buildNewsCarousel(),
                if (newsList.isNotEmpty) const SizedBox(height: 20),
                _buildAccountInfoCard(),
                const SizedBox(height: 20),
                _buildContactSection(),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: neonCyan, width: 1.5),
        boxShadow: [
          BoxShadow(color: neonCyan.withOpacity(0.2), blurRadius: 15),
          BoxShadow(color: neonMagenta.withOpacity(0.1), blurRadius: 10),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(2),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: neonCyan, width: 2),
                ),
                child: ClipOval(
                  child: Image.asset(
                    'assets/images/logo.jpg',
                    width: 70,
                    height: 70,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        width: 70,
                        height: 70,
                        color: baseDark,
                        child: Icon(Icons.person, color: neonCyan, size: 50),
                      );
                    },
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      username,
                      style: TextStyle(
                        color: primaryWhite,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [neonCyan.withOpacity(0.2), neonMagenta.withOpacity(0.1)],
                        ),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: neonCyan, width: 1),
                      ),
                      child: Text(
                        role.toUpperCase(),
                        style: TextStyle(
                          color: neonCyan,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  _buildStatChip(Icons.people, "$onlineUsers", "Online"),
                  const SizedBox(height: 4),
                  _buildStatChip(Icons.link, "$activeConnections", "Connections"),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: baseDark,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: neonCyan.withOpacity(0.5), width: 1),
            ),
            child: Row(
              children: [
                Icon(Icons.devices, color: neonCyan, size: 18),
                const SizedBox(width: 10),
                Text(
                  "Sessions id : ",
                  style: TextStyle(color: accentGrey, fontSize: 13),
                ),
                Expanded(
                  child: Text(
                    sessionKey,
                    style: TextStyle(color: primaryWhite, fontSize: 13),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: baseDark,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: neonCyan.withOpacity(0.5), width: 1),
            ),
            child: Row(
              children: [
                Icon(Icons.calendar_today, color: neonCyan, size: 18),
                const SizedBox(width: 10),
                Text(
                  "Account Exp : ",
                  style: TextStyle(color: accentGrey, fontSize: 13),
                ),
                Text(
                  expiredDate,
                  style: TextStyle(color: primaryWhite, fontSize: 13),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: baseDark,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: neonCyan.withOpacity(0.5), width: 1),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildHeaderMenuItem(Icons.vpn_key, "Key Sessions"),
                Container(width: 1, height: 30, color: neonCyan.withOpacity(0.3)),
                _buildHeaderMenuItem(Icons.explore, "Expedition"),
                Container(width: 1, height: 30, color: neonCyan.withOpacity(0.3)),
                _buildHeaderMenuItem(Icons.security, "Safety"),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderMenuItem(IconData icon, String label) {
    return Column(
      children: [
        Icon(icon, color: neonCyan, size: 22),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(color: primaryWhite, fontSize: 10),
        ),
      ],
    );
  }

  Widget _buildStatChip(IconData icon, String value, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: baseDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: neonCyan.withOpacity(0.5), width: 0.5),
      ),
      child: Row(
        children: [
          Icon(icon, color: neonCyan, size: 14),
          const SizedBox(width: 4),
          Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          Text(" $label", style: const TextStyle(color: Colors.white70, fontSize: 10)),
        ],
      ),
    );
  }

  Widget _buildNewsCarousel() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(Icons.newspaper, color: neonCyan, size: 22),
            const SizedBox(width: 8),
            const Text("Latest News",
                style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
          ],
        ),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: AspectRatio(
            aspectRatio: 16 / 9,
            child: PageView.builder(
              controller: _newsPageController,
              onPageChanged: (index) {
                setState(() {
                  _currentNewsIndex = index;
                });
              },
              itemCount: newsList.length,
              itemBuilder: (context, i) {
                final item = newsList[i];
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 0),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: cardDark,
                    border: Border.all(color: neonCyan.withOpacity(0.5), width: 1),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.5),
                        blurRadius: 20,
                        offset: const Offset(0, 5),
                      )
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        if (item['image'] != null) NewsMedia(url: item['image']),
                        Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.black.withOpacity(0.7),
                                Colors.transparent,
                                Colors.black.withOpacity(0.5),
                                neonCyan.withOpacity(0.1),
                              ],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              stops: const [0.0, 0.3, 0.7, 1.0],
                            ),
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          left: 0,
                          right: 0,
                          child: Container(
                            padding: const EdgeInsets.all(20),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  item['title'] ?? 'No Title',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    shadows: [
                                      const Shadow(
                                        color: Colors.black,
                                        blurRadius: 5,
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  item['desc'] ?? '',
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: Colors.white70,
                                    fontSize: 12,
                                    shadows: [
                                      const Shadow(
                                        color: Colors.black,
                                        blurRadius: 3,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildAccountInfoCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: neonCyan.withOpacity(0.5), width: 1.5),
        color: cardDark,
        boxShadow: [
          BoxShadow(
            color: neonCyan.withOpacity(0.15),
            blurRadius: 15,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(Icons.person_outline, "ACCOUNT INFO"),
          const SizedBox(height: 16),
          _buildInfoRow(Icons.person, "Username", username),
          const SizedBox(height: 12),
          _buildInfoRow(Icons.verified_user, "Role", role.toUpperCase(), valueColor: _getRoleColor(role)),
          const SizedBox(height: 12),
          _buildInfoRow(Icons.calendar_today, "Expired", expiredDate),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(IconData icon, String title) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [neonCyan.withOpacity(0.2), neonMagenta.withOpacity(0.1)],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: neonCyan, width: 1),
        boxShadow: [
          BoxShadow(
            color: neonCyan.withOpacity(0.2),
            blurRadius: 8,
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: neonCyan, size: 18),
          const SizedBox(width: 8),
          Text(title,
              style: TextStyle(color: neonCyan, fontSize: 14, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value, {Color valueColor = Colors.white}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: baseDark,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: neonCyan.withOpacity(0.3), width: 0.5),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: cardDark,
              shape: BoxShape.circle,
              border: Border.all(color: neonCyan, width: 1),
            ),
            child: Icon(icon, color: neonCyan, size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: TextStyle(color: accentGrey, fontSize: 11)),
                Text(value, 
                  style: TextStyle(
                    color: valueColor, 
                    fontSize: 14, 
                    fontWeight: FontWeight.bold,
                    shadows: [
                      const Shadow(
                        color: Colors.black,
                        blurRadius: 2,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContactSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: neonCyan.withOpacity(0.5), width: 1.5),
        color: cardDark,
        boxShadow: [
          BoxShadow(
            color: neonCyan.withOpacity(0.15),
            blurRadius: 15,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(Icons.contact_support, "CONTACT US"),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildContactButton(FontAwesomeIcons.telegram, "Telegram", 'https://t.me/Emakloewe'),
              _buildContactButton(FontAwesomeIcons.telegram, "Channel", 'https://t.me/testiYuziz'),
              _buildContactButton(FontAwesomeIcons.tiktok, "TikTok", 'https://www.tiktok.com/@YuziStr'),
              _buildContactButton(Icons.favorite, "Thanks To", '', isThanksTo: true),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildContactButton(IconData icon, String label, String url, {bool isThanksTo = false}) {
    if (isThanksTo) {
      return GestureDetector(
        onTap: _navigateToThanksToPage,
        child: Column(
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [neonCyan.withOpacity(0.2), neonMagenta.withOpacity(0.1)],
                ),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: neonCyan, width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: neonCyan.withOpacity(0.3),
                    blurRadius: 12,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Icon(icon, color: neonCyan, size: 28),
            ),
            const SizedBox(height: 8),
            Text(label, 
              style: TextStyle(
                color: Colors.white70, 
                fontSize: 12,
                shadows: [
                  const Shadow(
                    color: Colors.black,
                    blurRadius: 2,
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }
    
    return GestureDetector(
      onTap: () async {
        final uri = Uri.parse(url);
        if (await canLaunchUrl(uri)) await launchUrl(uri);
      },
      child: Column(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [neonCyan.withOpacity(0.2), neonMagenta.withOpacity(0.1)],
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: neonCyan, width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: neonCyan.withOpacity(0.3),
                  blurRadius: 12,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Icon(icon, color: neonCyan, size: 28),
          ),
          const SizedBox(height: 8),
          Text(label, 
            style: TextStyle(
              color: Colors.white70, 
              fontSize: 12,
              shadows: [
                const Shadow(
                  color: Colors.black,
                  blurRadius: 2,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _videoController.dispose();
    _appBarVideoController.dispose();
    channel?.sink.close(status.goingAway);
    _controller.dispose();
    _newsPageController.dispose();
    _autoSlideTimer?.cancel();
    super.dispose();
  }
}

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) {
            setState(() {});
            _controller?.setLooping(true);
            _controller?.setVolume(0.0);
            _controller?.play();
          }
        }).catchError((e) {
          print('Error loading video: $e');
        });
    }
  }

  bool _isVideo(String url) =>
      url.endsWith(".mp4") || url.endsWith(".webm") || url.endsWith(".mov") || url.endsWith(".mkv");

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      }
      return const Center(child: CircularProgressIndicator(color: neonCyan));
    }
    return Image.network(widget.url, fit: BoxFit.cover, errorBuilder: (context, error, stackTrace) {
      return Container(color: Colors.grey.shade800, child: const Icon(Icons.broken_image, color: neonCyan));
    });
  }
}