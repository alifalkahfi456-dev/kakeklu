// manage_server.dart - DEATH X-FLOID EDITION 💀🔥
// Dark theme dengan Neon Cyan + Magenta
// Modified by TANZ AI V8 for Professor KenzMD

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'services/api_config_service.dart';

// ============ WARNA NEON DEATH X-FLOID ============
const Color neonCyan = Color(0xFF00E5FF);
const Color neonMagenta = Color(0xFFFF1744);
const Color neonPurple = Color(0xFF9C4DCC);
const Color deepBlack = Color(0xFF070B12);
const Color cardDark = Color(0xFF0F0F1A);
const Color darkPurple = Color(0xFF1A1A2E);
const Color glassCyan = Color(0xFF00E5FF);

class ManageServerPage extends StatefulWidget {
  final String keyToken;
  const ManageServerPage({super.key, required this.keyToken});

  @override
  State<ManageServerPage> createState() => _ManageServerPageState();
}

class _ManageServerPageState extends State<ManageServerPage> {
  List<Map<String, dynamic>> vpsList = [];
  bool isLoading = false;

  final _hostController = TextEditingController();
  final _userController = TextEditingController();
  final _passController = TextEditingController();

  // Warna NEON
  final Color primaryNeon = neonCyan;
  final Color darkNeon = const Color(0xFF0088AA);
  final Color accentNeon = neonPurple;
  final Color lightNeon = const Color(0xFF66FFFF);
  final Color neonRed = neonMagenta;

  final ApiConfigService _apiService = ApiConfigService();

  @override
  void initState() {
    super.initState();
    _fetchVpsList();
  }

  Future<void> _fetchVpsList() async {
    setState(() => isLoading = true);
    final baseUrl = await _apiService.getBaseUrl();
    final uri = Uri.parse('$baseUrl/myServer?key=${widget.keyToken}');
    try {
      final res = await http.get(uri);
      final data = jsonDecode(res.body);
      setState(() {
        vpsList = List<Map<String, dynamic>>.from(data);
      });
    } catch (_) {
      _showError("Gagal mengambil data VPS.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _addVps() async {
    final host = _hostController.text.trim();
    final user = _userController.text.trim();
    final pass = _passController.text.trim();

    if (host.isEmpty || user.isEmpty || pass.isEmpty) {
      _showError("Isi semua field terlebih dahulu.");
      return;
    }

    final baseUrl = await _apiService.getBaseUrl();
    final uri = Uri.parse('$baseUrl/addServer');
    try {
      final res = await http.post(uri, body: {
        'key': widget.keyToken,
        'host': host,
        'username': user,
        'password': pass,
      });
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _hostController.clear();
        _userController.clear();
        _passController.clear();
        _fetchVpsList();
      } else {
        _showError(data['error'] ?? 'Gagal menambah VPS');
      }
    } catch (_) {
      _showError("Gagal terhubung ke server.");
    }
  }

  Future<void> _deleteVps(String host) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: neonMagenta.withOpacity(0.5)),
        ),
        title: Row(
          children: [
            Icon(Icons.warning, color: neonMagenta),
            const SizedBox(width: 8),
            Text("Konfirmasi Hapus", style: TextStyle(color: neonMagenta)),
          ],
        ),
        content: Text("Yakin ingin menghapus VPS $host?", style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text("BATAL", style: TextStyle(color: neonCyan)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text("HAPUS", style: TextStyle(color: neonMagenta)),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    final baseUrl = await _apiService.getBaseUrl();
    final uri = Uri.parse('$baseUrl/delServer');
    try {
      final res = await http.post(uri, body: {
        'key': widget.keyToken,
        'host': host,
      });
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _fetchVpsList();
      } else {
        _showError("Gagal menghapus VPS.");
      }
    } catch (_) {
      _showError("Gagal menghubungi server.");
    }
  }

  void _showError(String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: neonMagenta.withOpacity(0.5)),
        ),
        title: Row(
          children: [
            Icon(Icons.error, color: neonMagenta),
            const SizedBox(width: 8),
            Text("Error", style: TextStyle(color: neonMagenta)),
          ],
        ),
        content: Text(msg, style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: neonCyan)),
          ),
        ],
      ),
    );
  }

  void _showAddDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: neonCyan.withOpacity(0.5)),
        ),
        title: Row(
          children: [
            Icon(Icons.add_circle, color: neonCyan),
            const SizedBox(width: 8),
            Text("Tambah VPS", style: TextStyle(color: neonCyan, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildInput("IP VPS", _hostController, Icons.dns),
            const SizedBox(height: 12),
            _buildInput("Username", _userController, Icons.person),
            const SizedBox(height: 12),
            _buildInput("Password", _passController, Icons.lock, obscureText: true),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("BATAL", style: TextStyle(color: neonMagenta)),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [neonCyan, neonPurple]),
              borderRadius: BorderRadius.circular(12),
            ),
            child: TextButton(
              onPressed: () {
                Navigator.pop(context);
                _addVps();
              },
              style: TextButton.styleFrom(
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              ),
              child: const Text("TAMBAH", style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInput(String label, TextEditingController controller, IconData icon, {bool obscureText = false}) {
    return TextField(
      controller: controller,
      obscureText: obscureText,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.white70),
        prefixIcon: Icon(icon, color: neonCyan),
        filled: true,
        fillColor: darkPurple,
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: neonCyan.withOpacity(0.3)),
          borderRadius: BorderRadius.circular(12),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: neonCyan, width: 2),
          borderRadius: BorderRadius.circular(12),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: deepBlack,
      appBar: AppBar(
        title: ShaderMask(
          shaderCallback: (bounds) => LinearGradient(
            colors: [neonCyan, neonPurple],
          ).createShader(bounds),
          child: const Text(
            "Manage VPS Server",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.white,
              letterSpacing: 1,
            ),
          ),
        ),
        backgroundColor: cardDark,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 8),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [neonCyan, neonPurple]),
              borderRadius: BorderRadius.circular(12),
            ),
            child: IconButton(
              icon: const Icon(Icons.add, color: Colors.white),
              onPressed: _showAddDialog,
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [neonCyan, neonPurple, neonMagenta],
              ),
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: darkPurple,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: neonCyan.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  Icon(Icons.storage, color: neonCyan, size: 20),
                  const SizedBox(width: 8),
                  Text(
                    "My VPS List",
                    style: TextStyle(
                      fontSize: 16,
                      color: neonCyan,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    "${vpsList.length} Server",
                    style: TextStyle(
                      color: neonCyan.withOpacity(0.7),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: isLoading
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircularProgressIndicator(color: neonCyan),
                          const SizedBox(height: 16),
                          Text(
                            "Loading VPS data...",
                            style: TextStyle(color: neonCyan.withOpacity(0.7)),
                          ),
                        ],
                      ),
                    )
                  : vpsList.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.dns, color: neonCyan.withOpacity(0.5), size: 64),
                              const SizedBox(height: 16),
                              Text(
                                "No VPS Found",
                                style: TextStyle(
                                  color: neonCyan,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                "Tap + button to add VPS",
                                style: TextStyle(color: Colors.white54),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          itemCount: vpsList.length,
                          itemBuilder: (context, index) {
                            final vps = vpsList[index];
                            return Container(
                              margin: const EdgeInsets.only(bottom: 12),
                              decoration: BoxDecoration(
                                color: cardDark,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: neonCyan.withOpacity(0.2)),
                                boxShadow: [
                                  BoxShadow(
                                    color: neonCyan.withOpacity(0.08),
                                    blurRadius: 8,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: ListTile(
                                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                leading: Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [neonCyan.withOpacity(0.2), neonPurple.withOpacity(0.1)],
                                    ),
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(color: neonCyan.withOpacity(0.4)),
                                  ),
                                  child: Icon(Icons.dns, color: neonCyan, size: 24),
                                ),
                                title: Text(
                                  vps['host'],
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                subtitle: Text(
                                  "User: ${vps['username']}",
                                  style: TextStyle(
                                    color: neonCyan.withOpacity(0.7),
                                    fontSize: 12,
                                  ),
                                ),
                                trailing: Container(
                                  decoration: BoxDecoration(
                                    color: neonMagenta.withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(color: neonMagenta.withOpacity(0.3)),
                                  ),
                                  child: IconButton(
                                    icon: Icon(Icons.delete, color: neonMagenta, size: 20),
                                    onPressed: () => _deleteVps(vps['host']),
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _hostController.dispose();
    _userController.dispose();
    _passController.dispose();
    super.dispose();
  }
}