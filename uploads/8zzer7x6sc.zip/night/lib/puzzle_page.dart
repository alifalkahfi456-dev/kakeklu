// puzzle_page.dart - DEATH X-FLOID EDITION 💀🔥
// Dark theme dengan Neon Cyan + Magenta
// Modified by TANZ AI V8 for Professor KenzMD

import 'dart:math';
import 'package:flutter/material.dart';

// ============ WARNA NEON DEATH X-FLOID ============
const Color neonCyan = Color(0xFF00E5FF);
const Color neonMagenta = Color(0xFFFF1744);
const Color neonPurple = Color(0xFF9C4DCC);
const Color deepBlack = Color(0xFF070B12);
const Color darkPurple = Color(0xFF1A1A2E);
const Color cardDark = Color(0xFF0F0F1A);

class PuzzlePage extends StatefulWidget {
  const PuzzlePage({super.key});

  @override
  State<PuzzlePage> createState() => _PuzzlePageState();
}

class _PuzzlePageState extends State<PuzzlePage> with SingleTickerProviderStateMixin {
  List<int> tiles = List.generate(9, (i) => i);
  late AnimationController _winController;
  late Animation<double> _winAnimation;

  @override
  void initState() {
    super.initState();
    shuffle();
    _winController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _winAnimation = CurvedAnimation(parent: _winController, curve: Curves.elasticOut);
  }

  void shuffle() {
    setState(() {
      tiles.shuffle(Random());
    });
    if (isWin()) {
      _winController.reset();
    }
  }

  void move(int index) {
    int emptyIndex = tiles.indexOf(0);

    if ((index - emptyIndex).abs() == 1 ||
        (index - emptyIndex).abs() == 3) {
      setState(() {
        tiles[emptyIndex] = tiles[index];
        tiles[index] = 0;
      });
      
      if (isWin()) {
        _winController.forward();
      }
    }
  }

  bool isWin() {
    for (int i = 0; i < 8; i++) {
      if (tiles[i] != i + 1) return false;
    }
    return true;
  }

  @override
  void dispose() {
    _winController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool win = isWin();
    
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [deepBlack, darkPurple],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              /// TITLE
              ShaderMask(
                shaderCallback: (bounds) => LinearGradient(
                  colors: [neonCyan, neonPurple, neonMagenta],
                ).createShader(bounds),
                child: const Text(
                  "PUZZLE GAME",
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    letterSpacing: 3,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Container(
                width: 100,
                height: 3,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [neonCyan, neonPurple, neonMagenta],
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 20),

              /// WIN TEXT dengan animasi
              AnimatedBuilder(
                animation: _winAnimation,
                builder: (context, child) {
                  return Transform.scale(
                    scale: win ? _winAnimation.value : 1.0,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [neonCyan.withOpacity(0.2), neonPurple.withOpacity(0.1)],
                        ),
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(color: neonCyan.withOpacity(0.4), width: 1.5),
                        boxShadow: win ? [
                          BoxShadow(
                            color: neonCyan.withOpacity(0.4),
                            blurRadius: 20,
                            spreadRadius: 2,
                          ),
                          BoxShadow(
                            color: neonMagenta.withOpacity(0.2),
                            blurRadius: 15,
                            spreadRadius: 1,
                          ),
                        ] : [],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.emoji_events, color: neonCyan, size: 28),
                          const SizedBox(width: 12),
                          Text(
                            "YOU WIN! 🏆",
                            style: TextStyle(
                              fontSize: 20,
                              color: neonCyan,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
              
              const SizedBox(height: 30),

              /// BOARD
              SizedBox(
                width: 340,
                height: 340,
                child: GridView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: 9,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                  ),
                  itemBuilder: (context, index) {
                    final isZero = tiles[index] == 0;
                    final bool isInPlace = !isZero && tiles[index] == index + 1;
                    
                    return GestureDetector(
                      onTap: () => move(index),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        margin: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          gradient: isZero
                              ? null
                              : LinearGradient(
                                  colors: isInPlace
                                      ? [neonCyan.withOpacity(0.3), neonPurple.withOpacity(0.2)]
                                      : [cardDark, darkPurple],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                          color: isZero ? Colors.transparent : null,
                          borderRadius: BorderRadius.circular(16),
                          border: isZero
                              ? null
                              : Border.all(
                                  color: isInPlace 
                                      ? neonCyan.withOpacity(0.5) 
                                      : neonCyan.withOpacity(0.2),
                                  width: isInPlace ? 2 : 1,
                                ),
                          boxShadow: isZero
                              ? []
                              : [
                                  BoxShadow(
                                    color: isInPlace
                                        ? neonCyan.withOpacity(0.3)
                                        : Colors.black.withOpacity(0.3),
                                    blurRadius: 8,
                                    offset: const Offset(0, 3),
                                  ),
                                ],
                        ),
                        child: Center(
                          child: Text(
                            isZero ? "" : tiles[index].toString(),
                            style: TextStyle(
                              fontSize: 38,
                              fontWeight: FontWeight.bold,
                              color: isInPlace ? neonCyan : Colors.white,
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),

              const SizedBox(height: 40),

              /// SHUFFLE BUTTON dengan gradient
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [neonCyan, neonPurple],
                  ),
                  borderRadius: BorderRadius.circular(40),
                  boxShadow: [
                    BoxShadow(
                      color: neonCyan.withOpacity(0.3),
                      blurRadius: 15,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: ElevatedButton(
                  onPressed: () {
                    shuffle();
                    setState(() {});
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    shadowColor: Colors.transparent,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(40),
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.shuffle_rounded, size: 22),
                      const SizedBox(width: 12),
                      const Text(
                        "SHUFFLE",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              
              const SizedBox(height: 20),
              
              /// INFO TEXT
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: cardDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: neonCyan.withOpacity(0.2)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.lightbulb_outline, color: neonCyan, size: 14),
                    const SizedBox(width: 8),
                    Text(
                      "Tap tile to move it to empty space",
                      style: TextStyle(
                        color: Colors.white54,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}