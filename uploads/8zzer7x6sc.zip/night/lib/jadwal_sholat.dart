import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class JadwalSholat extends StatefulWidget {
  @override
  _JadwalSholatState createState() => _JadwalSholatState();
}

class _JadwalSholatState extends State<JadwalSholat> {
  Map<String, dynamic> prayerTimes = {};
  bool isLoading = true;
  String errorMessage = '';
  DateTime currentTime = DateTime.now();
  String currentDate = '';
  String nextPrayer = '';
  Duration timeLeft = Duration.zero;

  // Kota yang sudah di-set: Jakarta
  final String city = 'Jakarta';
  final String country = 'indonesia';

  @override
  void initState() {
    super.initState();
    fetchPrayerTimes();
    _updateTime();
  }

  void _updateTime() {
    Future.delayed(Duration(seconds: 1), () {
      if (mounted) {
        setState(() {
          currentTime = DateTime.now();
          _calculateNextPrayer();
        });
        _updateTime();
      }
    });
  }

  void _calculateNextPrayer() {
    if (prayerTimes.isEmpty) return;

    final now = DateFormat('HH:mm').format(currentTime);
    final prayers = [
      {'name': 'Imsak', 'time': prayerTimes['Imsak'] ?? '04:30'},
      {'name': 'Subuh', 'time': prayerTimes['Fajr'] ?? '04:45'},
      {'name': 'Dzuhur', 'time': prayerTimes['Dhuhr'] ?? '12:00'},
      {'name': 'Ashar', 'time': prayerTimes['Asr'] ?? '15:30'},
      {'name': 'Maghrib', 'time': prayerTimes['Maghrib'] ?? '18:00'},
      {'name': 'Isya', 'time': prayerTimes['Isha'] ?? '19:15'},
    ];

    String next = '';
    Duration minDiff = Duration(hours: 24);

    for (var prayer in prayers) {
      final prayerTime = DateFormat('HH:mm').parse(prayer['time']);
      final nowTime = DateFormat('HH:mm').parse(now);
      
      var diff = prayerTime.difference(nowTime);
      if (diff.isNegative) {
        diff = Duration(hours: 24) + diff;
      }
      
      if (diff < minDiff) {
        minDiff = diff;
        next = prayer['name'];
      }
    }

    setState(() {
      nextPrayer = next;
      timeLeft = minDiff;
    });
  }

  Future<void> fetchPrayerTimes() async {
    setState(() {
      isLoading = true;
      errorMessage = '';
    });

    try {
      final response = await http.get(
        Uri.parse('https://api.aladhan.com/v1/timingsByCity?city=$city&country=$country&method=2'),
      );
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          prayerTimes = data['data']['timings'];
          currentDate = '${data['data']['date']['gregorian']['date']} | ${data['data']['date']['hijri']['date']}';
          isLoading = false;
          _calculateNextPrayer();
        });
      } else {
        throw Exception('Gagal memuat jadwal sholat');
      }
    } catch (e) {
      setState(() {
        errorMessage = 'Error: ${e.toString()}';
        isLoading = false;
        // Data dummy jika API error
        prayerTimes = {
          'Imsak': '04:30',
          'Fajr': '04:45',
          'Sunrise': '06:00',
          'Dhuhr': '12:00',
          'Asr': '15:30',
          'Maghrib': '18:00',
          'Isha': '19:15',
        };
        currentDate = DateTime.now().toString().split(' ')[0];
        _calculateNextPrayer();
      });
    }
  }

  String _formatTimeLeft() {
    if (timeLeft.inHours > 0) {
      return '${timeLeft.inHours} jam ${timeLeft.inMinutes.remainder(60)} menit';
    } else if (timeLeft.inMinutes > 0) {
      return '${timeLeft.inMinutes} menit ${timeLeft.inSeconds.remainder(60)} detik';
    } else {
      return '${timeLeft.inSeconds} detik';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF0A0E27),
      appBar: AppBar(
        title: Text(
          'Jadwal Sholat • $city',
          style: TextStyle(
            color: Color(0xFFFFFFFF),
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Color(0xFF0A0E27),
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF0A0E27), Color(0xFF1A1F3A)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh, color: Color(0xFFF44336)),
            onPressed: fetchPrayerTimes,
          ),
        ],
      ),
      body: CustomPaint(
        painter: GridPainter(),
        child: SingleChildScrollView(
          padding: EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildGlassCard(
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              DateFormat('EEEE', 'id').format(currentTime),
                              style: TextStyle(
                                color: Color(0xFF94A3B8),
                                fontSize: 14,
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              DateFormat('dd MMMM yyyy').format(currentTime),
                              style: TextStyle(
                                color: Color(0xFFFFFFFF),
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: Color(0xFFF44336).withOpacity(0.2),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: Color(0xFFF44336).withOpacity(0.5),
                            ),
                          ),
                          child: Text(
                            DateFormat('HH : mm : ss').format(currentTime),
                            style: TextStyle(
                              color: Color(0xFFF44336),
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 16),
                    Divider(color: Color(0xFFF44336).withOpacity(0.2)),
                    SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildNextPrayerInfo(),
                      ],
                    ),
                  ],
                ),
              ),
              
              SizedBox(height: 20),
              
              _buildGlassCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.access_time, color: Color(0xFFF44336), size: 20),
                        SizedBox(width: 8),
                        Text(
                          'Waktu Sholat Hari Ini',
                          style: TextStyle(
                            color: Color(0xFFFFFFFF),
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 16),
                    if (isLoading)
                      Center(
                        child: CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFF44336)),
                        ),
                      )
                    else ...[
                      _buildPrayerRow('Imsak', prayerTimes['Imsak'] ?? '-', Icons.nightlight_round),
                      _buildPrayerRow('Subuh', prayerTimes['Fajr'] ?? '-', Icons.wb_twilight),
                      _buildPrayerRow('Terbit', prayerTimes['Sunrise'] ?? '-', Icons.wb_sunny),
                      _buildPrayerRow('Dzuhur', prayerTimes['Dhuhr'] ?? '-', Icons.wb_sunny),
                      _buildPrayerRow('Ashar', prayerTimes['Asr'] ?? '-', Icons.wb_twilight),
                      _buildPrayerRow('Maghrib', prayerTimes['Maghrib'] ?? '-', Icons.nightlight_round),
                      _buildPrayerRow('Isya', prayerTimes['Isha'] ?? '-', Icons.bedtime),
                    ],
                  ],
                ),
              ),
              
              SizedBox(height: 20),
              
              _buildGlassCard(
                child: Column(
                  children: [
                    _buildFeature(
                      Icons.location_city,
                      'Lokasi',
                      '$city, $country',
                    ),
                    Divider(
                      color: Color(0xFFF44336).withOpacity(0.2),
                      height: 1,
                    ),
                    _buildFeature(
                      Icons.calendar_today,
                      'Metode',
                      'Kemenag RI (Syafii)',
                    ),
                    Divider(
                      color: Color(0xFFF44336).withOpacity(0.2),
                      height: 1,
                    ),
                    _buildFeature(
                      Icons.info,
                      'Info',
                      'Data dari API Aladhan',
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNextPrayerInfo() {
    return Column(
      children: [
        Text(
          'Menuju Waktu',
          style: TextStyle(
            color: Color(0xFF94A3B8),
            fontSize: 12,
          ),
        ),
        SizedBox(height: 8),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: Color(0xFFF44336),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            nextPrayer.isEmpty ? '-' : nextPrayer,
            style: TextStyle(
              color: Color(0xFFFFFFFF),
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
        ),
        SizedBox(height: 8),
        Text(
          _formatTimeLeft(),
          style: TextStyle(
            color: Color(0xFFEF5350),
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildPrayerRow(String name, String time, IconData icon) {
    bool isNext = name == nextPrayer;
    
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(
        color: isNext ? Color(0xFFF44336).withOpacity(0.15) : Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isNext ? Color(0xFFF44336) : Color(0xFFF44336).withOpacity(0.2),
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Color(0x1AFFFFFF),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: Color(0xFFF44336), size: 20),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Text(
              name,
              style: TextStyle(
                color: isNext ? Color(0xFFF44336) : Color(0xFFFFFFFF),
                fontSize: 16,
                fontWeight: isNext ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ),
          Text(
            time,
            style: TextStyle(
              color: Color(0xFFFFFFFF),
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGlassCard({required Widget child}) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0x1AFFFFFF), Color(0x0DFFFFFF)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Color(0xFFF44336).withOpacity(0.3),
        ),
      ),
      padding: EdgeInsets.all(20),
      child: child,
    );
  }

  Widget _buildFeature(IconData icon, String title, String subtitle) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Color(0xFFF44336).withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: Color(0xFFF44336), size: 24),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Color(0xFFFFFFFF),
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  subtitle,
                  style: TextStyle(color: Color(0xFF94A3B8), fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Helper untuk format tanggal
class DateFormat {
  static String format(DateTime date, String pattern) {
    if (pattern == 'HH:mm:ss') {
      return '${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}:${date.second.toString().padLeft(2, '0')}';
    }
    if (pattern == 'HH:mm') {
      return '${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
    }
    if (pattern == 'dd MMMM yyyy') {
      final months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Ags', 'Sep', 'Okt', 'Nov', 'Des'];
      return '${date.day} ${months[date.month - 1]} ${date.year}';
    }
    if (pattern == 'EEEE') {
      final days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
      return days[date.weekday % 7];
    }
    return date.toString();
  }

  static DateTime parse(String time) {
    final parts = time.split(':');
    return DateTime(2000, 1, 1, int.parse(parts[0]), int.parse(parts[1]));
  }
}

class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paintWhite = Paint()
      ..color = Colors.white.withOpacity(0.02)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;

    final paintRed = Paint()
      ..color = Color(0xFFF44336).withOpacity(0.05)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;

    const double spacing = 40;

    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paintWhite);
      if (x % (spacing * 2) == 0) {
        canvas.drawLine(Offset(x, 0), Offset(x, size.height), paintRed);
      }
    }

    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paintWhite);
      if (y % (spacing * 2) == 0) {
        canvas.drawLine(Offset(0, y), Offset(size.width, y), paintRed);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}