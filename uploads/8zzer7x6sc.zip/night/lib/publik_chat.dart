// publik_chat.dart - DEATH X-FLOID EDITION 💀🔥
// Dark theme dengan Neon Cyan + Magenta
// Modified by TANZ AI V8 for Professor KenzMD

import '../services/api_config_service.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';

// ============ WARNA NEON DEATH X-FLOID ============
const Color neonCyan = Color(0xFF00E5FF);
const Color neonMagenta = Color(0xFFFF1744);
const Color neonPurple = Color(0xFF9C4DCC);
const Color deepBlack = Color(0xFF070B12);
const Color cardDark = Color(0xFF0F0F1A);
const Color darkPurple = Color(0xFF1A1A2E);
const Color neonYellow = Color(0xFFFFE600);

class ChatMessage {
  final String id;
  final String userId;
  final String username;
  final String role;
  final String? message;
  final String timestamp;
  final bool isDeleted;

  ChatMessage({
    required this.id,
    required this.userId,
    required this.username,
    required this.role,
    this.message,
    required this.timestamp,
    required this.isDeleted,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> json) {
    return ChatMessage(
      id: json['id']?.toString() ?? DateTime.now().millisecondsSinceEpoch.toString(),
      userId: json['userId']?.toString() ?? '',
      username: json['username']?.toString() ?? 'Unknown',
      role: json['role']?.toString() ?? 'Member',
      message: json['message']?.toString(),
      timestamp: json['timestamp']?.toString() ?? DateTime.now().toIso8601String(),
      isDeleted: json['isDeleted'] ?? false,
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'username': username,
      'role': role,
      'message': message,
      'timestamp': timestamp,
      'isDeleted': isDeleted,
    };
  }
}

class CommunityPage extends StatefulWidget {
  final String username;
  final String role;

  const CommunityPage({super.key, required this.username, required this.role});

  @override
  State<CommunityPage> createState() => _CommunityPageState();
}

class _CommunityPageState extends State<CommunityPage> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final FocusNode _focusNode = FocusNode();
  
  // === WARNA NEON ===
  final Color bgDark = deepBlack;
  final Color bgCard = cardDark;
  final Color primaryColor = neonCyan;
  final Color accentColor = neonPurple;
  final Color textGrey = const Color(0xFF9E9E9E);
  final Color borderGlass = neonCyan.withOpacity(0.15);
  
  List<ChatMessage> _messages = [];
  bool _isLoading = true;
  bool _isSending = false;
  Timer? _refreshTimer;
  bool _showScrollButton = false;
  
  late String _baseUrl;
  bool _isInitialized = false;
  
  int _retryCount = 0;
  bool _hasError = false;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _initializeService();
  }

  Future<void> _initializeService() async {
    try {
      final apiConfig = ApiConfigService();
      _baseUrl = await apiConfig.getBaseUrl();
      
      print('✅ Base URL loaded: $_baseUrl');
      
      setState(() {
        _isInitialized = true;
        _hasError = false;
      });
      
      await _testConnection();
      await _loadMessages();
      _startAutoRefresh();
      _scrollController.addListener(_scrollListener);
      
    } catch (e) {
      print('❌ Error initializing: $e');
      setState(() {
        _isLoading = false;
        _hasError = true;
        _errorMessage = 'Failed to connect to server: $e';
      });
    }
  }
  
  Future<bool> _testConnection() async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/chat/messages'),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 5));
      
      print('✅ Connection test: ${response.statusCode}');
      return response.statusCode == 200;
    } catch (e) {
      print('❌ Connection test failed: $e');
      return false;
    }
  }

  void _scrollListener() {
    if (_scrollController.hasClients) {
      final isAtBottom = _scrollController.position.pixels >=
          _scrollController.position.maxScrollExtent - 100;
      if (mounted) {
        setState(() {
          _showScrollButton = !isAtBottom;
        });
      }
    }
  }

  void _startAutoRefresh() {
    _refreshTimer?.cancel();
    _refreshTimer = Timer.periodic(const Duration(seconds: 3), (timer) {
      if (_isInitialized && mounted) {
        _loadMessages();
      }
    });
  }

  Future<void> _loadMessages() async {
    if (!_isInitialized || _baseUrl.isEmpty) return;
    
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/chat/messages'),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        
        if (mounted) {
          setState(() {
            _messages = data.map((msg) => ChatMessage.fromJson(msg)).toList();
            _isLoading = false;
            _hasError = false;
          });
          
          if (_scrollController.hasClients && _messages.isNotEmpty) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (_scrollController.position.pixels >= 
                  _scrollController.position.maxScrollExtent - 200) {
                _scrollToBottom();
              }
            });
          }
        }
      } else if (response.statusCode == 404) {
        print('⚠️ Chat endpoint not found, initializing...');
        await _initializeChatRoom();
      } else {
        print('❌ Load messages failed: ${response.statusCode}');
        if (mounted) {
          setState(() {
            _hasError = true;
            _errorMessage = 'Server error: ${response.statusCode}';
          });
        }
      }
    } catch (e) {
      print('❌ Error loading messages: $e');
      if (mounted && _messages.isEmpty) {
        setState(() {
          _isLoading = false;
          _hasError = true;
          _errorMessage = 'Failed to load messages: $e';
        });
      }
    }
  }
  
  Future<void> _initializeChatRoom() async {
    try {
      final initResponse = await http.post(
        Uri.parse('$_baseUrl/chat/init'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'roomId': 'public_chat',
          'createdBy': widget.username,
        }),
      ).timeout(const Duration(seconds: 5));
      
      if (initResponse.statusCode == 200 || initResponse.statusCode == 201) {
        print('✅ Chat room initialized');
        await _loadMessages();
      }
    } catch (e) {
      print('❌ Failed to initialize chat room: $e');
    }
  }

  Future<void> _sendMessage() async {
    final message = _messageController.text.trim();
    if (message.isEmpty || _isSending || !_isInitialized) return;

    setState(() {
      _isSending = true;
    });

    try {
      final messageData = {
        'userId': widget.username,
        'username': widget.username,
        'role': widget.role,
        'message': message,
        'timestamp': DateTime.now().toIso8601String(),
        'roomId': 'public_chat',
      };

      final response = await http.post(
        Uri.parse('$_baseUrl/chat/send'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(messageData),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200 || response.statusCode == 201) {
        _messageController.clear();
        await _loadMessages();
        
        WidgetsBinding.instance.addPostFrameCallback((_) {
          _scrollToBottom();
        });
        
      } else {
        throw Exception('Failed to send message: ${response.statusCode}');
      }
    } catch (e) {
      print('❌ Error sending message: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to send message: $e'),
            backgroundColor: neonMagenta,
            duration: const Duration(seconds: 3),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isSending = false;
        });
      }
    }
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients && _scrollController.position.maxScrollExtent > 0) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  String _formatTime(String timestamp) {
    try {
      final date = DateTime.parse(timestamp);
      final now = DateTime.now();
      final difference = now.difference(date);
      
      if (difference.inDays > 0) {
        return '${difference.inDays}d ago';
      } else if (difference.inHours > 0) {
        return '${difference.inHours}h ago';
      } else if (difference.inMinutes > 0) {
        return '${difference.inMinutes}m ago';
      } else {
        return 'Just now';
      }
    } catch (e) {
      try {
        final date = DateTime.parse(timestamp);
        return '${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
      } catch (_) {
        return timestamp;
      }
    }
  }

  Widget _buildRoleBadge(String role) {
    Color color;
    switch (role.toLowerCase()) {
      case 'owner':
        color = neonYellow;
        break;
      case 'admin':
        color = neonPurple;
        break;
      case 'reseller':
        color = const Color(0xFF4CAF50);
        break;
      case 'vip':
        color = neonPurple;
        break;
      case 'moderator':
        color = neonMagenta;
        break;
      default:
        color = textGrey;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color.withOpacity(0.2), color.withOpacity(0.1)],
        ),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.4), width: 1),
      ),
      child: Text(
        role.toUpperCase(),
        style: TextStyle(
          color: color,
          fontSize: 9,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessage message) {
    final isMe = message.userId == widget.username;
    final isDeleted = message.isDeleted;

    if (isDeleted) {
      return Container(
        margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: bgCard,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: borderGlass),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: borderGlass,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.delete_outline, color: Colors.grey, size: 14),
              ),
              const SizedBox(width: 10),
              Text(
                'This message was deleted',
                style: TextStyle(
                  color: textGrey,
                  fontSize: 13,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ),
        ),
      );
    }

    final int currentIndex = _messages.indexOf(message);
    final bool isSameSender = currentIndex > 0 && 
                              _messages[currentIndex - 1].userId == message.userId;

    return Container(
      margin: EdgeInsets.only(
        top: isSameSender ? 2 : 8,
        bottom: 4,
        left: isMe ? 60 : 12,
        right: isMe ? 12 : 60,
      ),
      child: Column(
        crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          if (!isMe && !isSameSender)
            Padding(
              padding: const EdgeInsets.only(left: 4, bottom: 6),
              child: Row(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [neonCyan, neonPurple],
                      ),
                      border: Border.all(color: neonCyan, width: 1.5),
                    ),
                    child: const Icon(Icons.person, color: Colors.white, size: 18),
                  ),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            message.username,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              fontSize: 14,
                            ),
                          ),
                          const SizedBox(width: 6),
                          _buildRoleBadge(message.role),
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        _formatTime(message.timestamp),
                        style: TextStyle(
                          color: textGrey,
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          if (message.message != null && message.message!.isNotEmpty)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: isMe 
                    ? LinearGradient(
                        colors: [neonCyan.withOpacity(0.15), neonPurple.withOpacity(0.1)],
                      )
                    : null,
                color: isMe ? null : bgCard,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: isMe ? neonCyan.withOpacity(0.3) : borderGlass,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  SelectableText(
                    message.message!,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        _formatTime(message.timestamp),
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.5),
                          fontSize: 10,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      if (isMe) ...[
                        const SizedBox(width: 6),
                        Icon(
                          Icons.check_circle_rounded,
                          color: neonCyan.withOpacity(0.6),
                          size: 12,
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    final uniqueUsers = _messages.map((m) => m.userId).toSet().length;
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: bgDark,
        border: Border(
          bottom: BorderSide(
            color: neonCyan.withOpacity(0.2),
            width: 1,
          ),
        ),
      ),
      child: SafeArea(
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [neonCyan, neonPurple],
                ),
                border: Border.all(color: neonCyan, width: 1.5),
              ),
              child: const Icon(Icons.group_rounded, color: Colors.white, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ShaderMask(
                    shaderCallback: (bounds) => LinearGradient(
                      colors: [neonCyan, neonPurple],
                    ).createShader(bounds),
                    child: const Text(
                      'PUBLIC CHAT',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    uniqueUsers > 0 ? '$uniqueUsers active' : 'Be the first to chat!',
                    style: TextStyle(
                      color: neonCyan.withOpacity(0.7),
                      fontSize: 11,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [neonCyan.withOpacity(0.2), neonPurple.withOpacity(0.1)],
                ),
                shape: BoxShape.circle,
                border: Border.all(color: neonCyan.withOpacity(0.3)),
              ),
              child: IconButton(
                icon: Icon(Icons.refresh_rounded, color: neonCyan, size: 20),
                onPressed: _loadMessages,
                padding: const EdgeInsets.all(8),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMessageInput() {
    return Container(
      margin: const EdgeInsets.all(12),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: bgCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: neonCyan.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  color: bgDark,
                  border: Border.all(color: neonCyan.withOpacity(0.2), width: 1),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _messageController,
                        focusNode: _focusNode,
                        style: const TextStyle(color: Colors.white, fontSize: 14),
                        decoration: InputDecoration(
                          hintText: 'Type your message...',
                          hintStyle: TextStyle(color: textGrey, fontSize: 13),
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                        ),
                        onSubmitted: (_) => _sendMessage(),
                        maxLines: 2,
                        minLines: 1,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: _isSending
                          ? Container(
                              padding: const EdgeInsets.all(8),
                              child: SizedBox(
                                width: 22,
                                height: 22,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: neonCyan,
                                ),
                              ),
                            )
                          : Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [neonCyan, neonPurple],
                                ),
                                shape: BoxShape.circle,
                              ),
                              child: IconButton(
                                onPressed: _sendMessage,
                                icon: const Icon(
                                  Icons.send_rounded,
                                  color: Colors.white,
                                  size: 18,
                                ),
                                padding: const EdgeInsets.all(10),
                              ),
                            ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [neonCyan.withOpacity(0.2), neonPurple.withOpacity(0.1)],
              ),
              border: Border.all(color: neonCyan.withOpacity(0.3)),
            ),
            child: Icon(
              Icons.chat_bubble_outline_rounded,
              color: neonCyan,
              size: 40,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'No messages yet',
            style: TextStyle(
              color: neonCyan,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Start the conversation, ${widget.username}!',
            style: TextStyle(
              color: textGrey,
              fontSize: 13,
              fontWeight: FontWeight.w400,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 50,
            height: 50,
            child: CircularProgressIndicator(
              strokeWidth: 3,
              color: neonCyan,
              backgroundColor: bgCard,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Loading messages...',
            style: TextStyle(
              color: neonCyan.withOpacity(0.7),
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildErrorState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: bgCard,
              border: Border.all(color: neonMagenta.withOpacity(0.3)),
            ),
            child: Icon(
              Icons.error_outline_rounded,
              color: neonMagenta,
              size: 40,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Connection Error',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _errorMessage,
            style: TextStyle(
              color: textGrey,
              fontSize: 13,
              fontWeight: FontWeight.w400,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [neonCyan, neonPurple]),
              borderRadius: BorderRadius.circular(12),
            ),
            child: ElevatedButton(
              onPressed: () {
                setState(() {
                  _hasError = false;
                  _isLoading = true;
                });
                _initializeService();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text('Retry Connection'),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _scrollController.removeListener(_scrollListener);
    _scrollController.dispose();
    _focusNode.dispose();
    _messageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        backgroundColor: cardDark,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: neonCyan),
          onPressed: () => Navigator.pop(context),
        ),
        title: ShaderMask(
          shaderCallback: (bounds) => LinearGradient(
            colors: [neonCyan, neonPurple],
          ).createShader(bounds),
          child: const Text(
            "Public Chat",
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [neonCyan, neonPurple, neonMagenta],
              ),
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            Expanded(
              child: Stack(
                children: [
                  if (_isLoading)
                    _buildLoadingState()
                  else if (_hasError)
                    _buildErrorState()
                  else if (_messages.isEmpty)
                    _buildEmptyState()
                  else
                    ListView.builder(
                      controller: _scrollController,
                      padding: const EdgeInsets.only(top: 12, bottom: 80),
                      itemCount: _messages.length,
                      itemBuilder: (context, index) {
                        return _buildMessageBubble(_messages[index]);
                      },
                    ),
                  if (_showScrollButton && !_isLoading && _messages.isNotEmpty)
                    Positioned(
                      right: 16,
                      bottom: 80,
                      child: GestureDetector(
                        onTap: _scrollToBottom,
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [neonCyan, neonPurple],
                            ),
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: neonCyan.withOpacity(0.3),
                                blurRadius: 12,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: const Icon(
                            Icons.arrow_downward_rounded,
                            color: Colors.white,
                            size: 20,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            _buildMessageInput(),
          ],
        ),
      ),
    );
  }
}