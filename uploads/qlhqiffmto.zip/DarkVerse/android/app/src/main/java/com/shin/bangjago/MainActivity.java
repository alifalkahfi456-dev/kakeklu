package com.shin.bangjago;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
