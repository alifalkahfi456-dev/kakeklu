module.exports = {
  tokens: "8661538960:AAFxsbrYiUkv1Yhuz_kbE4OvzRpCaKT89vE",  // Masukin Bot token kamu
  owners: "7250235697", // Masukin ID Telegram kamu
  port: "1000", // Masukin Port panel kamu 
  ipvps: "https://ranzhere.danzxnstore.my.id" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};

/* WAJIB BACA !!!
 cari di index.js halaman 1995-1996 di situ masukin bot token sama id tele lu.

 emngnya knpa bang?
 lu buka aja dulu. di sana udah gw kasi penjelasannya
*/