import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// ─── Palette: Biru Modern (sama dengan halaman lain) ─────────────────────────
class _C {
  static const bg         = Color(0xFF0A1929);      // Biru gelap background
  static const surface    = Color(0xFF0F2B40);      // Biru tua surface
  static const card       = Color(0xFF143D5C);      // Biru card
  static const border     = Color(0xFF1A5A8A);      // Biru border
  static const borderLit  = Color(0xFF2B7ABF);      // Biru terang border
  
  static const blueDark   = Color(0xFF0A4D8C);
  static const blueMid    = Color(0xFF1A6FB0);
  static const blueLight  = Color(0xFF2D8FD9);
  static const blueAccent = Color(0xFF4AA5F0);
  
  static const green      = Color(0xFF22C55E);
  static const amber      = Color(0xFFF59E0B);
  static const red        = Color(0xFFEF4444);
  static const purple     = Color(0xFFA78BFA);
  
  static const text       = Color(0xFFF0F8FF);      // Putih kebiruan
  static const textSub    = Color(0xFFB0D4F0);      // Biru muda
  static const textDim    = Color(0xFF5A9BC0);      // Biru redup
  
  static const LinearGradient blueGrad = LinearGradient(
    colors: [Color(0xFF1A6FB0), Color(0xFF0A4D8C), Color(0xFF063A6B)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class ThanksToPage extends StatefulWidget {
  const ThanksToPage({Key? key}) : super(key: key);

  @override
  _ThanksToPageState createState() => _ThanksToPageState();
}

class _ThanksToPageState extends State<ThanksToPage> with SingleTickerProviderStateMixin {
  List<Map<String, dynamic>> thanksToList = [];
  bool isLoading = true;
  bool hasError = false;
  int currentIndex = 0;
  late PageController _pageController;
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: 0.8);
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _scaleAnimation = Tween<double>(begin: 0.95, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeOut,
      ),
    );
    fetchThanksTo();
  }

  @override
  void dispose() {
    _pageController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> fetchThanksTo() async {
    setState(() {
      isLoading = true;
      hasError = false;
    });

    try {
      final response = await http.get(Uri.parse('http://outoorder.jhonaleyhost.web.id:8456/tq'));
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        
        if (data['status'] == true && data['result'] is List) {
          setState(() {
            thanksToList = List<Map<String, dynamic>>.from(data['result']);
            isLoading = false;
          });
          _animationController.forward();
        } else {
          setState(() {
            hasError = true;
            isLoading = false;
          });
        }
      } else {
        setState(() {
          hasError = true;
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        hasError = true;
        isLoading = false;
      });
    }
  }

  Future<void> launchContact(String url) async {
    String formattedUrl = url;
    if (!formattedUrl.startsWith('http')) {
      if (formattedUrl.startsWith('t.me/')) {
        formattedUrl = 'https://$formattedUrl';
      } else {
        formattedUrl = 'https://t.me/$formattedUrl';
      }
    }
    
    if (await canLaunchUrl(Uri.parse(formattedUrl))) {
      await launchUrl(Uri.parse(formattedUrl), mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Cannot open: $formattedUrl'),
          backgroundColor: _C.red,
        ),
      );
    }
  }

  Widget _buildProfileCard(Map<String, dynamic> person, int index) {
    final bool isCenter = index == currentIndex;
    
    return GestureDetector(
      onTap: () {
        _pageController.animateToPage(
          index,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeInOut,
        );
      },
      child: AnimatedBuilder(
        animation: _pageController,
        builder: (context, child) {
          double value = 1.0;
          if (_pageController.position.haveDimensions) {
            value = _pageController.page! - index;
            value = (1 - (value.abs() * 0.3)).clamp(0.0, 1.0);
          }
          
          return Transform.scale(
            scale: isCenter ? 1.0 : 0.9 * value,
            child: Opacity(
              opacity: isCenter ? 1.0 : 0.7,
              child: child,
            ),
          );
        },
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            color: _C.card,
            boxShadow: [
              BoxShadow(
                color: isCenter ? _C.blueMid.withOpacity(0.4) : Colors.black.withOpacity(0.3),
                blurRadius: isCenter ? 25 : 15,
                spreadRadius: isCenter ? 2 : 1,
                offset: const Offset(0, 10),
              ),
            ],
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: isCenter 
                ? [_C.card, _C.surface]
                : [_C.surface, _C.card],
            ),
            border: Border.all(
              color: isCenter ? _C.blueLight.withOpacity(0.5) : _C.border,
              width: isCenter ? 1.5 : 1.0,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 160,
                  height: 160,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: isCenter ? _C.blueLight.withOpacity(0.8) : _C.blueDark.withOpacity(0.5),
                      width: isCenter ? 3 : 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: isCenter ? _C.blueMid.withOpacity(0.3) : _C.blueDark.withOpacity(0.15),
                        blurRadius: 20,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: person['ppUrl'] != null &&
                            person['ppUrl'].toString().isNotEmpty
                        ? CachedNetworkImage(
                            imageUrl: person['ppUrl'].toString(),
                            placeholder: (context, url) => Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [_C.blueDark.withOpacity(0.1), _C.blueMid.withOpacity(0.1)],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                              ),
                              child: Center(
                                child: Icon(
                                  Icons.person,
                                  color: _C.blueLight.withOpacity(0.5),
                                  size: 50,
                                ),
                              ),
                            ),
                            errorWidget: (context, url, error) => Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [_C.blueDark.withOpacity(0.1), _C.blueMid.withOpacity(0.1)],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                              ),
                              child: Center(
                                child: Icon(
                                  Icons.person,
                                  color: _C.blueLight.withOpacity(0.5),
                                  size: 50,
                                ),
                              ),
                            ),
                            fit: BoxFit.cover,
                          )
                        : Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [_C.blueDark.withOpacity(0.1), _C.blueMid.withOpacity(0.1)],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                            ),
                            child: Center(
                              child: Icon(
                                Icons.person,
                                color: _C.blueLight.withOpacity(0.5),
                                size: 50,
                              ),
                            ),
                          ),
                  ),
                ),
                const SizedBox(height: 24),
                Text(
                  person['name']?.toString() ?? 'Unknown',
                  style: TextStyle(
                    color: _C.text,
                    fontSize: isCenter ? 22 : 20,
                    fontWeight: isCenter ? FontWeight.bold : FontWeight.w600,
                    letterSpacing: 0.5,
                  ),
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: _C.blueMid.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: _C.blueMid.withOpacity(0.3)),
                  ),
                  child: Text(
                    person['status']?.toString() ?? 'No Status',
                    style: TextStyle(
                      color: _C.blueLight,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                    textAlign: TextAlign.center,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const SizedBox(height: 20),
                if (person['contac'] != null &&
                    person['contac'].toString().isNotEmpty && isCenter)
                  ElevatedButton(
                    onPressed: () => launchContact(person['contac'].toString()),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _C.blueMid,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 12,
                      ),
                      elevation: 5,
                      shadowColor: _C.blueMid.withOpacity(0.4),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(FontAwesomeIcons.telegram, size: 18),
                        const SizedBox(width: 10),
                        Text(
                          'Contact on Telegram',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildIndicator() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(
        thanksToList.length,
        (index) {
          return AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            width: currentIndex == index ? 20 : 8,
            height: 8,
            margin: const EdgeInsets.symmetric(horizontal: 4),
            decoration: BoxDecoration(
              color: currentIndex == index ? _C.blueLight : _C.textDim.withOpacity(0.3),
              borderRadius: BorderRadius.circular(4),
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: _C.surface,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _C.border),
                      ),
                      child: Icon(
                        Icons.arrow_back_ios_new_rounded,
                        color: _C.textSub,
                        size: 18,
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  ShaderMask(
                    shaderCallback: (bounds) => const LinearGradient(
                      colors: [_C.blueAccent, _C.blueLight],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ).createShader(bounds),
                    child: const Text(
                      "Thanks To",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: isLoading
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation<Color>(_C.blueMid),
                            strokeWidth: 2,
                          ),
                          const SizedBox(height: 16),
                          Text(
                            "Loading Profiles...",
                            style: TextStyle(
                              color: _C.textSub,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                    )
                  : hasError
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                width: 80,
                                height: 80,
                                decoration: BoxDecoration(
                                  color: _C.red.withOpacity(0.1),
                                  shape: BoxShape.circle,
                                  border: Border.all(color: _C.red.withOpacity(0.3)),
                                ),
                                child: Icon(
                                  Icons.error_outline,
                                  color: _C.red,
                                  size: 40,
                                ),
                              ),
                              const SizedBox(height: 20),
                              Text(
                                "Failed to load data",
                                style: TextStyle(
                                  color: _C.text,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                "Please check your connection",
                                style: TextStyle(
                                  color: _C.textDim,
                                  fontSize: 14,
                                ),
                              ),
                              const SizedBox(height: 24),
                              ElevatedButton(
                                onPressed: fetchThanksTo,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: _C.blueMid,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 32,
                                    vertical: 14,
                                  ),
                                ),
                                child: Text(
                                  "Retry",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                      : thanksToList.isEmpty
                          ? Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    width: 120,
                                    height: 120,
                                    decoration: BoxDecoration(
                                      color: _C.surface,
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                        color: _C.border,
                                      ),
                                    ),
                                    child: Icon(
                                      Icons.group,
                                      color: _C.textDim,
                                      size: 50,
                                    ),
                                  ),
                                  const SizedBox(height: 20),
                                  Text(
                                    "No profiles available",
                                    style: TextStyle(
                                      color: _C.textDim,
                                      fontSize: 16,
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : Column(
                              children: [
                                Expanded(
                                  child: AnimatedBuilder(
                                    animation: _animationController,
                                    builder: (context, child) {
                                      return Transform.scale(
                                        scale: _scaleAnimation.value,
                                        child: child,
                                      );
                                    },
                                    child: PageView.builder(
                                      controller: _pageController,
                                      itemCount: thanksToList.length,
                                      onPageChanged: (index) {
                                        setState(() {
                                          currentIndex = index;
                                        });
                                      },
                                      itemBuilder: (context, index) {
                                        return _buildProfileCard(thanksToList[index], index);
                                      },
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 16),
                                _buildIndicator(),
                                const SizedBox(height: 20),
                              ],
                            ),
            ),
          ],
        ),
      ),
    );
  }
}