package com.fixch.zsnz;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
